// ============================================
// CLINICALC - FORMULARIOS CONTINUACIÓN
// Formularios 5-10: Sodio, IMC, BSA, Osm, CHADS, HAS-BLED
// ============================================

// === 5. SODIO CORREGIDO === //
function createCorrectedSodiumForm() {
    const units = Storage.getSettings().units;
    return `
        <form id="correctedSodiumForm" onsubmit="calculateCorrectedSodium(event)">
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Sodio sérico (mEq/L)
                </label>
                <input type="number" id="sodiumNa" required step="any" min="120" max="160" class="form-input">
            </div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Glucosa (${units.glucose})
                </label>
                <input type="number" id="glucose" required step="any" class="form-input">
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular Sodio Corregido
            </button>
        </form>
        <div id="correctedSodiumResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateCorrectedSodium(event) {
    event.preventDefault();
    const inputs = {
        sodium: parseFloat(document.getElementById('sodiumNa').value),
        glucose: parseFloat(document.getElementById('glucose').value)
    };
    const result = Calculators.calculateCorrectedSodium(inputs);
    
    const container = document.getElementById('correctedSodiumResult');
    container.innerHTML = `
        <div class="result-card" style="background: linear-gradient(135deg, var(--brand-accent-dark), var(--brand-accent)); padding: 24px; border-radius: var(--radius-lg); color: var(--brand-primary-dark); margin-bottom: 16px;">
            <div style="font-size: 13px; font-weight: 600; margin-bottom: 8px; opacity: 0.8;">SODIO CORREGIDO</div>
            <div style="font-size: 36px; font-weight: 800; margin-bottom: 4px;">
                ${result.value} <span style="font-size: 20px; font-weight: 600;">${result.unit}</span>
            </div>
            <div style="font-size: 14px; font-weight: 600; margin-bottom: 12px;">
                ${result.interpretation.label}
            </div>
            <div style="background: rgba(30, 56, 114, 0.15); padding: 12px; border-radius: 8px; font-size: 13px;">
                <strong>Fórmula de Katz:</strong> ${result.value} ${result.unit}<br>
                <strong>Fórmula de Hillier:</strong> ${result.hillier} ${result.unit}
            </div>
        </div>
        <div class="interpretation-card" style="background: var(--bg-secondary); padding: 20px; border-radius: var(--radius-lg); border-left: 4px solid var(--${result.interpretation.color});">
            <h4 style="font-size: 14px; font-weight: 700; margin-bottom: 8px;">Interpretación</h4>
            <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.6;">
                ${result.interpretation.description}
            </p>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('correctedSodiumForm').reset(); document.getElementById('correctedSodiumResult').style.display='none';" style="width: 100%; margin-top: 16px;">
            🔄 Nuevo Cálculo
        </button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 5, calculatorName: 'Sodio Corregido', inputs, result, interpretation: result.interpretation });
}

// === 6. IMC === //
function createBMIForm() {
    const units = Storage.getSettings().units;
    return `
        <form id="bmiForm" onsubmit="calculateBMI(event)">
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Peso (${units.weight})
                </label>
                <input type="number" id="weight" required step="any" min="30" max="300" class="form-input">
            </div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Altura (${units.height})
                </label>
                <input type="number" id="height" required step="any" class="form-input">
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular IMC
            </button>
        </form>
        <div id="bmiResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateBMI(event) {
    event.preventDefault();
    const inputs = {
        weight: parseFloat(document.getElementById('weight').value),
        height: parseFloat(document.getElementById('height').value)
    };
    const result = Calculators.calculateBMI(inputs);
    displayGenericResult(result, inputs, 6, 'IMC', null, 'bmiResult');
    Storage.addToHistory({ calculatorId: 6, calculatorName: 'IMC', inputs, result, interpretation: result.interpretation });
}

// === 7. BSA === //
function createBSAForm() {
    const units = Storage.getSettings().units;
    return `
        <form id="bsaForm" onsubmit="calculateBSA(event)">
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">Fórmula</label>
                <select id="bsaFormula" class="form-input">
                    <option value="Mosteller">Mosteller (Recomendada)</option>
                    <option value="DuBois">DuBois</option>
                </select>
            </div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Peso (${units.weight})
                </label>
                <input type="number" id="weightBSA" required step="any" min="30" max="300" class="form-input">
            </div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Altura (${units.height})
                </label>
                <input type="number" id="heightBSA" required step="any" class="form-input">
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular BSA
            </button>
        </form>
        <div id="bsaResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateBSA(event) {
    event.preventDefault();
    const formula = document.getElementById('bsaFormula').value;
    const inputs = {
        weight: parseFloat(document.getElementById('weightBSA').value),
        height: parseFloat(document.getElementById('heightBSA').value)
    };
    const result = Calculators.calculateBSA(inputs, formula);
    displayGenericResult(result, inputs, 7, 'BSA', formula, 'bsaResult');
    Storage.addToHistory({ calculatorId: 7, calculatorName: 'BSA', formula, inputs, result, interpretation: result.interpretation });
}

// === 8. OSMOLARIDAD === //
function createOsmolarityForm() {
    const units = Storage.getSettings().units;
    return `
        <form id="osmolarityForm" onsubmit="calculateOsmolarity(event)">
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Sodio (mEq/L)
                </label>
                <input type="number" id="sodiumOsm" required step="any" class="form-input">
            </div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Glucosa (${units.glucose})
                </label>
                <input type="number" id="glucoseOsm" required step="any" class="form-input">
            </div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    BUN (${units.bun})
                </label>
                <input type="number" id="bunOsm" required step="any" class="form-input">
            </div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Osmolaridad medida (opcional) - mOsm/kg
                </label>
                <input type="number" id="measuredOsm" step="any" class="form-input" placeholder="Dejar vacío si no se midió">
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular Osmolaridad
            </button>
        </form>
        <div id="osmolarityResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateOsmolarity(event) {
    event.preventDefault();
    const measuredInput = document.getElementById('measuredOsm').value;
    const inputs = {
        sodium: parseFloat(document.getElementById('sodiumOsm').value),
        glucose: parseFloat(document.getElementById('glucoseOsm').value),
        bun: parseFloat(document.getElementById('bunOsm').value),
        measuredOsm: measuredInput ? parseFloat(measuredInput) : null
    };
    const result = Calculators.calculateOsmolarity(inputs);
    
    const container = document.getElementById('osmolarityResult');
    container.innerHTML = `
        <div class="result-card" style="background: linear-gradient(135deg, var(--brand-accent-dark), var(--brand-accent)); padding: 24px; border-radius: var(--radius-lg); color: var(--brand-primary-dark); margin-bottom: 16px;">
            <div style="font-size: 13px; font-weight: 600; margin-bottom: 8px; opacity: 0.8;">OSMOLARIDAD CALCULADA</div>
            <div style="font-size: 36px; font-weight: 800; margin-bottom: 4px;">
                ${result.value} <span style="font-size: 20px; font-weight: 600;">${result.unit}</span>
            </div>
            <div style="font-size: 14px; font-weight: 600; margin-bottom: 12px;">
                ${result.interpretation.label}
            </div>
            ${result.osmGap !== null ? `
                <div style="background: rgba(30, 56, 114, 0.15); padding: 12px; border-radius: 8px; font-size: 13px;">
                    <strong>Gap Osmolar:</strong> ${result.osmGap} mOsm/kg
                    ${Math.abs(result.osmGap) > 10 ? '<br><span style="color: #dc2626;">⚠️ Gap >10: considerar tóxicos (metanol, etilenglicol)</span>' : ''}
                </div>
            ` : ''}
        </div>
        <div class="interpretation-card" style="background: var(--bg-secondary); padding: 20px; border-radius: var(--radius-lg); border-left: 4px solid var(--${result.interpretation.color});">
            <h4 style="font-size: 14px; font-weight: 700; margin-bottom: 8px;">Interpretación</h4>
            <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.6;">
                ${result.interpretation.description}
            </p>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('osmolarityForm').reset(); document.getElementById('osmolarityResult').style.display='none';" style="width: 100%; margin-top: 16px;">
            🔄 Nuevo Cálculo
        </button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 8, calculatorName: 'Osmolaridad', inputs, result, interpretation: result.interpretation });
}

// === 9. CHADS2-VASc === //
function createCHADSVAScForm() {
    return `
        <form id="chadsVascForm" onsubmit="calculateCHADSVASc(event)">
            <div style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">Edad (años)</label>
                <input type="number" id="ageCHADS" required min="18" max="120" class="form-input">
            </div>
            <div style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">Sexo</label>
                <select id="sexCHADS" required class="form-input">
                    <option value="M">Masculino</option>
                    <option value="F">Femenino</option>
                </select>
            </div>
            <div style="background: var(--bg-secondary); padding: 16px; border-radius: 12px; margin-bottom: 16px;">
                <p style="font-size: 13px; font-weight: 600; margin-bottom: 12px;">Seleccione factores de riesgo:</p>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="chf" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Insuficiencia Cardíaca (CHF)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="hypertension" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Hipertensión</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="diabetes" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Diabetes</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="stroke" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">ACV/AIT/Embolia previos</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                    <input type="checkbox" id="vascularDisease" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Enfermedad Vascular</span>
                </label>
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular CHADS₂-VASc
            </button>
        </form>
        <div id="chadsVascResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateCHADSVASc(event) {
    event.preventDefault();
    const inputs = {
        age: parseInt(document.getElementById('ageCHADS').value),
        sex: document.getElementById('sexCHADS').value,
        chf: document.getElementById('chf').checked,
        hypertension: document.getElementById('hypertension').checked,
        diabetes: document.getElementById('diabetes').checked,
        stroke: document.getElementById('stroke').checked,
        vascularDisease: document.getElementById('vascularDisease').checked
    };
    const result = Calculators.calculateCHADSVASc(inputs);
    displayGenericResult(result, inputs, 9, 'CHADS₂-VASc', null, 'chadsVascResult');
    Storage.addToHistory({ calculatorId: 9, calculatorName: 'CHADS₂-VASc', inputs, result, interpretation: result.interpretation });
}

// === 10. HAS-BLED === //
function createHASBLEDForm() {
    return `
        <form id="hasBledForm" onsubmit="calculateHASBLED(event)">
            <div style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">Edad (años)</label>
                <input type="number" id="ageHAS" required min="18" max="120" class="form-input">
            </div>
            <div style="background: var(--bg-secondary); padding: 16px; border-radius: 12px; margin-bottom: 16px;">
                <p style="font-size: 13px; font-weight: 600; margin-bottom: 12px;">Seleccione factores de riesgo:</p>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="hypertensionHAS" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Hipertensión no controlada (>160 mmHg)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="abnormalRenal" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Función renal anormal (diálisis, Cr >2.3)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="abnormalLiver" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Función hepática anormal</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="strokeHAS" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">ACV previo</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="bleeding" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Historia de sangrado</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="labileINR" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">INR lábil (si usa warfarina)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="drugs" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Medicación predisponente (AINEs, antiplaquetarios)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                    <input type="checkbox" id="alcohol" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Abuso de alcohol (≥8 bebidas/semana)</span>
                </label>
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular HAS-BLED
            </button>
        </form>
        <div id="hasBledResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateHASBLED(event) {
    event.preventDefault();
    const inputs = {
        age: parseInt(document.getElementById('ageHAS').value),
        hypertension: document.getElementById('hypertensionHAS').checked,
        abnormalRenal: document.getElementById('abnormalRenal').checked,
        abnormalLiver: document.getElementById('abnormalLiver').checked,
        stroke: document.getElementById('strokeHAS').checked,
        bleeding: document.getElementById('bleeding').checked,
        labileINR: document.getElementById('labileINR').checked,
        drugs: document.getElementById('drugs').checked,
        alcohol: document.getElementById('alcohol').checked
    };
    const result = Calculators.calculateHASBLED(inputs);
    displayGenericResult(result, inputs, 10, 'HAS-BLED', null, 'hasBledResult');
    Storage.addToHistory({ calculatorId: 10, calculatorName: 'HAS-BLED', inputs, result, interpretation: result.interpretation });
}

// === 16. SOFA === //
function createSOFAForm() {
    const units = Storage.getSettings().units;
    const crMax = units.creatinine === 'mg/dL' ? 15 : 1326;
    const crLabel = units.creatinine;
    return `
        <form id="sofaForm" onsubmit="calculateSOFA(event)">
            <div class="alert-box" style="background: #fef3c7; border-left: 4px solid #f59e0b; padding: 16px; border-radius: 8px; margin-bottom: 16px;">
                <p style="font-size: 13px; color: #92400e; margin: 0;">
                    <strong>⚠️ Nota:</strong> SOFA Score evalúa disfunción orgánica en UCI. Un incremento ≥2 puntos en contexto infeccioso confirma sepsis (Sepsis-3).
                </p>
            </div>

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.05em;">Respiratorio</div>
            <div class="form-group" style="margin-bottom: 8px;">
                <label style="display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px;">PaO₂/FiO₂ (mmHg)</label>
                <input type="number" id="sofaPaFi" required step="any" min="20" max="600" class="form-input">
            </div>
            <div style="background: var(--bg-secondary); padding: 12px; border-radius: 8px; margin-bottom: 16px;">
                <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                    <input type="checkbox" id="sofaVent" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">En ventilación mecánica (necesario para score 3-4)</span>
                </label>
            </div>

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.05em;">Coagulación</div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px;">Plaquetas (×10³/µL)</label>
                <input type="number" id="sofaPlatelets" required step="any" min="1" max="800" class="form-input">
            </div>

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.05em;">Hepático</div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px;">Bilirrubina (mg/dL)</label>
                <input type="number" id="sofaBilirubin" required step="any" min="0.1" max="50" class="form-input">
            </div>

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.05em;">Cardiovascular</div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px;">Estado hemodinámico</label>
                <select id="sofaCardio" required class="form-input">
                    <option value="0">0 – PAM ≥70 mmHg sin vasopresores</option>
                    <option value="1">1 – PAM &lt;70 mmHg sin vasopresores</option>
                    <option value="2">2 – Dopamina ≤5 µg/kg/min o Dobutamina</option>
                    <option value="3">3 – Dopamina 5-15 µg/kg/min o NE/Epi ≤0.1 µg/kg/min</option>
                    <option value="4">4 – Dopamina &gt;15 µg/kg/min o NE/Epi &gt;0.1 µg/kg/min</option>
                </select>
            </div>

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.05em;">Neurológico</div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px;">Glasgow Coma Scale (GCS)</label>
                <input type="number" id="sofaGCS" required min="3" max="15" class="form-input">
            </div>

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.05em;">Renal</div>
            <div class="form-group" style="margin-bottom: 8px;">
                <label style="display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px;">Creatinina sérica (${crLabel})</label>
                <input type="number" id="sofaCreatinine" required step="any" min="0.1" max="${crMax}" class="form-input">
            </div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px;">Diuresis 24h (mL) <span style="font-weight: 400; color: var(--text-secondary);">— opcional</span></label>
                <input type="number" id="sofaUrine" step="any" min="0" max="10000" class="form-input" placeholder="Dejar vacío si no disponible">
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular SOFA
            </button>
        </form>
        <div id="sofaResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateSOFA(event) {
    event.preventDefault();
    const urineInput = document.getElementById('sofaUrine').value;
    const inputs = {
        pao2fio2: parseFloat(document.getElementById('sofaPaFi').value),
        ventilation: document.getElementById('sofaVent').checked,
        platelets: parseFloat(document.getElementById('sofaPlatelets').value),
        bilirubin: parseFloat(document.getElementById('sofaBilirubin').value),
        cardiovascular: document.getElementById('sofaCardio').value,
        gcs: parseInt(document.getElementById('sofaGCS').value),
        creatinine: parseFloat(document.getElementById('sofaCreatinine').value),
        urineOutput: urineInput ? parseFloat(urineInput) : null
    };
    const result = Calculators.calculateSOFA(inputs);
    const c = result.components;

    const componentRow = (label, score) => {
        const colors = ['#22c55e', '#84cc16', '#f59e0b', '#f97316', '#ef4444'];
        const color = colors[score] || '#ef4444';
        return `<div style="display: flex; justify-content: space-between; align-items: center; padding: 8px 0; border-bottom: 1px solid rgba(255,255,255,0.1);">
            <span style="font-size: 13px;">${label}</span>
            <span style="font-size: 16px; font-weight: 700; background: ${color}22; color: ${color}; padding: 2px 10px; border-radius: 20px;">${score}</span>
        </div>`;
    };

    const container = document.getElementById('sofaResult');
    container.innerHTML = `
        <div class="result-card" style="background: linear-gradient(135deg, var(--brand-accent-dark), var(--brand-accent)); padding: 24px; border-radius: var(--radius-lg); color: var(--brand-primary-dark); margin-bottom: 16px;">
            <div style="font-size: 13px; font-weight: 600; margin-bottom: 8px; opacity: 0.8;">SOFA SCORE TOTAL</div>
            <div style="font-size: 36px; font-weight: 800; margin-bottom: 4px;">
                ${result.value} <span style="font-size: 20px; font-weight: 600;">${result.unit}</span>
            </div>
            <div style="font-size: 14px; font-weight: 600;">${result.interpretation.label}</div>
        </div>
        <div style="background: var(--bg-secondary); padding: 20px; border-radius: var(--radius-lg); margin-bottom: 16px;">
            <h4 style="font-size: 13px; font-weight: 700; margin-bottom: 12px; text-transform: uppercase; letter-spacing: 0.05em;">Puntuación por órgano (0-4)</h4>
            ${componentRow('Respiratorio (PaO₂/FiO₂)', c.resp)}
            ${componentRow('Coagulación (Plaquetas)', c.coag)}
            ${componentRow('Hepático (Bilirrubina)', c.liver)}
            ${componentRow('Cardiovascular', c.cardio)}
            ${componentRow('Neurológico (GCS)', c.neuro)}
            ${componentRow('Renal (Creatinina/Diuresis)', c.renal)}
        </div>
        <div class="interpretation-card" style="background: var(--bg-secondary); padding: 20px; border-radius: var(--radius-lg); border-left: 4px solid var(--${result.interpretation.color});">
            <h4 style="font-size: 14px; font-weight: 700; margin-bottom: 8px;">Interpretación</h4>
            <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.6;">${result.interpretation.description}</p>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('sofaForm').reset(); document.getElementById('sofaResult').style.display='none';" style="width: 100%; margin-top: 16px;">
            🔄 Nuevo Cálculo
        </button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 16, calculatorName: 'SOFA', inputs, result, interpretation: result.interpretation });
}

// === 17. NIHSS === //
const NIHSS_HELP = {
    loc: {
        title: '1a. Nivel de Consciencia',
        content: `
            <p style="font-size:13px;font-weight:700;color:var(--text-primary);margin:0 0 8px;">Pasos de exploración</p>
            <ol style="margin:0 0 14px;padding-left:20px;font-size:13px;color:var(--text-secondary);line-height:1.9;">
                <li>Observe al paciente sin estimulación adicional</li>
                <li>Llame al paciente por su nombre en voz alta</li>
                <li>Si no responde, aplique estímulo táctil suave (toque el hombro)</li>
                <li>Si persiste sin respuesta, aplique estímulo doloroso: presión en esternón o lecho ungueal</li>
                <li>Evalúe la calidad y rapidez de la respuesta</li>
            </ol>
            <div style="background:#7c3aed11;border-left:3px solid #7c3aed;padding:10px 12px;border-radius:0 6px 6px 0;margin-bottom:12px;">
                <p style="font-size:12px;font-weight:700;color:#7c3aed;margin:0 0 4px;">🧠 Paciente con consciencia alterada</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">Use estímulos progresivos: verbal → táctil → nociceptivo. No asuma somnolencia si hay barrera del lenguaje — verifique respuesta a órdenes gestuales. Documente exactamente qué estímulo generó respuesta.</p>
            </div>
            <div style="background:#f59e0b11;border-left:3px solid #f59e0b;padding:10px 12px;border-radius:0 6px 6px 0;">
                <p style="font-size:12px;font-weight:700;color:#f59e0b;margin:0 0 4px;">💡 Perla clínica</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">La intubación orotraqueal NO limita este ítem — evalúe despertar y respuesta motora. Un paciente agitado que "pelea" con el tubo = alerta (puntúa 0).</p>
            </div>`
    },
    locQ: {
        title: '1b. Preguntas de Orientación',
        content: `
            <p style="font-size:13px;font-weight:700;color:var(--text-primary);margin:0 0 8px;">Pasos de exploración</p>
            <ol style="margin:0 0 14px;padding-left:20px;font-size:13px;color:var(--text-secondary);line-height:1.9;">
                <li>Pregunte: <em>"¿En qué mes estamos?"</em></li>
                <li>Pregunte: <em>"¿Cuántos años tiene usted?"</em></li>
                <li>Solo acepte respuestas exactamente correctas — no aproximaciones</li>
                <li>No repita las preguntas ni dé pistas</li>
                <li>No acepte respuestas con ayuda de familiares</li>
            </ol>
            <div style="background:#7c3aed11;border-left:3px solid #7c3aed;padding:10px 12px;border-radius:0 6px 6px 0;margin-bottom:12px;">
                <p style="font-size:12px;font-weight:700;color:#7c3aed;margin:0 0 4px;">🧠 Paciente con consciencia alterada</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">Si el nivel de consciencia impide responder verbalmente, intente comunicación escrita. Afasia severa sin ninguna comunicación posible = puntúe 2. No puntúe 2 solo por disartria si la respuesta intenta ser correcta.</p>
            </div>
            <div style="background:#f59e0b11;border-left:3px solid #f59e0b;padding:10px 12px;border-radius:0 6px 6px 0;">
                <p style="font-size:12px;font-weight:700;color:#f59e0b;margin:0 0 4px;">💡 Perla clínica</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">Autocorrección válida: "tengo… no, 65 años" = correcto. El ítem mide orientación, no velocidad de respuesta. El paciente intubado que puede escribir se evalúa normalmente.</p>
            </div>`
    },
    locC: {
        title: '1c. Órdenes Motoras',
        content: `
            <p style="font-size:13px;font-weight:700;color:var(--text-primary);margin:0 0 8px;">Pasos de exploración</p>
            <ol style="margin:0 0 14px;padding-left:20px;font-size:13px;color:var(--text-secondary);line-height:1.9;">
                <li>Orden 1: <em>"Abra y cierre los ojos"</em></li>
                <li>Orden 2: <em>"Abra y cierre la mano no parética"</em></li>
                <li>Repita cada orden solo una vez</li>
                <li>Evalúe si realiza el esfuerzo aunque no complete la acción</li>
                <li>Alternativa si hay trauma en mano: <em>"Levante la pierna"</em></li>
            </ol>
            <div style="background:#7c3aed11;border-left:3px solid #7c3aed;padding:10px 12px;border-radius:0 6px 6px 0;margin-bottom:12px;">
                <p style="font-size:12px;font-weight:700;color:#7c3aed;margin:0 0 4px;">🧠 Paciente con consciencia alterada</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">En estuporoso: dé la orden en voz muy alta y repita una vez. En coma profundo sin respuesta a estímulos: marque 2 directamente. No se deben realizar gestos demostrativos (si lo imita, puntúe como no realizado).</p>
            </div>
            <div style="background:#f59e0b11;border-left:3px solid #f59e0b;padding:10px 12px;border-radius:0 6px 6px 0;">
                <p style="font-size:12px;font-weight:700;color:#f59e0b;margin:0 0 4px;">💡 Perla clínica</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">El esfuerzo visible cuenta aunque no complete la acción. Un intento fallido = realizó una tarea (puntúa 1). Solo la ausencia total de intento en ambas = 2.</p>
            </div>`
    },
    gaze: {
        title: '2. Mirada Conjugada',
        content: `
            <p style="font-size:13px;font-weight:700;color:var(--text-primary);margin:0 0 8px;">Pasos de exploración</p>
            <ol style="margin:0 0 14px;padding-left:20px;font-size:13px;color:var(--text-secondary);line-height:1.9;">
                <li>Pida al paciente que siga su dedo con la mirada</li>
                <li>Mueva su dedo horizontalmente de lado a lado lentamente</li>
                <li>Observe si ambos ojos se mueven conjugados y alcanzan excursión completa</li>
                <li>Observe si hay desviación tónica de la mirada en reposo</li>
                <li>Evalúe si la paresia puede superarse voluntariamente</li>
            </ol>
            <div style="background:#7c3aed11;border-left:3px solid #7c3aed;padding:10px 12px;border-radius:0 6px 6px 0;margin-bottom:12px;">
                <p style="font-size:12px;font-weight:700;color:#7c3aed;margin:0 0 4px;">🧠 Paciente con consciencia alterada</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">Use la maniobra oculocefálica (ojos de muñeca): gire la cabeza bruscamente hacia un lado — los ojos deben desviarse en sentido contrario si el reflejo es normal. Contraindicado si hay sospecha de trauma cervical.</p>
            </div>
            <div style="background:#f59e0b11;border-left:3px solid #f59e0b;padding:10px 12px;border-radius:0 6px 6px 0;">
                <p style="font-size:12px;font-weight:700;color:#f59e0b;margin:0 0 4px;">💡 Perla clínica</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">Desviación conjugada <strong>hacia</strong> la lesión = hemisférica. Desviación <strong>contraria</strong> a la lesión = tallo cerebral. Paresia que el paciente puede superar = puntúa 1, no 2.</p>
            </div>`
    },
    visual: {
        title: '3. Campos Visuales',
        content: `
            <p style="font-size:13px;font-weight:700;color:var(--text-primary);margin:0 0 8px;">Pasos de exploración</p>
            <ol style="margin:0 0 14px;padding-left:20px;font-size:13px;color:var(--text-secondary);line-height:1.9;">
                <li>Posiciónese frente al paciente a aproximadamente 1 metro</li>
                <li>Pida que mire fijamente a sus ojos durante toda la prueba</li>
                <li>Presente 1-2 dedos simultáneamente en los 4 cuadrantes visuales</li>
                <li>Pregunte: <em>"¿Cuántos dedos ve de cada lado?"</em></li>
                <li>Repita en diferentes cuadrantes para confirmar</li>
            </ol>
            <div style="background:#7c3aed11;border-left:3px solid #7c3aed;padding:10px 12px;border-radius:0 6px 6px 0;margin-bottom:12px;">
                <p style="font-size:12px;font-weight:700;color:#7c3aed;margin:0 0 4px;">🧠 Paciente con consciencia alterada</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">Use la amenaza visual: aproxime su mano bruscamente al ojo del paciente desde cada cuadrante. El parpadeo indica campo visual intacto en esa zona. Ausencia de parpadeo ante amenaza = déficit en ese cuadrante.</p>
            </div>
            <div style="background:#f59e0b11;border-left:3px solid #f59e0b;padding:10px 12px;border-radius:0 6px 6px 0;">
                <p style="font-size:12px;font-weight:700;color:#f59e0b;margin:0 0 4px;">💡 Perla clínica</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">Hemianopsia bilateral (puntúa 3) es rara en ACV; sugiere lesión de corteza visual bilateral o tallo cerebral. Cuadrantanopsia superior = lesión temporal; inferior = lesión parietal.</p>
            </div>`
    },
    facial: {
        title: '4. Parálisis Facial',
        content: `
            <p style="font-size:13px;font-weight:700;color:var(--text-primary);margin:0 0 8px;">Pasos de exploración</p>
            <ol style="margin:0 0 14px;padding-left:20px;font-size:13px;color:var(--text-secondary);line-height:1.9;">
                <li>Observe la simetría facial en reposo</li>
                <li>Pida que muestre los dientes o sonría ampliamente</li>
                <li>Pida que cierre los ojos con fuerza (compare la resistencia al abrirlos)</li>
                <li>Observe asimetría del surco nasogeniano y comisura labial</li>
                <li>Observe si puede elevar ambas cejas simétricamente</li>
            </ol>
            <div style="background:#7c3aed11;border-left:3px solid #7c3aed;padding:10px 12px;border-radius:0 6px 6px 0;margin-bottom:12px;">
                <p style="font-size:12px;font-weight:700;color:#7c3aed;margin:0 0 4px;">🧠 Paciente con consciencia alterada</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">Aplique estímulo doloroso (presión supraorbitaria o lecho ungueal) y observe asimetría en la mueca de dolor. La hemicara que no se contrae al estímulo = lado parético.</p>
            </div>
            <div style="background:#f59e0b11;border-left:3px solid #f59e0b;padding:10px 12px;border-radius:0 6px 6px 0;">
                <p style="font-size:12px;font-weight:700;color:#f59e0b;margin:0 0 4px;">💡 Perla clínica</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;"><strong>Central (ACV):</strong> respeta el tercio superior (puede arrugar el ceño), afecta mitad inferior. <strong>Periférica (Bell):</strong> afecta toda la hemicara — no puede cerrar el ojo (signo de Bell positivo).</p>
            </div>`
    },
    motorArm: {
        title: '5a/5b. Función Motora del Brazo',
        content: `
            <p style="font-size:13px;font-weight:700;color:var(--text-primary);margin:0 0 8px;">Pasos de exploración</p>
            <ol style="margin:0 0 14px;padding-left:20px;font-size:13px;color:var(--text-secondary);line-height:1.9;">
                <li><strong>Sentado:</strong> extienda el brazo a 90° (palma abajo)</li>
                <li><strong>Acostado:</strong> extienda el brazo a 45°</li>
                <li>Pida: <em>"Mantenga el brazo en esta posición por 10 segundos"</em></li>
                <li>Observe si cae antes de 10 segundos y con qué velocidad</li>
                <li>Evalúe ambos brazos por separado — nunca permita apoyo</li>
            </ol>
            <div style="background:#7c3aed11;border-left:3px solid #7c3aed;padding:10px 12px;border-radius:0 6px 6px 0;margin-bottom:12px;">
                <p style="font-size:12px;font-weight:700;color:#7c3aed;margin:0 0 4px;">🧠 Paciente con consciencia alterada</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">Posicione usted el brazo pasivamente en la posición correcta y suéltelo. Observe si mantiene, cae lentamente o cae de inmediato. Cualquier resistencia visible aunque sea mínima = puntúa 3, no 4.</p>
            </div>
            <div style="background:#f59e0b11;border-left:3px solid #f59e0b;padding:10px 12px;border-radius:0 6px 6px 0;">
                <p style="font-size:12px;font-weight:700;color:#f59e0b;margin:0 0 4px;">💡 Perla clínica</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">Amputación o fusión articular = marque 9 (no evaluable) y documente el motivo. El ítem mide fuerza antigravitacional, no motricidad fina. Evalúe siempre ambos lados aunque uno sea normal.</p>
            </div>`
    },
    motorLeg: {
        title: '6a/6b. Función Motora de la Pierna',
        content: `
            <p style="font-size:13px;font-weight:700;color:var(--text-primary);margin:0 0 8px;">Pasos de exploración</p>
            <ol style="margin:0 0 14px;padding-left:20px;font-size:13px;color:var(--text-secondary);line-height:1.9;">
                <li>Paciente en decúbito supino</li>
                <li>Pida: <em>"Levante la pierna a 30° del nivel de la cama"</em></li>
                <li>Tiempo de sostén: <strong>5 segundos</strong> (diferente al brazo)</li>
                <li>Observe si cae antes y con qué velocidad</li>
                <li>Evalúe ambas piernas por separado</li>
            </ol>
            <div style="background:#7c3aed11;border-left:3px solid #7c3aed;padding:10px 12px;border-radius:0 6px 6px 0;margin-bottom:12px;">
                <p style="font-size:12px;font-weight:700;color:#7c3aed;margin:0 0 4px;">🧠 Paciente con consciencia alterada</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">Posicione usted la pierna a 30° y suéltela. Con dolor lumbar: ayude a posicionar y evalúe el esfuerzo de mantención. Mismos criterios que el brazo: esfuerzo mínimo visible = 3, ningún movimiento = 4.</p>
            </div>
            <div style="background:#f59e0b11;border-left:3px solid #f59e0b;padding:10px 12px;border-radius:0 6px 6px 0;">
                <p style="font-size:12px;font-weight:700;color:#f59e0b;margin:0 0 4px;">💡 Perla clínica</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">⚠️ El tiempo es <strong>5 segundos</strong>, no 10 como el brazo. La diferencia entre 3 y 4 es clave: cualquier resistencia mínima = 3; ningún movimiento en absoluto = 4.</p>
            </div>`
    },
    ataxia: {
        title: '7. Ataxia de Extremidades',
        content: `
            <p style="font-size:13px;font-weight:700;color:var(--text-primary);margin:0 0 8px;">Pasos de exploración</p>
            <ol style="margin:0 0 14px;padding-left:20px;font-size:13px;color:var(--text-secondary);line-height:1.9;">
                <li><strong>Índice-nariz:</strong> pida que toque su nariz y luego el dedo del examinador alternadamente (varias veces rápido)</li>
                <li><strong>Talón-rodilla:</strong> pida que deslice el talón de una pierna por la espinilla de la otra</li>
                <li>Observe dismetría (error en distancia) y temblor intencional</li>
                <li>Evalúe ambos lados</li>
                <li>La ataxia debe ser <strong>desproporcionada</strong> a la debilidad presente</li>
            </ol>
            <div style="background:#7c3aed11;border-left:3px solid #7c3aed;padding:10px 12px;border-radius:0 6px 6px 0;margin-bottom:12px;">
                <p style="font-size:12px;font-weight:700;color:#7c3aed;margin:0 0 4px;">🧠 Paciente con consciencia alterada</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">Si la alteración de consciencia impide seguir instrucciones o si hay parálisis que impide el movimiento: puntúe 0 (no se puede evaluar ataxia). No puntúe ataxia en una extremidad pléjica.</p>
            </div>
            <div style="background:#f59e0b11;border-left:3px solid #f59e0b;padding:10px 12px;border-radius:0 6px 6px 0;">
                <p style="font-size:12px;font-weight:700;color:#f59e0b;margin:0 0 4px;">💡 Perla clínica</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">Si el motor del brazo puntúa 3-4, no puede evaluarse ataxia en ese brazo — la paresia explica el déficit. Ataxia verdadera sugiere lesión cerebelosa o de vías espinocerebelosas (ACV de fosa posterior).</p>
            </div>`
    },
    sensory: {
        title: '8. Sensibilidad',
        content: `
            <p style="font-size:13px;font-weight:700;color:var(--text-primary);margin:0 0 8px;">Pasos de exploración</p>
            <ol style="margin:0 0 14px;padding-left:20px;font-size:13px;color:var(--text-secondary);line-height:1.9;">
                <li>Use un objeto punzante (alfiler estéril, punta de lapicero o palillo)</li>
                <li>Toque cara, brazo, tronco y pierna en ambos lados</li>
                <li>Compare lado derecho vs izquierdo</li>
                <li>Pregunte: <em>"¿Siente esto igual en ambos lados?"</em></li>
                <li>Pruebe con ojos cerrados para evitar sesgos visuales</li>
            </ol>
            <div style="background:#7c3aed11;border-left:3px solid #7c3aed;padding:10px 12px;border-radius:0 6px 6px 0;margin-bottom:12px;">
                <p style="font-size:12px;font-weight:700;color:#7c3aed;margin:0 0 4px;">🧠 Paciente con consciencia alterada</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">Aplique estímulo doloroso bilateral (pinchazo en brazo o pierna de cada lado). Observe asimetría en la mueca facial de dolor o en la retirada de la extremidad. Ausencia de reacción unilateral = pérdida severa (puntúa 2).</p>
            </div>
            <div style="background:#f59e0b11;border-left:3px solid #f59e0b;padding:10px 12px;border-radius:0 6px 6px 0;">
                <p style="font-size:12px;font-weight:700;color:#f59e0b;margin:0 0 4px;">💡 Perla clínica</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">Solo puntúe déficit claro que afecte cara + brazo + pierna (hemianestesia). Pérdida aislada de un segmento puede ser previa o artefactual. Paciente afásico grave que no reacciona al dolor = puntúe 2.</p>
            </div>`
    },
    language: {
        title: '9. Mejor Lenguaje (Afasia)',
        content: `
            <p style="font-size:13px;font-weight:700;color:var(--text-primary);margin:0 0 8px;">Pasos de exploración</p>
            <ol style="margin:0 0 14px;padding-left:20px;font-size:13px;color:var(--text-secondary);line-height:1.9;">
                <li><strong>Fluidez:</strong> pida que describa lo que ve en una imagen o su día</li>
                <li><strong>Denominación:</strong> muestre objetos: reloj, lápiz, llave — <em>"¿Qué es esto?"</em></li>
                <li><strong>Comprensión:</strong> órdenes simples y complejas (<em>"Señale el techo, luego la puerta"</em>)</li>
                <li><strong>Lectura:</strong> entregue papel con "Cierre los ojos"</li>
                <li><strong>Repetición:</strong> <em>"Ni sí, ni no, ni pero"</em></li>
            </ol>
            <div style="background:#7c3aed11;border-left:3px solid #7c3aed;padding:10px 12px;border-radius:0 6px 6px 0;margin-bottom:12px;">
                <p style="font-size:12px;font-weight:700;color:#7c3aed;margin:0 0 4px;">🧠 Paciente con consciencia alterada</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">Si no hay respuesta verbal ni intento comunicativo y no sigue órdenes = puntúe 3 (mutismo). No confunda disartria (articulación defectuosa) con afasia (problema del lenguaje en sí). Use comunicación escrita si la disartria impide la expresión oral.</p>
            </div>
            <div style="background:#f59e0b11;border-left:3px solid #f59e0b;padding:10px 12px;border-radius:0 6px 6px 0;">
                <p style="font-size:12px;font-weight:700;color:#f59e0b;margin:0 0 4px;">💡 Perla clínica</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;"><strong>Broca:</strong> comprende, habla telegráfico, se frustra. <strong>Wernicke:</strong> habla fluido e incoherente, no comprende. <strong>Global:</strong> no comprende ni habla. Broca = frontal dominante; Wernicke = temporal dominante.</p>
            </div>`
    },
    dysarthria: {
        title: '10. Disartria',
        content: `
            <p style="font-size:13px;font-weight:700;color:var(--text-primary);margin:0 0 8px;">Pasos de exploración</p>
            <ol style="margin:0 0 14px;padding-left:20px;font-size:13px;color:var(--text-secondary);line-height:1.9;">
                <li>Pida que repita palabras: <em>"Artillería"</em>, <em>"Transmisor"</em>, <em>"Caballero"</em></li>
                <li>Pida que repita frases: <em>"Me gustaría ir de compras mañana"</em></li>
                <li>Observe claridad de articulación, <strong>no el contenido</strong></li>
                <li>Inteligible pero con esfuerzo visible = leve-moderada (puntúa 1)</li>
                <li>Ininteligible o ausencia de producción verbal = severa (puntúa 2)</li>
            </ol>
            <div style="background:#7c3aed11;border-left:3px solid #7c3aed;padding:10px 12px;border-radius:0 6px 6px 0;margin-bottom:12px;">
                <p style="font-size:12px;font-weight:700;color:#7c3aed;margin:0 0 4px;">🧠 Paciente con consciencia alterada</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">Si el nivel de consciencia impide la cooperación: observe si produce vocalizaciones. Vocalización incomprensible que no corresponde a confusión = disartria severa (puntúa 2). Paciente intubado: marque 9 (no evaluable).</p>
            </div>
            <div style="background:#f59e0b11;border-left:3px solid #f59e0b;padding:10px 12px;border-radius:0 6px 6px 0;">
                <p style="font-size:12px;font-weight:700;color:#f59e0b;margin:0 0 4px;">💡 Perla clínica</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;"><strong>Disartria:</strong> problema de la musculatura articulatoria (labios, lengua, paladar). <strong>Afasia:</strong> problema del lenguaje como función cortical. Un paciente afásico puede tener articulación perfectamente normal.</p>
            </div>`
    },
    extinction: {
        title: '11. Extinción e Inatención',
        content: `
            <p style="font-size:13px;font-weight:700;color:var(--text-primary);margin:0 0 8px;">Pasos de exploración</p>
            <ol style="margin:0 0 14px;padding-left:20px;font-size:13px;color:var(--text-secondary);line-height:1.9;">
                <li><strong>Táctil:</strong> toque simultáneamente ambas manos — <em>"¿Dónde lo toqué?"</em></li>
                <li><strong>Visual:</strong> presente dedos simultáneamente en ambos campos visuales</li>
                <li><strong>Auditivo:</strong> chasquee los dedos a ambos lados de la cabeza</li>
                <li>Observe si ignora sistemáticamente estímulos de un lado cuando son bilaterales</li>
                <li>Evalúe si el paciente reconoce su extremidad parética</li>
            </ol>
            <div style="background:#7c3aed11;border-left:3px solid #7c3aed;padding:10px 12px;border-radius:0 6px 6px 0;margin-bottom:12px;">
                <p style="font-size:12px;font-weight:700;color:#7c3aed;margin:0 0 4px;">🧠 Paciente con consciencia alterada</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">Observe si gira los ojos/cabeza hacia estímulos de un solo lado e ignora el otro. Evalúe si interactúa con personas a ambos lados de la cama o solo a uno. La estimulación auditiva (chasquidos) es útil en pacientes con bajo nivel de respuesta.</p>
            </div>
            <div style="background:#f59e0b11;border-left:3px solid #f59e0b;padding:10px 12px;border-radius:0 6px 6px 0;">
                <p style="font-size:12px;font-weight:700;color:#f59e0b;margin:0 0 4px;">💡 Perla clínica</p>
                <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.6;">Heminegligencia sugiere lesión del hemisferio no dominante (derecho en el 90%). Un paciente puede ver cada campo visual perfectamente por separado, pero ignorar el izquierdo en estimulación bilateral simultánea (extinción). Indica peor pronóstico funcional y rehabilitación más compleja.</p>
            </div>`
    }
};

function showNIHSSHelp(key) {
    const h = NIHSS_HELP[key];
    if (!h) return;

    const overlay = document.createElement('div');
    overlay.style.cssText = `position:fixed;inset:0;background:rgba(0,0,0,0.6);
        display:flex;align-items:flex-start;justify-content:center;z-index:10000;
        backdrop-filter:blur(4px);padding:20px;animation:fadeIn 0.2s ease;overflow-y:auto;`;

    overlay.innerHTML = `
        <div style="background:var(--bg-card);border-radius:var(--radius-xl);padding:24px;
                    max-width:520px;width:100%;margin:auto;box-shadow:var(--shadow-xl);
                    animation:scaleIn 0.3s ease;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:16px;">
                <h3 style="font-size:16px;font-weight:700;color:var(--text-primary);margin:0;padding-right:12px;">
                    🔍 ${h.title}
                </h3>
                <button onclick="this.closest('.nihss-help-overlay').remove()"
                        style="background:var(--bg-secondary);border:none;width:32px;height:32px;
                               border-radius:8px;cursor:pointer;font-size:18px;flex-shrink:0;
                               display:flex;align-items:center;justify-content:center;color:var(--text-secondary);">✕</button>
            </div>
            ${h.content}
        </div>`;

    overlay.classList.add('nihss-help-overlay');
    overlay.onclick = e => { if (e.target === overlay) overlay.remove(); };
    document.body.appendChild(overlay);
}

function createNIHSSForm() {
    const select = (id, options) => `
        <select id="${id}" class="form-input" style="margin-bottom: 0;">
            ${options.map((o, i) => `<option value="${i}">${i} – ${o}</option>`).join('')}
        </select>`;

    const item = (label, id, options, helpKey) => `
        <div style="margin-bottom: 14px;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
                <label style="font-weight:600;font-size:13px;color:var(--text-primary);">${label}</label>
                ${helpKey ? `<button type="button" onclick="showNIHSSHelp('${helpKey}')"
                    style="font-size:11px;background:#3b82f611;border:1px solid #3b82f644;color:#3b82f6;
                           padding:3px 10px;border-radius:12px;cursor:pointer;font-weight:600;
                           white-space:nowrap;flex-shrink:0;">
                    🔍 ¿Cómo explorar?
                </button>` : ''}
            </div>
            ${select(id, options)}
        </div>`;

    return `
        <form id="nihssForm" onsubmit="calculateNIHSS(event)">
            <div class="alert-box" style="background: #dbeafe; border-left: 4px solid #3b82f6; padding: 16px; border-radius: 8px; margin-bottom: 16px;">
                <p style="font-size: 13px; color: #1e3a8a; margin: 0;">
                    <strong>ℹ️ Nota:</strong> NIHSS evalúa la severidad del ACV isquémico. Escala validada para guiar decisión de trombolisis y trombectomía mecánica. Pulse <strong>🔍 ¿Cómo explorar?</strong> en cada ítem para ver la guía de exploración neurológica.
                </p>
            </div>

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin-bottom: 10px; text-transform: uppercase; letter-spacing: 0.05em;">Conciencia</div>
            ${item('1a. Nivel de conciencia', 'nihssLOC', ['Alerta', 'Somnoliento (estimulación menor)', 'Estuporoso (estímulo repetido)', 'Coma (sólo reflejos)'], 'loc')}
            ${item('1b. Preguntas de orientación (mes y edad)', 'nihssLOCQ', ['Ambas correctas', 'Una correcta', 'Ninguna / intubado / afásico'], 'locQ')}
            ${item('1c. Órdenes motoras (ojos y mano)', 'nihssLOCC', ['Ambas correctas', 'Una correcta', 'Ninguna'], 'locC')}

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin: 14px 0 10px; text-transform: uppercase; letter-spacing: 0.05em;">Oculomotor y Visual</div>
            ${item('2. Mirada conjugada', 'nihssGaze', ['Normal', 'Paresia parcial (puede ser superada)', 'Desviación forzada o parálisis completa'], 'gaze')}
            ${item('3. Campos visuales', 'nihssVisual', ['Sin pérdida', 'Hemianopsia parcial', 'Hemianopsia completa', 'Ceguera bilateral'], 'visual')}

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin: 14px 0 10px; text-transform: uppercase; letter-spacing: 0.05em;">Motricidad Facial</div>
            ${item('4. Parálisis facial', 'nihssFacial', ['Normal', 'Leve (borramiento surco nasogeniano)', 'Parcial (parálisis inferior)', 'Completa (hemiplejia facial)'], 'facial')}

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin: 14px 0 10px; text-transform: uppercase; letter-spacing: 0.05em;">Motor Extremidades (10 s brazo / 5 s pierna)</div>
            ${item('5a. Motor brazo izquierdo', 'nihssMAL', ['Sin caída (10 s)', 'Caída sin tocar cama', 'Algo contra gravedad', 'Sin movimiento contra gravedad', 'Sin movimiento'], 'motorArm')}
            ${item('5b. Motor brazo derecho', 'nihssMAR', ['Sin caída (10 s)', 'Caída sin tocar cama', 'Algo contra gravedad', 'Sin movimiento contra gravedad', 'Sin movimiento'], 'motorArm')}
            ${item('6a. Motor pierna izquierda', 'nihssMLegL', ['Sin caída (5 s)', 'Caída sin tocar cama', 'Algo contra gravedad', 'Sin movimiento contra gravedad', 'Sin movimiento'], 'motorLeg')}
            ${item('6b. Motor pierna derecha', 'nihssMLegR', ['Sin caída (5 s)', 'Caída sin tocar cama', 'Algo contra gravedad', 'Sin movimiento contra gravedad', 'Sin movimiento'], 'motorLeg')}

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin: 14px 0 10px; text-transform: uppercase; letter-spacing: 0.05em;">Coordinación y Sensibilidad</div>
            ${item('7. Ataxia de extremidades', 'nihssAtaxia', ['Ausente', 'En una extremidad', 'En dos extremidades'], 'ataxia')}
            ${item('8. Sensibilidad', 'nihssSensory', ['Normal', 'Pérdida leve-moderada (siente el pinchazo)', 'Pérdida severa o bilateral (no siente)'], 'sensory')}

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin: 14px 0 10px; text-transform: uppercase; letter-spacing: 0.05em;">Lenguaje y Habla</div>
            ${item('9. Mejor lenguaje', 'nihssLanguage', ['Normal', 'Afasia leve-moderada', 'Afasia severa (comunicación fragmentada)', 'Mutismo / afasia global'], 'language')}
            ${item('10. Disartria', 'nihssDysarthria', ['Normal', 'Leve-moderada (inteligible)', 'Severa (ininteligible) o intubado'], 'dysarthria')}

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin: 14px 0 10px; text-transform: uppercase; letter-spacing: 0.05em;">Inatención</div>
            ${item('11. Extinción e inatención', 'nihssExtinction', ['Normal', 'Inatención en una modalidad', 'Hemineglect severo (>1 modalidad)'], 'extinction')}

            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px; margin-top: 8px;">
                🧮 Calcular NIHSS
            </button>
        </form>
        <div id="nihssResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateNIHSS(event) {
    event.preventDefault();
    const v = id => parseInt(document.getElementById(id).value);
    const inputs = {
        loc: v('nihssLOC'), locQuestions: v('nihssLOCQ'), locCommands: v('nihssLOCC'),
        gaze: v('nihssGaze'), visual: v('nihssVisual'), facial: v('nihssFacial'),
        motorArmL: v('nihssMAL'), motorArmR: v('nihssMAR'),
        motorLegL: v('nihssMLegL'), motorLegR: v('nihssMLegR'),
        ataxia: v('nihssAtaxia'), sensory: v('nihssSensory'),
        language: v('nihssLanguage'), dysarthria: v('nihssDysarthria'),
        extinction: v('nihssExtinction')
    };
    const result = Calculators.calculateNIHSS(inputs);
    displayGenericResult(result, inputs, 17, 'NIHSS', null, 'nihssResult');
    Storage.addToHistory({ calculatorId: 17, calculatorName: 'NIHSS', inputs, result, interpretation: result.interpretation });
}

// === 18. GLASGOW COMA SCALE === //
function createGlasgowForm() {
    const sel = (id, options) => `
        <select id="${id}" class="form-input" onchange="updateGlasgowTotal()">
            ${options.map((o, i) => `<option value="${i + 1}">${i + 1} – ${o}</option>`).join('')}
        </select>`;

    return `
        <form id="glasgowForm" onsubmit="calculateGlasgow(event)">

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.05em;">E — Apertura ocular</div>
            <div style="margin-bottom: 16px;">
                ${sel('gcsEyes', [
                    'Sin respuesta',
                    'Al dolor',
                    'A la voz',
                    'Espontánea'
                ])}
            </div>

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.05em;">V — Respuesta verbal</div>
            <div style="margin-bottom: 16px;">
                ${sel('gcsVerbal', [
                    'Sin respuesta',
                    'Sonidos incomprensibles',
                    'Palabras inapropiadas',
                    'Confuso / desorientado',
                    'Orientado y coherente'
                ])}
            </div>

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.05em;">M — Respuesta motora</div>
            <div style="margin-bottom: 20px;">
                ${sel('gcsMotor', [
                    'Sin respuesta',
                    'Extensión (descerebración)',
                    'Flexión anormal (decorticación)',
                    'Retirada al dolor',
                    'Localiza el dolor',
                    'Obedece órdenes'
                ])}
            </div>

            <div id="glasgowLiveTotal" style="background: var(--bg-secondary); padding: 16px; border-radius: 12px; margin-bottom: 16px; text-align: center;">
                <div style="font-size: 12px; font-weight: 600; color: var(--text-secondary); margin-bottom: 4px;">TOTAL GCS (E+V+M)</div>
                <div id="glasgowTotalDisplay" style="font-size: 32px; font-weight: 800;">3</div>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular Glasgow
            </button>
        </form>
        <div id="glasgowResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function updateGlasgowTotal() {
    const eyes = parseInt(document.getElementById('gcsEyes')?.value || 1);
    const verbal = parseInt(document.getElementById('gcsVerbal')?.value || 1);
    const motor = parseInt(document.getElementById('gcsMotor')?.value || 1);
    const display = document.getElementById('glasgowTotalDisplay');
    if (display) display.textContent = eyes + verbal + motor;
}

function calculateGlasgow(event) {
    event.preventDefault();
    const inputs = {
        eyes: parseInt(document.getElementById('gcsEyes').value),
        verbal: parseInt(document.getElementById('gcsVerbal').value),
        motor: parseInt(document.getElementById('gcsMotor').value)
    };
    const result = Calculators.calculateGlasgow(inputs);
    const c = result.components;

    const container = document.getElementById('glasgowResult');
    container.innerHTML = `
        <div class="result-card" style="background: linear-gradient(135deg, var(--brand-accent-dark), var(--brand-accent)); padding: 24px; border-radius: var(--radius-lg); color: var(--brand-primary-dark); margin-bottom: 16px;">
            <div style="font-size: 13px; font-weight: 600; margin-bottom: 8px; opacity: 0.8;">GLASGOW COMA SCALE</div>
            <div style="font-size: 36px; font-weight: 800; margin-bottom: 4px;">
                ${result.value} <span style="font-size: 20px; font-weight: 600;">/15</span>
            </div>
            <div style="font-size: 14px; font-weight: 600; margin-bottom: 12px;">${result.interpretation.label}</div>
            <div style="background: rgba(30, 56, 114, 0.15); padding: 12px; border-radius: 8px; font-size: 14px; display: flex; justify-content: space-around;">
                <span><strong>E</strong> ${c.eyes}/4</span>
                <span><strong>V</strong> ${c.verbal}/5</span>
                <span><strong>M</strong> ${c.motor}/6</span>
            </div>
        </div>
        <div class="interpretation-card" style="background: var(--bg-secondary); padding: 20px; border-radius: var(--radius-lg); border-left: 4px solid var(--${result.interpretation.color});">
            <h4 style="font-size: 14px; font-weight: 700; margin-bottom: 8px;">Interpretación</h4>
            <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.6;">${result.interpretation.description}</p>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('glasgowForm').reset(); document.getElementById('glasgowResult').style.display='none'; updateGlasgowTotal();" style="width: 100%; margin-top: 16px;">
            🔄 Nuevo Cálculo
        </button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 18, calculatorName: 'Glasgow', inputs, result, interpretation: result.interpretation });
}

// === 19. TIMI UA/NSTEMI === //
function createTIMI_NSTEMIForm() {
    return `
        <form id="timiNSTEMIForm" onsubmit="calculateTIMI_NSTEMI(event)">
            <div class="alert-box" style="background: #fef3c7; border-left: 4px solid #f59e0b; padding: 16px; border-radius: 8px; margin-bottom: 16px;">
                <p style="font-size: 13px; color: #92400e; margin: 0;">
                    <strong>⚠️ Uso:</strong> Angina inestable y NSTEMI. Predice muerte, IAM o revascularización urgente a 14 días.
                </p>
            </div>
            <div style="background: var(--bg-secondary); padding: 16px; border-radius: 12px; margin-bottom: 16px;">
                <p style="font-size: 13px; font-weight: 600; margin-bottom: 12px;">Marque los criterios presentes (1 punto cada uno):</p>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="timiAge65" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Edad ≥65 años</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="timiRiskFactors" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">≥3 factores de riesgo de EAC (HTA, DM, dislipemia, tabaquismo, EAC familiar)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="timiKnownCAD" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">EAC conocida (estenosis coronaria ≥50%)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="timiAspirin" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Uso de AAS en los últimos 7 días</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="timiSevereAngina" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Angina severa (≥2 episodios en 24h)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="timiElevMarkers" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Marcadores cardíacos elevados (troponina o CK-MB)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                    <input type="checkbox" id="timiSTDev" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Desviación del ST ≥0.5 mm en ECG</span>
                </label>
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular TIMI UA/NSTEMI
            </button>
        </form>
        <div id="timiNSTEMIResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateTIMI_NSTEMI(event) {
    event.preventDefault();
    const inputs = {
        age65:        document.getElementById('timiAge65').checked,
        riskFactors:  document.getElementById('timiRiskFactors').checked,
        knownCAD:     document.getElementById('timiKnownCAD').checked,
        aspirin:      document.getElementById('timiAspirin').checked,
        severeAngina: document.getElementById('timiSevereAngina').checked,
        elevMarkers:  document.getElementById('timiElevMarkers').checked,
        stDeviation:  document.getElementById('timiSTDev').checked
    };
    const result = Calculators.calculateTIMI_NSTEMI(inputs);
    displayGenericResult(result, inputs, 19, 'TIMI UA/NSTEMI', null, 'timiNSTEMIResult');
    Storage.addToHistory({ calculatorId: 19, calculatorName: 'TIMI UA/NSTEMI', inputs, result, interpretation: result.interpretation });
}

// === 20. TIMI STEMI === //
function createTIMI_STEMIForm() {
    const units = Storage.getSettings().units;
    return `
        <form id="timiSTEMIForm" onsubmit="calculateTIMI_STEMI(event)">
            <div class="alert-box" style="background: #fee2e2; border-left: 4px solid #ef4444; padding: 16px; border-radius: 8px; margin-bottom: 16px;">
                <p style="font-size: 13px; color: #7f1d1d; margin: 0;">
                    <strong>🚨 Uso:</strong> IAMCEST. Predice mortalidad a 30 días para guiar intensidad del tratamiento.
                </p>
            </div>

            <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px;">
                <div>
                    <label style="display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px;">Edad (años)</label>
                    <input type="number" id="timiSAge" required min="18" max="120" class="form-input">
                </div>
                <div>
                    <label style="display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px;">Peso (${units.weight})</label>
                    <input type="number" id="timiSWeight" required step="any" min="30" max="300" class="form-input">
                </div>
            </div>

            <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px;">
                <div>
                    <label style="display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px;">PAS (mmHg)</label>
                    <input type="number" id="timiSSBP" required min="40" max="250" class="form-input">
                </div>
                <div>
                    <label style="display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px;">FC (lpm)</label>
                    <input type="number" id="timiSHR" required min="20" max="250" class="form-input">
                </div>
            </div>

            <div style="background: var(--bg-secondary); padding: 16px; border-radius: 12px; margin-bottom: 16px;">
                <p style="font-size: 13px; font-weight: 600; margin-bottom: 12px;">Factores adicionales:</p>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="timiSRiskHx" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">DM / HTA / angina previa (1 pt)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="timiSKillip" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Killip ≥II — signos de insuficiencia cardíaca (2 pts)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="timiSAnteriorST" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Elevación ST anterior o bloqueo de rama izquierda (1 pt)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                    <input type="checkbox" id="timiSTimeLate" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Tiempo a tratamiento >4 horas (1 pt)</span>
                </label>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular TIMI STEMI
            </button>
        </form>
        <div id="timiSTEMIResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateTIMI_STEMI(event) {
    event.preventDefault();
    const inputs = {
        age:          parseInt(document.getElementById('timiSAge').value),
        sbp:          parseInt(document.getElementById('timiSSBP').value),
        hr:           parseInt(document.getElementById('timiSHR').value),
        weight:       parseFloat(document.getElementById('timiSWeight').value),
        riskHistory:  document.getElementById('timiSRiskHx').checked,
        killip2plus:  document.getElementById('timiSKillip').checked,
        anteriorST:   document.getElementById('timiSAnteriorST').checked,
        timeLate:     document.getElementById('timiSTimeLate').checked
    };
    const result = Calculators.calculateTIMI_STEMI(inputs);
    displayGenericResult(result, inputs, 20, 'TIMI STEMI', null, 'timiSTEMIResult');
    Storage.addToHistory({ calculatorId: 20, calculatorName: 'TIMI STEMI', inputs, result, interpretation: result.interpretation });
}

// === 21. GRACE SCORE === //
function createGRACEForm() {
    const units = Storage.getSettings().units;
    const crMax = units.creatinine === 'mg/dL' ? 15 : 1326;
    return `
        <form id="graceForm" onsubmit="calculateGRACE(event)">
            <div class="alert-box" style="background: #dbeafe; border-left: 4px solid #3b82f6; padding: 16px; border-radius: 8px; margin-bottom: 16px;">
                <p style="font-size: 13px; color: #1e3a8a; margin: 0;">
                    <strong>ℹ️ Uso:</strong> Síndrome coronario agudo (STEMI y NSTEMI). Predice mortalidad intrahospitalaria.
                </p>
            </div>

            <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px;">
                <div>
                    <label style="display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px;">Edad (años)</label>
                    <input type="number" id="graceAge" required min="18" max="120" class="form-input">
                </div>
                <div>
                    <label style="display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px;">FC (lpm)</label>
                    <input type="number" id="graceHR" required min="20" max="250" class="form-input">
                </div>
            </div>

            <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px;">
                <div>
                    <label style="display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px;">PAS (mmHg)</label>
                    <input type="number" id="graceSBP" required min="40" max="250" class="form-input">
                </div>
                <div>
                    <label style="display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px;">Creatinina (${units.creatinine})</label>
                    <input type="number" id="graceCr" required step="any" min="0.1" max="${crMax}" class="form-input">
                </div>
            </div>

            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 6px; font-weight: 600; font-size: 14px;">Clase Killip</label>
                <select id="graceKillip" required class="form-input">
                    <option value="1">Killip I — Sin signos de IC</option>
                    <option value="2">Killip II — Crepitantes, S3 o ingurgitación yugular</option>
                    <option value="3">Killip III — Edema agudo de pulmón</option>
                    <option value="4">Killip IV — Shock cardiogénico</option>
                </select>
            </div>

            <div style="background: var(--bg-secondary); padding: 16px; border-radius: 12px; margin-bottom: 16px;">
                <p style="font-size: 13px; font-weight: 600; margin-bottom: 12px;">Variables adicionales:</p>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="graceArrest" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">PCR al ingreso (43 pts)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="graceSTDev" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Desviación del ST en ECG (30 pts)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                    <input type="checkbox" id="graceMarkers" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Marcadores cardíacos elevados (15 pts)</span>
                </label>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular GRACE Score
            </button>
        </form>
        <div id="graceResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateGRACE(event) {
    event.preventDefault();
    const inputs = {
        age:           parseInt(document.getElementById('graceAge').value),
        hr:            parseInt(document.getElementById('graceHR').value),
        sbp:           parseInt(document.getElementById('graceSBP').value),
        creatinine:    parseFloat(document.getElementById('graceCr').value),
        killip:        document.getElementById('graceKillip').value,
        cardiacArrest: document.getElementById('graceArrest').checked,
        stDeviation:   document.getElementById('graceSTDev').checked,
        elevMarkers:   document.getElementById('graceMarkers').checked
    };
    const result = Calculators.calculateGRACE(inputs);
    const c = result.components;

    const ptRow = (label, pts) => pts > 0 ? `
        <div style="display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid rgba(255,255,255,0.07); font-size: 13px;">
            <span style="color: var(--text-secondary);">${label}</span>
            <span style="font-weight: 700;">+${pts}</span>
        </div>` : '';

    const container = document.getElementById('graceResult');
    container.innerHTML = `
        <div class="result-card" style="background: linear-gradient(135deg, var(--brand-accent-dark), var(--brand-accent)); padding: 24px; border-radius: var(--radius-lg); color: var(--brand-primary-dark); margin-bottom: 16px;">
            <div style="font-size: 13px; font-weight: 600; margin-bottom: 8px; opacity: 0.8;">GRACE SCORE</div>
            <div style="font-size: 36px; font-weight: 800; margin-bottom: 4px;">
                ${result.value} <span style="font-size: 20px; font-weight: 600;">${result.unit}</span>
            </div>
            <div style="font-size: 14px; font-weight: 600;">${result.interpretation.label}</div>
        </div>
        <div style="background: var(--bg-secondary); padding: 20px; border-radius: var(--radius-lg); margin-bottom: 16px;">
            <h4 style="font-size: 13px; font-weight: 700; margin-bottom: 12px; text-transform: uppercase; letter-spacing: 0.05em;">Desglose de puntos</h4>
            ${ptRow('Edad', c.agePoints)}
            ${ptRow('Frecuencia cardíaca', c.hrPoints)}
            ${ptRow('Presión arterial sistólica', c.sbpPoints)}
            ${ptRow('Creatinina', c.crPoints)}
            ${ptRow('Clase Killip', c.killipPoints)}
            ${ptRow('PCR al ingreso', c.arrestPoints)}
            ${ptRow('Desviación del ST', c.stPoints)}
            ${ptRow('Marcadores elevados', c.markerPoints)}
        </div>
        <div class="interpretation-card" style="background: var(--bg-secondary); padding: 20px; border-radius: var(--radius-lg); border-left: 4px solid var(--${result.interpretation.color});">
            <h4 style="font-size: 14px; font-weight: 700; margin-bottom: 8px;">Interpretación</h4>
            <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.6;">${result.interpretation.description}</p>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('graceForm').reset(); document.getElementById('graceResult').style.display='none';" style="width: 100%; margin-top: 16px;">
            🔄 Nuevo Cálculo
        </button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 21, calculatorName: 'GRACE', inputs, result, interpretation: result.interpretation });
}

// === 22. ESCALA DE BRADEN === //
function createBradenForm() {
    const sel = (id, label, options, maxVal) => {
        const opts = options.map((o, i) => {
            const val = i + 1;
            return `<option value="${val}">${val} – ${o}</option>`;
        }).join('');
        return `
        <div style="margin-bottom: 14px;">
            <label style="display: block; margin-bottom: 6px; font-weight: 600; font-size: 13px;">${label} <span style="font-weight: 400; color: var(--text-secondary);">(1–${maxVal})</span></label>
            <select id="${id}" class="form-input" onchange="updateBradenTotal()" style="margin-bottom: 0;">
                ${opts}
            </select>
        </div>`;
    };

    return `
        <form id="bradenForm" onsubmit="calculateBraden(event)">
            <div class="alert-box" style="background: #f0fdf4; border-left: 4px solid #22c55e; padding: 16px; border-radius: 8px; margin-bottom: 16px;">
                <p style="font-size: 13px; color: #14532d; margin: 0;">
                    <strong>ℹ️ Nota:</strong> Puntuación más baja = mayor riesgo. Total 6–23. Valorar al ingreso y cada 24-48h.
                </p>
            </div>

            ${sel('bradenSensory', 'Percepción sensorial', [
                'Sin respuesta (no reacciona a estímulos dolorosos)',
                'Muy limitada (responde solo al dolor, no comunica malestar)',
                'Levemente limitada (responde a órdenes verbales, puede comunicar)',
                'Sin limitación (responde, sin déficit sensorial)'
            ], 4)}

            ${sel('bradenMoisture', 'Humedad de la piel', [
                'Constantemente húmedo (pañal/ropa siempre empapados)',
                'Muy húmedo (cambios frecuentes, al menos 1 vez por turno)',
                'Ocasionalmente húmedo (cambio extra ~1/día)',
                'Raramente húmedo (piel seca, cambio rutinario)'
            ], 4)}

            ${sel('bradenActivity', 'Actividad', [
                'Encamado (confinado en cama)',
                'En silla (capacidad de caminar muy limitada o nula)',
                'Camina ocasionalmente (distancias muy cortas, con ayuda)',
                'Camina frecuentemente (fuera de la habitación ≥2 veces/día)'
            ], 4)}

            ${sel('bradenMobility', 'Movilidad', [
                'Completamente inmóvil (no puede cambiar posición sin ayuda)',
                'Muy limitada (cambios ligeros y ocasionales de posición)',
                'Ligeramente limitada (cambios frecuentes pero con poca fuerza)',
                'Sin limitación (cambia de posición frecuentemente sin ayuda)'
            ], 4)}

            ${sel('bradenNutrition', 'Nutrición', [
                'Muy pobre (nunca come completo, escasa ingesta de líquidos)',
                'Probablemente inadecuada (raramente come >½ ración)',
                'Adecuada (come >½ de comidas, con suplementos si precisa)',
                'Excelente (come siempre completo, nunca rechaza comida)'
            ], 4)}

            ${sel('bradenFriction', 'Fricción y cizallamiento', [
                'Problema (requiere asistencia máxima, se desliza constantemente)',
                'Problema potencial (se mueve con algo de asistencia, algo de fricción)',
                'Sin problema aparente (se mueve independientemente, sin fricción)'
            ], 3)}

            <div id="bradenLiveTotal" style="background: var(--bg-secondary); padding: 16px; border-radius: 12px; margin-bottom: 16px; text-align: center;">
                <div style="font-size: 12px; font-weight: 600; color: var(--text-secondary); margin-bottom: 4px;">TOTAL BRADEN</div>
                <div id="bradenTotalDisplay" style="font-size: 32px; font-weight: 800;">6</div>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular Escala de Braden
            </button>
        </form>
        <div id="bradenResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function updateBradenTotal() {
    const ids = ['bradenSensory','bradenMoisture','bradenActivity','bradenMobility','bradenNutrition','bradenFriction'];
    const total = ids.reduce((sum, id) => {
        const el = document.getElementById(id);
        return sum + (el ? parseInt(el.value) : 1);
    }, 0);
    const display = document.getElementById('bradenTotalDisplay');
    if (display) display.textContent = total;
}

function calculateBraden(event) {
    event.preventDefault();
    const inputs = {
        sensory:   parseInt(document.getElementById('bradenSensory').value),
        moisture:  parseInt(document.getElementById('bradenMoisture').value),
        activity:  parseInt(document.getElementById('bradenActivity').value),
        mobility:  parseInt(document.getElementById('bradenMobility').value),
        nutrition: parseInt(document.getElementById('bradenNutrition').value),
        friction:  parseInt(document.getElementById('bradenFriction').value)
    };
    const result = Calculators.calculateBraden(inputs);
    const c = result.components;

    const labels = [
        ['Percepción sensorial', c.sensory, 4],
        ['Humedad',              c.moisture, 4],
        ['Actividad',            c.activity, 4],
        ['Movilidad',            c.mobility, 4],
        ['Nutrición',            c.nutrition, 4],
        ['Fricción/cizalla',     c.friction, 3]
    ];

    const barRow = ([label, val, max]) => {
        const pct = (val / max) * 100;
        const color = pct <= 25 ? '#ef4444' : pct <= 50 ? '#f97316' : pct <= 75 ? '#f59e0b' : '#22c55e';
        return `<div style="margin-bottom: 10px;">
            <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 3px;">
                <span style="color: var(--text-secondary);">${label}</span>
                <span style="font-weight: 700;">${val}/${max}</span>
            </div>
            <div style="background: rgba(255,255,255,0.1); border-radius: 4px; height: 6px;">
                <div style="background: ${color}; width: ${pct}%; height: 100%; border-radius: 4px;"></div>
            </div>
        </div>`;
    };

    const container = document.getElementById('bradenResult');
    container.innerHTML = `
        <div class="result-card" style="background: linear-gradient(135deg, var(--brand-accent-dark), var(--brand-accent)); padding: 24px; border-radius: var(--radius-lg); color: var(--brand-primary-dark); margin-bottom: 16px;">
            <div style="font-size: 13px; font-weight: 600; margin-bottom: 8px; opacity: 0.8;">ESCALA DE BRADEN</div>
            <div style="font-size: 36px; font-weight: 800; margin-bottom: 4px;">
                ${result.value} <span style="font-size: 20px; font-weight: 600;">/23</span>
            </div>
            <div style="font-size: 14px; font-weight: 600;">${result.interpretation.label}</div>
        </div>
        <div style="background: var(--bg-secondary); padding: 20px; border-radius: var(--radius-lg); margin-bottom: 16px;">
            <h4 style="font-size: 13px; font-weight: 700; margin-bottom: 14px; text-transform: uppercase; letter-spacing: 0.05em;">Puntuación por subescala</h4>
            ${labels.map(barRow).join('')}
        </div>
        <div class="interpretation-card" style="background: var(--bg-secondary); padding: 20px; border-radius: var(--radius-lg); border-left: 4px solid var(--${result.interpretation.color});">
            <h4 style="font-size: 14px; font-weight: 700; margin-bottom: 8px;">Interpretación</h4>
            <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.6;">${result.interpretation.description}</p>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('bradenForm').reset(); document.getElementById('bradenResult').style.display='none'; updateBradenTotal();" style="width: 100%; margin-top: 16px;">
            🔄 Nuevo Cálculo
        </button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 22, calculatorName: 'Braden', inputs, result, interpretation: result.interpretation });
}

// === 23. MACOCHA SCORE === //
function createMACOCHAForm() {
    return `
        <form id="macochаForm" onsubmit="calculateMAOCHA(event)">
            <div style="background: #dbeafe; border-left: 4px solid #3b82f6; padding: 16px; border-radius: 8px; margin-bottom: 16px;">
                <p style="font-size: 13px; color: #1e3a8a; margin: 0;">
                    <strong>ℹ️ MACOCHA Score</strong> — Predice intubación difícil en UCI/Emergencias. Score ≥4 indica alto riesgo (tasa de fallo >90%). <em>De Jong et al., AJRCCM 2013.</em>
                </p>
            </div>

            <div style="background: var(--bg-secondary); padding: 16px; border-radius: 12px; margin-bottom: 16px;">
                <p style="font-size: 13px; font-weight: 700; margin-bottom: 12px; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-secondary);">Criterios (marcar los presentes)</p>

                <label style="display: flex; align-items: flex-start; gap: 10px; margin-bottom: 14px; cursor: pointer;">
                    <input type="checkbox" id="macMallampati" style="width: 18px; height: 18px; margin-top: 2px; flex-shrink: 0;">
                    <span style="font-size: 14px;"><strong>Mallampati clase III o IV</strong> <span style="color: var(--brand-accent); font-weight: 700;">+5 pts</span><br><span style="font-size: 12px; color: var(--text-secondary);">Solo visible paladar blando o úvula / no visible paladar blando</span></span>
                </label>

                <label style="display: flex; align-items: flex-start; gap: 10px; margin-bottom: 14px; cursor: pointer;">
                    <input type="checkbox" id="macOSA" style="width: 18px; height: 18px; margin-top: 2px; flex-shrink: 0;">
                    <span style="font-size: 14px;"><strong>Apnea obstructiva del sueño</strong> <span style="color: var(--brand-accent); font-weight: 700;">+2 pts</span></span>
                </label>

                <label style="display: flex; align-items: flex-start; gap: 10px; margin-bottom: 14px; cursor: pointer;">
                    <input type="checkbox" id="macCervical" style="width: 18px; height: 18px; margin-top: 2px; flex-shrink: 0;">
                    <span style="font-size: 14px;"><strong>Limitación de columna cervical</strong> <span style="font-weight: 700;">+1 pt</span><br><span style="font-size: 12px; color: var(--text-secondary);">Incapacidad de flexionar/extender el cuello</span></span>
                </label>

                <label style="display: flex; align-items: flex-start; gap: 10px; margin-bottom: 14px; cursor: pointer;">
                    <input type="checkbox" id="macOpening" style="width: 18px; height: 18px; margin-top: 2px; flex-shrink: 0;">
                    <span style="font-size: 14px;"><strong>Apertura oral &lt;3 cm</strong> <span style="font-weight: 700;">+1 pt</span></span>
                </label>

                <label style="display: flex; align-items: flex-start; gap: 10px; margin-bottom: 14px; cursor: pointer;">
                    <input type="checkbox" id="macComa" style="width: 18px; height: 18px; margin-top: 2px; flex-shrink: 0;">
                    <span style="font-size: 14px;"><strong>Coma (GCS &lt;8)</strong> <span style="font-weight: 700;">+1 pt</span></span>
                </label>

                <label style="display: flex; align-items: flex-start; gap: 10px; margin-bottom: 14px; cursor: pointer;">
                    <input type="checkbox" id="macHypoxemia" style="width: 18px; height: 18px; margin-top: 2px; flex-shrink: 0;">
                    <span style="font-size: 14px;"><strong>Hipoxemia grave (SpO₂ &lt;80% pre-intubación)</strong> <span style="font-weight: 700;">+1 pt</span></span>
                </label>

                <label style="display: flex; align-items: flex-start; gap: 10px; cursor: pointer;">
                    <input type="checkbox" id="macNonAnest" style="width: 18px; height: 18px; margin-top: 2px; flex-shrink: 0;">
                    <span style="font-size: 14px;"><strong>Operador no anestesiólogo</strong> <span style="font-weight: 700;">+1 pt</span></span>
                </label>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular MACOCHA
            </button>
        </form>
        <div id="macochаResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateMAOCHA(event) {
    event.preventDefault();
    const inputs = {
        mallampati: document.getElementById('macMallampati').checked,
        osa:        document.getElementById('macOSA').checked,
        cervical:   document.getElementById('macCervical').checked,
        opening:    document.getElementById('macOpening').checked,
        coma:       document.getElementById('macComa').checked,
        hypoxemia:  document.getElementById('macHypoxemia').checked,
        nonAnest:   document.getElementById('macNonAnest').checked
    };
    const result = Calculators.calculateMAOCHA(inputs);
    displayGenericResult(result, inputs, 23, 'MACOCHA Score', null, 'macochаResult');
    Storage.addToHistory({ calculatorId: 23, calculatorName: 'MACOCHA Score', inputs, result, interpretation: result.interpretation });
}

// === 24. PBW + VOLUMEN TIDAL === //
function createPBWForm() {
    const units = Storage.getSettings().units;
    const hUnit = units.height || 'cm';
    return `
        <form id="pbwForm" onsubmit="calculatePBW(event)">
            <div style="background: #dbeafe; border-left: 4px solid #3b82f6; padding: 16px; border-radius: 8px; margin-bottom: 16px;">
                <p style="font-size: 13px; color: #1e3a8a; margin: 0;">
                    <strong>ℹ️ ARDSNet</strong> — El volumen tidal se calcula sobre el <strong>peso corporal predicho (PBW)</strong>, no el peso real. Solo se necesita la talla. <em>NEJM 2000.</em>
                </p>
            </div>

            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">Sexo biológico</label>
                <select id="pbwSex" required class="form-input">
                    <option value="male">Hombre</option>
                    <option value="female">Mujer</option>
                </select>
            </div>

            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">Talla (${hUnit})</label>
                <input type="number" id="pbwHeight" required step="any" min="100" max="220" class="form-input" placeholder="Puede estimarse visualmente">
            </div>

            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">Contexto clínico</label>
                <select id="pbwMode" required class="form-input">
                    <option value="ards">ARDS / Pulmón lesionado → TV 6 mL/kg PBW</option>
                    <option value="normal">Sin ARDS / Pulmón normal → TV 8 mL/kg PBW</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular PBW y Volumen Tidal
            </button>
        </form>
        <div id="pbwResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculatePBW(event) {
    event.preventDefault();
    const inputs = {
        sex:    document.getElementById('pbwSex').value,
        height: parseFloat(document.getElementById('pbwHeight').value),
        mode:   document.getElementById('pbwMode').value
    };
    const result = Calculators.calculatePBW(inputs);
    const targetTV = inputs.mode === 'ards' ? result.tv6 : result.tv8;
    const targetLabel = inputs.mode === 'ards' ? '6 mL/kg (ARDS)' : '8 mL/kg (estándar)';

    const row = (label, value, highlight) => `
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px solid var(--border-color);">
            <span style="font-size: 13px; color: var(--text-secondary);">${label}</span>
            <span style="font-size: 15px; font-weight: ${highlight ? '800' : '600'}; color: ${highlight ? 'var(--brand-accent)' : 'var(--text-primary)'};">${value}</span>
        </div>`;

    const container = document.getElementById('pbwResult');
    container.innerHTML = `
        <div style="background: linear-gradient(135deg, var(--brand-accent-dark), var(--brand-accent)); padding: 24px; border-radius: var(--radius-lg); color: var(--brand-primary-dark); margin-bottom: 16px;">
            <div style="font-size: 13px; font-weight: 600; margin-bottom: 8px; opacity: 0.8;">PESO CORPORAL PREDICHO (PBW)</div>
            <div style="font-size: 36px; font-weight: 800; margin-bottom: 4px;">${result.value} <span style="font-size: 20px; font-weight: 600;">kg</span></div>
            <div style="font-size: 14px; font-weight: 600;">Vol. tidal objetivo: ${targetTV} mL</div>
        </div>
        <div style="background: var(--bg-secondary); padding: 20px; border-radius: var(--radius-lg); margin-bottom: 16px;">
            <h4 style="font-size: 13px; font-weight: 700; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.05em;">Volúmenes tidales</h4>
            ${row('4 mL/kg PBW — ARDS severo', result.tv4 + ' mL', false)}
            ${row('6 mL/kg PBW — ARDS / protector ✓', result.tv6 + ' mL', inputs.mode === 'ards')}
            ${row('8 mL/kg PBW — Sin ARDS ✓', result.tv8 + ' mL', inputs.mode === 'normal')}
        </div>
        <div style="background: var(--bg-secondary); padding: 20px; border-radius: var(--radius-lg); margin-bottom: 16px;">
            <h4 style="font-size: 13px; font-weight: 700; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.05em;">Parámetros de ventilación</h4>
            ${row('Frecuencia respiratoria', '12 – 20 rpm', false)}
            ${row('Presión plateau máxima', '< 30 cmH₂O', false)}
            ${row('PEEP mínimo', '≥ 5 cmH₂O', false)}
        </div>
        <div style="background: var(--bg-secondary); padding: 16px; border-radius: var(--radius-lg); border-left: 4px solid var(--info, #3b82f6); margin-bottom: 16px;">
            <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.6; margin: 0;">${result.interpretation.description}</p>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('pbwForm').reset(); document.getElementById('pbwResult').style.display='none';" style="width: 100%; margin-top: 0;">
            🔄 Nuevo Cálculo
        </button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 24, calculatorName: 'PBW / Vol. Tidal', inputs, result, interpretation: result.interpretation });
}

// === 25. FOUR SCORE === //
function createFOURScoreForm() {
    const sel = (id, options) => `
        <select id="${id}" class="form-input" onchange="updateFOURTotal()">
            ${options.map((o, i) => `<option value="${i}">${i} – ${o}</option>`).reverse().join('')}
        </select>`;

    return `
        <form id="fourScoreForm" onsubmit="calculateFOURScore(event)">
            <div style="background: #fef3c7; border-left: 4px solid #f59e0b; padding: 16px; border-radius: 8px; margin-bottom: 16px;">
                <p style="font-size: 13px; color: #92400e; margin: 0;">
                    <strong>⚠️ Para pacientes intubados</strong> — El FOUR Score reemplaza al Glasgow cuando la respuesta verbal no puede evaluarse. <em>Wijdicks et al., Mayo Clin Proc 2005.</em>
                </p>
            </div>

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.05em;">E — Apertura ocular</div>
            <div style="margin-bottom: 16px;">
                ${sel('fourEyes', [
                    'Párpados cerrados al dolor',
                    'Párpados cerrados, abren al dolor',
                    'Párpados cerrados, abren a la voz',
                    'Abiertos pero sin seguimiento',
                    'Abiertos o abiertos, con seguimiento o parpadeo a la orden'
                ])}
            </div>

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.05em;">M — Respuesta motora</div>
            <div style="margin-bottom: 16px;">
                ${sel('fourMotor', [
                    'Sin respuesta o mioclonías generalizadas',
                    'Extensión al dolor (descerebración)',
                    'Flexión al dolor (decorticación)',
                    'Localiza el dolor',
                    'Obedece a la orden (pulgar arriba / puño / señal de paz)'
                ])}
            </div>

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.05em;">B — Reflejos de tronco encefálico</div>
            <div style="margin-bottom: 16px;">
                ${sel('fourBrainstem', [
                    'Ausencia de reflejos pupilares, corneales y tusígeno',
                    'Reflejos pupilares Y corneales ausentes',
                    'Reflejo pupilar O corneal ausente',
                    'Una pupila dilatada y fija',
                    'Reflejos pupilares y corneales presentes'
                ])}
            </div>

            <div style="font-size: 13px; font-weight: 700; color: var(--text-secondary); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.05em;">R — Respiración</div>
            <div style="margin-bottom: 20px;">
                ${sel('fourResp', [
                    'Apnea o respira a la frecuencia del ventilador (intubado)',
                    'Respira por encima del ventilador (intubado)',
                    'Respiración irregular (no intubado)',
                    'Patrón de Cheyne-Stokes (no intubado)',
                    'Patrón regular (no intubado)'
                ])}
            </div>

            <div style="background: var(--bg-secondary); padding: 16px; border-radius: 12px; margin-bottom: 16px; text-align: center;">
                <div style="font-size: 12px; font-weight: 600; color: var(--text-secondary); margin-bottom: 4px;">TOTAL FOUR SCORE (E+M+B+R)</div>
                <div id="fourTotalDisplay" style="font-size: 32px; font-weight: 800;">0</div>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular FOUR Score
            </button>
        </form>
        <div id="fourScoreResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function updateFOURTotal() {
    const eyes      = parseInt(document.getElementById('fourEyes')?.value || 0);
    const motor     = parseInt(document.getElementById('fourMotor')?.value || 0);
    const brainstem = parseInt(document.getElementById('fourBrainstem')?.value || 0);
    const resp      = parseInt(document.getElementById('fourResp')?.value || 0);
    const display   = document.getElementById('fourTotalDisplay');
    if (display) display.textContent = eyes + motor + brainstem + resp;
}

function calculateFOURScore(event) {
    event.preventDefault();
    const inputs = {
        eyes:        parseInt(document.getElementById('fourEyes').value),
        motor:       parseInt(document.getElementById('fourMotor').value),
        brainstem:   parseInt(document.getElementById('fourBrainstem').value),
        respiration: parseInt(document.getElementById('fourResp').value)
    };
    const result = Calculators.calculateFOURScore(inputs);
    const c = result.components;
    const colorMap = { success: 'var(--success)', warning: 'var(--warning)', danger: 'var(--danger)', info: '#3b82f6' };

    const container = document.getElementById('fourScoreResult');
    container.innerHTML = `
        <div style="background: linear-gradient(135deg, var(--brand-accent-dark), var(--brand-accent)); padding: 24px; border-radius: var(--radius-lg); color: var(--brand-primary-dark); margin-bottom: 16px;">
            <div style="font-size: 13px; font-weight: 600; margin-bottom: 8px; opacity: 0.8;">FOUR SCORE</div>
            <div style="font-size: 36px; font-weight: 800; margin-bottom: 4px;">
                ${result.value} <span style="font-size: 20px; font-weight: 500;">/16</span>
            </div>
            <div style="font-size: 14px; font-weight: 600; margin-bottom: 12px;">${result.interpretation.label}</div>
            <div style="background: rgba(30,56,114,0.15); padding: 12px; border-radius: 8px; font-size: 14px; display: flex; justify-content: space-around;">
                <span><strong>E</strong> ${c.eyes}/4</span>
                <span><strong>M</strong> ${c.motor}/4</span>
                <span><strong>B</strong> ${c.brainstem}/4</span>
                <span><strong>R</strong> ${c.respiration}/4</span>
            </div>
        </div>
        <div style="background: var(--bg-secondary); padding: 20px; border-radius: var(--radius-lg); border-left: 4px solid ${colorMap[result.interpretation.color] || 'var(--brand-accent)'}; margin-bottom: 16px;">
            <h4 style="font-size: 14px; font-weight: 700; margin-bottom: 8px;">Interpretación</h4>
            <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.6;">${result.interpretation.description}</p>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('fourScoreForm').reset(); document.getElementById('fourScoreResult').style.display='none'; updateFOURTotal();" style="width: 100%; margin-top: 0;">
            🔄 Nuevo Cálculo
        </button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 25, calculatorName: 'FOUR Score', inputs, result, interpretation: result.interpretation });
}

// === 26. HEART SCORE === //
function createHEARTForm() {
    const sel = (id, opts) => `
        <select id="${id}" class="form-input">
            ${opts.map((o, i) => `<option value="${i}">${i} — ${o}</option>`).join('')}
        </select>`;
    return `
        <form id="heartForm" onsubmit="calculateHEART(event)">
            <div style="background:#fef3c7; border-left:4px solid #f59e0b; padding:16px; border-radius:8px; margin-bottom:16px;">
                <p style="font-size:13px; color:#92400e; margin:0;">
                    <strong>⚠️ Uso en Urgencias</strong> — Aplicar en dolor torácico con sospecha de SCA. No usar como única herramienta diagnóstica. <em>Six AJ et al., Neth Heart J 2008.</em>
                </p>
            </div>

            <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:8px; text-transform:uppercase; letter-spacing:0.05em;">H — Historia</div>
            <div style="margin-bottom:16px;">
                ${sel('heartHistory', [
                    'Levemente sospechosa — no típica, inespecífica',
                    'Moderadamente sospechosa — mixta o atípica',
                    'Altamente sospechosa — típica de SCA (opresiva, irradiación, diaforesis)'
                ])}
            </div>

            <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:8px; text-transform:uppercase; letter-spacing:0.05em;">E — ECG</div>
            <div style="margin-bottom:16px;">
                ${sel('heartECG', [
                    'Normal',
                    'Alteración inespecífica de repolarización / BRI conocido / HVI / cambios no diagnósticos',
                    'Depresión ST significativa o elevación nueva / BRI nuevo / cambios isquémicos activos'
                ])}
            </div>

            <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:8px; text-transform:uppercase; letter-spacing:0.05em;">A — Edad (Age)</div>
            <div style="margin-bottom:16px;">
                ${sel('heartAge', [
                    'Menor de 45 años',
                    '45 – 64 años',
                    '65 años o mayor'
                ])}
            </div>

            <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:8px; text-transform:uppercase; letter-spacing:0.05em;">R — Factores de riesgo</div>
            <div style="margin-bottom:16px;">
                ${sel('heartRisk', [
                    'Sin factores de riesgo conocidos',
                    '1-2 factores (HTA, DM, dislipemia, tabaquismo, obesidad, antecedente familiar)',
                    '≥3 factores de riesgo O aterosclerosis conocida (SCA previo, stent, bypass, ACV, EAP)'
                ])}
            </div>

            <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:8px; text-transform:uppercase; letter-spacing:0.05em;">T — Troponina</div>
            <div style="margin-bottom:20px;">
                ${sel('heartTroponin', [
                    '≤ Límite normal del laboratorio',
                    '1-3× el límite normal',
                    '> 3× el límite normal'
                ])}
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">
                🧮 Calcular HEART Score
            </button>
        </form>
        <div id="heartResult" style="display:none; margin-top:24px;"></div>
    `;
}

function calculateHEART(event) {
    event.preventDefault();
    const inputs = {
        history:     parseInt(document.getElementById('heartHistory').value),
        ecg:         parseInt(document.getElementById('heartECG').value),
        age:         parseInt(document.getElementById('heartAge').value),
        riskFactors: parseInt(document.getElementById('heartRisk').value),
        troponin:    parseInt(document.getElementById('heartTroponin').value)
    };
    const result = Calculators.calculateHEART(inputs);
    const c = result.components;
    const colorMap = { success: 'var(--success)', warning: 'var(--warning)', danger: 'var(--danger)' };
    const labels = ['H', 'E', 'A', 'R', 'T'];
    const vals   = [c.history, c.ecg, c.age, c.riskFactors, c.troponin];

    const container = document.getElementById('heartResult');
    container.innerHTML = `
        <div style="background:linear-gradient(135deg,var(--brand-accent-dark),var(--brand-accent)); padding:24px; border-radius:var(--radius-lg); color:var(--brand-primary-dark); margin-bottom:16px;">
            <div style="font-size:13px; font-weight:600; margin-bottom:8px; opacity:0.8;">HEART SCORE</div>
            <div style="font-size:36px; font-weight:800; margin-bottom:4px;">
                ${result.value} <span style="font-size:20px; font-weight:500;">/10</span>
            </div>
            <div style="font-size:14px; font-weight:600; margin-bottom:12px;">${result.interpretation.label}</div>
            <div style="background:rgba(30,56,114,0.15); padding:12px; border-radius:8px; font-size:14px; display:flex; justify-content:space-around;">
                ${labels.map((l, i) => `<span><strong>${l}</strong> ${vals[i]}</span>`).join('')}
            </div>
        </div>
        <div style="background:var(--bg-secondary); padding:20px; border-radius:var(--radius-lg); border-left:4px solid ${colorMap[result.interpretation.color]}; margin-bottom:16px;">
            <h4 style="font-size:14px; font-weight:700; margin-bottom:8px;">Interpretación</h4>
            <p style="font-size:13px; color:var(--text-secondary); line-height:1.6;">${result.interpretation.description}</p>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('heartForm').reset(); document.getElementById('heartResult').style.display='none';" style="width:100%; margin-top:0;">
            🔄 Nuevo Cálculo
        </button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 26, calculatorName: 'HEART Score', inputs, result, interpretation: result.interpretation });
}

// === 27. REGLA PERC === //
function createPERCForm() {
    const check = (id, text) => `
        <label style="display:flex; align-items:flex-start; gap:10px; margin-bottom:12px; cursor:pointer;">
            <input type="checkbox" id="${id}" style="width:18px; height:18px; margin-top:2px; flex-shrink:0;">
            <span style="font-size:14px;">${text}</span>
        </label>`;
    return `
        <form id="percForm" onsubmit="calculatePERC(event)">
            <div style="background:#dbeafe; border-left:4px solid #3b82f6; padding:16px; border-radius:8px; margin-bottom:16px;">
                <p style="font-size:13px; color:#1e3a8a; margin:0;">
                    <strong>ℹ️ Solo en bajo riesgo pre-test</strong> — Aplicar únicamente si la probabilidad pre-test de TEP es BAJA (Wells ≤1 o Geneva bajo). Marcar los criterios que el paciente <strong>SÍ cumple</strong>. Si ninguno aplica → TEP descartado. <em>Kline JA et al., J Thromb Haemost 2004.</em>
                </p>
            </div>

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:20px;">
                <p style="font-size:13px; font-weight:700; margin-bottom:14px; text-transform:uppercase; letter-spacing:0.05em; color:var(--text-secondary);">Marcar si está presente</p>
                ${check('percAge',     'Edad ≥ 50 años')}
                ${check('percHR',      'Frecuencia cardíaca ≥ 100 lpm')}
                ${check('percSpO2',    'SpO₂ < 95% en aire ambiente')}
                ${check('percLeg',     'Edema unilateral de miembro inferior')}
                ${check('percHemo',    'Hemoptisis')}
                ${check('percSurg',    'Cirugía o trauma en las últimas 4 semanas (con anestesia general)')}
                ${check('percVTE',     'TEP o TVP previos documentados')}
                ${check('percEstro',   'Uso de estrógenos (ACO, TRH, embarazo)')}
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">
                🧮 Aplicar Regla PERC
            </button>
        </form>
        <div id="percResult" style="display:none; margin-top:24px;"></div>
    `;
}

function calculatePERC(event) {
    event.preventDefault();
    const inputs = {
        age50:       document.getElementById('percAge').checked,
        hr100:       document.getElementById('percHR').checked,
        spo294:      document.getElementById('percSpO2').checked,
        legSwelling: document.getElementById('percLeg').checked,
        hemoptysis:  document.getElementById('percHemo').checked,
        surgery:     document.getElementById('percSurg').checked,
        priorVTE:    document.getElementById('percVTE').checked,
        estrogen:    document.getElementById('percEstro').checked
    };
    const result = Calculators.calculatePERC(inputs);
    const isNegative = result.value === 0;
    const bgColor   = isNegative ? 'linear-gradient(135deg,#059669,#10b981)' : 'linear-gradient(135deg,#dc2626,#ef4444)';
    const textColor = 'white';

    const container = document.getElementById('percResult');
    container.innerHTML = `
        <div style="background:${bgColor}; padding:24px; border-radius:var(--radius-lg); color:${textColor}; margin-bottom:16px; text-align:center;">
            <div style="font-size:40px; margin-bottom:8px;">${isNegative ? '✅' : '⚠️'}</div>
            <div style="font-size:20px; font-weight:800; margin-bottom:4px;">${result.interpretation.label}</div>
            <div style="font-size:14px; opacity:0.9;">${isNegative ? 'Todos los criterios PERC negativos' : `${result.value} criterio${result.value > 1 ? 's' : ''} positivo${result.value > 1 ? 's' : ''}`}</div>
        </div>
        <div style="background:var(--bg-secondary); padding:20px; border-radius:var(--radius-lg); border-left:4px solid ${isNegative ? 'var(--success)' : 'var(--danger)'}; margin-bottom:16px;">
            <h4 style="font-size:14px; font-weight:700; margin-bottom:8px;">Interpretación</h4>
            <p style="font-size:13px; color:var(--text-secondary); line-height:1.6;">${result.interpretation.description}</p>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('percForm').reset(); document.getElementById('percResult').style.display='none';" style="width:100%; margin-top:0;">
            🔄 Nuevo Cálculo
        </button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 27, calculatorName: 'Regla PERC', inputs, result, interpretation: result.interpretation });
}

// === 28. CAD / CADE — PROTOCOLO INTEGRAL === //
function createDKAForm() {
    const units = Storage.getSettings().units;
    const wUnit = units.weight || 'kg';
    return `
        <form id="dkaForm" onsubmit="calculateDKAProtocol(event)">

            <!-- Sección 1: Paciente -->
            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:14px; text-transform:uppercase; letter-spacing:0.05em;">Datos del Paciente</div>

                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Peso (${wUnit})</label>
                    <input type="number" id="dkaWeight" required step="any" min="30" max="300" class="form-input" oninput="updateDKALiveCalcs()">
                </div>

                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Tipo de presentación</label>
                    <select id="dkaType" required class="form-input" onchange="updateDKALiveCalcs()">
                        <option value="classic">CAD Clásica — Glucosa ≥ 200 mg/dL (11.1 mmol/L)</option>
                        <option value="cade">CAD Euglucémica (CADE) — Glucosa &lt; 250 mg/dL (13.9 mmol/L) · SGLT-2i / embarazo / ayuno</option>
                    </select>
                </div>

                <div class="form-group">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Estado hemodinámico</label>
                    <select id="dkaHemo" required class="form-input">
                        <option value="mild">Hipovolemia leve-moderada (más frecuente)</option>
                        <option value="severe">Hipovolemia severa — signos de shock</option>
                        <option value="euvolemic">Euvolémico</option>
                        <option value="cardiogenic">Choque cardiogénico / Falla cardíaca</option>
                    </select>
                </div>
            </div>

            <!-- Sección 2: Laboratorio -->
            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:14px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:14px; text-transform:uppercase; letter-spacing:0.05em;">Laboratorio</div>

                <div style="display:grid; grid-template-columns:1fr auto; gap:8px; margin-bottom:14px; align-items:end;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Glucosa</label>
                        <input type="number" id="dkaGlucose" required step="any" min="30" max="2000" class="form-input" oninput="updateDKALiveCalcs()">
                    </div>
                    <select id="dkaGlucoseUnit" class="form-input" style="min-width:100px;" onchange="updateDKALiveCalcs()">
                        <option value="mg/dL" ${(Storage.getSetting('units.glucose')||'mg/dL')==='mg/dL' ? 'selected' : ''}>mg/dL</option>
                        <option value="mmol/L" ${Storage.getSetting('units.glucose')==='mmol/L' ? 'selected' : ''}>mmol/L</option>
                    </select>
                </div>

                <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:14px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">pH venoso/arterial</label>
                        <input type="number" id="dkaPh" required step="0.01" min="6.5" max="7.5" class="form-input" placeholder="ej. 7.15">
                        <p style="font-size:11px; color:var(--text-tertiary); margin-top:4px;">GSV tan confiable como GSA en CAD (ADA 2024)</p>
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">HCO₃⁻ (mEq/L)</label>
                        <input type="number" id="dkaHco3" required step="any" min="1" max="40" class="form-input" oninput="updateDKALiveCalcs()">
                    </div>
                </div>

                <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:14px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Na⁺ (mEq/L)</label>
                        <input type="number" id="dkaSodium" required step="any" min="115" max="170" class="form-input" oninput="updateDKALiveCalcs()">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">
                            K⁺ (mEq/L) <span style="color:#ef4444; font-size:11px;">crítico</span>
                        </label>
                        <input type="number" id="dkaPotassium" required step="0.1" min="1.5" max="8" class="form-input" id="dkaPotassium" oninput="updateDKALiveCalcs()">
                    </div>
                </div>

                <div class="form-group">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">
                        Cl⁻ (mEq/L)
                        <span style="font-size:11px; font-weight:500; color:var(--text-tertiary); margin-left:6px;">opcional — para calcular Anión Gap</span>
                    </label>
                    <input type="number" id="dkaChloride" step="any" min="85" max="130" class="form-input" placeholder="Dejar vacío si no disponible" oninput="updateDKALiveCalcs()">
                </div>
            </div>

            <!-- Cálculos en tiempo real -->
            <div id="dkaLiveCalcs"></div>

            <div style="background:#fef3c7; border-left:4px solid #f59e0b; padding:14px; border-radius:8px; margin-bottom:16px; margin-top:4px;">
                <p style="font-size:12px; color:#92400e; margin:0;">
                    <strong>⚠️ Herramienta de apoyo clínico</strong> — Verificar siempre con el equipo médico. Basado en ADA Consensus Report 2024 · JBDS 2023 · JAMA Netw Open 2020.
                </p>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">
                🧮 Generar Protocolo CAD/CADE
            </button>
        </form>
        <div id="dkaResult" style="display:none; margin-top:24px;"></div>
    `;
}

function updateDKALiveCalcs() {
    const glucoseUnit = document.getElementById('dkaGlucoseUnit')?.value || 'mg/dL';

    // Ajustar min/max del input de glucosa según la unidad seleccionada
    const glucoseField = document.getElementById('dkaGlucose');
    if (glucoseField) {
        if (glucoseUnit === 'mmol/L') {
            glucoseField.min  = '1.7';
            glucoseField.max  = '111';
            glucoseField.step = '0.1';
        } else {
            glucoseField.min  = '30';
            glucoseField.max  = '2000';
            glucoseField.step = 'any';
        }
    }

    const glucoseVal  = parseFloat(glucoseField?.value);
    const sodiumVal   = parseFloat(document.getElementById('dkaSodium')?.value);
    const chlorideVal = parseFloat(document.getElementById('dkaChloride')?.value);
    const hco3Val     = parseFloat(document.getElementById('dkaHco3')?.value);
    const kVal        = parseFloat(document.getElementById('dkaPotassium')?.value);
    const liveDiv     = document.getElementById('dkaLiveCalcs');
    if (!liveDiv) return;

    let glucoseMg = glucoseVal;
    if (glucoseUnit === 'mmol/L' && !isNaN(glucoseVal)) glucoseMg = glucoseVal / 0.0555;

    const naCorr = (!isNaN(sodiumVal) && !isNaN(glucoseMg))
        ? Math.round((sodiumVal + 2.4 * (glucoseMg - 100) / 100) * 10) / 10 : null;
    const ag = (!isNaN(sodiumVal) && !isNaN(chlorideVal) && !isNaN(hco3Val))
        ? Math.round((sodiumVal - (chlorideVal + hco3Val)) * 10) / 10 : null;
    const osm = (!isNaN(sodiumVal) && !isNaN(glucoseMg))
        ? Math.round((2 * sodiumVal + glucoseMg / 18) * 10) / 10 : null;

    // Color K+ field
    const kField = document.getElementById('dkaPotassium');
    if (kField && !isNaN(kVal)) {
        kField.style.borderColor = kVal < 3.3 ? '#dc2626' : '';
        kField.style.boxShadow   = kVal < 3.3 ? '0 0 0 3px rgba(220,38,38,0.15)' : '';
    }

    const hasData = naCorr !== null || ag !== null || osm !== null;
    if (!hasData) { liveDiv.innerHTML = ''; return; }

    let rows = '';
    if (naCorr !== null) {
        const c = naCorr > 150 ? '#f59e0b' : 'var(--success)';
        rows += `<div style="display:flex;justify-content:space-between;margin-bottom:6px;"><span>Na corregido (ADA 2024)</span><strong style="color:${c}">${naCorr} mEq/L${naCorr > 150 ? ' ⚠' : ''}</strong></div>`;
    }
    if (ag !== null) {
        const c = ag > 12 ? '#ef4444' : 'var(--success)';
        rows += `<div style="display:flex;justify-content:space-between;margin-bottom:6px;"><span>Anión Gap</span><strong style="color:${c}">${ag} mEq/L${ag > 12 ? ' ↑' : ''}</strong></div>`;
    }
    if (osm !== null) {
        rows += `<div style="display:flex;justify-content:space-between;"><span>Osmolaridad efectiva</span><strong>${osm} mOsm/kg</strong></div>`;
    }

    let kAlert = '';
    if (!isNaN(kVal) && kVal < 3.3) {
        kAlert = `<div style="background:#fef2f2;border:1px solid #dc2626;border-radius:6px;padding:8px;margin-top:8px;color:#dc2626;font-weight:700;font-size:12px;">⚠️ K⁺ ${kVal} mEq/L — RETENER INSULINA al generar el protocolo</div>`;
    }

    liveDiv.innerHTML = `<div style="background:var(--bg-secondary);padding:12px;border-radius:10px;margin-bottom:12px;font-size:13px;"><div style="font-size:11px;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.05em;margin-bottom:8px;">Cálculos automáticos</div>${rows}${kAlert}</div>`;
}

// Función reutilizable por calculateDKAProtocol y showFullResult
function buildDKAProtocolHTML(r, inputs) {
    const section = (icon, title, color, content) => `
        <div style="margin-bottom:12px; border-radius:var(--radius-lg); overflow:hidden; border:1px solid ${color}33;">
            <div style="background:${color}22; padding:12px 16px; display:flex; align-items:center; gap:8px; border-bottom:1px solid ${color}33;">
                <span style="font-size:18px;">${icon}</span>
                <span style="font-size:14px; font-weight:700; color:${color};">${title}</span>
            </div>
            <div style="padding:14px 16px; background:var(--bg-card); font-size:13px; line-height:1.8;">${content}</div>
        </div>`;

    const check = (met, label, actual, target) => {
        if (met === null) return `<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--border-color);"><span>${label}</span><span style="color:var(--text-tertiary);">No disponible</span></div>`;
        const ic = met ? '✅' : '❌';
        const co = met ? 'var(--success)' : 'var(--danger)';
        return `<div style="display:flex;justify-content:space-between;align-items:center;padding:4px 0;border-bottom:1px solid var(--border-color);"><span>${label} <span style="color:var(--text-tertiary);font-size:11px;">(actual: ${actual})</span></span><span style="color:${co};font-weight:700;">${ic} ${target}</span></div>`;
    };

    const headerHTML = `
        <div style="background:${r.severity.colorHex}; padding:20px; border-radius:var(--radius-lg); color:white; margin-bottom:12px;">
            <div style="font-size:22px; font-weight:800; margin-bottom:6px;">${r.severity.badge} ${r.severity.label}</div>
            <div style="font-size:13px; opacity:0.9; display:flex; flex-wrap:wrap; gap:12px;">
                <span>pH ${inputs.ph}</span><span>HCO₃ ${inputs.hco3} mEq/L</span>
                <span>Glucosa ${inputs.glucose} ${inputs.glucoseUnit}</span><span>K⁺ ${inputs.potassium} mEq/L</span>
            </div>
            <div style="margin-top:8px; font-size:12px; opacity:0.85; display:flex; gap:12px; flex-wrap:wrap;">
                <span>Na corregido: ${r.naCorregido} mEq/L</span>
                ${r.agCalc !== null ? `<span>AG: ${r.agCalc} mEq/L</span>` : ''}
                <span>Osm efectiva: ${r.osmEffective} mOsm/kg</span>
            </div>
        </div>`;

    const alertHTML = r.criticalAlert.hasAlert ? `
        <div style="background:#7f1d1d; color:#fca5a5; border:2px solid #dc2626; border-radius:var(--radius-lg); padding:16px; margin-bottom:12px; font-weight:700; font-size:14px; display:flex; align-items:center; gap:10px;">
            <span style="font-size:24px;">🚨</span><span>${r.criticalAlert.message}</span>
        </div>` : '';

    const cadeHTML = r.isCADE ? `
        <div style="background:#4c1d95; color:#c4b5fd; border:2px solid #7c3aed; border-radius:var(--radius-lg); padding:16px; margin-bottom:12px;">
            <div style="font-weight:700; font-size:14px; margin-bottom:6px;">🟣 CAD EUGLUCÉMICA (CADE)</div>
            <div style="font-size:13px; line-height:1.7;">
                • Glucosa aparentemente normal — no descartar CAD<br>
                • Dextrosa 5-10% <strong>DESDE EL INICIO</strong><br>
                • Suspender SGLT-2i inmediatamente si aplica<br>
                • Meta: cerrar el Anión Gap (no bajar glucosa)
            </div>
        </div>` : '';

    const kColor = r.potassium.holdInsulin ? '#dc2626' : '#f59e0b';

    const fluidContent = `
        <div><strong>Bolo inicial:</strong> <span style="color:var(--brand-accent);font-weight:700;">${r.fluids.bolusML} mL</span> de ${r.fluids.fluidType} en ${r.fluids.bolusTime}</div>
        <div><strong>Mantenimiento:</strong> 150–200 mL/h de cristaloide balanceado</div>
        <div><strong>Fluido recomendado:</strong> Ringer Lactato o Plasmalyte ✓ — <em>SS 0.9% genera AGMA hiperclorémica</em></div>
        <div><strong>Na corregido:</strong> ${r.fluids.naNote}</div>
        <div><strong>Agregar Dextrosa:</strong> ${r.fluids.dextroseStart}</div>
        ${r.fluids.hemodynamic === 'cardiogenic' ? '<div style="margin-top:4px;color:#f59e0b;font-weight:600;">⚠️ Choque cardiogénico — evaluar vasopresores desde el inicio</div>' : ''}`;

    const potassiumContent = `
        <div><strong>K⁺ actual:</strong> ${r.potassium.value} mEq/L</div>
        <div><strong>Acción:</strong> <span style="color:${kColor};font-weight:700;">${r.potassium.kAction}</span></div>
        ${r.potassium.kRate !== '—' ? `<div><strong>Velocidad:</strong> ${r.potassium.kRate}</div>` : ''}
        <div style="margin-top:4px;">${r.potassium.kNote}</div>
        <div style="margin-top:4px;color:var(--text-secondary);font-size:12px;">Fosfato: reponer solo si &lt; 1 mg/dL · Magnesio: reponer si bajo</div>`;

    const insulinContent = r.potassium.holdInsulin
        ? `<div style="color:#dc2626;font-weight:700;">⚠️ INSULINA EN ESPERA — Reiniciar cuando K⁺ ≥ 3.3 mEq/L</div>`
        : `<div><strong>Vía:</strong> ${r.insulin.insulinRoute} ${r.insulin.isSevereOrShock ? '(IV — caso severo/shock)' : '(IV o SC según severidad)'}</div>
           <div><strong>Insulina IV:</strong> <span style="color:var(--brand-accent);font-weight:700;">Regular 0.1 U/kg/h = ${r.insulin.doseIV} U/h</span></div>
           <div><strong>Si Glu &lt; 250 mg/dL:</strong> reducir a <strong>0.05 U/kg/h = ${r.insulin.doseIVReduced} U/h</strong> + Dextrosa</div>
           <div><strong>Insulina SC (leve/mod):</strong> Lispro/Aspart ${r.insulin.doseSCBolus} U · c/2h si Glu>250 · c/4h si Glu&lt;250</div>
           <div style="margin-top:4px;color:#dc2626;font-weight:600;">⛔ NO detener insulina IV — agregar Dextrosa hasta BA ≤ 12 + HCO₃ > 18</div>
           ${r.isCADE ? '<div style="margin-top:4px;color:#7c3aed;font-weight:600;">CADE: misma dosis — la insulina cierra el AG, no baja la glucosa</div>' : ''}`;

    const bicarboContent = r.bicarbonate.indicated
        ? `<div style="color:#dc2626;font-weight:700;">pH ${r.bicarbonate.ph} &lt; 6.9 — BICARBONATO INDICADO</div>
           <div>100 mEq NaHCO₃ en 400 mL agua + 20 mEq KCl en 2 h IV · Repetir c/2h hasta pH > 7.0</div>
           <div style="color:var(--text-secondary);">Monitorear K⁺ — el bicarbonato lo desplaza intracelularmente</div>`
        : `<div style="color:var(--success);font-weight:600;">pH ${r.bicarbonate.ph} ≥ 6.9 — No indicado</div>
           <div style="color:var(--text-secondary);">Uso rutinario no mejora outcomes y puede empeorar la hipocalemia.</div>`;

    const resContent = `
        ${check(r.resolution.agMet, 'Brecha Aniónica', r.resolution.agCalc !== null ? `${r.resolution.agCalc} mEq/L` : 'no calculada', '≤ 12 mEq/L')}
        ${check(r.resolution.hco3Met, 'HCO₃⁻', `${r.resolution.hco3} mEq/L`, '> 18 mEq/L')}
        ${check(r.resolution.phMet, 'pH', r.resolution.ph, '> 7.30')}
        <div style="padding:4px 0;border-bottom:1px solid var(--border-color);">Tolerancia a vía oral — confirmar clínicamente</div>
        <div style="padding:4px 0;">β-hidroxibutirato &lt; 0.6 mmol/L — si disponible</div>`;

    const transContent = `
        <div><strong>Criterio:</strong> BA ≤ 12 + HCO₃ > 18 + tolerando VO</div>
        <div><strong>Glargina:</strong> 0.5–0.8 U/kg/día = <span style="color:var(--brand-accent);font-weight:700;">${r.transition.glarginMin}–${r.transition.glarginMax} U/día</span></div>
        <div>50% basal (glargina) · 50% bolo (aspart/lispro con comidas)</div>
        <div style="color:#dc2626;font-weight:600;">⛔ Mantener infusión IV 2 h tras la primera glargina</div>
        <div style="color:var(--text-secondary);font-size:12px;">t½ plasmático insulina IV = 6 min — suspensión brusca reinicia cetogénesis</div>`;

    return `${headerHTML}${alertHTML}${cadeHTML}
        ${section('💧', '1. Fluidos IV', '#3b82f6', fluidContent)}
        ${section('🧪', '2. Potasio', r.potassium.holdInsulin ? '#dc2626' : '#f59e0b', potassiumContent)}
        ${section('💉', '3. Insulina', '#22c55e', insulinContent)}
        ${section('🔬', '4. Bicarbonato', r.bicarbonate.indicated ? '#dc2626' : '#6366f1', bicarboContent)}
        ${section('📋', '5. Criterios de Resolución', '#8b5cf6', resContent)}
        ${section('🔄', '6. Transición a Insulina SC', '#14b8a6', transContent)}`;
}

function calculateDKAProtocol(event) {
    event.preventDefault();
    const chlorideRaw = document.getElementById('dkaChloride').value;
    const inputs = {
        weight:      parseFloat(document.getElementById('dkaWeight').value),
        type:        document.getElementById('dkaType').value,
        hemodynamic: document.getElementById('dkaHemo').value,
        glucose:     parseFloat(document.getElementById('dkaGlucose').value),
        glucoseUnit: document.getElementById('dkaGlucoseUnit').value,
        ph:          parseFloat(document.getElementById('dkaPh').value),
        hco3:        parseFloat(document.getElementById('dkaHco3').value),
        sodium:      parseFloat(document.getElementById('dkaSodium').value),
        potassium:   parseFloat(document.getElementById('dkaPotassium').value),
        chloride:    chlorideRaw === '' ? null : parseFloat(chlorideRaw)
    };
    const r = Calculators.calculateDKA(inputs);
    const container = document.getElementById('dkaResult');
    container.innerHTML = buildDKAProtocolHTML(r, inputs) + `
        <button class="btn btn-secondary" onclick="document.getElementById('dkaForm').reset(); document.getElementById('dkaResult').style.display='none'; document.getElementById('dkaLiveCalcs').innerHTML='';" style="width:100%; margin-top:12px;">
            🔄 Nuevo Protocolo
        </button>`;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 28, calculatorName: 'CAD / CADE', inputs, result: r, interpretation: r.interpretation });
}

// === 31. ASMA AGUDA — CRISIS BRONQUIAL === //
function createAsmaForm() {
    const wUnit = Storage.getSetting('units.weight') || 'kg';
    return `
        <form id="asmaForm" onsubmit="calculateAsmaProtocol(event)">

            <!-- Sección 1: Paciente -->
            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:14px; text-transform:uppercase; letter-spacing:0.05em;">Datos del Paciente</div>
                <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Edad (años)</label>
                        <input type="number" id="asmaAge" min="14" max="120" class="form-input" placeholder="ej: 35">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Peso (${wUnit})</label>
                        <input type="number" id="asmaWeight" required step="any" min="20" max="300" class="form-input" placeholder="ej: 70" oninput="updateAsmaLiveCalcs()">
                    </div>
                </div>
            </div>

            <!-- Sección 2: Evaluación clínica -->
            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:14px; text-transform:uppercase; letter-spacing:0.05em;">⚡ Evaluación Clínica</div>

                <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:14px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">SpO₂ (%)</label>
                        <input type="number" id="asmaSpo2" required min="60" max="100" class="form-input" placeholder="ej: 95" oninput="updateAsmaLiveCalcs()">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">FC (lpm)</label>
                        <input type="number" id="asmaHr" required min="40" max="250" class="form-input" placeholder="ej: 110" oninput="updateAsmaLiveCalcs()">
                    </div>
                </div>

                <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:14px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">FR (rpm)</label>
                        <input type="number" id="asmaRr" required min="8" max="80" class="form-input" placeholder="ej: 22" oninput="updateAsmaLiveCalcs()">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">
                            FEM (% mejor personal)
                            <span style="font-size:11px; font-weight:400; color:var(--text-tertiary);">opcional</span>
                        </label>
                        <input type="number" id="asmaFem" min="0" max="100" class="form-input" placeholder="ej: 60" oninput="updateAsmaLiveCalcs()">
                    </div>
                </div>

                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Habla</label>
                    <select id="asmaSpeech" required class="form-input" onchange="updateAsmaLiveCalcs()">
                        <option value="">-- Seleccionar --</option>
                        <option value="sentences">Frases completas</option>
                        <option value="phrases">Solo frases cortas</option>
                        <option value="words">Solo palabras</option>
                        <option value="unable">Incapaz de hablar</option>
                    </select>
                </div>

                <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:14px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Músculos accesorios</label>
                        <select id="asmaAccessory" required class="form-input" onchange="updateAsmaLiveCalcs()">
                            <option value="">-- Seleccionar --</option>
                            <option value="no">No</option>
                            <option value="si">Sí (uso activo)</option>
                        </select>
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Sibilancias</label>
                        <select id="asmaWheeze" required class="form-input" onchange="updateAsmaLiveCalcs()">
                            <option value="">-- Seleccionar --</option>
                            <option value="expiratory">Espiratorias</option>
                            <option value="biphasic">Bifásicas (insp + esp)</option>
                            <option value="silent">Silencio torácico ⚠️</option>
                        </select>
                    </div>
                </div>

                <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Nivel de conciencia</label>
                        <select id="asmaConsciousness" required class="form-input" onchange="updateAsmaLiveCalcs()">
                            <option value="">-- Seleccionar --</option>
                            <option value="alert">Alerta</option>
                            <option value="confused">Confuso / somnoliento</option>
                        </select>
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Cianosis</label>
                        <select id="asmaCyanosis" required class="form-input" onchange="updateAsmaLiveCalcs()">
                            <option value="">-- Seleccionar --</option>
                            <option value="no">No</option>
                            <option value="si">Sí</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Sección 3: Gasometría (opcional) -->
            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:14px; text-transform:uppercase; letter-spacing:0.05em;">
                    Gasometría <span style="font-size:11px; font-weight:500; text-transform:none;">(opcional)</span>
                </div>
                <div class="form-group">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">PaCO₂ (mmHg)</label>
                    <input type="number" id="asmaPaco2" min="10" max="100" step="0.1" class="form-input" placeholder="ej: 38 — ≥ 45 indica agotamiento ventilatorio" oninput="updateAsmaLiveCalcs()">
                    <p style="font-size:11px; color:var(--text-tertiary); margin-top:4px;">PaCO₂ normal o elevada en crisis grave = fallo ventilatorio inminente</p>
                </div>
            </div>

            <!-- Clasificación en tiempo real -->
            <div id="asmaLiveCalcs"></div>

            <div style="background:#fef3c7; border-left:4px solid #f59e0b; padding:14px; border-radius:8px; margin-bottom:16px;">
                <p style="font-size:12px; color:#92400e; margin:0;">
                    <strong>⚠️ Herramienta de apoyo clínico</strong> — Verificar siempre con el equipo médico. Basado en GINA 2024 · BTS-SIGN 2023 · ERS/ATS 2022.
                </p>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">
                ⚡ Generar Protocolo de Tratamiento
            </button>
        </form>
        <div id="asmaResult" style="display:none; margin-top:24px;"></div>
    `;
}

function updateAsmaLiveCalcs() {
    const container = document.getElementById('asmaLiveCalcs');
    if (!container) return;

    const spo2Val  = document.getElementById('asmaSpo2').value;
    const hrVal    = document.getElementById('asmaHr').value;
    const rrVal    = document.getElementById('asmaRr').value;
    const femVal   = document.getElementById('asmaFem').value;
    const paco2Val = document.getElementById('asmaPaco2').value;
    const speech        = document.getElementById('asmaSpeech').value;
    const accessory     = document.getElementById('asmaAccessory').value;
    const wheeze        = document.getElementById('asmaWheeze').value;
    const consciousness = document.getElementById('asmaConsciousness').value;
    const cyanosis      = document.getElementById('asmaCyanosis').value;

    const spo2  = spo2Val  !== '' ? parseFloat(spo2Val)  : null;
    const hr    = hrVal    !== '' ? parseFloat(hrVal)    : null;
    const rr    = rrVal    !== '' ? parseFloat(rrVal)    : null;
    const fem   = femVal   !== '' ? parseFloat(femVal)   : null;
    const paco2 = paco2Val !== '' ? parseFloat(paco2Val) : null;

    const anyFilled = spo2 !== null || hr !== null || rr !== null || fem !== null || speech || wheeze || consciousness || cyanosis;
    if (!anyFilled) { container.innerHTML = ''; return; }

    const fatal = [];
    if (spo2 !== null && spo2 < 90)    fatal.push(`SpO₂ ${spo2}% (<90%)`);
    if (fem !== null && fem < 33)       fatal.push(`FEM ${fem}% (<33%)`);
    if (wheeze === 'silent')            fatal.push('Silencio torácico');
    if (cyanosis === 'si')              fatal.push('Cianosis');
    if (consciousness === 'confused')   fatal.push('Confuso/somnoliento');
    if (paco2 !== null && paco2 >= 45)  fatal.push(`PaCO₂ ${paco2} mmHg (≥45)`);

    const severe = [];
    if (!fatal.length) {
        if (spo2 !== null && spo2 >= 90 && spo2 <= 93)     severe.push(`SpO₂ ${spo2}% (90-93%)`);
        if (fem !== null && fem >= 33 && fem <= 50)          severe.push(`FEM ${fem}% (33-50%)`);
        if (speech === 'words' || speech === 'unable')        severe.push('Solo palabras / Incapaz de hablar');
        if (hr !== null && hr >= 120)                         severe.push(`FC ${hr} lpm (≥120)`);
        if (rr !== null && rr >= 25)                          severe.push(`FR ${rr} rpm (≥25)`);
        if (accessory === 'si')                               severe.push('Músculos accesorios activos');
    }

    const moderate = [];
    if (!fatal.length && !severe.length) {
        if (spo2 !== null && spo2 >= 94 && spo2 <= 96)      moderate.push(`SpO₂ ${spo2}% (94-96%)`);
        if (fem !== null && fem >= 51 && fem <= 75)           moderate.push(`FEM ${fem}% (51-75%)`);
        if (speech === 'phrases')                              moderate.push('Solo frases cortas');
        if (hr !== null && hr >= 100 && hr < 120)             moderate.push(`FC ${hr} lpm (100-119)`);
        if (rr !== null && rr >= 20 && rr < 25)               moderate.push(`FR ${rr} rpm (20-24)`);
    }

    let badge, label, color, criteria;
    if (fatal.length)        { badge = '🔴'; label = 'POTENCIALMENTE FATAL'; color = '#dc2626'; criteria = fatal; }
    else if (severe.length)  { badge = '🟠'; label = 'GRAVE';                color = '#ea580c'; criteria = severe; }
    else if (moderate.length){ badge = '🟡'; label = 'MODERADA';             color = '#ca8a04'; criteria = moderate; }
    else                     { badge = '🟢'; label = 'LEVE';                 color = '#16a34a'; criteria = []; }

    container.innerHTML = `
        <div style="background:${color}22; border:1px solid ${color}55; border-radius:10px; padding:14px; margin-bottom:16px;">
            <div style="font-size:13px; font-weight:700; color:${color}; margin-bottom:${criteria.length ? 6 : 0}px;">${badge} Clasificación estimada: ${label}</div>
            ${criteria.length
                ? `<div style="font-size:12px; color:${color}cc; line-height:1.6;">Criterios: ${criteria.join(' · ')}</div>`
                : '<div style="font-size:12px; color:#9ca3af;">Complete los campos para refinar la clasificación</div>'
            }
        </div>`;
}

function buildAsmaProtocolHTML(r, inputs) {
    const { severity, o2, saba, ipratropium, cortico, magnesio, aminofilina, admision, alta, isFatal, isSevere } = r;
    const c = severity.colorHex;
    let sn = 1;

    function section(icon, title, color, content) {
        return `
        <div style="background:${color}18; border:1px solid ${color}33; border-radius:10px; margin-bottom:12px; overflow:hidden;">
            <div style="background:${color}28; border-bottom:1px solid ${color}33; padding:11px 16px; display:flex; align-items:center; gap:8px;">
                <span style="font-size:17px;">${icon}</span>
                <span style="font-size:14px; font-weight:700; color:${color};">${title}</span>
            </div>
            <div style="padding:13px 16px; font-size:13px; line-height:1.85; color:var(--text-primary);">${content}</div>
        </div>`;
    }

    // Header
    let html = `
    <div style="background:${c}; border-radius:12px; padding:20px; margin-bottom:16px; color:white;">
        <div style="font-size:12px; font-weight:600; opacity:0.85; margin-bottom:4px; text-transform:uppercase; letter-spacing:0.05em;">Crisis Aguda de Asma Bronquial</div>
        <div style="font-size:22px; font-weight:800; margin-bottom:12px;">${severity.badge} ${severity.label}</div>
        <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:8px; font-size:12px;">
            ${inputs.spo2   ? `<div><div style="opacity:0.75;">SpO₂</div><div style="font-weight:700;">${inputs.spo2}%</div></div>` : ''}
            ${inputs.hr     ? `<div><div style="opacity:0.75;">FC</div><div style="font-weight:700;">${inputs.hr} lpm</div></div>` : ''}
            ${inputs.rr     ? `<div><div style="opacity:0.75;">FR</div><div style="font-weight:700;">${inputs.rr} rpm</div></div>` : ''}
            ${inputs.fem    ? `<div><div style="opacity:0.75;">FEM</div><div style="font-weight:700;">${inputs.fem}%</div></div>` : ''}
            ${inputs.paco2  ? `<div><div style="opacity:0.75;">PaCO₂</div><div style="font-weight:700;">${inputs.paco2} mmHg</div></div>` : ''}
            ${r.weightKg    ? `<div><div style="opacity:0.75;">Peso</div><div style="font-weight:700;">${r.weightKg} kg</div></div>` : ''}
        </div>
    </div>`;

    if (isFatal) {
        html += `<div style="background:#7f1d1d; border:1px solid #ef4444; border-radius:10px; padding:14px; margin-bottom:12px; color:#fca5a5;">
            🚨 <strong>CRISIS POTENCIALMENTE FATAL</strong> — Activar equipo de emergencias · Preparar vía aérea · Ingreso en UCI inmediato
        </div>`;
    }

    if (inputs.wheeze === 'silent') {
        html += `<div style="background:#431407; border:1px solid #f97316; border-radius:10px; padding:14px; margin-bottom:12px; color:#fdba74;">
            ⚠️ <strong>Silencio torácico:</strong> Obstrucción crítica — ausencia de sibilancias NO indica mejoría. Fallo ventilatorio inminente. Evaluar intubación de urgencia.
        </div>`;
    }

    // 1. Oxigenoterapia
    html += section('💨', `${sn++}. Oxigenoterapia`, '#3b82f6',
        o2.needed
            ? `<b>Iniciar O₂</b> — Objetivo: SpO₂ ${o2.target}<br><b>Dispositivo:</b> ${o2.device}`
            : `SpO₂ ${inputs.spo2}% — O₂ suplementario no requerido inicialmente. Monitorizar SpO₂ continuamente.`
    );

    // 2. Salbutamol
    let sabaContent;
    if (isFatal) {
        sabaContent = `<b>Salbutamol IV:</b> ${saba.ivDose}<br>
            <b>Preparación:</b> ${saba.ivPrep}<br>
            <b>Nebulizado simultáneo:</b> ${saba.nebDose}<br>
            <span style="color:#f87171;">⚠️ ${saba.note}</span>`;
    } else if (isSevere) {
        sabaContent = `<b>Nebulizado:</b> ${saba.nebDose}<br>
            <b>Alternativa MDI + cámara:</b> ${saba.mdiDose}`;
    } else {
        sabaContent = `<b>MDI + cámara espaciadora:</b> ${saba.mdiDose}<br>
            <b>Alternativa nebulizado:</b> ${saba.nebDose}`;
    }
    html += section('🫁', `${sn++}. Salbutamol (SABA)`, '#22c55e', sabaContent);

    // 3. Ipratropio (condicional)
    if (ipratropium.indicated) {
        html += section('🔵', `${sn++}. Ipratropio (Anticolinérgico)`, '#8b5cf6',
            `<b>Nebulizado:</b> ${ipratropium.nebDose}<br>
             <b>MDI + cámara:</b> ${ipratropium.mdiDose}<br>
             Puede combinarse con salbutamol en el mismo nebulizador`);
    }

    // 4. Corticosteroides
    let corticoContent = `<b>${cortico.drug1}</b>`;
    if (cortico.drug2) corticoContent += `<br>o bien <b>${cortico.drug2}</b>`;
    corticoContent += `<br><b>Duración:</b> ${cortico.duration}<br><span style="color:#fbbf24;">⏱️ ${cortico.note}</span>`;
    html += section('💊', `${sn++}. Corticosteroides`, '#f59e0b', corticoContent);

    // 5. MgSO4 (condicional)
    if (magnesio.indicated) {
        html += section('🧲', `${sn++}. Sulfato de Magnesio`, '#06b6d4',
            `<b>Dosis:</b> ${magnesio.dose}<br>
             <b>Cuándo:</b> ${magnesio.when}<br>
             <b>Precaución:</b> ${magnesio.caution}`);
    }

    // 6. Aminofilina (condicional, solo fatal)
    if (aminofilina.indicated) {
        html += section('⚠️', `${sn++}. Aminofilina (2ª línea — rescate)`, '#dc2626',
            `<b>Carga:</b> ${aminofilina.loading}<br>
             <span style="color:#f87171;">${aminofilina.loadingNote}</span><br>
             <b>Mantenimiento:</b> ${aminofilina.maintenance}<br>
             <span style="color:#fbbf24;">⚠️ ${aminofilina.warning}</span>`);
    }

    // Destino y monitorización
    let admiContent;
    if (admision.icu) {
        admiContent = `🔴 <b>INGRESO EN UCI / ÁREA DE CRÍTICOS</b><br>${admision.criteria}<br><br>
            <b>Monitorización:</b> ECG continuo · SpO₂ · Capnografía · Gasometría seriada · IOT si deterioro`;
    } else if (admision.required) {
        admiContent = `🟠 <b>INGRESO HOSPITALARIO</b><br>${admision.criteria}<br><br>
            <b>Reevaluar a los 30-60 min:</b> SpO₂ · FC · FR · FEM<br>
            <b>Criterios de alta diferida:</b> FEM ≥ 50% + SpO₂ ≥ 94% estable`;
    } else {
        admiContent = `🟢 <b>Alta a domicilio</b> si cumple todos los criterios tras observación:<br>
            ${alta.criteria.map(x => `• ${x}`).join('<br>')}`;
    }
    html += section('📋', `${sn++}. Destino y Monitorización`, '#64748b', admiContent);

    html += `<div style="font-size:11px; color:#64748b; text-align:right; margin-top:4px; padding:0 4px;">
        GINA 2024 · BTS-SIGN 2023 · ERS/ATS 2022</div>`;

    return html;
}

function calculateAsmaProtocol(event) {
    event.preventDefault();
    const ageRaw   = document.getElementById('asmaAge').value;
    const femRaw   = document.getElementById('asmaFem').value;
    const paco2Raw = document.getElementById('asmaPaco2').value;
    const inputs = {
        age:           ageRaw   !== '' ? parseFloat(ageRaw)   : null,
        weight:        parseFloat(document.getElementById('asmaWeight').value),
        spo2:          parseFloat(document.getElementById('asmaSpo2').value),
        hr:            parseFloat(document.getElementById('asmaHr').value),
        rr:            parseFloat(document.getElementById('asmaRr').value),
        speech:        document.getElementById('asmaSpeech').value,
        accessory:     document.getElementById('asmaAccessory').value,
        wheeze:        document.getElementById('asmaWheeze').value,
        consciousness: document.getElementById('asmaConsciousness').value,
        cyanosis:      document.getElementById('asmaCyanosis').value,
        fem:           femRaw   !== '' ? parseFloat(femRaw)   : null,
        paco2:         paco2Raw !== '' ? parseFloat(paco2Raw) : null,
    };
    const r = Calculators.calculateAsma(inputs);
    const container = document.getElementById('asmaResult');
    container.innerHTML = buildAsmaProtocolHTML(r, inputs) + `
        <button class="btn btn-secondary" onclick="document.getElementById('asmaForm').reset(); document.getElementById('asmaResult').style.display='none'; document.getElementById('asmaLiveCalcs').innerHTML='';" style="width:100%; margin-top:12px;">
            🔄 Nueva Evaluación
        </button>`;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 31, calculatorName: 'Asma Aguda', inputs, result: r, interpretation: r.interpretation });
}

// === 32. CONTROL ASMA CRÓNICA — CLASIFICACIÓN Y ESCALÓN === //
function createAsmaControlForm() {
    return `
        <form id="asmaControlForm" onsubmit="calculateAsmaControlProtocol(event)">

            <!-- Sección 1: Situación actual -->
            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:14px; text-transform:uppercase; letter-spacing:0.05em;">Situación Actual</div>

                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">¿El paciente está actualmente en tratamiento para asma?</label>
                    <select id="acEnTratamiento" required class="form-input" onchange="updateAsmaControlLiveCalcs(); _acToggleTratamiento(this.value)">
                        <option value="">-- Seleccionar --</option>
                        <option value="no">No — Diagnóstico inicial / Virgen a tratamiento</option>
                        <option value="si">Sí — Ya está en tratamiento</option>
                    </select>
                </div>

                <div id="acTratamientoFields" style="display:none;">
                    <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                        <div>
                            <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Escalón actual</label>
                            <select id="acEscalon" class="form-input" onchange="updateAsmaControlLiveCalcs()">
                                <option value="1">Escalón 1 — Solo rescate PRN</option>
                                <option value="2">Escalón 2 — ICS dosis baja</option>
                                <option value="3">Escalón 3 — ICS + LABA</option>
                                <option value="4">Escalón 4 — ICS alta dosis + LABA</option>
                                <option value="5">Escalón 5 — Biológicos / add-ons</option>
                            </select>
                        </div>
                        <div>
                            <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Tiempo en escalón actual</label>
                            <select id="acTiempoEscalon" class="form-input" onchange="updateAsmaControlLiveCalcs()">
                                <option value="lt3">< 3 meses</option>
                                <option value="gte3">≥ 3 meses</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sección 2: Síntomas últimas 4 semanas -->
            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:14px; text-transform:uppercase; letter-spacing:0.05em;">Síntomas — Últimas 4 Semanas</div>

                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Síntomas diurnos</label>
                    <select id="acSintomasDiurnos" required class="form-input" onchange="updateAsmaControlLiveCalcs()">
                        <option value="">-- Seleccionar --</option>
                        <option value="none">Ninguno</option>
                        <option value="lte2">≤ 2 días/semana</option>
                        <option value="gt2">> 2 días/sem (pero no diarios)</option>
                        <option value="daily">Diarios o continuos</option>
                    </select>
                </div>

                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Despertares nocturnos</label>
                    <select id="acSintomasNocturnos" required class="form-input" onchange="updateAsmaControlLiveCalcs()">
                        <option value="">-- Seleccionar --</option>
                        <option value="none">Ninguno</option>
                        <option value="lte2">≤ 2 veces/mes</option>
                        <option value="gt2">> 2 veces/mes (pero no semanales)</option>
                        <option value="frequent">Frecuentes — ≥ 1 vez/semana</option>
                    </select>
                </div>

                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Limitación de actividad</label>
                    <select id="acLimitacion" required class="form-input" onchange="updateAsmaControlLiveCalcs()">
                        <option value="">-- Seleccionar --</option>
                        <option value="none">Ninguna</option>
                        <option value="alguna">Alguna</option>
                        <option value="bastante">Bastante</option>
                        <option value="total">Importante / Total</option>
                    </select>
                </div>

                <div class="form-group">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Uso de inhalador de rescate</label>
                    <select id="acRescate" required class="form-input" onchange="updateAsmaControlLiveCalcs()">
                        <option value="">-- Seleccionar --</option>
                        <option value="lte2">≤ 2 días/semana</option>
                        <option value="gt2">> 2 días/semana</option>
                    </select>
                </div>
            </div>

            <!-- Sección 3: Función pulmonar (opcional) -->
            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:14px; text-transform:uppercase; letter-spacing:0.05em;">
                    Función Pulmonar <span style="font-size:11px; font-weight:500; text-transform:none;">(opcional)</span>
                </div>
                <div class="form-group">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">FEV1 o FEM (% del predicho)</label>
                    <select id="acFev1fem" class="form-input" onchange="updateAsmaControlLiveCalcs()">
                        <option value="none">No disponible / No medido</option>
                        <option value="gte80">≥ 80% — Normal</option>
                        <option value="60-79">60-79% — Reducido</option>
                        <option value="lt60">< 60% — Muy reducido</option>
                    </select>
                </div>
            </div>

            <!-- Sección 4: Factores de riesgo -->
            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:14px; text-transform:uppercase; letter-spacing:0.05em;">Factores de Riesgo</div>

                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Exacerbaciones en el último año</label>
                    <select id="acExacerbaciones" class="form-input" onchange="updateAsmaControlLiveCalcs()">
                        <option value="none">Ninguna</option>
                        <option value="1">1 exacerbación</option>
                        <option value="gte2">≥ 2 exacerbaciones</option>
                    </select>
                </div>

                <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">OCS sistémicos en el último año</label>
                        <select id="acOcs" class="form-input" onchange="updateAsmaControlLiveCalcs()">
                            <option value="no">No</option>
                            <option value="si">Sí</option>
                        </select>
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Tabaquismo activo</label>
                        <select id="acTabaco" class="form-input" onchange="updateAsmaControlLiveCalcs()">
                            <option value="no">No</option>
                            <option value="si">Sí (fumador activo)</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Live calcs -->
            <div id="acLiveCalcs"></div>

            <div style="background:#fef3c7; border-left:4px solid #f59e0b; padding:14px; border-radius:8px; margin-bottom:16px;">
                <p style="font-size:12px; color:#92400e; margin:0;">
                    <strong>⚕️ Herramienta de apoyo clínico</strong> — Verificar siempre la técnica inhalatoria y adherencia antes de subir escalón. Fuentes: GINA 2024 · SEPAR 2023 · ALAT 2023.
                </p>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">
                🫁 Generar Recomendación de Tratamiento
            </button>
        </form>
        <div id="acResult" style="display:none; margin-top:24px;"></div>
    `;
}

function _acToggleTratamiento(val) {
    const el = document.getElementById('acTratamientoFields');
    if (el) el.style.display = val === 'si' ? 'block' : 'none';
}

function updateAsmaControlLiveCalcs() {
    const container = document.getElementById('acLiveCalcs');
    if (!container) return;

    const enTrat  = document.getElementById('acEnTratamiento').value;
    const diurnos = document.getElementById('acSintomasDiurnos').value;
    const noct    = document.getElementById('acSintomasNocturnos').value;
    const lim     = document.getElementById('acLimitacion').value;
    const resc    = document.getElementById('acRescate').value;

    if (!enTrat || !diurnos || !noct || !lim || !resc) {
        container.innerHTML = '';
        return;
    }

    // Control score (GINA)
    let score = 0;
    if (diurnos === 'gt2' || diurnos === 'daily') score++;
    if (lim !== 'none') score++;
    if (noct === 'gt2' || noct === 'frequent') score++;
    if (resc === 'gt2') score++;

    let badge, label, color;
    if (score === 0)       { badge = '✅'; label = 'Bien controlado';          color = '#16a34a'; }
    else if (score <= 2)   { badge = '⚠️'; label = 'Parcialmente controlado'; color = '#ca8a04'; }
    else                   { badge = '🔴'; label = 'No controlado';            color = '#dc2626'; }

    const criterios = [];
    if (score > 0) {
        if (diurnos === 'gt2' || diurnos === 'daily') criterios.push('Síntomas diurnos > 2 días/sem');
        if (lim !== 'none') criterios.push('Limitación de actividad');
        if (noct === 'gt2' || noct === 'frequent') criterios.push('Despertares nocturnos');
        if (resc === 'gt2') criterios.push('Rescate > 2 días/sem');
    }

    container.innerHTML = `
        <div style="background:${color}22; border:1px solid ${color}55; border-radius:10px; padding:14px; margin-bottom:16px;">
            <div style="font-size:13px; font-weight:700; color:${color}; margin-bottom:${criterios.length ? 6 : 0}px;">${badge} Control estimado: ${label} (${score}/4 criterios)</div>
            ${criterios.length
                ? `<div style="font-size:12px; color:${color}cc; line-height:1.6;">Criterios presentes: ${criterios.join(' · ')}</div>`
                : '<div style="font-size:12px; color:#9ca3af;">Ningún criterio de mal control — asma bien controlada</div>'
            }
        </div>`;
}

function buildAsmaControlProtocolHTML(r, inputs) {
    const { enTratamiento, control, severidad, escalonActual, escalonRec, cambio,
            escalonData, riesgos, derivar, controlScore } = r;
    const c = escalonData.colorHex;
    let sn = 1;

    function section(icon, title, color, content) {
        return `
        <div style="background:${color}18; border:1px solid ${color}33; border-radius:10px; margin-bottom:12px; overflow:hidden;">
            <div style="background:${color}28; border-bottom:1px solid ${color}33; padding:11px 16px; display:flex; align-items:center; gap:8px;">
                <span style="font-size:17px;">${icon}</span>
                <span style="font-size:14px; font-weight:700; color:${color};">${title}</span>
            </div>
            <div style="padding:13px 16px; font-size:13px; line-height:1.85; color:var(--text-primary);">${content}</div>
        </div>`;
    }

    // Header
    const esNuevo  = enTratamiento === 'no';
    const cambioIcon = cambio === 'subir' ? '⬆️' : cambio === 'bajar' ? '⬇️' : cambio === 'mantener' ? '↔️' : '▶️';
    const cambioLabel = cambio === 'subir' ? 'Subir escalón' : cambio === 'bajar' ? 'Bajar escalón' : cambio === 'mantener' ? 'Mantener escalón' : 'Escalón inicial';

    let html = `
    <div style="background:${c}; border-radius:12px; padding:20px; margin-bottom:16px; color:white;">
        <div style="font-size:12px; font-weight:600; opacity:0.85; margin-bottom:4px; text-transform:uppercase; letter-spacing:0.05em;">
            ${esNuevo ? 'Clasificación y Tratamiento del Asma' : 'Control del Asma — Seguimiento'}
        </div>
        <div style="font-size:20px; font-weight:800; margin-bottom:6px;">
            ${esNuevo ? `${severidad.badge} ${severidad.label}` : `${control.badge} ${control.label}`}
        </div>
        <div style="display:flex; align-items:center; gap:10px; font-size:14px; opacity:0.9; margin-bottom:10px;">
            ${escalonActual ? `<span>Escalón ${escalonActual}</span><span>${cambioIcon}</span>` : ''}
            <span style="font-weight:700; font-size:16px;">${escalonData.label} ${cambioIcon} ${cambioLabel}</span>
        </div>
        ${!esNuevo ? `<div style="font-size:12px; opacity:0.8;">${controlScore}/4 criterios de mal control</div>` : ''}
    </div>`;

    // Derivación urgente
    if (derivar) {
        html += `<div style="background:#431407; border:1px solid #f97316; border-radius:10px; padding:14px; margin-bottom:12px; color:#fdba74;">
            🏥 <strong>Derivar a Neumología / Alergología</strong> — Escalón 4-5 o asma de difícil control. Evaluar fenotipo para biológicos.
        </div>`;
    }

    // 1. Evaluación de control (solo si en tratamiento)
    if (!esNuevo) {
        const ajuste = cambio === 'subir'
            ? `Subir a ${escalonData.label}: asma no controlada con tratamiento actual. Antes de subir: verificar técnica inhalatoria y adherencia.`
            : cambio === 'bajar'
            ? `Considerar bajar a ${escalonData.label}: bien controlada ≥ 3 meses. Reducir 25-50% dosis ICS. Reevaluar en 4-6 semanas.`
            : `Mantener ${escalonData.label}: continuar tratamiento actual. Reevaluar en 3-6 meses.`;
        html += section('📊', `${sn++}. Evaluación de Control`, c,
            `<b>Control:</b> ${control.badge} ${control.label} (${controlScore}/4 criterios)<br>
             <b>Recomendación:</b> ${ajuste}`);
    }

    // 2. Controlador
    if (escalonData.controlador) {
        let ctContent = `<b>${escalonData.controlador}</b><br>
            <div style="white-space:pre-line; margin: 6px 0 6px 8px;">${escalonData.controladorDetalle}</div>`;
        if (escalonData.controladorAlt) {
            ctContent += `<br><b>Opciones adicionales:</b> ${escalonData.controladorAlt}`;
        }
        if (escalonData.smart) {
            ctContent += `<br><span style="color:#38bdf8;"><b>💡 SMART disponible:</b> ${escalonData.rescatadorDetalle}</span>`;
        }
        html += section('💊', `${sn++}. Medicación Controladora`, c, ctContent);
    } else {
        html += section('💊', `${sn++}. Medicación Controladora`, '#16a34a',
            'Sin controlador diario necesario en Escalón 1. Si se usa rescate > 2 días/semana de forma consistente → subir a Escalón 2.');
    }

    // 3. Rescatador
    const rescContent = `<b>${escalonData.rescatador}</b><br>${escalonData.rescatadorDetalle}`;
    html += section('🫁', `${sn++}. Inhalador de Rescate (SABA / ICS-Formoterol)`, '#3b82f6', rescContent);

    // 4. Biológicos (solo escalón 5)
    if (escalonRec === 5 && escalonData.biologicos) {
        const bio = escalonData.biologicos;
        const bioContent = `
            <div style="margin-bottom:10px; padding:10px; background:#7c3aed22; border-radius:8px;">
                <div style="font-weight:700; color:#a78bfa; margin-bottom:4px;">🧬 ${bio.alergico.fenotipo}</div>
                <b>Fármaco:</b> ${bio.alergico.farmacos}<br>
                <b>Indicación:</b> ${bio.alergico.indicacion}
            </div>
            <div style="margin-bottom:10px; padding:10px; background:#dc262622; border-radius:8px;">
                <div style="font-weight:700; color:#f87171; margin-bottom:4px;">🔬 ${bio.eosinofilico.fenotipo}</div>
                <b>Fármacos:</b> ${bio.eosinofilico.farmacos}<br>
                <b>Indicación:</b> ${bio.eosinofilico.indicacion}
            </div>
            <div style="padding:10px; background:#0284c722; border-radius:8px;">
                <div style="font-weight:700; color:#38bdf8; margin-bottom:4px;">💉 ${bio.tipo2.fenotipo}</div>
                <b>Fármaco:</b> ${bio.tipo2.farmacos}<br>
                <b>Indicación:</b> ${bio.tipo2.indicacion}
            </div>`;
        html += section('🧬', `${sn++}. Biológicos por Fenotipo (Escalón 5)`, '#7c3aed', bioContent);
    }

    // 5. Factores de riesgo
    if (riesgos.length) {
        html += section('⚠️', `${sn++}. Factores de Riesgo Identificados`, '#f59e0b',
            riesgos.map(r => `• ${r}`).join('<br>'));
    }

    // 6. Medidas no farmacológicas
    html += section('📋', `${sn++}. Medidas No Farmacológicas`, '#64748b',
        `• <b>Técnica inhalatoria:</b> Revisar en cada visita (hasta 80% usan mal el inhalador)<br>
         • <b>Adherencia:</b> Clave antes de subir escalón<br>
         • <b>Evitar desencadenantes:</b> Alérgenos (polvo, ácaros, pollen), AINE/AAS, humo de tabaco, RGE<br>
         • <b>Vacunas:</b> Gripe anual · Neumococo (si ≥ 65a o escalón ≥ 3) · COVID<br>
         ${inputs.tabaco === 'si' ? '• <span style="color:#f87171;"><b>🚬 Cesación tabáquica urgente</b> — reduce respuesta al tratamiento y progresión de la enfermedad</span><br>' : ''}
         • <b>Plan de acción escrito:</b> Instrucciones para crisis leve y cuándo acudir a urgencias`);

    html += `<div style="font-size:11px; color:#64748b; text-align:right; margin-top:4px; padding:0 4px;">
        GINA 2024 · SEPAR 2023 · ALAT 2023</div>`;

    return html;
}

function calculateAsmaControlProtocol(event) {
    event.preventDefault();
    const enTrat = document.getElementById('acEnTratamiento').value;
    const inputs = {
        enTratamiento:     enTrat,
        escalon:           document.getElementById('acEscalon').value,
        tiempoEscalon:     document.getElementById('acTiempoEscalon').value,
        sintomasDiurnos:   document.getElementById('acSintomasDiurnos').value,
        sintomasNocturnos: document.getElementById('acSintomasNocturnos').value,
        limitacion:        document.getElementById('acLimitacion').value,
        rescate:           document.getElementById('acRescate').value,
        fev1fem:           document.getElementById('acFev1fem').value,
        exacerbaciones:    document.getElementById('acExacerbaciones').value,
        ocs:               document.getElementById('acOcs').value,
        tabaco:            document.getElementById('acTabaco').value,
    };
    const r = Calculators.calculateAsmaControl(inputs);
    const container = document.getElementById('acResult');
    container.innerHTML = buildAsmaControlProtocolHTML(r, inputs) + `
        <button class="btn btn-secondary" onclick="document.getElementById('asmaControlForm').reset(); document.getElementById('acResult').style.display='none'; document.getElementById('acLiveCalcs').innerHTML=''; _acToggleTratamiento('');" style="width:100%; margin-top:12px;">
            🔄 Nueva Evaluación
        </button>`;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 32, calculatorName: 'Control Asma', inputs, result: r, interpretation: r.interpretation });
}

// === 35. CALCULADORA GENERAL === //
// Estado global de la calculadora
let _cV = '0', _cPrev = null, _cOp = null, _cWait = false, _cExpr = '';

function _cUpdate() {
    const d = document.getElementById('calcDisplay');
    if (!d) return;

    // Poner el texto primero para poder medir scrollWidth
    d.textContent = _cV;

    // Reducir fuente hasta que quepa, o dejar que se salga por la izquierda (Apple)
    const sizes = [80, 66, 52, 40, 30];
    for (const sz of sizes) {
        d.style.fontSize = sz + 'px';
        if (d.scrollWidth <= d.clientWidth || sz === 30) break;
    }

    // Operator buttons: active = white bg + orange text; normal = orange bg + white text
    const opIds = { '÷':'calcOpD', '×':'calcOpX', '−':'calcOpS', '+':'calcOpA' };
    Object.entries(opIds).forEach(([sym, id]) => {
        const b = document.getElementById(id);
        if (!b) return;
        const isActive = _cOp === sym && _cWait;
        b.style.background = isActive ? '#ffffff' : '#FF9F0A';
        b.style.color      = isActive ? '#FF9F0A' : '#ffffff';
    });

    // AC / C toggle
    const acBtn = document.getElementById('calcBtnAC');
    if (acBtn) acBtn.textContent = (_cV === '0' && _cPrev === null) ? 'AC' : 'C';
}

function calcNum(d) {
    if (_cV === 'Error') return;
    if (_cWait) { _cV = String(d); _cWait = false; }
    else { _cV = _cV === '0' ? String(d) : _cV + d; }
    if (_cV.replace(/[-.]/, '').length > 12) { _cV = _cV.slice(0, -1); return; }
    _cUpdate();
}

function calcDot() {
    if (_cWait) { _cV = '0.'; _cWait = false; }
    else if (!_cV.includes('.')) { _cV += '.'; }
    _cUpdate();
}

function calcClear() {
    if (_cV !== '0') {
        _cV = '0';                                              // C: solo borra entrada actual
    } else {
        _cPrev = null; _cOp = null; _cWait = false; _cExpr = ''; // AC: borra todo
    }
    _cUpdate();
}

function calcBack() {
    if (_cWait || _cV === 'Error') { _cV = '0'; _cWait = false; _cUpdate(); return; }
    _cV = _cV.length > 1 ? _cV.slice(0, -1) : '0';
    _cUpdate();
}

function calcSign() {
    if (_cV === '0' || _cV === 'Error') return;
    _cV = _cV.startsWith('-') ? _cV.slice(1) : '-' + _cV;
    _cUpdate();
}

function calcPct() {
    const v = parseFloat(_cV);
    const result = _cPrev !== null && _cOp ? _cPrev * v / 100 : v / 100;
    _cV = String(parseFloat(result.toFixed(10)));
    _cWait = true;
    _cUpdate();
}

function calcOp(op) {
    if (_cV === 'Error') return;
    const v = parseFloat(_cV);
    if (_cPrev !== null && !_cWait) {
        const res = _cCalc(_cPrev, v, _cOp);
        if (!isFinite(res)) { _cV = 'Error'; _cPrev = 0; }
        else {
            const abs = Math.abs(res);
            _cV = (abs !== 0 && (abs >= 1e13 || abs < 1e-7))
                ? parseFloat(res.toPrecision(10)).toString()
                : String(parseFloat(res.toFixed(10)));
            _cPrev = parseFloat(_cV);
        }
    } else {
        _cPrev = v;
    }
    _cOp = op;
    _cWait = true;
    _cExpr = _cV + ' ' + op;
    _cUpdate();
}

function calcEq() {
    if (_cV === 'Error' || _cOp === null || _cPrev === null) return;
    const v = parseFloat(_cV);
    const res = _cCalc(_cPrev, v, _cOp);
    _cExpr = '';
    if (!isFinite(res)) {
        _cV = res === Infinity ? 'Error' : 'Error';
    } else {
        const abs = Math.abs(res);
        if (abs !== 0 && (abs >= 1e13 || abs < 1e-7)) {
            // Notación científica para números muy grandes o muy pequeños
            _cV = parseFloat(res.toPrecision(10)).toString();
        } else {
            _cV = String(parseFloat(res.toFixed(10)));
        }
    }
    _cPrev = null; _cOp = null; _cWait = true;
    _cUpdate();
}

function _cCalc(a, b, op) {
    if (op === '+') return a + b;
    if (op === '−') return a - b;
    if (op === '×') return a * b;
    if (op === '÷') return b === 0 ? Infinity : a / b;
    return b;
}

function createCalculadoraForm() {
    _cV = '0'; _cPrev = null; _cOp = null; _cWait = false; _cExpr = '';

    // Press feedback via brightness
    const tap = `onpointerdown="this.style.filter='brightness(1.5)'" onpointerup="this.style.filter='none'" onpointerleave="this.style.filter='none'"`;

    // Base style for all buttons
    const circle = `border:none;cursor:pointer;-webkit-tap-highlight-color:transparent;display:flex;align-items:center;justify-content:center;transition:filter 0.08s;width:100%;aspect-ratio:1/1;border-radius:50%;`;

    // Number buttons — dark gray, white text
    const nb = (lbl, fn) =>
        `<button onclick="${fn}" ${tap} style="${circle}background:#333;color:#fff;font-size:30px;font-weight:400;">${lbl}</button>`;

    // Utility buttons (AC/C, ±, %) — light gray, black text
    const ub = (lbl, fn, id = '') =>
        `<button ${id ? `id="${id}"` : ''} onclick="${fn}" ${tap} style="${circle}background:#a5a5a5;color:#000;font-size:${lbl.length > 1 ? '22px' : '28px'};font-weight:500;">${lbl}</button>`;

    // Operator buttons — Apple orange, toggled by _cUpdate
    const ob = (lbl, fn, id) =>
        `<button id="${id}" onclick="${fn}" ${tap} style="${circle}background:#FF9F0A;color:#fff;font-size:34px;font-weight:300;">${lbl}</button>`;

    // Wide pill 0 — spans 2 columns, left-padded
    const wideZero = `<button onclick="calcNum('0')" ${tap}
        style="border:none;cursor:pointer;-webkit-tap-highlight-color:transparent;
               grid-column:span 2;background:#333;color:#fff;font-size:30px;font-weight:400;
               border-radius:999px;display:flex;align-items:center;padding-left:28px;
               transition:filter 0.08s;">0</button>`;

    return `
        <div style="background:#000;border-radius:20px;overflow:hidden;max-width:380px;margin:0 auto;user-select:none;">

            <!-- Display -->
            <div style="padding:28px 24px 20px;min-height:150px;display:flex;flex-direction:column;justify-content:flex-end;align-items:flex-end;">
                <div id="calcDisplay"
                     style="font-size:80px;font-weight:200;color:#fff;line-height:1;
                            white-space:nowrap;overflow:hidden;text-align:right;width:100%;">0</div>
            </div>

            <!-- Botones -->
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:13px;padding:4px 16px 24px;">

                ${ub('AC', 'calcClear()', 'calcBtnAC')}
                ${ub('±',  'calcSign()')}
                ${ub('%',  'calcPct()')}
                ${ob('÷',  "calcOp('÷')", 'calcOpD')}

                ${nb('7', "calcNum('7')")}
                ${nb('8', "calcNum('8')")}
                ${nb('9', "calcNum('9')")}
                ${ob('×', "calcOp('×')", 'calcOpX')}

                ${nb('4', "calcNum('4')")}
                ${nb('5', "calcNum('5')")}
                ${nb('6', "calcNum('6')")}
                ${ob('−', "calcOp('−')", 'calcOpS')}

                ${nb('1', "calcNum('1')")}
                ${nb('2', "calcNum('2')")}
                ${nb('3', "calcNum('3')")}
                ${ob('+', "calcOp('+')", 'calcOpA')}

                ${wideZero}
                ${nb('.', 'calcDot()')}
                ${ob('=', 'calcEq()', 'calcBtnEq')}

            </div>
        </div>
    `;
}

// === 34. PAM — PRESIÓN ARTERIAL MEDIA === //
function createPAMForm() {
    return `
        <form id="pamForm" onsubmit="calculatePAM(event)">
            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:14px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:14px; text-transform:uppercase; letter-spacing:0.05em;">Tensión Arterial</div>

                <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:14px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">PAS (mmHg)</label>
                        <input type="number" id="pamPas" required min="40" max="300" class="form-input" placeholder="ej: 120" oninput="updatePAMLive()">
                        <p style="font-size:11px; color:var(--text-tertiary); margin-top:4px;">Sistólica</p>
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">PAD (mmHg)</label>
                        <input type="number" id="pamPad" required min="20" max="200" class="form-input" placeholder="ej: 80" oninput="updatePAMLive()">
                        <p style="font-size:11px; color:var(--text-tertiary); margin-top:4px;">Diastólica</p>
                    </div>
                </div>

                <div id="pamLive"></div>
            </div>

            <div style="background:var(--bg-secondary); padding:14px; border-radius:10px; margin-bottom:14px; font-size:12px; color:var(--text-secondary); line-height:1.7;">
                <strong>Objetivos clínicos orientativos:</strong><br>
                ≥ 65 mmHg — Shock séptico (SSC 2021) · UCI general<br>
                ≥ 70 mmHg — Shock cardiogénico<br>
                ≥ 80 mmHg — TCE grave · HTA crónica previa
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">
                🩸 Calcular PAM
            </button>
        </form>
        <div id="pamResult" style="display:none; margin-top:20px;"></div>
    `;
}

function updatePAMLive() {
    const el = document.getElementById('pamLive');
    if (!el) return;
    const pas = parseFloat(document.getElementById('pamPas').value);
    const pad = parseFloat(document.getElementById('pamPad').value);
    if (isNaN(pas) || isNaN(pad)) { el.innerHTML = ''; return; }
    const pam = Math.round((pad + (pas - pad) / 3) * 10) / 10;
    const color = pam < 60 ? '#ef4444' : pam < 65 ? '#f59e0b' : pam <= 100 ? '#22c55e' : '#f59e0b';
    el.innerHTML = `
        <div style="background:${color}20; border:1px solid ${color}55; border-radius:8px; padding:10px 14px; display:flex; justify-content:space-between; align-items:center;">
            <span style="font-size:13px; font-weight:600; color:${color};">PAM estimada</span>
            <span style="font-size:20px; font-weight:800; color:${color};">${pam} <span style="font-size:13px; font-weight:500;">mmHg</span></span>
        </div>`;
}

function calculatePAM(event) {
    event.preventDefault();
    const inputs = {
        pas: parseFloat(document.getElementById('pamPas').value),
        pad: parseFloat(document.getElementById('pamPad').value)
    };
    const r = Calculators.calculatePAM(inputs);
    const colors = { danger: '#ef4444', warning: '#f59e0b', success: '#22c55e' };
    const c = colors[r.interpretation.color] || '#64748b';
    document.getElementById('pamResult').innerHTML = `
        <div style="background:${c}; border-radius:12px; padding:20px; margin-bottom:14px; color:white;">
            <div style="font-size:12px; font-weight:600; opacity:0.85; margin-bottom:4px; text-transform:uppercase; letter-spacing:0.05em;">Presión Arterial Media</div>
            <div style="font-size:48px; font-weight:900; line-height:1; margin-bottom:6px;">${r.value} <span style="font-size:18px; font-weight:500;">mmHg</span></div>
            <div style="font-size:15px; font-weight:700;">${r.interpretation.stage} — ${r.interpretation.label}</div>
        </div>
        <div style="background:var(--bg-secondary); border-left:4px solid ${c}; padding:16px; border-radius:10px; margin-bottom:14px;">
            <p style="font-size:13px; color:var(--text-primary); margin:0; line-height:1.6;">${r.interpretation.description}</p>
        </div>
        <div style="background:var(--bg-secondary); padding:14px; border-radius:10px; margin-bottom:14px; font-size:12px; color:var(--text-secondary); line-height:1.7;">
            <strong style="color:var(--text-primary);">Fórmula:</strong> PAM = PAD + (PAS − PAD) / 3 = ${inputs.pad} + (${inputs.pas} − ${inputs.pad}) / 3 = <strong>${r.value} mmHg</strong>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('pamForm').reset(); document.getElementById('pamResult').style.display='none'; document.getElementById('pamLive').innerHTML='';" style="width:100%;">
            🔄 Nuevo Cálculo
        </button>`;
    document.getElementById('pamResult').style.display = 'block';
    Storage.addToHistory({ calculatorId: 34, calculatorName: 'PAM', inputs, result: r, interpretation: r.interpretation });
}

// === 33. DIAGNÓSTICO LES — CRITERIOS ACR/EULAR 2019 === //
function createLESForm() {
    // Helper: genera una sección de dominio con checkboxes individuales
    // items: [[id, label, pts, nota?], ...]
    function domCheck(icon, title, max, items) {
        return `
        <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:12px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); text-transform:uppercase; letter-spacing:0.05em;">${icon} ${title}</div>
                <span style="font-size:11px; color:var(--text-tertiary); background:var(--bg-card); padding:2px 8px; border-radius:12px;">máx ${max} pts</span>
            </div>
            <p style="font-size:11px; color:var(--text-tertiary); margin-top:3px; margin-bottom:12px;">Marque todos los presentes — suma solo el de mayor puntuación</p>
            ${items.map(([id, label, pts, note]) => `
            <label style="display:flex; align-items:flex-start; gap:10px; padding:10px; border-radius:8px; cursor:pointer; margin-bottom:5px; background:var(--bg-card);">
                <input type="checkbox" id="${id}" onchange="updateLESLiveCalcs()" style="margin-top:2px; flex-shrink:0; width:16px; height:16px; accent-color:#7c3aed; cursor:pointer;">
                <div style="flex:1; min-width:0;">
                    <div style="font-size:13px; font-weight:500; color:var(--text-primary);">${label}</div>
                    ${note ? `<div style="font-size:11px; color:var(--text-tertiary); margin-top:2px;">${note}</div>` : ''}
                </div>
                <div style="font-size:12px; font-weight:700; color:#7c3aed; flex-shrink:0; padding-left:8px;">${pts} pts</div>
            </label>`).join('')}
        </div>`;
    }

    return `
        <form id="lesForm" onsubmit="calculateLESForm(event)">

            <!-- ANA: criterio de entrada obligatorio -->
            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px; border:2px solid #3b82f655;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                    <div style="font-size:13px; font-weight:700; color:#3b82f6; text-transform:uppercase; letter-spacing:0.05em;">🔬 Criterio de Entrada</div>
                    <span style="font-size:11px; background:#3b82f622; color:#3b82f6; padding:2px 8px; border-radius:12px; font-weight:600;">obligatorio</span>
                </div>
                <div class="form-group" style="margin-bottom:0;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Anticuerpos Antinucleares (ANA)</label>
                    <select id="lesAna" required class="form-input" onchange="updateLESLiveCalcs()">
                        <option value="">-- Seleccionar --</option>
                        <option value="positive">✅ Positivo ≥1:80 (HEp-2 o técnica equivalente validada)</option>
                        <option value="negative">❌ Negativo &lt;1:80</option>
                        <option value="not_done">⚠️ No realizado aún</option>
                    </select>
                    <p style="font-size:11px; color:var(--text-tertiary); margin-top:4px;">ANA ≥1:80 es requisito obligatorio para clasificación formal ACR/EULAR 2019</p>
                </div>
            </div>

            <!-- Dominios clínicos — checkboxes individuales (suma solo el mayor por dominio) -->
            ${domCheck('🌡️', 'Constitucional', 2, [
                ['lesFever', 'Fiebre >38.3°C inexplicada', 2, 'Descartar infección u otra causa']
            ])}

            ${domCheck('🩸', 'Hematológico', 4, [
                ['lesLeukopenia',       'Leucopenia <4.000/µL', 3, null],
                ['lesThrombocytopenia', 'Trombocitopenia <100.000/µL', 4, null],
                ['lesHemolysis',        'Hemólisis autoinmune', 4, 'Coombs directo positivo + anemia hemolítica']
            ])}

            ${domCheck('🧠', 'Neuropsiquiátrico', 5, [
                ['lesDelirium',  'Delirium', 2, 'Excluir causas metabólicas, tóxicas o infecciosas'],
                ['lesPsychosis', 'Psicosis', 3, null],
                ['lesSeizures',  'Convulsiones', 5, null]
            ])}

            ${domCheck('🔴', 'Mucocutáneo', 6, [
                ['lesAlopecia',        'Alopecia no cicatricial (parcheada o difusa)', 2, null],
                ['lesOralUlcers',      'Úlceras orales (paladar o mucosa oral)', 2, null],
                ['lesSubacuteDiscoid', 'Lupus cutáneo subagudo o discoide', 4, null],
                ['lesAcuteCutaneous',  'Lupus cutáneo agudo — eritema malar / rash fotosensible', 6, null]
            ])}

            ${domCheck('💧', 'Seroso', 6, [
                ['lesEffusion',     'Derrame pleural o pericárdico (sin otra causa)', 5, null],
                ['lesPericarditis', 'Pericarditis aguda (≥2: dolor, roce, ST difuso, derrame)', 6, null]
            ])}

            ${domCheck('🦴', 'Musculoesquelético', 6, [
                ['lesJoints', 'Sinovitis ≥2 articulaciones o rigidez matutina ≥30 min', 6, null]
            ])}

            ${domCheck('🫘', 'Renal', 10, [
                ['lesProteinuria', 'Proteinuria >0.5 g/24h o cociente Pr/Cr >0.5', 4, null],
                ['lesBiopsy25',    'Biopsia renal: Nefritis lúpica clase II o V', 8, null],
                ['lesBiopsy34',    'Biopsia renal: Nefritis lúpica clase III o IV', 10, null]
            ])}

            <!-- Dominio inmunológico: selects (mantienen "No realizado" como estado distinto de negativo) -->
            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                    <div style="font-size:13px; font-weight:700; color:var(--text-secondary); text-transform:uppercase; letter-spacing:0.05em;">🔬 Inmunológico</div>
                    <span style="font-size:11px; color:var(--text-tertiary); background:var(--bg-card); padding:2px 8px; border-radius:12px;">máx 12 pts · 3 categorías aditivas</span>
                </div>
                <p style="font-size:11px; color:var(--text-tertiary); margin-top:3px; margin-bottom:14px;">Estas 3 categorías se suman entre sí (a diferencia de los dominios clínicos)</p>

                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:13px;">Anticuerpos antifosfolípidos <span style="font-weight:400; color:var(--text-tertiary);">(+2 pts si positivo)</span></label>
                    <select id="lesAntiphospholipid" class="form-input" onchange="updateLESLiveCalcs()">
                        <option value="not_done">No realizado</option>
                        <option value="negative">Negativos</option>
                        <option value="positive">Positivos — anti-CL IgG >40 GPL · anti-β2GPI IgG >40 U · o anticoagulante lúpico</option>
                    </select>
                </div>

                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:13px;">Complemento <span style="font-weight:400; color:var(--text-tertiary);">(+3 o +4 pts)</span></label>
                    <select id="lesComplement" class="form-input" onchange="updateLESLiveCalcs()">
                        <option value="not_done">No realizado</option>
                        <option value="normal">Normal — C3 y C4 en rango</option>
                        <option value="one_low">C3 O C4 bajo — 3 pts</option>
                        <option value="both_low">C3 Y C4 ambos bajos — 4 pts</option>
                    </select>
                </div>

                <div class="form-group" style="margin-bottom:0;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:13px;">Anticuerpos específicos LES <span style="font-weight:400; color:var(--text-tertiary);">(+6 pts)</span></label>
                    <select id="lesSpecificAb" class="form-input" onchange="updateLESLiveCalcs()">
                        <option value="not_done">No realizado</option>
                        <option value="negative">Negativos</option>
                        <option value="positive">Anti-dsDNA positivo (≥90% especificidad) O Anti-Sm positivo</option>
                    </select>
                </div>
            </div>

            <!-- Score en tiempo real -->
            <div id="lesLiveCalcs"></div>

            <div style="background:#fef3c7; border-left:4px solid #f59e0b; padding:14px; border-radius:8px; margin-bottom:16px;">
                <p style="font-size:12px; color:#92400e; margin:0;">
                    <strong>⚠️ Herramienta de apoyo clínico</strong> — Criterios de <em>clasificación</em>, no de diagnóstico definitivo. Marque solo criterios sin explicación alternativa más probable. Basado en: Aringer M et al., Arthritis Rheumatol 2019.
                </p>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">
                🧬 Calcular Score ACR/EULAR 2019
            </button>
        </form>
        <div id="lesResult" style="display:none; margin-top:24px;"></div>
    `;
}

function updateLESLiveCalcs() {
    const container = document.getElementById('lesLiveCalcs');
    if (!container) return;

    const ana = document.getElementById('lesAna').value;
    if (!ana) { container.innerHTML = ''; return; }

    const ck = id => document.getElementById(id)?.checked || false;

    const sc  = ck('lesFever') ? 2 : 0;
    const sh  = Math.max(ck('lesLeukopenia') ? 3 : 0, ck('lesThrombocytopenia') ? 4 : 0, ck('lesHemolysis') ? 4 : 0);
    const sn  = Math.max(ck('lesDelirium') ? 2 : 0, ck('lesPsychosis') ? 3 : 0, ck('lesSeizures') ? 5 : 0);
    const sm  = Math.max(ck('lesAlopecia') ? 2 : 0, ck('lesOralUlcers') ? 2 : 0, ck('lesSubacuteDiscoid') ? 4 : 0, ck('lesAcuteCutaneous') ? 6 : 0);
    const ss  = Math.max(ck('lesEffusion') ? 5 : 0, ck('lesPericarditis') ? 6 : 0);
    const smu = ck('lesJoints') ? 6 : 0;
    const sr  = Math.max(ck('lesProteinuria') ? 4 : 0, ck('lesBiopsy25') ? 8 : 0, ck('lesBiopsy34') ? 10 : 0);

    const aphospho = document.getElementById('lesAntiphospholipid').value;
    const comp     = document.getElementById('lesComplement').value;
    const specAb   = document.getElementById('lesSpecificAb').value;
    const sap = aphospho === 'positive' ? 2 : 0;
    const sco = comp === 'both_low' ? 4 : comp === 'one_low' ? 3 : 0;
    const sab = specAb === 'positive' ? 6 : 0;
    const total   = sc + sh + sn + sm + ss + smu + sr + sap + sco + sab;
    const pending = [aphospho, comp, specAb].filter(v => v === 'not_done').length;

    let badge, label, color;
    if (ana === 'not_done')                     { badge = '⚠️'; label = 'Score parcial — ANA pendiente';            color = '#2563eb'; }
    else if (ana === 'negative')                { badge = '⬜'; label = 'ANA negativo — LES muy improbable';        color = '#475569'; }
    else if (ana === 'positive' && total >= 10) { badge = '🧬'; label = 'Cumple criterios ACR/EULAR 2019 para LES'; color = '#7c3aed'; }
    else if (ana === 'positive' && total >= 7)  { badge = '🟡'; label = 'Score elevado — completar evaluación';      color = '#ca8a04'; }
    else                                        { badge = '🟢'; label = 'Score bajo — no cumple criterios';          color = '#16a34a'; }

    container.innerHTML = `
        <div style="background:${color}22; border:1px solid ${color}55; border-radius:10px; padding:14px; margin-bottom:16px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                <div style="font-size:13px; font-weight:700; color:${color};">${badge} ${label}</div>
                <div style="font-size:22px; font-weight:800; color:${color};">${total}<span style="font-size:12px; font-weight:500;"> pts</span></div>
            </div>
            <div style="font-size:12px; color:${color}cc;">
                Umbral: ≥10 pts + ANA positivo${pending > 0 ? ` · ${pending} test${pending > 1 ? 's' : ''} inmunológico${pending > 1 ? 's' : ''} pendiente${pending > 1 ? 's' : ''}` : ''}
            </div>
        </div>`;
}

function buildLESResultHTML(r, inputs) {
    const { totalScore, classification, classLabel, pendingTests, maxAdditional, domains } = r;

    const colorMap = {
        'met':          '#7c3aed',
        'possible':     '#ca8a04',
        'not_met':      '#16a34a',
        'incomplete':   '#2563eb',
        'ana_negative': '#475569'
    };
    const c = colorMap[classification] || '#64748b';

    const badgeMap = {
        'met':          '🧬 CUMPLE CRITERIOS ACR/EULAR 2019',
        'possible':     '🟡 SCORE ELEVADO — EVALUACIÓN INCOMPLETA',
        'not_met':      '🟢 NO CUMPLE CRITERIOS',
        'incomplete':   '⚠️ EVALUACIÓN INCOMPLETA',
        'ana_negative': '⬜ ANA NEGATIVO'
    };

    // Header
    let html = `
    <div style="background:${c}; border-radius:12px; padding:20px; margin-bottom:16px; color:white;">
        <div style="font-size:12px; font-weight:600; opacity:0.85; margin-bottom:6px; text-transform:uppercase; letter-spacing:0.05em;">Lupus Eritematoso Sistémico — Clasificación</div>
        <div style="font-size:16px; font-weight:800; margin-bottom:10px;">${badgeMap[classification]}</div>
        <div style="display:flex; align-items:baseline; gap:10px; margin-bottom:6px;">
            <span style="font-size:44px; font-weight:900; line-height:1;">${totalScore}</span>
            <span style="font-size:15px; opacity:0.85;">pts &nbsp;/&nbsp; umbral ≥10 + ANA positivo</span>
        </div>
        <div style="font-size:13px; opacity:0.9;">${classLabel}</div>
    </div>`;

    // ANA alerts
    if (r.anaNotDone) {
        html += `<div style="background:#1e3a5f; border:1px solid #3b82f6; border-radius:10px; padding:14px; margin-bottom:12px; color:#93c5fd;">
            ⚠️ <strong>ANA no realizado</strong> — Es el criterio de entrada obligatorio según ACR/EULAR 2019. Sin ANA no puede emitirse clasificación definitiva. Solicitar urgente.
        </div>`;
    } else if (r.anaNegative) {
        html += `<div style="background:#1e293b; border:1px solid #64748b; border-radius:10px; padding:14px; margin-bottom:12px; color:#94a3b8;">
            ❌ <strong>ANA negativo</strong> — Descarta LES con sensibilidad del 97-99%. No se aplica la clasificación ACR/EULAR 2019.<br>
            <span style="font-size:11px;">Excepción rara: LES ANA-negativo (&lt;1% de casos). Si la sospecha clínica es muy alta, repetir ANA en distinto laboratorio/técnica.</span>
        </div>`;
    }

    // Domain breakdown
    html += `
    <div style="background:var(--bg-secondary); border-radius:10px; padding:16px; margin-bottom:12px;">
        <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:12px; text-transform:uppercase; letter-spacing:0.05em;">Desglose por Dominio</div>
        ${domains.map(d => {
            const checkedCriteria = d.isAdditive
                ? d.criteria.filter(cr => cr.state !== 'not_done')
                : d.criteria.filter(cr => cr.checked);
            return `
            <div style="padding:9px 0; border-bottom:1px solid rgba(148,163,184,0.15);">
                <div style="display:flex; justify-content:space-between; align-items:center; ${checkedCriteria.length ? 'margin-bottom:5px;' : ''}">
                    <div style="font-size:13px; font-weight:600; color:var(--text-primary);">${d.icon} ${d.name}</div>
                    <div style="font-size:15px; font-weight:700; color:${d.score > 0 ? c : 'var(--text-tertiary)'};">
                        ${d.score}<span style="font-size:11px; font-weight:400; color:var(--text-tertiary);"> / ${d.max}</span>
                    </div>
                </div>
                ${d.isAdditive
                    ? d.criteria.map(cr => {
                        const isNotDone = cr.state === 'not_done';
                        const isPos     = cr.score > 0;
                        const col = isNotDone ? '#64748b' : isPos ? c : '#475569';
                        const icon = isNotDone ? '○' : isPos ? '✓' : '✗';
                        return `<div style="display:flex; justify-content:space-between; padding:2px 0 2px 14px; font-size:12px; color:${col};">
                            <span>${icon} ${cr.label}${isNotDone ? ' — pendiente' : ''}</span>
                            <span style="margin-left:8px; white-space:nowrap;">${isNotDone ? '? pts' : isPos ? `+${cr.score} pts` : '0 pts'}</span>
                        </div>`;
                    }).join('')
                    : checkedCriteria.map(cr => {
                        const col = cr.counts ? c : '#64748b';
                        return `<div style="display:flex; justify-content:space-between; padding:2px 0 2px 14px; font-size:12px; color:${col};">
                            <span>${cr.counts ? '✓' : '↳'} ${cr.label}</span>
                            <span style="margin-left:8px; white-space:nowrap;">${cr.pts} pts${cr.counts ? '' : ' — no suma'}</span>
                        </div>`;
                    }).join('')
                }
            </div>`;
        }).join('')}
        <div style="display:flex; justify-content:space-between; align-items:center; padding:10px 0 0 0; border-top:2px solid ${c}44; margin-top:4px;">
            <div style="font-size:14px; font-weight:700; color:var(--text-primary);">TOTAL</div>
            <div style="font-size:22px; font-weight:800; color:${c};">${totalScore} pts</div>
        </div>
    </div>`;

    // Pending tests
    if (pendingTests.length > 0) {
        html += `
        <div style="background:var(--bg-secondary); border:1px solid #f59e0b44; border-radius:10px; padding:14px; margin-bottom:12px;">
            <div style="font-size:13px; font-weight:700; color:#fbbf24; margin-bottom:8px;">📋 Tests pendientes que podrían modificar el resultado</div>
            ${maxAdditional > 0 ? `<div style="font-size:12px; color:#d97706; margin-bottom:10px; padding:6px 10px; background:#f59e0b22; border-radius:6px;">Hasta +${maxAdditional} pts adicionales posibles si positivos</div>` : ''}
            ${pendingTests.map(t => `
            <div style="padding:6px 0; border-bottom:1px solid rgba(148,163,184,0.12);">
                <div style="font-size:13px; color:var(--text-primary);">→ ${t.test}</div>
                <div style="font-size:11px; color:#d97706; padding-left:12px;">${t.pts}</div>
            </div>`).join('')}
        </div>`;
    }

    // Differential diagnosis (ANA negative)
    if (r.anaNegative) {
        html += `
        <div style="background:var(--bg-secondary); border-radius:10px; padding:14px; margin-bottom:12px;">
            <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:10px; text-transform:uppercase; letter-spacing:0.05em;">Diagnósticos alternativos a considerar</div>
            <div style="font-size:13px; line-height:1.9; color:var(--text-primary);">
                • Enfermedad mixta del tejido conectivo (EMTC) — anti-U1-RNP<br>
                • Síndrome de Sjögren primario — anti-Ro/SSA, anti-La/SSB<br>
                • Artritis reumatoide — FR, anti-CCP<br>
                • Vasculitis ANCA-asociada — ANCA c/p<br>
                • Lupus inducido por fármacos — anti-histona<br>
                • Síndrome antifosfolípido primario
            </div>
        </div>`;
    }

    // Referral
    if (classification === 'met' || classification === 'possible' || (r.anaNotDone && totalScore >= 5)) {
        html += `
        <div style="background:#1e3a2f; border:1px solid #22c55e33; border-radius:10px; padding:14px; margin-bottom:12px; color:#86efac;">
            👨‍⚕️ <strong>Derivar a Reumatología</strong><br>
            <span style="font-size:12px;">Los criterios ACR/EULAR 2019 son de <em>clasificación</em> (no diagnóstico definitivo). El diagnóstico clínico, la evaluación de actividad y el plan terapéutico requieren valoración especializada.</span>
        </div>`;
    }

    html += `<div style="font-size:11px; color:#64748b; text-align:right; margin-top:4px; padding:0 4px;">
        ACR/EULAR 2019 · Aringer M et al., Arthritis Rheumatol 2019;71:1400-1412</div>`;

    return html;
}

function calculateLESForm(event) {
    event.preventDefault();
    const ck = id => document.getElementById(id)?.checked || false;
    const inputs = {
        ana:               document.getElementById('lesAna').value,
        fever:             ck('lesFever'),
        leukopenia:        ck('lesLeukopenia'),
        thrombocytopenia:  ck('lesThrombocytopenia'),
        hemolysis:         ck('lesHemolysis'),
        delirium:          ck('lesDelirium'),
        psychosis:         ck('lesPsychosis'),
        seizures:          ck('lesSeizures'),
        alopecia:          ck('lesAlopecia'),
        oralUlcers:        ck('lesOralUlcers'),
        subacuteDiscoid:   ck('lesSubacuteDiscoid'),
        acuteCutaneous:    ck('lesAcuteCutaneous'),
        effusion:          ck('lesEffusion'),
        pericarditis:      ck('lesPericarditis'),
        joints:            ck('lesJoints'),
        proteinuria:       ck('lesProteinuria'),
        biopsy25:          ck('lesBiopsy25'),
        biopsy34:          ck('lesBiopsy34'),
        antiphospholipid:  document.getElementById('lesAntiphospholipid').value,
        complement:        document.getElementById('lesComplement').value,
        specificAb:        document.getElementById('lesSpecificAb').value,
    };
    const r = Calculators.calculateLES(inputs);
    const container = document.getElementById('lesResult');
    container.innerHTML = buildLESResultHTML(r, inputs) + `
        <button class="btn btn-secondary" onclick="document.getElementById('lesForm').reset(); document.getElementById('lesResult').style.display='none'; document.getElementById('lesLiveCalcs').innerHTML='';" style="width:100%; margin-top:12px;">
            🔄 Nueva Evaluacion
        </button>`;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 33, calculatorName: 'Diagnóstico LES', inputs, result: r, interpretation: r.interpretation });
}

// === 39. EPOC — CLASIFICACIÓN Y TRATAMIENTO (GOLD 2025) === //
function createEPOCForm() {
    const catDefs = [
        ['Tos',                     'Nunca toso',                    'Siempre estoy tosiendo'],
        ['Flema / Expectoración',    'No tengo flema en el pecho',    'El pecho completamente lleno de flema'],
        ['Opresión torácica',        'No siento ninguna opresión',    'Siento una gran opresión en el pecho'],
        ['Disnea al subir escaleras','Sin disnea al subir escaleras', 'Mucha disnea al subir escaleras'],
        ['Actividades domésticas',   'Sin limitaciones en casa',      'Muy limitado en actividades del hogar'],
        ['Seguridad para salir',     'Salgo de casa con confianza',   'No me siento seguro para salir'],
        ['Calidad del sueño',        'Duermo profundamente',          'Me despierto mucho por mi enfermedad'],
        ['Energía',                  'Tengo mucha energía',           'No tengo ninguna energía'],
    ];
    const catHTML = catDefs.map((d, i) => `
        <div style="background:var(--bg-card);border-radius:8px;padding:10px 12px;margin-bottom:8px;">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:4px;">
                <span style="font-size:13px;font-weight:600;color:var(--text-primary);">${i+1}. ${d[0]}</span>
                <select id="cat${i}" onchange="updateEPOCLive()"
                    style="padding:6px 8px;border-radius:6px;border:1px solid var(--border-color);background:var(--bg-secondary);color:var(--text-primary);font-size:15px;font-weight:700;width:60px;text-align:center;">
                    ${[0,1,2,3,4,5].map(v=>`<option value="${v}">${v}</option>`).join('')}
                </select>
            </div>
            <div style="font-size:11px;color:var(--text-secondary);">0: ${d[1]} &nbsp;·&nbsp; 5: ${d[2]}</div>
        </div>`).join('');

    return `
        <div style="background:var(--bg-secondary);padding:14px 16px;border-radius:12px;margin-bottom:14px;border-left:4px solid #22c55e;">
            <p style="font-size:13px;color:var(--text-secondary);margin:0;line-height:1.5;">
                Clasifica la EPOC según GOLD 2025: grado espirométrico (1–4), carga sintomática (CAT + mMRC), historia de exacerbaciones y Esquema ABE con recomendación de tratamiento.
            </p>
        </div>
        <form id="epocForm" onsubmit="calculateEPOCForm(event)">

            <!-- Espirometría -->
            <div style="background:var(--bg-secondary);padding:16px;border-radius:12px;margin-bottom:10px;">
                <div style="font-size:13px;font-weight:700;color:var(--text-secondary);margin-bottom:12px;text-transform:uppercase;letter-spacing:0.05em;">Espirometría post-broncodilatador</div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                    <div>
                        <label style="font-size:12px;font-weight:600;color:var(--text-secondary);display:block;margin-bottom:6px;">FEV₁/FVC (ej: 0.65)</label>
                        <input type="number" id="epocFev1fvc" min="0.1" max="1.2" step="0.01" placeholder="ej: 0.65" oninput="updateEPOCLive()"
                            style="width:100%;padding:10px 12px;border-radius:8px;border:1px solid var(--border-color);background:var(--bg-card);color:var(--text-primary);font-size:14px;box-sizing:border-box;">
                        <div style="font-size:11px;color:var(--text-secondary);margin-top:3px;">Diagnóstico EPOC: &lt;0.70 post-BD</div>
                    </div>
                    <div>
                        <label style="font-size:12px;font-weight:600;color:var(--text-secondary);display:block;margin-bottom:6px;">FEV₁ (% predicho)</label>
                        <input type="number" id="epocFev1" min="1" max="150" step="1" placeholder="ej: 55" oninput="updateEPOCLive()"
                            style="width:100%;padding:10px 12px;border-radius:8px;border:1px solid var(--border-color);background:var(--bg-card);color:var(--text-primary);font-size:14px;box-sizing:border-box;">
                        <div style="font-size:11px;color:var(--text-secondary);margin-top:3px;">GOLD 1≥80 · 2:50-79 · 3:30-49 · 4&lt;30</div>
                    </div>
                </div>
                <div id="epocFev1Banner" style="margin-top:8px;"></div>
            </div>

            <!-- CAT Score -->
            <div style="background:var(--bg-secondary);padding:16px;border-radius:12px;margin-bottom:10px;">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
                    <div style="font-size:13px;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.05em;">CAT Score (0–40)</div>
                    <span id="epocCatTotal" style="font-size:18px;font-weight:800;color:var(--text-secondary);">0 pts</span>
                </div>
                <div style="font-size:11px;color:var(--text-secondary);margin-bottom:10px;">Puntúa cada ítem de 0 (mejor) a 5 (peor). Umbral clínico: ≥10 pts = síntomas significativos.</div>
                ${catHTML}
            </div>

            <!-- mMRC -->
            <div style="background:var(--bg-secondary);padding:16px;border-radius:12px;margin-bottom:10px;">
                <div style="font-size:13px;font-weight:700;color:var(--text-secondary);margin-bottom:10px;text-transform:uppercase;letter-spacing:0.05em;">Escala mMRC (disnea)</div>
                <select id="epocMmrc" onchange="updateEPOCLive()" style="width:100%;padding:10px 12px;border-radius:8px;border:1px solid var(--border-color);background:var(--bg-card);color:var(--text-primary);font-size:13px;">
                    <option value="">-- Seleccionar grado mMRC --</option>
                    <option value="0">0 — Disnea solo con ejercicio intenso (correr, subir colina empinada)</option>
                    <option value="1">1 — Disnea al caminar rápido en llano o al subir pendiente leve</option>
                    <option value="2">2 — Camina más despacio que pares o para al caminar a su propio ritmo</option>
                    <option value="3">3 — Para a descansar tras ~100 m o pocos minutos en llano</option>
                    <option value="4">4 — Demasiada disnea para salir de casa o al vestirse/desvestirse</option>
                </select>
                <div style="font-size:11px;color:var(--text-secondary);margin-top:6px;">mMRC ≥ 2 = síntomas significativos (equivale a CAT ≥ 10)</div>
            </div>

            <!-- Exacerbaciones -->
            <div style="background:var(--bg-secondary);padding:16px;border-radius:12px;margin-bottom:10px;">
                <div style="font-size:13px;font-weight:700;color:var(--text-secondary);margin-bottom:12px;text-transform:uppercase;letter-spacing:0.05em;">Exacerbaciones — último año</div>
                <div>
                    <label style="font-size:12px;font-weight:600;color:var(--text-secondary);display:block;margin-bottom:6px;">Exacerbaciones moderadas (sin hospitalización)</label>
                    <select id="epocExacMod" onchange="updateEPOCLive()" style="width:100%;padding:10px 12px;border-radius:8px;border:1px solid var(--border-color);background:var(--bg-card);color:var(--text-primary);font-size:14px;">
                        <option value="0">0 — Ninguna</option>
                        <option value="1">1 exacerbación moderada</option>
                        <option value="2">≥ 2 exacerbaciones moderadas</option>
                    </select>
                </div>
                <label style="display:flex;align-items:flex-start;gap:12px;padding:10px;border-radius:8px;cursor:pointer;margin-top:8px;background:var(--bg-card);">
                    <input type="checkbox" id="epocHospitalization" onchange="updateEPOCLive()" style="width:18px;height:18px;margin-top:2px;flex-shrink:0;cursor:pointer;">
                    <div>
                        <div style="font-size:14px;font-weight:600;color:var(--text-primary);">≥ 1 hospitalización por EPOC en el último año</div>
                        <div style="font-size:12px;color:var(--text-secondary);margin-top:2px;">Clasifica directamente en Grupo E independiente del CAT/mMRC</div>
                    </div>
                </label>
            </div>

            <!-- Eosinófilos -->
            <div style="background:var(--bg-secondary);padding:16px;border-radius:12px;margin-bottom:10px;">
                <div style="font-size:13px;font-weight:700;color:var(--text-secondary);margin-bottom:4px;text-transform:uppercase;letter-spacing:0.05em;">Eosinófilos en sangre (opcional)</div>
                <p style="font-size:12px;color:var(--text-secondary);margin:0 0 10px 0;">Solo relevante en Grupo E para decidir si añadir ICS. Si no disponible, dejar vacío.</p>
                <div style="display:flex;align-items:center;gap:8px;">
                    <input type="number" id="epocEos" min="0" max="3000" placeholder="ej: 250" oninput="updateEPOCLive()"
                        style="flex:1;min-width:0;padding:10px 12px;border-radius:8px;border:1px solid var(--border-color);background:var(--bg-card);color:var(--text-primary);font-size:14px;">
                    <span style="font-size:13px;color:var(--text-secondary);flex-shrink:0;">cél/µL</span>
                </div>
                <div style="font-size:11px;color:var(--text-secondary);margin-top:4px;">&lt;100: retirar ICS seguro · 100–299: zona gris · ≥300: triple terapia indicada</div>
            </div>

            <!-- Live preview -->
            <div style="background:var(--bg-secondary);padding:14px 16px;border-radius:12px;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between;gap:12px;">
                <span style="font-size:13px;color:var(--text-secondary);">Clasificación estimada:</span>
                <span id="epocLive" style="font-size:14px;font-weight:700;color:var(--text-secondary);">— · —</span>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%;padding:14px;">
                🫁 Clasificar y Ver Tratamiento
            </button>
        </form>
        <div id="epocResult"></div>`;
}

function _epocInputs() {
    return {
        fev1fvc: document.getElementById('epocFev1fvc')?.value || '',
        fev1:    document.getElementById('epocFev1')?.value || '',
        cat:     [0,1,2,3,4,5,6,7].map(i => document.getElementById('cat' + i)?.value || '0'),
        mmrc:    document.getElementById('epocMmrc')?.value ?? '',
        exacMod: document.getElementById('epocExacMod')?.value || '0',
        hospitalization: document.getElementById('epocHospitalization')?.checked || false,
        eos:     document.getElementById('epocEos')?.value || '',
    };
}

function updateEPOCLive() {
    const r = Calculators.calculateEPOC(_epocInputs());
    // CAT total
    const catEl = document.getElementById('epocCatTotal');
    if (catEl) {
        catEl.textContent = (r.catScore ?? 0) + ' pts';
        catEl.style.color = r.catColor || 'var(--text-secondary)';
    }
    // FEV1 banner
    const bannerEl = document.getElementById('epocFev1Banner');
    if (bannerEl) {
        if (r.fev1fvcHigh) {
            bannerEl.innerHTML = `<div style="background:#f59e0b22;border:1px solid #f59e0b;border-radius:8px;padding:8px 12px;">
                <p style="font-size:12px;color:#f59e0b;margin:0;">⚠️ FEV₁/FVC ≥ 0.70 — no cumple el criterio espirométrico de EPOC</p></div>`;
        } else { bannerEl.innerHTML = ''; }
    }
    // Live badge
    const liveEl = document.getElementById('epocLive');
    if (!liveEl) return;
    if (!r.abeGroup) { liveEl.style.color = 'var(--text-secondary)'; liveEl.textContent = '— · —'; return; }
    liveEl.style.color = r.abeColor;
    liveEl.textContent = `${r.abeLabel}${r.goldGrade ? ' · GOLD ' + r.goldGrade : ''}`;
}

function buildEPOCResultHTML(r) {
    // GOLD badge
    const goldBadge = r.goldGrade ? `
        <div style="background:${r.goldColor}22;border:2px solid ${r.goldColor};border-radius:14px;padding:14px;text-align:center;">
            <div style="font-size:11px;font-weight:700;color:var(--text-secondary);text-transform:uppercase;margin-bottom:4px;">Grado GOLD</div>
            <div style="font-size:26px;font-weight:800;color:${r.goldColor};">GOLD ${r.goldGrade}</div>
            <div style="font-size:12px;color:var(--text-secondary);margin-top:2px;">${r.goldLabel.split('—')[1].trim()}</div>
        </div>` : `
        <div style="background:var(--bg-secondary);border:2px solid var(--border-color);border-radius:14px;padding:14px;text-align:center;">
            <div style="font-size:11px;font-weight:700;color:var(--text-secondary);text-transform:uppercase;margin-bottom:4px;">Grado GOLD</div>
            <div style="font-size:18px;font-weight:700;color:var(--text-secondary);">${r.fev1fvcHigh ? 'No EPOC' : 'Sin datos'}</div>
        </div>`;

    // ABE badge
    const abeBadge = r.abeGroup ? `
        <div style="background:${r.abeColor}22;border:2px solid ${r.abeColor};border-radius:14px;padding:14px;text-align:center;">
            <div style="font-size:11px;font-weight:700;color:var(--text-secondary);text-transform:uppercase;margin-bottom:4px;">Esquema ABE</div>
            <div style="font-size:36px;font-weight:800;color:${r.abeColor};">Grupo ${r.abeGroup}</div>
            <div style="font-size:12px;color:var(--text-secondary);margin-top:2px;">${r.abeLabel.split('—')[1].trim()}</div>
        </div>` : `
        <div style="background:var(--bg-secondary);border:2px solid var(--border-color);border-radius:14px;padding:14px;text-align:center;">
            <div style="font-size:11px;font-weight:700;color:var(--text-secondary);text-transform:uppercase;margin-bottom:4px;">Esquema ABE</div>
            <div style="font-size:18px;font-weight:700;color:var(--text-secondary);">Sin datos</div>
        </div>`;

    // Warning if FEV1/FVC >= 0.70
    const fev1Banner = r.fev1fvcHigh ? `<div style="background:#f59e0b22;border:1px solid #f59e0b;border-radius:10px;padding:12px 14px;margin-bottom:12px;">
        <p style="font-size:13px;color:#f59e0b;margin:0;font-weight:600;">⚠️ FEV₁/FVC ${r.fev1fvcNum?.toFixed(2)} ≥ 0.70 — no se cumple el criterio espirométrico de EPOC (requiere &lt;0.70 post-BD). El Esquema ABE clasifica síntomas y exacerbaciones, pero el diagnóstico de EPOC requiere confirmación espirométrica.</p></div>` : '';

    // CAT + mMRC summary
    const catMmrcHTML = `
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px;">
            <div style="background:var(--bg-secondary);border-radius:10px;padding:12px 14px;">
                <div style="font-size:11px;font-weight:700;color:var(--text-secondary);text-transform:uppercase;margin-bottom:4px;">CAT Score</div>
                <div style="font-size:24px;font-weight:800;color:${r.catColor || 'var(--text-secondary)'};">${r.catScore ?? '—'}<span style="font-size:13px;font-weight:600;"> /40</span></div>
                <div style="font-size:12px;color:var(--text-secondary);margin-top:2px;">${r.catLevel || '—'}</div>
                ${r.catScore !== null ? `<div style="font-size:11px;color:${r.catScore >= 10 ? '#f59e0b' : '#22c55e'};margin-top:3px;font-weight:600;">${r.catScore >= 10 ? '⚠️ ≥10 — síntomas significativos' : '✓ <10 — síntomas leves'}</div>` : ''}
            </div>
            <div style="background:var(--bg-secondary);border-radius:10px;padding:12px 14px;">
                <div style="font-size:11px;font-weight:700;color:var(--text-secondary);text-transform:uppercase;margin-bottom:4px;">mMRC</div>
                <div style="font-size:24px;font-weight:800;color:${r.mmrcNum !== null && r.mmrcNum >= 2 ? '#f59e0b' : 'var(--text-secondary)'};">${r.mmrcNum ?? '—'}<span style="font-size:13px;font-weight:600;"> /4</span></div>
                <div style="font-size:12px;color:var(--text-secondary);margin-top:2px;">${r.mmrcLabel || '—'}</div>
                ${r.mmrcNum !== null ? `<div style="font-size:11px;color:${r.mmrcNum >= 2 ? '#f59e0b' : '#22c55e'};margin-top:3px;font-weight:600;">${r.mmrcNum >= 2 ? '⚠️ ≥2 — síntomas significativos' : '✓ <2 — síntomas leves'}</div>` : ''}
            </div>
        </div>`;

    // ABE table
    const abeRows = [
        { g: 'A', color: '#22c55e', symp: 'CAT <10 / mMRC 0–1', exac: '0–1 moderadas, sin hospitalización', tx: 'LAMA o LABA' },
        { g: 'B', color: '#f59e0b', symp: 'CAT ≥10 / mMRC ≥2', exac: '0–1 moderadas, sin hospitalización', tx: 'LAMA → LABA+LAMA si persiste' },
        { g: 'E', color: '#ef4444', symp: 'Cualquiera', exac: '≥2 moderadas O ≥1 hospitalización', tx: 'LABA+LAMA (± ICS según eos)' },
    ].map(row => {
        const active = row.g === r.abeGroup;
        const bg = active ? row.color + '22' : 'transparent';
        const fw = active ? '700' : '400';
        return `<tr style="background:${bg};border-left:3px solid ${active ? row.color : 'transparent'};">
            <td style="padding:8px 10px;font-size:14px;font-weight:800;color:${active ? row.color : 'var(--text-secondary)'};">Grupo ${row.g}</td>
            <td style="padding:8px 10px;font-size:12px;color:var(--text-secondary);font-weight:${fw};">${row.symp}</td>
            <td style="padding:8px 10px;font-size:12px;color:var(--text-secondary);font-weight:${fw};">${row.exac}</td>
            <td style="padding:8px 10px;font-size:12px;color:${active ? row.color : 'var(--text-secondary)'};font-weight:${fw};">${row.tx}</td>
        </tr>`;
    }).join('');

    // Treatment block
    const treatmentHTML = r.abeGroup ? `
        <div style="background:${r.treatmentColor}15;border-left:4px solid ${r.treatmentColor};border-radius:0 12px 12px 0;padding:14px 16px;margin-bottom:12px;">
            <div style="font-size:13px;font-weight:700;color:${r.treatmentColor};margin-bottom:8px;text-transform:uppercase;letter-spacing:0.03em;">Tratamiento recomendado</div>
            <div style="font-size:13px;font-weight:700;color:var(--text-primary);margin-bottom:8px;">${r.treatmentTitle}</div>
            ${r.treatmentLines.map(l => `<div style="font-size:12px;color:var(--text-secondary);margin-bottom:4px;line-height:1.4;">${l}</div>`).join('')}
        </div>` : '';

    // ICS note
    const icsColors = { keep: '#ef4444', gray: '#f59e0b', remove: '#22c55e' };
    const icsHTML = r.icsNote ? `
        <div style="background:${icsColors[r.icsNote.level]}15;border:1px solid ${icsColors[r.icsNote.level]}44;border-radius:10px;padding:10px 14px;margin-bottom:12px;">
            <p style="font-size:12px;color:${icsColors[r.icsNote.level]};margin:0;font-weight:600;">💊 Guía ICS: ${r.icsNote.text}</p>
        </div>` : '';

    return `<div style="margin-top:16px;">
        ${fev1Banner}
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px;">
            ${goldBadge}${abeBadge}
        </div>
        ${catMmrcHTML}
        <div style="background:var(--bg-secondary);border-radius:12px;overflow:hidden;margin-bottom:14px;">
            <div style="padding:12px 14px;font-size:12px;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.05em;border-bottom:1px solid var(--border-color);">Esquema ABE (GOLD 2023-2025)</div>
            <div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;min-width:360px;">
                <thead><tr style="border-bottom:1px solid var(--border-color);">
                    <th style="padding:6px 10px;font-size:11px;color:var(--text-secondary);text-align:left;">Grupo</th>
                    <th style="padding:6px 10px;font-size:11px;color:var(--text-secondary);text-align:left;">Síntomas</th>
                    <th style="padding:6px 10px;font-size:11px;color:var(--text-secondary);text-align:left;">Exacerbaciones</th>
                    <th style="padding:6px 10px;font-size:11px;color:var(--text-secondary);text-align:left;">Tratamiento inicial</th>
                </tr></thead>
                <tbody>${abeRows}</tbody>
            </table></div>
        </div>
        ${treatmentHTML}
        ${icsHTML}
        <div style="background:var(--bg-secondary);border-radius:10px;padding:12px 14px;margin-bottom:12px;">
            <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.5;">ℹ️ El grado GOLD espirométrico (1–4) define la <strong>severidad</strong> de la obstrucción, no el tratamiento. El tratamiento farmacológico lo define el <strong>Esquema ABE</strong>.</p>
        </div>
        <p style="font-size:11px;color:var(--text-secondary);text-align:center;margin:0;">GOLD 2025 Report · goldcopd.org · Basado en GOLD 2023–2025</p>
    </div>`;
}

function calculateEPOCForm(event) {
    event.preventDefault();
    const inputs = _epocInputs();
    const r = Calculators.calculateEPOC(inputs);
    document.getElementById('epocResult').innerHTML = buildEPOCResultHTML(r);
    Storage.addToHistory({ calculatorId: 39, calculatorName: 'EPOC', inputs, result: { value: r.value, unit: r.unit, description: r.description }, interpretation: r.interpretation });
}

// === 38. FIB-4 / APRI — FIBROSIS HEPÁTICA === //
function _fibCk(id) { return document.getElementById(id)?.checked || false; }

function createFibrosisForm() {
    function ck(id, label, sub) {
        return `<label style="display:flex;align-items:flex-start;gap:12px;padding:10px;border-radius:8px;cursor:pointer;margin-bottom:6px;background:var(--bg-card);">
            <input type="checkbox" id="${id}" onchange="updateFibrosisLive()" style="width:18px;height:18px;margin-top:2px;flex-shrink:0;cursor:pointer;">
            <div>
                <div style="font-size:14px;font-weight:600;color:var(--text-primary);">${label}</div>
                ${sub ? `<div style="font-size:12px;color:var(--text-secondary);margin-top:2px;">${sub}</div>` : ''}
            </div>
        </label>`;
    }
    return `
        <div style="background:var(--bg-secondary);padding:14px 16px;border-radius:12px;margin-bottom:14px;border-left:4px solid #f97316;">
            <p style="font-size:13px;color:var(--text-secondary);margin:0;line-height:1.5;">
                Evaluación no invasiva de fibrosis hepática. FIB-4 es la herramienta más validada (AASLD 2023, EASL, OMS) para estadificar sin biopsia. Los estigmas clínicos contextualizan el resultado.
            </p>
        </div>
        <form id="fibrosisForm" onsubmit="calculateFibrosisForm(event)">

            <div style="background:var(--bg-secondary);padding:16px;border-radius:12px;margin-bottom:10px;">
                <div style="font-size:13px;font-weight:700;color:var(--text-secondary);margin-bottom:10px;text-transform:uppercase;letter-spacing:0.05em;">Contexto clínico (opcional)</div>
                <select id="fibEtiologia" style="width:100%;padding:10px 12px;border-radius:8px;border:1px solid var(--border-color);background:var(--bg-card);color:var(--text-primary);font-size:14px;">
                    <option value="">Etiología no especificada / Desconocida</option>
                    <option value="hcv">Hepatitis C (VHC)</option>
                    <option value="hbv">Hepatitis B (VHB)</option>
                    <option value="alcohol">Enfermedad hepática alcohólica</option>
                    <option value="masld">MASLD / NAFLD (hígado graso no alcohólico)</option>
                    <option value="otra">Otra</option>
                </select>
            </div>

            <div style="background:var(--bg-secondary);padding:16px;border-radius:12px;margin-bottom:10px;">
                <div style="font-size:13px;font-weight:700;color:var(--text-secondary);margin-bottom:12px;text-transform:uppercase;letter-spacing:0.05em;">Laboratorio</div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px;">
                    <div>
                        <label style="font-size:12px;font-weight:600;color:var(--text-secondary);display:block;margin-bottom:6px;">EDAD (años)</label>
                        <input type="number" id="fibAge" min="18" max="120" placeholder="ej: 55" oninput="updateFibrosisLive()"
                            style="width:100%;padding:10px 12px;border-radius:8px;border:1px solid var(--border-color);background:var(--bg-card);color:var(--text-primary);font-size:14px;box-sizing:border-box;">
                    </div>
                    <div>
                        <label style="font-size:12px;font-weight:600;color:var(--text-secondary);display:block;margin-bottom:6px;">AST / TGO (U/L)</label>
                        <input type="number" id="fibAst" min="0" placeholder="ej: 65" oninput="updateFibrosisLive()"
                            style="width:100%;padding:10px 12px;border-radius:8px;border:1px solid var(--border-color);background:var(--bg-card);color:var(--text-primary);font-size:14px;box-sizing:border-box;">
                    </div>
                    <div>
                        <label style="font-size:12px;font-weight:600;color:var(--text-secondary);display:block;margin-bottom:6px;">ALT / TGP (U/L)</label>
                        <input type="number" id="fibAlt" min="0" placeholder="ej: 45" oninput="updateFibrosisLive()"
                            style="width:100%;padding:10px 12px;border-radius:8px;border:1px solid var(--border-color);background:var(--bg-card);color:var(--text-primary);font-size:14px;box-sizing:border-box;">
                    </div>
                    <div>
                        <label style="font-size:12px;font-weight:600;color:var(--text-secondary);display:block;margin-bottom:6px;">LSN AST/TGO (U/L)</label>
                        <select id="fibLsn" onchange="updateFibrosisLive()" style="width:100%;padding:10px 12px;border-radius:8px;border:1px solid var(--border-color);background:var(--bg-card);color:var(--text-primary);font-size:14px;">
                            <option value="35">35 U/L</option>
                            <option value="40" selected>40 U/L (default)</option>
                            <option value="45">45 U/L</option>
                            <option value="50">50 U/L</option>
                        </select>
                    </div>
                </div>
                <label style="font-size:12px;font-weight:600;color:var(--text-secondary);display:block;margin-bottom:6px;">PLAQUETAS</label>
                <div style="display:flex;gap:8px;align-items:center;overflow:hidden;">
                    <input type="number" id="fibPlatelets" min="0" placeholder="ej: 170" oninput="updateFibrosisLive()"
                        style="flex:1;min-width:0;padding:10px 12px;border-radius:8px;border:1px solid var(--border-color);background:var(--bg-card);color:var(--text-primary);font-size:14px;box-sizing:border-box;">
                    <select id="fibPlateletsUnit" onchange="_fibUpdatePlateletPlaceholder(); updateFibrosisLive()"
                        style="flex-shrink:0;padding:10px 8px;border-radius:8px;border:1px solid var(--border-color);background:var(--bg-card);color:var(--text-primary);font-size:13px;">
                        <option value="k">&times;10³/µL</option>
                        <option value="mm3">/mm³</option>
                    </select>
                </div>
                <div style="font-size:11px;color:var(--text-secondary);margin-top:4px;">Si tu laboratorio reporta 170 000 selecciona /mm³; si reporta 170 selecciona ×10³/µL.</div>
            </div>

            <div style="background:var(--bg-secondary);padding:16px;border-radius:12px;margin-bottom:10px;">
                <div style="font-size:13px;font-weight:700;color:var(--text-secondary);margin-bottom:12px;text-transform:uppercase;letter-spacing:0.05em;">Estigmas — Dermatológico</div>
                ${ck('fibSpider','Spider nevi / Arañas vasculares','>5 lesiones en tronco o cara')}
                ${ck('fibEritemaPalmar','Eritema palmar','Eritema en eminencias tenar/hipotenar, bilateral')}
                ${ck('fibIctericia','Ictericia / Icterus escleral','Coloración amarillenta de piel o escleróticas')}
                ${ck('fibLeucon','Leuconiquia / Uñas de Terry','Blanqueamiento ungueal; zona blanca proximal con banda distal rosada')}
                ${ck('fibDupuytren','Contractura de Dupuytren','Fibrosis de fascia palmar — asociada a hepatopatía alcohólica')}
            </div>

            <div style="background:var(--bg-secondary);padding:16px;border-radius:12px;margin-bottom:10px;">
                <div style="font-size:13px;font-weight:700;color:var(--text-secondary);margin-bottom:12px;text-transform:uppercase;letter-spacing:0.05em;">Estigmas — Endocrino / Nutricional</div>
                ${ck('fibGineco','Ginecomastia','En hombres — hiperestrogenismo por metabolismo hepático alterado')}
                ${ck('fibVello','Pérdida de vello corporal','Rarefacción axilar y/o púbica')}
                ${ck('fibSarcopenia','Pérdida de masa muscular / Sarcopenia','Atrofia visible en extremidades, región temporal o interóseos')}
            </div>

            <div style="background:var(--bg-secondary);padding:16px;border-radius:12px;margin-bottom:10px;">
                <div style="font-size:13px;font-weight:700;color:var(--text-secondary);margin-bottom:12px;text-transform:uppercase;letter-spacing:0.05em;">Estigmas — Abdominal / Vascular</div>
                ${ck('fibHepato','Hepatomegalia','Hígado palpable por debajo del reborde costal')}
                ${ck('fibEsplen','Esplenomegalia','Bazo palpable — signo de hipertensión portal')}
                ${ck('fibAscitis','Ascitis','Matidez cambiante, oleada ascítica o distensión abdominal')}
                ${ck('fibCaput','Circulación colateral abdominal (caput medusae)','Venas visibles en pared abdominal irradiando desde ombligo')}
                ${ck('fibEdema','Edema periférico bilateral','Edema maleolar o pretibial bilateral')}
            </div>

            <div style="background:var(--bg-secondary);padding:16px;border-radius:12px;margin-bottom:10px;">
                <div style="font-size:13px;font-weight:700;color:var(--text-secondary);margin-bottom:12px;text-transform:uppercase;letter-spacing:0.05em;">Estigmas — Neurológico</div>
                ${ck('fibAsterixis','Asterixis / Flapping tremor','Movimiento aleteante al extender muñecas — encefalopatía hepática')}
                ${ck('fibEncefalop','Encefalopatía / Confusión fluctuante','Desorientación o comportamiento anómalo fluctuante')}
            </div>

            <div style="background:var(--bg-secondary);padding:14px 16px;border-radius:12px;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between;gap:12px;">
                <span style="font-size:13px;color:var(--text-secondary);">FIB-4 / APRI estimado:</span>
                <span id="fibLiveScore" style="font-size:14px;font-weight:700;color:var(--text-secondary);">— / —</span>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%;padding:14px;">
                🩺 Calcular FIB-4 / APRI
            </button>
        </form>
        <div id="fibrosisResult"></div>`;
}

function _fibUpdatePlateletPlaceholder() {
    const unit = document.getElementById('fibPlateletsUnit')?.value;
    const inp = document.getElementById('fibPlatelets');
    if (!inp) return;
    inp.placeholder = unit === 'mm3' ? 'ej: 170 000' : 'ej: 170';
}

function _fibrosisInputs() {
    return {
        age: document.getElementById('fibAge')?.value || '',
        ast: document.getElementById('fibAst')?.value || '',
        alt: document.getElementById('fibAlt')?.value || '',
        platelets: document.getElementById('fibPlatelets')?.value || '',
        plateletsUnit: document.getElementById('fibPlateletsUnit')?.value || 'k',
        lsnAst: document.getElementById('fibLsn')?.value || '40',
        etiologia: document.getElementById('fibEtiologia')?.value || '',
        spiderNevi:    _fibCk('fibSpider'),    eritemaPalmar: _fibCk('fibEritemaPalmar'),
        ictericia:     _fibCk('fibIctericia'), leuconiquia:   _fibCk('fibLeucon'),
        dupuytren:     _fibCk('fibDupuytren'), ginecomastia:  _fibCk('fibGineco'),
        perdidaVello:  _fibCk('fibVello'),     sarcopenia:    _fibCk('fibSarcopenia'),
        hepatomegalia: _fibCk('fibHepato'),    esplenomegalia:_fibCk('fibEsplen'),
        ascitis:       _fibCk('fibAscitis'),   caputMedusae:  _fibCk('fibCaput'),
        edema:         _fibCk('fibEdema'),     asterixis:     _fibCk('fibAsterixis'),
        encefalopatia: _fibCk('fibEncefalop'),
    };
}

function updateFibrosisLive() {
    const r = Calculators.calculateFibrosis(_fibrosisInputs());
    const el = document.getElementById('fibLiveScore');
    if (!el) return;
    if (r.fib4 === null) { el.style.color = 'var(--text-secondary)'; el.textContent = '— / —'; return; }
    el.style.color = r.fib4Color;
    el.textContent = `FIB-4: ${r.fib4} · APRI: ${r.apri ?? '—'}`;
}

function buildFibrosisResultHTML(r) {
    const stigmataNames = {
        spiderNevi:'Spider nevi', eritemaPalmar:'Eritema palmar', ictericia:'Ictericia / Icterus',
        leuconiquia:'Leuconiquia / Uñas de Terry', dupuytren:'Contractura de Dupuytren',
        ginecomastia:'Ginecomastia', perdidaVello:'Pérdida de vello corporal',
        sarcopenia:'Pérdida de masa muscular', hepatomegalia:'Hepatomegalia',
        esplenomegalia:'Esplenomegalia', ascitis:'Ascitis', caputMedusae:'Circulación colateral abdominal',
        edema:'Edema periférico bilateral', asterixis:'Asterixis / Flapping tremor',
        encefalopatia:'Encefalopatía hepática',
    };
    const fib4Rows = r.isOld ? [
        { range:'<2.0',     zone:'low',  label:'Bajo riesgo',   color:'#22c55e' },
        { range:'2.0–3.25', zone:'gray', label:'Indeterminado', color:'#f59e0b' },
        { range:'>3.25',    zone:'high', label:'Alto riesgo',   color:'#ef4444' },
    ] : [
        { range:'<1.30',    zone:'low',  label:'F0–F2 probable',  color:'#22c55e' },
        { range:'1.30–2.67',zone:'gray', label:'Indeterminado',   color:'#f59e0b' },
        { range:'>2.67',    zone:'high', label:'F3–F4 probable',  color:'#ef4444' },
    ];
    const fib4TableRows = fib4Rows.map(row => {
        const isActive = row.zone === r.fib4Zone;
        const bg = isActive ? row.color+'22' : 'transparent';
        const fw = isActive ? '700' : '400';
        return `<tr style="background:${bg};border-left:3px solid ${isActive?row.color:'transparent'};">
            <td style="padding:8px 10px;font-size:13px;font-weight:${fw};color:${isActive?row.color:'var(--text-secondary)'};white-space:nowrap;">${row.range}</td>
            <td style="padding:8px 10px;font-size:13px;font-weight:${fw};color:${isActive?row.color:'var(--text-secondary)'};">${row.label}</td>
        </tr>`;
    }).join('');

    const ageNote = r.isOld ? `<div style="background:#3b82f622;border:1px solid #3b82f6;border-radius:8px;padding:10px 12px;margin-top:8px;">
        <p style="font-size:12px;color:#3b82f6;margin:0;">ℹ️ Paciente >65 años — cutoffs ajustados (AASLD 2023)</p></div>` : '';

    const apriColor = r.apriColor || '#64748b';
    const detectedStigmata = r.stigmataMap ? Object.entries(r.stigmataMap).filter(([,v])=>v).map(([k])=>stigmataNames[k]||k) : [];
    const stigmataHTML = detectedStigmata.length === 0
        ? '<p style="font-size:13px;color:var(--text-secondary);margin:0;">Ningún estigma marcado</p>'
        : `<div style="display:flex;flex-wrap:wrap;gap:6px;">${detectedStigmata.map(s=>`<span style="background:var(--bg-card);border:1px solid var(--border-color);border-radius:6px;padding:4px 8px;font-size:12px;color:var(--text-primary);">${s}</span>`).join('')}</div>`;
    const stigmataLevelLabel = r.stigmataCount === 0 ? 'Sin estigmas' : r.stigmataCount <= 2 ? 'Sospecha moderada' : 'Alta sospecha clínica';
    const stigmataLevelColor = r.stigmataCount === 0 ? '#22c55e' : r.stigmataCount <= 2 ? '#f59e0b' : '#ef4444';

    return `<div style="margin-top:16px;">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px;">
            <div style="background:${(r.fib4Color||'#64748b')}22;border:2px solid ${r.fib4Color||'#64748b'};border-radius:14px;padding:16px;text-align:center;">
                <div style="font-size:12px;font-weight:700;color:var(--text-secondary);margin-bottom:4px;text-transform:uppercase;">FIB-4</div>
                <div style="font-size:28px;font-weight:800;color:${r.fib4Color||'#64748b'};">${r.fib4 ?? '—'}</div>
                <div style="font-size:12px;color:var(--text-secondary);margin-top:4px;">${r.fib4Label || '—'}</div>
            </div>
            <div style="background:${apriColor}22;border:2px solid ${apriColor};border-radius:14px;padding:16px;text-align:center;">
                <div style="font-size:12px;font-weight:700;color:var(--text-secondary);margin-bottom:4px;text-transform:uppercase;">APRI</div>
                <div style="font-size:28px;font-weight:800;color:${apriColor};">${r.apri ?? '—'}</div>
                <div style="font-size:12px;color:var(--text-secondary);margin-top:4px;">${r.apriLabel || '—'}</div>
            </div>
        </div>
        <div style="background:var(--bg-secondary);border-radius:12px;overflow:hidden;margin-bottom:14px;">
            <div style="padding:12px 14px;font-size:12px;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.05em;border-bottom:1px solid var(--border-color);">Umbrales FIB-4${r.isOld?' (ajustados >65 años)':''}</div>
            <table style="width:100%;border-collapse:collapse;">
                <thead><tr style="border-bottom:1px solid var(--border-color);">
                    <th style="padding:6px 10px;font-size:11px;color:var(--text-secondary);text-align:left;">FIB-4</th>
                    <th style="padding:6px 10px;font-size:11px;color:var(--text-secondary);text-align:left;">Interpretación</th>
                </tr></thead>
                <tbody>${fib4TableRows}</tbody>
            </table>
            ${ageNote}
        </div>
        <div style="background:var(--bg-secondary);border-radius:12px;padding:16px;margin-bottom:14px;">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
                <div style="font-size:13px;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.05em;">Estigmas clínicos (${r.stigmataCount})</div>
                <span style="font-size:12px;font-weight:700;color:${stigmataLevelColor};">${stigmataLevelLabel}</span>
            </div>
            ${stigmataHTML}
        </div>
        <div style="background:${r.combinedColor}15;border-left:4px solid ${r.combinedColor};border-radius:0 12px 12px 0;padding:14px 16px;margin-bottom:12px;">
            <div style="font-size:14px;font-weight:700;color:${r.combinedColor};margin-bottom:6px;">${r.combinedLabel}</div>
            <p style="font-size:13px;color:var(--text-secondary);margin:0;line-height:1.5;">${r.combinedRec}</p>
        </div>
        <div style="background:var(--bg-secondary);border-radius:10px;padding:12px 14px;margin-bottom:12px;">
            <p style="font-size:12px;color:var(--text-secondary);margin:0;line-height:1.5;">⚠️ FIB-4 y APRI son herramientas de <strong>cribado</strong>, no de diagnóstico definitivo. La elastografía hepática y la biopsia son el estándar de referencia cuando los resultados son indeterminados o discordantes.</p>
        </div>
        <p style="font-size:11px;color:var(--text-secondary);text-align:center;margin:0;">Vallet-Pichard A et al. <em>Hepatology.</em> 2007 &nbsp;·&nbsp; Wai CT et al. <em>Hepatology.</em> 2003</p>
    </div>`;
}

function calculateFibrosisForm(event) {
    event.preventDefault();
    const inputs = _fibrosisInputs();
    if (!inputs.age || !inputs.ast || !inputs.alt || !inputs.platelets) {
        document.getElementById('fibrosisResult').innerHTML = '<p style="color:var(--danger);font-size:13px;padding:10px;">Completa edad, AST/TGO, ALT/TGP y plaquetas para calcular.</p>';
        return;
    }
    const r = Calculators.calculateFibrosis(inputs);
    document.getElementById('fibrosisResult').innerHTML = buildFibrosisResultHTML(r);
    Storage.addToHistory({ calculatorId: 38, calculatorName: 'FIB-4 / APRI', inputs, result: { value: r.value, unit: r.unit, description: r.description }, interpretation: r.interpretation });
}

// === 37. PSI/PORT — ÍNDICE DE SEVERIDAD DE NEUMONÍA === //
function _psiCk(id) { return document.getElementById(id)?.checked || false; }

function createPSIForm() {
    function ck(id, label, sub) {
        return `<label style="display:flex;align-items:flex-start;gap:12px;padding:10px;border-radius:8px;cursor:pointer;margin-bottom:6px;background:var(--bg-card);">
            <input type="checkbox" id="${id}" onchange="updatePSILive()" style="width:18px;height:18px;margin-top:2px;flex-shrink:0;cursor:pointer;">
            <div>
                <div style="font-size:14px;font-weight:600;color:var(--text-primary);">${label}</div>
                ${sub ? `<div style="font-size:12px;color:var(--text-secondary);margin-top:2px;">${sub}</div>` : ''}
            </div>
        </label>`;
    }
    return `
        <div style="background:var(--bg-secondary);padding:14px 16px;border-radius:12px;margin-bottom:14px;border-left:4px solid #22c55e;">
            <p style="font-size:13px;color:var(--text-secondary);margin:0;line-height:1.5;">
                Estratifica la severidad de la NAC en clases I–V. Los laboratorios son <strong>opcionales</strong> — si no están disponibles, déjalos sin marcar (no suman puntos, pero el score puede subestimar la severidad).
            </p>
        </div>
        <form id="psiForm" onsubmit="calculatePSIForm(event)">

            <!-- Datos demográficos -->
            <div style="background:var(--bg-secondary);padding:16px;border-radius:12px;margin-bottom:10px;">
                <div style="font-size:13px;font-weight:700;color:var(--text-secondary);margin-bottom:12px;text-transform:uppercase;letter-spacing:0.05em;">Datos del paciente</div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px;">
                    <div>
                        <label style="font-size:12px;font-weight:600;color:var(--text-secondary);display:block;margin-bottom:6px;">EDAD (años)</label>
                        <input type="number" id="psiAge" min="18" max="120" placeholder="ej: 65" oninput="updatePSILive()"
                            style="width:100%;padding:10px 12px;border-radius:8px;border:1px solid var(--border-color);background:var(--bg-card);color:var(--text-primary);font-size:14px;box-sizing:border-box;">
                    </div>
                    <div>
                        <label style="font-size:12px;font-weight:600;color:var(--text-secondary);display:block;margin-bottom:6px;">SEXO</label>
                        <select id="psiSex" onchange="updatePSILive()" style="width:100%;padding:10px 12px;border-radius:8px;border:1px solid var(--border-color);background:var(--bg-card);color:var(--text-primary);font-size:14px;">
                            <option value="M">Masculino</option>
                            <option value="F">Femenino (−10 pts)</option>
                        </select>
                    </div>
                </div>
                ${ck('psiNursing','Residente de hogar de ancianos / institución','Independiente de la edad — suma +10 pts')}
            </div>

            <!-- Comorbilidades -->
            <div style="background:var(--bg-secondary);padding:16px;border-radius:12px;margin-bottom:10px;">
                <div style="font-size:13px;font-weight:700;color:var(--text-secondary);margin-bottom:12px;text-transform:uppercase;letter-spacing:0.05em;">Comorbilidades</div>
                ${ck('psiNeoplasia','Neoplasia activa','+30 pts — tumor sólido, hematológico, o neoplasia diagnosticada en el último año (excl. cáncer de piel basocelular/espinocelular)')}
                ${ck('psiLiver','Enfermedad hepática','+20 pts — cirrosis u otra hepatopatía crónica documentada')}
                ${ck('psiChf','Insuficiencia cardíaca congestiva (ICC)','+10 pts — documentada por historia, examen o imagen')}
                ${ck('psiCerebro','Enfermedad cerebrovascular','+10 pts — ACV o isquemia cerebral transitoria documentados')}
                ${ck('psiRenal','Enfermedad renal','+10 pts — ERC documentada o elevación de creatinina/BUN en contexto crónico')}
            </div>

            <!-- Examen físico -->
            <div style="background:var(--bg-secondary);padding:16px;border-radius:12px;margin-bottom:10px;">
                <div style="font-size:13px;font-weight:700;color:var(--text-secondary);margin-bottom:12px;text-transform:uppercase;letter-spacing:0.05em;">Examen físico</div>
                ${ck('psiAms','Alteración del estado mental (AMS)','+20 pts — desorientación, estupor, coma. Nuevo respecto al basal')}
                ${ck('psiRr30','Frecuencia respiratoria ≥30/min','+20 pts')}
                ${ck('psiSbp90','PAS <90 mmHg','+20 pts — hipotensión sostenida')}
                ${ck('psiTemp','Temperatura <35°C o ≥40°C','+15 pts — hipotermia o fiebre alta')}
                ${ck('psiHr125','Frecuencia cardíaca ≥125/min','+10 pts')}
            </div>

            <!-- Laboratorio y radiología (opcionales) -->
            <div style="background:var(--bg-secondary);padding:16px;border-radius:12px;margin-bottom:10px;">
                <div style="font-size:13px;font-weight:700;color:var(--text-secondary);margin-bottom:4px;text-transform:uppercase;letter-spacing:0.05em;">Laboratorio y radiología</div>
                <p style="font-size:12px;color:var(--text-secondary);margin:0 0 12px 0;">Marca solo los criterios que están presentes y confirmados. Si el lab no está disponible, déjalo sin marcar.</p>
                ${ck('psiPh','pH arterial &lt;7.35','+30 pts — acidemia en gasometría arterial')}
                ${ck('psiBun','BUN ≥30 mg/dL (≥11 mmol/L)','+20 pts — nitrógeno ureico elevado')}
                ${ck('psiNa','Sodio sérico &lt;130 mEq/L','+20 pts — hiponatremia significativa')}
                ${ck('psiGlucose','Glucosa ≥250 mg/dL (≥14 mmol/L)','+10 pts')}
                ${ck('psiHct','Hematocrito &lt;30%','+10 pts — anemia significativa')}
                ${ck('psiHypoxia','PaO₂ &lt;60 mmHg o SaO₂ &lt;90%','+10 pts — hipoxemia en gasometría o pulsioximetría')}
                ${ck('psiEffusion','Derrame pleural en radiografía de tórax','+10 pts')}
            </div>

            <!-- Live score -->
            <div style="background:var(--bg-secondary);padding:14px 16px;border-radius:12px;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between;gap:12px;">
                <span style="font-size:13px;color:var(--text-secondary);">Score / Clase estimada:</span>
                <span id="psiLiveClass" style="font-size:15px;font-weight:700;color:#22c55e;">— pts · Clase ?</span>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%;padding:14px;">
                🫁 Calcular PSI/PORT
            </button>
        </form>
        <div id="psiResult"></div>`;
}

function _psiInputs() {
    return {
        age: document.getElementById('psiAge')?.value || '0',
        sex: document.getElementById('psiSex')?.value || 'M',
        nursingHome:   _psiCk('psiNursing'),
        neoplasia:     _psiCk('psiNeoplasia'),
        liver:         _psiCk('psiLiver'),
        chf:           _psiCk('psiChf'),
        cerebrovascular: _psiCk('psiCerebro'),
        renal:         _psiCk('psiRenal'),
        ams:           _psiCk('psiAms'),
        rr30:          _psiCk('psiRr30'),
        sbp90:         _psiCk('psiSbp90'),
        tempAbnormal:  _psiCk('psiTemp'),
        hr125:         _psiCk('psiHr125'),
        phAcidosis:    _psiCk('psiPh'),
        bunHigh:       _psiCk('psiBun'),
        sodiumLow:     _psiCk('psiNa'),
        glucoseHigh:   _psiCk('psiGlucose'),
        hctLow:        _psiCk('psiHct'),
        hypoxia:       _psiCk('psiHypoxia'),
        effusion:      _psiCk('psiEffusion'),
    };
}

function updatePSILive() {
    const r = Calculators.calculatePSI(_psiInputs());
    const el = document.getElementById('psiLiveClass');
    if (!el) return;
    if (!document.getElementById('psiAge')?.value) {
        el.style.color = 'var(--text-secondary)'; el.textContent = '— pts · Clase ?'; return;
    }
    el.style.color = r.color;
    el.textContent = r.isClassI ? 'Clase I — Ambulatorio' : `${r.score} pts · Clase ${r.riskClass}`;
}

function buildPSIResultHTML(r) {
    const claseRows = [
        { n: 'I',   label: 'Clase I',   crit: '≤50 a, sin comorbilidades, vitales normales', mort: '<0.1%', color: '#22c55e' },
        { n: 'II',  label: 'Clase II',  crit: '≤70 pts',  mort: '0.6%',  color: '#22c55e' },
        { n: 'III', label: 'Clase III', crit: '71–90 pts', mort: '2.8%',  color: '#f59e0b' },
        { n: 'IV',  label: 'Clase IV',  crit: '91–130 pts',mort: '8.2%',  color: '#f97316' },
        { n: 'V',   label: 'Clase V',   crit: '>130 pts',  mort: '29.2%', color: '#ef4444' },
    ];

    const tableRows = claseRows.map(cl => {
        const isActive = cl.n === r.riskClass;
        const bg = isActive ? cl.color + '22' : 'transparent';
        const fw = isActive ? '700' : '400';
        const border = isActive ? `border-left:3px solid ${cl.color};` : 'border-left:3px solid transparent;';
        return `<tr style="background:${bg};${border}">
            <td style="padding:8px 10px;font-size:13px;font-weight:${fw};color:${isActive?cl.color:'var(--text-secondary)'};white-space:nowrap;">${cl.label}</td>
            <td style="padding:8px 10px;font-size:12px;color:var(--text-secondary);">${cl.crit}</td>
            <td style="padding:8px 10px;font-size:13px;font-weight:${fw};color:${isActive?cl.color:'var(--text-secondary)'};text-align:center;">${cl.mort}</td>
        </tr>`;
    }).join('');

    const scoreLabel = r.isClassI ? 'N/A (Clase I)' : `${r.score} pts`;

    const classIBanner = r.isClassI ? `<div style="background:#22c55e22;border:1px solid #22c55e;border-radius:10px;padding:12px 14px;margin-bottom:12px;">
        <p style="font-size:13px;color:#22c55e;margin:0;line-height:1.5;">
            ✅ Paciente ≤50 años sin comorbilidades y con signos vitales normales — <strong>Clase I por algoritmo directo</strong> (score no requerido).
            Si dispone de laboratorios, su normalidad confirmaría la clasificación.
        </p></div>` : '';

    return `<div style="margin-top:16px;">
        ${classIBanner}
        <!-- Badge -->
        <div style="background:${r.color}22;border:2px solid ${r.color};border-radius:14px;padding:20px;text-align:center;margin-bottom:14px;">
            <div style="font-size:14px;font-weight:600;color:var(--text-secondary);margin-bottom:4px;">PSI/PORT Score</div>
            <div style="font-size:36px;font-weight:800;color:${r.color};margin-bottom:4px;">Clase ${r.riskClass}</div>
            <div style="font-size:16px;font-weight:600;color:var(--text-primary);">${scoreLabel}</div>
            <div style="font-size:13px;color:var(--text-secondary);margin-top:6px;">
                Mortalidad a 30 días: <strong style="color:${r.color};">${r.mortality}</strong>
            </div>
        </div>
        <!-- Tabla -->
        <div style="background:var(--bg-secondary);border-radius:12px;overflow:hidden;margin-bottom:14px;">
            <div style="padding:12px 14px;font-size:12px;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.05em;border-bottom:1px solid var(--border-color);">Mortalidad a 30 días por clase (Fine et al.)</div>
            <table style="width:100%;border-collapse:collapse;">
                <thead><tr style="border-bottom:1px solid var(--border-color);">
                    <th style="padding:6px 10px;font-size:11px;color:var(--text-secondary);text-align:left;">Clase</th>
                    <th style="padding:6px 10px;font-size:11px;color:var(--text-secondary);text-align:left;">Criterio</th>
                    <th style="padding:6px 10px;font-size:11px;color:var(--text-secondary);text-align:center;">Mortalidad</th>
                </tr></thead>
                <tbody>${tableRows}</tbody>
            </table>
        </div>
        <!-- Disposición -->
        <div style="background:${r.color}15;border-left:4px solid ${r.color};border-radius:0 10px 10px 0;padding:12px 14px;margin-bottom:12px;">
            <div style="font-size:12px;font-weight:700;color:${r.color};margin-bottom:4px;text-transform:uppercase;letter-spacing:0.05em;">Disposición recomendada</div>
            <div style="font-size:13px;color:var(--text-primary);">${r.disposicion}</div>
        </div>
        <p style="font-size:11px;color:var(--text-secondary);text-align:center;margin:0;">Fine MJ et al. <em>N Engl J Med.</em> 1997;336(4):243–50 · PSI/PORT Cohort Study</p>
    </div>`;
}

function calculatePSIForm(event) {
    event.preventDefault();
    const inputs = _psiInputs();
    if (!inputs.age || parseInt(inputs.age) < 18) {
        document.getElementById('psiResult').innerHTML = '<p style="color:var(--danger);font-size:13px;padding:10px;">Ingresa una edad válida (≥18 años).</p>';
        return;
    }
    const r = Calculators.calculatePSI(inputs);
    document.getElementById('psiResult').innerHTML = buildPSIResultHTML(r);
    Storage.addToHistory({ calculatorId: 37, calculatorName: 'PSI/PORT', inputs, result: { value: r.value, unit: r.unit, description: r.description }, interpretation: r.interpretation });
}

// === 36. KILLIP-KIMBALL === //
function createKillipForm() {
    return `
        <div style="background:var(--bg-secondary); padding:14px 16px; border-radius:12px; margin-bottom:14px; border-left:4px solid #ef4444;">
            <p style="font-size:13px; color:var(--text-secondary); margin:0; line-height:1.5;">
                Clasifica la severidad de insuficiencia cardíaca en IAM. Marca los hallazgos clínicos presentes — la clase se determina automáticamente.
            </p>
        </div>

        <form id="killipForm" onsubmit="calculateKillipForm(event)">

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:10px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:12px; text-transform:uppercase; letter-spacing:0.05em;">Hallazgos pulmonares</div>
                <label style="font-size:14px; font-weight:600; color:var(--text-primary); display:block; margin-bottom:8px;">Estertores crepitantes</label>
                <select id="killipEstertores" onchange="updateKillipLive()" style="width:100%; padding:10px 12px; border-radius:8px; border:1px solid var(--border-color); background:var(--bg-card); color:var(--text-primary); font-size:14px;">
                    <option value="ninguno">Sin estertores</option>
                    <option value="menor_mitad">Estertores en &lt;½ de los campos pulmonares</option>
                    <option value="mayor_mitad">Estertores en &gt;½ de los campos pulmonares (EAP)</option>
                </select>
            </div>

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:10px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:12px; text-transform:uppercase; letter-spacing:0.05em;">Hallazgos cardíacos y venosos</div>
                <label style="display:flex; align-items:flex-start; gap:12px; padding:10px; border-radius:8px; cursor:pointer; margin-bottom:6px; background:var(--bg-card);">
                    <input type="checkbox" id="killipS3" onchange="updateKillipLive()" style="width:18px; height:18px; margin-top:2px; flex-shrink:0; cursor:pointer;">
                    <div>
                        <div style="font-size:14px; font-weight:600; color:var(--text-primary);">Tercer ruido (S3) / Galope ventricular</div>
                        <div style="font-size:12px; color:var(--text-secondary); margin-top:2px;">Galope protodiastólico audible en foco mitral</div>
                    </div>
                </label>
                <label style="display:flex; align-items:flex-start; gap:12px; padding:10px; border-radius:8px; cursor:pointer; background:var(--bg-card);">
                    <input type="checkbox" id="killipJVD" onchange="updateKillipLive()" style="width:18px; height:18px; margin-top:2px; flex-shrink:0; cursor:pointer;">
                    <div>
                        <div style="font-size:14px; font-weight:600; color:var(--text-primary);">Ingurgitación yugular (JVD)</div>
                        <div style="font-size:12px; color:var(--text-secondary); margin-top:2px;">Distensión venosa yugular con paciente a 45°</div>
                    </div>
                </label>
            </div>

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:10px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:12px; text-transform:uppercase; letter-spacing:0.05em;">Signos de shock cardiogénico</div>
                <label style="display:flex; align-items:flex-start; gap:12px; padding:10px; border-radius:8px; cursor:pointer; margin-bottom:6px; background:var(--bg-card);">
                    <input type="checkbox" id="killipPasBaja" onchange="updateKillipLive()" style="width:18px; height:18px; margin-top:2px; flex-shrink:0; cursor:pointer;">
                    <div>
                        <div style="font-size:14px; font-weight:600; color:var(--text-primary);">PAS &lt;90 mmHg</div>
                        <div style="font-size:12px; color:var(--text-secondary); margin-top:2px;">Hipotensión sostenida (no transitoria)</div>
                    </div>
                </label>
                <label style="display:flex; align-items:flex-start; gap:12px; padding:10px; border-radius:8px; cursor:pointer; background:var(--bg-card);">
                    <input type="checkbox" id="killipHipoperf" onchange="updateKillipLive()" style="width:18px; height:18px; margin-top:2px; flex-shrink:0; cursor:pointer;">
                    <div>
                        <div style="font-size:14px; font-weight:600; color:var(--text-primary);">Signos de hipoperfusión periférica</div>
                        <div style="font-size:12px; color:var(--text-secondary); margin-top:2px;">Extremidades frías/cianóticas, diaforesis, oliguria (&lt;30 mL/h), alteración del estado mental</div>
                    </div>
                </label>
            </div>

            <div style="background:var(--bg-secondary); padding:14px 16px; border-radius:12px; margin-bottom:14px; display:flex; align-items:center; gap:12px;">
                <span style="font-size:13px; color:var(--text-secondary);">Clase estimada:</span>
                <span id="killipLiveClass" style="font-size:15px; font-weight:700; color:#22c55e;">Clase I — Sin signos de IC</span>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">
                🫀 Clasificar Killip-Kimball
            </button>
        </form>
        <div id="killipResult"></div>`;
}

function updateKillipLive() {
    const estertores = document.getElementById('killipEstertores')?.value || 'ninguno';
    const s3 = document.getElementById('killipS3')?.checked || false;
    const jvd = document.getElementById('killipJVD')?.checked || false;
    const pasBaja = document.getElementById('killipPasBaja')?.checked || false;
    const hipoperfusion = document.getElementById('killipHipoperf')?.checked || false;
    const r = Calculators.calculateKillip({ estertores, s3, jvd, pasBaja, hipoperfusion });
    const el = document.getElementById('killipLiveClass');
    if (!el) return;
    if (!r.clase) {
        el.style.color = '#f59e0b';
        el.textContent = 'Indeterminado — verificar datos';
    } else {
        el.style.color = r.color;
        el.textContent = `${r.label} — ${r.desc}`;
    }
}

function buildKillipResultHTML(r) {
    const claseRows = [
        { n: 1, label: 'Clase I',   desc: 'Sin signos de IC',       hist: '~6%',  act: '1–2%',   color: '#22c55e' },
        { n: 2, label: 'Clase II',  desc: 'IC leve',                hist: '~17%', act: '4–6%',   color: '#f59e0b' },
        { n: 3, label: 'Clase III', desc: 'Edema agudo de pulmón',  hist: '~38%', act: '8–12%',  color: '#f97316' },
        { n: 4, label: 'Clase IV',  desc: 'Shock cardiogénico',     hist: '~81%', act: '40–60%', color: '#ef4444' },
    ];
    const manejo = {
        1: ['Protocolo IAM estándar: antiagregación dual, anticoagulación, reperfusión urgente','Monitorización continua (ECG, SpO₂, PA)','IECA/ARA-II según tolerancia hemodinámica','Betabloqueador una vez estabilizado (sin contraindicación)'],
        2: ['O₂ suplementario — objetivo SpO₂ ≥94%','Furosemida IV (20–40 mg); evaluar respuesta diurética','Nitratos IV si PAS >90 mmHg (reducir precarga)','IECA desde etapa temprana si PAS lo permite','Monitorización hemodinámica estrecha'],
        3: ['O₂ de alto flujo; CPAP/VNI precoz (reduce necesidad de intubación)','Furosemida IV a dosis altas (40–80 mg); infusión continua si respuesta insuficiente','Nitratos IV (reducción agresiva de precarga y poscarga)','Revascularización precoz (beneficio en STEMI con EAP)','Preparar posible intubación si VNI falla'],
        4: ['Vasopresores: norepinefrina 1ª línea (objetivo PAS ≥90 mmHg)','Dobutamina si bajo gasto sin hipotensión severa','Soporte ventilatorio invasivo si hipoxemia refractaria','Revascularización urgente — beneficio demostrado en STEMI (SHOCK Trial)','BCIA no recomendado de rutina (IABP-SHOCK II no demostró beneficio)','Considerar Impella / ECMO-VA en centros especializados','Traslado a centro con programa de shock cardiogénico'],
    };
    const disposicion = {
        1: 'Unidad coronaria / sala con monitoreo continuo',
        2: 'UCI coronaria',
        3: 'UCI',
        4: 'UCI — considerar traslado urgente a centro de shock cardiogénico',
    };

    if (!r.clase) {
        return `<div style="background:#f59e0b22; border:1px solid #f59e0b; border-radius:12px; padding:16px; margin-top:16px;">
            <div style="font-size:15px; font-weight:700; color:#f59e0b; margin-bottom:8px;">⚠️ Clase indeterminada</div>
            <p style="font-size:13px; color:var(--text-secondary); line-height:1.5; margin:0;">${r.warning}</p>
        </div>`;
    }

    const tableRows = claseRows.map(cl => {
        const isActive = cl.n === r.clase;
        const bg = isActive ? cl.color + '22' : 'transparent';
        const fw = isActive ? '700' : '400';
        const border = isActive ? `border-left:3px solid ${cl.color};` : 'border-left:3px solid transparent;';
        return `<tr style="background:${bg};${border}">
            <td style="padding:8px 10px;font-size:13px;font-weight:${fw};color:${isActive?cl.color:'var(--text-secondary)'};white-space:nowrap;">${cl.label}</td>
            <td style="padding:8px 10px;font-size:12px;color:var(--text-secondary);">${cl.desc}</td>
            <td style="padding:8px 10px;font-size:13px;font-weight:${fw};color:${isActive?cl.color:'var(--text-secondary)'};text-align:center;">${cl.hist}</td>
            <td style="padding:8px 10px;font-size:13px;font-weight:${fw};color:${isActive?cl.color:'var(--text-secondary)'};text-align:center;">${cl.act}</td>
        </tr>`;
    }).join('');

    const manejoItems = (manejo[r.clase] || []).map(m =>
        `<li style="font-size:13px;color:var(--text-secondary);line-height:1.5;margin-bottom:6px;">${m}</li>`
    ).join('');

    const warningBanner = r.warning ? `<div style="background:#f59e0b22;border:1px solid #f59e0b;border-radius:10px;padding:12px 14px;margin-bottom:12px;">
        <p style="font-size:13px;color:#f59e0b;margin:0;line-height:1.5;">⚠️ ${r.warning}</p></div>` : '';

    return `<div style="margin-top:16px;">
        ${warningBanner}
        <div style="background:${r.color}22;border:2px solid ${r.color};border-radius:14px;padding:20px;text-align:center;margin-bottom:14px;">
            <div style="font-size:32px;font-weight:800;color:${r.color};margin-bottom:4px;">${r.label}</div>
            <div style="font-size:15px;font-weight:600;color:var(--text-primary);">${r.desc}</div>
            <div style="font-size:13px;color:var(--text-secondary);margin-top:6px;">
                Mortalidad histórica: <strong style="color:${r.color};">${r.mortalidadHist}</strong>
                &nbsp;·&nbsp;
                Contemporánea: <strong style="color:${r.color};">${r.mortalidadAct}</strong>
            </div>
        </div>
        <div style="background:var(--bg-secondary);border-radius:12px;overflow:hidden;margin-bottom:14px;">
            <div style="padding:12px 14px;font-size:12px;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.05em;border-bottom:1px solid var(--border-color);">Mortalidad intrahospitalaria por clase</div>
            <table style="width:100%;border-collapse:collapse;">
                <thead><tr style="border-bottom:1px solid var(--border-color);">
                    <th style="padding:6px 10px;font-size:11px;color:var(--text-secondary);text-align:left;">Clase</th>
                    <th style="padding:6px 10px;font-size:11px;color:var(--text-secondary);text-align:left;">Descripción</th>
                    <th style="padding:6px 10px;font-size:11px;color:var(--text-secondary);text-align:center;">1967</th>
                    <th style="padding:6px 10px;font-size:11px;color:var(--text-secondary);text-align:center;">Actual</th>
                </tr></thead>
                <tbody>${tableRows}</tbody>
            </table>
        </div>
        <div style="background:var(--bg-secondary);border-radius:12px;padding:16px;margin-bottom:12px;">
            <div style="font-size:13px;font-weight:700;color:var(--text-secondary);margin-bottom:10px;text-transform:uppercase;letter-spacing:0.05em;">Manejo esencial</div>
            <ul style="margin:0;padding-left:18px;">${manejoItems}</ul>
        </div>
        <div style="background:${r.color}15;border-left:4px solid ${r.color};border-radius:0 10px 10px 0;padding:12px 14px;margin-bottom:12px;">
            <div style="font-size:12px;font-weight:700;color:${r.color};margin-bottom:4px;text-transform:uppercase;letter-spacing:0.05em;">Disposición recomendada</div>
            <div style="font-size:13px;color:var(--text-primary);">${disposicion[r.clase]}</div>
        </div>
        <p style="font-size:11px;color:var(--text-secondary);text-align:center;margin:0;">Killip T &amp; Kimball JT. <em>Am J Cardiol.</em> 1967;20(4):457–64</p>
    </div>`;
}

function calculateKillipForm(event) {
    event.preventDefault();
    const inputs = {
        estertores: document.getElementById('killipEstertores').value,
        s3: document.getElementById('killipS3').checked,
        jvd: document.getElementById('killipJVD').checked,
        pasBaja: document.getElementById('killipPasBaja').checked,
        hipoperfusion: document.getElementById('killipHipoperf').checked,
    };
    const r = Calculators.calculateKillip(inputs);
    document.getElementById('killipResult').innerHTML = buildKillipResultHTML(r);
    Storage.addToHistory({ calculatorId: 36, calculatorName: 'Killip-Kimball', inputs, result: { value: r.value, unit: r.unit, description: r.description }, interpretation: r.interpretation });
}

// === 40. ESTADO HIPEROSMOLAR HIPERGLUCÉMICO (EHH/HHS) === //
function createHHSForm() {
    const units = Storage.getSettings().units;
    const wUnit = units.weight || 'kg';
    return `
        <form id="hhsForm" onsubmit="calculateHHSProtocol(event)">

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:14px; text-transform:uppercase; letter-spacing:0.05em;">Datos del Paciente</div>

                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Peso (${wUnit})</label>
                    <input type="number" id="hhsWeight" required step="any" min="30" max="300" class="form-input">
                </div>

                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Estado mental</label>
                    <select id="hhsMental" required class="form-input">
                        <option value="alerta">Alerta</option>
                        <option value="somnoliento">Somnoliento / confuso</option>
                        <option value="estupor">Estupor</option>
                        <option value="coma">Coma</option>
                    </select>
                </div>

                <div class="form-group">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Estado hemodinámico</label>
                    <select id="hhsHemo" required class="form-input">
                        <option value="mild">Hipovolemia leve-moderada (más frecuente)</option>
                        <option value="severe">Hipovolemia severa — signos de shock</option>
                        <option value="euvolemic">Euvolémico</option>
                        <option value="cardiogenic">Choque cardiogénico / Falla cardíaca</option>
                    </select>
                </div>
            </div>

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:14px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:14px; text-transform:uppercase; letter-spacing:0.05em;">Laboratorio</div>

                <div style="display:grid; grid-template-columns:1fr auto; gap:8px; margin-bottom:14px; align-items:end;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Glucosa</label>
                        <input type="number" id="hhsGlucose" required step="any" min="200" max="3000" class="form-input" oninput="updateHHSLiveCalcs()">
                    </div>
                    <select id="hhsGlucoseUnit" class="form-input" style="min-width:100px;" onchange="updateHHSLiveCalcs()">
                        <option value="mg/dL" ${(Storage.getSetting('units.glucose')||'mg/dL')==='mg/dL' ? 'selected' : ''}>mg/dL</option>
                        <option value="mmol/L" ${Storage.getSetting('units.glucose')==='mmol/L' ? 'selected' : ''}>mmol/L</option>
                    </select>
                </div>

                <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:14px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Na⁺ (mEq/L)</label>
                        <input type="number" id="hhsSodium" required step="any" min="115" max="170" class="form-input" oninput="updateHHSLiveCalcs()">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">
                            K⁺ (mEq/L) <span style="color:#ef4444; font-size:11px;">crítico</span>
                        </label>
                        <input type="number" id="hhsPotassium" required step="0.1" min="1.5" max="8" class="form-input" oninput="updateHHSLiveCalcs()">
                    </div>
                </div>

                <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">pH <span style="font-size:11px; font-weight:500; color:var(--text-tertiary);">opcional</span></label>
                        <input type="number" id="hhsPh" step="0.01" min="6.5" max="7.5" class="form-input" placeholder="ej. 7.35">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">HCO₃⁻ (mEq/L) <span style="font-size:11px; font-weight:500; color:var(--text-tertiary);">opcional</span></label>
                        <input type="number" id="hhsHco3" step="any" min="1" max="40" class="form-input" placeholder="ej. 22">
                    </div>
                </div>
            </div>

            <div id="hhsLiveCalcs"></div>

            <div style="background:#fef3c7; border-left:4px solid #f59e0b; padding:14px; border-radius:8px; margin-bottom:16px; margin-top:4px;">
                <p style="font-size:12px; color:#92400e; margin:0;">
                    <strong>⚠️ Herramienta de apoyo clínico</strong> — Verificar siempre con el equipo médico. Basado en ADA Consensus Report 2024 · JBDS-IP 2022.
                </p>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">
                🧮 Generar Protocolo EHH
            </button>
        </form>
        <div id="hhsResult" style="display:none; margin-top:24px;"></div>
    `;
}

function updateHHSLiveCalcs() {
    const glucoseUnit = document.getElementById('hhsGlucoseUnit')?.value || 'mg/dL';
    const glucoseVal = parseFloat(document.getElementById('hhsGlucose')?.value);
    const sodiumVal = parseFloat(document.getElementById('hhsSodium')?.value);
    const kVal = parseFloat(document.getElementById('hhsPotassium')?.value);
    const liveDiv = document.getElementById('hhsLiveCalcs');
    if (!liveDiv) return;

    let glucoseMg = glucoseVal;
    if (glucoseUnit === 'mmol/L' && !isNaN(glucoseVal)) glucoseMg = glucoseVal / 0.0555;

    const naCorr = (!isNaN(sodiumVal) && !isNaN(glucoseMg))
        ? Math.round((sodiumVal + 2.4 * (glucoseMg - 100) / 100) * 10) / 10 : null;
    const osm = (!isNaN(sodiumVal) && !isNaN(glucoseMg))
        ? Math.round((2 * sodiumVal + glucoseMg / 18) * 10) / 10 : null;

    const kField = document.getElementById('hhsPotassium');
    if (kField && !isNaN(kVal)) {
        kField.style.borderColor = kVal < 3.3 ? '#dc2626' : '';
        kField.style.boxShadow = kVal < 3.3 ? '0 0 0 3px rgba(220,38,38,0.15)' : '';
    }

    if (naCorr === null && osm === null) { liveDiv.innerHTML = ''; return; }

    let rows = '';
    if (naCorr !== null) {
        rows += `<div style="display:flex;justify-content:space-between;margin-bottom:6px;"><span>Na corregido</span><strong>${naCorr} mEq/L</strong></div>`;
    }
    if (osm !== null) {
        const c = osm >= 320 ? '#dc2626' : 'var(--success)';
        rows += `<div style="display:flex;justify-content:space-between;"><span>Osmolaridad efectiva</span><strong style="color:${c}">${osm} mOsm/kg${osm >= 320 ? ' ⚠' : ''}</strong></div>`;
    }

    let kAlert = '';
    if (!isNaN(kVal) && kVal < 3.3) {
        kAlert = `<div style="background:#fef2f2;border:1px solid #dc2626;border-radius:6px;padding:8px;margin-top:8px;color:#dc2626;font-weight:700;font-size:12px;">⚠️ K⁺ ${kVal} mEq/L — RETENER INSULINA al generar el protocolo</div>`;
    }

    liveDiv.innerHTML = `<div style="background:var(--bg-secondary);padding:12px;border-radius:10px;margin-bottom:12px;font-size:13px;"><div style="font-size:11px;font-weight:700;color:var(--text-secondary);text-transform:uppercase;letter-spacing:0.05em;margin-bottom:8px;">Cálculos automáticos</div>${rows}${kAlert}</div>`;
}

function buildHHSProtocolHTML(r, inputs) {
    const section = (icon, title, color, content) => `
        <div style="margin-bottom:12px; border-radius:var(--radius-lg); overflow:hidden; border:1px solid ${color}33;">
            <div style="background:${color}22; padding:12px 16px; display:flex; align-items:center; gap:8px; border-bottom:1px solid ${color}33;">
                <span style="font-size:18px;">${icon}</span>
                <span style="font-size:14px; font-weight:700; color:${color};">${title}</span>
            </div>
            <div style="padding:14px 16px; background:var(--bg-card); font-size:13px; line-height:1.8;">${content}</div>
        </div>`;

    const headerHTML = `
        <div style="background:${r.severity.colorHex}; padding:20px; border-radius:var(--radius-lg); color:white; margin-bottom:12px;">
            <div style="font-size:22px; font-weight:800; margin-bottom:6px;">${r.severity.badge} ${r.severity.label}</div>
            <div style="font-size:13px; opacity:0.9; display:flex; flex-wrap:wrap; gap:12px;">
                <span>Glucosa ${inputs.glucose} ${inputs.glucoseUnit}</span><span>K⁺ ${inputs.potassium} mEq/L</span>
                <span>Estado mental: ${inputs.mentalStatus}</span>
            </div>
            <div style="margin-top:8px; font-size:12px; opacity:0.85; display:flex; gap:12px; flex-wrap:wrap;">
                <span>Na corregido: ${r.naCorregido} mEq/L</span>
                <span>Osm efectiva: ${r.osmEffective} mOsm/kg</span>
            </div>
        </div>`;

    const alertHTML = r.criticalAlert.hasAlert ? `
        <div style="background:#7f1d1d; color:#fca5a5; border:2px solid #dc2626; border-radius:var(--radius-lg); padding:16px; margin-bottom:12px; font-weight:700; font-size:14px; display:flex; align-items:center; gap:10px;">
            <span style="font-size:24px;">🚨</span><span>${r.criticalAlert.message}</span>
        </div>` : '';

    const overlapHTML = (inputs.ph && !isNaN(parseFloat(inputs.ph)) && (parseFloat(inputs.ph) < 7.30 || (inputs.hco3 && parseFloat(inputs.hco3) < 18))) ? `
        <div style="background:#4c1d95; color:#c4b5fd; border:2px solid #7c3aed; border-radius:var(--radius-lg); padding:16px; margin-bottom:12px; font-size:13px;">
            <strong>⚠️ Posible solapamiento CAD-EHH:</strong> pH/HCO₃ sugieren un componente de cetoacidosis concomitante — evaluar cetonas/anión gap y considerar manejo combinado (protocolo de insulina tipo CAD).
        </div>` : '';

    const kColor = r.potassium.holdInsulin ? '#dc2626' : '#f59e0b';

    const fluidContent = `
        <div><strong>Bolo inicial:</strong> <span style="color:var(--brand-accent);font-weight:700;">${r.fluids.bolusML} mL</span> de ${r.fluids.fluidType} en ${r.fluids.bolusTime}</div>
        <div><strong>Mantenimiento:</strong> 250–500 mL/h tras la primera hora, ajustando según diuresis y respuesta hemodinámica</div>
        <div><strong>Meta:</strong> reponer ~50% del déficit estimado (habitualmente 8-10 L) en las primeras 12h, el resto en las siguientes 24h</div>
        <div><strong>Na corregido:</strong> ${r.fluids.naNote}</div>
        <div style="margin-top:4px;color:#dc2626;font-weight:600;">⛔ NO iniciar insulina simultáneamente con los fluidos — la expansión de volumen por sí sola reduce la glucemia y evita el colapso vascular por desplazamiento osmótico brusco</div>
        ${r.fluids.hemodynamic === 'cardiogenic' ? '<div style="margin-top:4px;color:#f59e0b;font-weight:600;">⚠️ Choque cardiogénico — evaluar vasopresores/monitorización invasiva desde el inicio</div>' : ''}`;

    const potassiumContent = `
        <div><strong>K⁺ actual:</strong> ${r.potassium.value} mEq/L</div>
        <div><strong>Acción:</strong> <span style="color:${kColor};font-weight:700;">${r.potassium.kAction}</span></div>
        ${r.potassium.kRate !== '—' ? `<div><strong>Velocidad:</strong> ${r.potassium.kRate}</div>` : ''}
        <div style="margin-top:4px;">${r.potassium.kNote}</div>`;

    const insulinContent = r.insulin.holdInsulin
        ? `<div style="color:#dc2626;font-weight:700;">⚠️ INSULINA EN ESPERA — Reiniciar cuando K⁺ ≥ 3.3 mEq/L Y tras ≥1h de fluidoterapia</div>`
        : `<div><strong>Iniciar solo tras ≥1h de fluidoterapia y K⁺ ≥ 3.3 mEq/L</strong></div>
           <div><strong>Insulina IV:</strong> <span style="color:var(--brand-accent);font-weight:700;">Regular 0.05 U/kg/h = ${r.insulin.doseIV} U/h</span> (dosis fija menor que en CAD — mínima cetosis)</div>
           <div><strong>Objetivo de descenso:</strong> 50-70 mg/dL/h — si desciende más rápido, reducir la infusión</div>
           <div><strong>Si Glu &lt; 250-300 mg/dL:</strong> añadir Dextrosa 5% y mantener glucemia en ese rango hasta normalizar la osmolaridad y el estado mental</div>`;

    const vigilanciaContent = `
        <div><strong>Buscar causa precipitante:</strong> infección (más frecuente), IAM, ACV, incumplimiento terapéutico, fármacos (corticoides, diuréticos, antipsicóticos atípicos)</div>
        <div style="margin-top:4px;"><strong>Tromboprofilaxis:</strong> HBPM — el EHH cursa con hiperviscosidad y alto riesgo trombótico</div>
        <div style="margin-top:4px;color:#dc2626;font-weight:600;">⛔ Evitar corrección rápida — caída de Osm efectiva &lt; 3-8 mOsm/kg/h y de Na corregido &lt; 10 mEq/L/24h (riesgo de edema cerebral, más en jóvenes)</div>
        <div style="margin-top:4px;color:var(--text-secondary);font-size:12px;">Mortalidad del EHH (10-20%) mayor que la de la CAD — vigilancia estrecha en UCI/intermedios</div>`;

    const resContent = `
        <div style="padding:4px 0;border-bottom:1px solid var(--border-color);">Osmolaridad efectiva ≤ 315 mOsm/kg</div>
        <div style="padding:4px 0;border-bottom:1px solid var(--border-color);">Glucemia &lt; 250-300 mg/dL</div>
        <div style="padding:4px 0;border-bottom:1px solid var(--border-color);">Recuperación del estado mental/alerta basal</div>
        <div style="padding:4px 0;">Estabilidad hemodinámica y tolerancia a vía oral</div>`;

    const transContent = `
        <div><strong>Criterio:</strong> resolución + tolerando VO</div>
        <div><strong>Glargina:</strong> 0.5–0.8 U/kg/día = <span style="color:var(--brand-accent);font-weight:700;">${r.transition.glarginMin}–${r.transition.glarginMax} U/día</span></div>
        <div style="color:#dc2626;font-weight:600;">⛔ Mantener infusión IV 2h tras la primera dosis de glargina</div>`;

    return `${headerHTML}${alertHTML}${overlapHTML}
        ${section('💧', '1. Fluidos IV', '#3b82f6', fluidContent)}
        ${section('🧪', '2. Potasio', r.potassium.holdInsulin ? '#dc2626' : '#f59e0b', potassiumContent)}
        ${section('💉', '3. Insulina', '#22c55e', insulinContent)}
        ${section('🩹', '4. Vigilancia y Prevención', '#f97316', vigilanciaContent)}
        ${section('📋', '5. Criterios de Resolución', '#8b5cf6', resContent)}
        ${section('🔄', '6. Transición a Insulina SC', '#14b8a6', transContent)}`;
}

function calculateHHSProtocol(event) {
    event.preventDefault();
    const phRaw = document.getElementById('hhsPh').value;
    const hco3Raw = document.getElementById('hhsHco3').value;
    const inputs = {
        weight: parseFloat(document.getElementById('hhsWeight').value),
        hemodynamic: document.getElementById('hhsHemo').value,
        mentalStatus: document.getElementById('hhsMental').value,
        glucose: parseFloat(document.getElementById('hhsGlucose').value),
        glucoseUnit: document.getElementById('hhsGlucoseUnit').value,
        sodium: parseFloat(document.getElementById('hhsSodium').value),
        potassium: parseFloat(document.getElementById('hhsPotassium').value),
        chloride: null,
        ph: phRaw === '' ? null : parseFloat(phRaw),
        hco3: hco3Raw === '' ? null : parseFloat(hco3Raw)
    };
    const r = Calculators.calculateHHS(inputs);
    const container = document.getElementById('hhsResult');
    container.innerHTML = buildHHSProtocolHTML(r, inputs) + `
        <button class="btn btn-secondary" onclick="document.getElementById('hhsForm').reset(); document.getElementById('hhsResult').style.display='none'; document.getElementById('hhsLiveCalcs').innerHTML='';" style="width:100%; margin-top:12px;">
            🔄 Nuevo Protocolo
        </button>`;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 40, calculatorName: 'EHH', inputs, result: r, interpretation: r.interpretation });
}

// === 41. CRISIS HIPERTENSIVA === //
function createHypertensiveCrisisForm() {
    return `
        <form id="htnCrisisForm" onsubmit="calculateHypertensiveCrisisProtocol(event)">

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:14px; text-transform:uppercase; letter-spacing:0.05em;">Presión Arterial</div>
                <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">PAS (mmHg)</label>
                        <input type="number" id="htnSbp" required step="any" min="100" max="300" class="form-input">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">PAD (mmHg)</label>
                        <input type="number" id="htnDbp" required step="any" min="50" max="200" class="form-input">
                    </div>
                </div>
                <p style="font-size:11px; color:var(--text-tertiary); margin-top:8px;">Umbral habitual de crisis hipertensiva: PAS ≥ 180 o PAD ≥ 120 mmHg.</p>
            </div>

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:6px; text-transform:uppercase; letter-spacing:0.05em;">Daño Agudo de Órgano Diana</div>
                <p style="font-size:12px; color:var(--text-tertiary); margin-bottom:12px;">Marcar todo lo presente. Si no se marca ninguno → Urgencia hipertensiva (manejo oral).</p>

                ${[
                    ['acv_isquemico', 'ACV isquémico agudo (déficit neurológico focal)'],
                    ['acv_hemorragico', 'ACV hemorrágico (hemorragia intracerebral)'],
                    ['disec_aortica', 'Dolor torácico desgarrante — sospecha de disección aórtica'],
                    ['eap', 'Disnea aguda — edema agudo de pulmón / falla cardíaca'],
                    ['sca', 'Dolor torácico isquémico — síndrome coronario agudo'],
                    ['encefalopatia', 'Alteración de conciencia/convulsiones sin foco — encefalopatía hipertensiva'],
                    ['preeclampsia_eclampsia', 'Embarazo + proteinuria/síntomas o convulsiones — preeclampsia/eclampsia'],
                    ['ira', 'Daño renal agudo / hematuria-oliguria de novo'],
                    ['retinopatia', 'Papiledema / hemorragias retinianas (fondo de ojo grado III-IV)']
                ].map(([id, label]) => `
                    <label style="display:flex; align-items:flex-start; gap:10px; margin-bottom:10px; cursor:pointer;">
                        <input type="checkbox" class="htn-damage" value="${id}" style="width:18px; height:18px; margin-top:2px;" ${id === 'acv_isquemico' ? 'onchange="toggleHtnThrombo(this)"' : ''}>
                        <span style="font-size:13px;">${label}</span>
                    </label>`).join('')}

                <div id="htnThromboWrap" style="display:none; margin-top:6px; padding-left:28px;">
                    <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                        <input type="checkbox" id="htnThrombo" style="width:16px; height:16px;">
                        <span style="font-size:12px; color:var(--text-secondary);">¿Candidato a trombólisis IV? (ventana &lt; 4.5h)</span>
                    </label>
                </div>
            </div>

            <div style="background:#fef3c7; border-left:4px solid #f59e0b; padding:14px; border-radius:8px; margin-bottom:16px;">
                <p style="font-size:12px; color:#92400e; margin:0;">
                    <strong>⚠️ Herramienta de apoyo clínico</strong> — Verificar siempre con el equipo médico. Basado en ACC/AHA 2017 · ESC/ESH 2023.
                </p>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">
                🧮 Generar Protocolo
            </button>
        </form>
        <div id="htnCrisisResult" style="display:none; margin-top:24px;"></div>
    `;
}

function toggleHtnThrombo(checkbox) {
    const wrap = document.getElementById('htnThromboWrap');
    if (wrap) wrap.style.display = checkbox.checked ? 'block' : 'none';
}

function buildHypertensiveCrisisHTML(r) {
    const section = (icon, title, color, content) => `
        <div style="margin-bottom:12px; border-radius:var(--radius-lg); overflow:hidden; border:1px solid ${color}33;">
            <div style="background:${color}22; padding:12px 16px; display:flex; align-items:center; gap:8px; border-bottom:1px solid ${color}33;">
                <span style="font-size:18px;">🩺</span>
                <span style="font-size:14px; font-weight:700; color:${color};">${title}</span>
            </div>
            <div style="padding:14px 16px; background:var(--bg-card); font-size:13px; line-height:1.8;">${content}</div>
        </div>`;

    const headerHTML = `
        <div style="background:${r.severity.colorHex}; padding:20px; border-radius:var(--radius-lg); color:white; margin-bottom:12px;">
            <div style="font-size:22px; font-weight:800; margin-bottom:6px;">${r.severity.badge} ${r.severity.label}</div>
            <div style="font-size:14px; opacity:0.9;">PA: ${r.sbp}/${r.dbp} mmHg</div>
        </div>`;

    if (!r.isEmergency) {
        return `${headerHTML}
            ${section('💊', 'Manejo Ambulatorio (Urgencia Hipertensiva)', '#f59e0b', `
                <div><strong>Fármacos orales:</strong> Captopril 25 mg VO, Labetalol 200-400 mg VO o Clonidina 0.1-0.2 mg VO</div>
                <div style="margin-top:4px;"><strong>Meta:</strong> reducir la PA de forma gradual en 24-48h (no en la sala de urgencias)</div>
                <div style="margin-top:4px;color:#dc2626;font-weight:600;">⛔ NO usar Nifedipino sublingual — riesgo de hipotensión brusca e isquemia (miocárdica/cerebral)</div>
                <div style="margin-top:4px;">Reposo, ambiente tranquilo, reevaluar en 30-60 min. Ajustar/reiniciar tratamiento antihipertensivo crónico y asegurar seguimiento ambulatorio precoz.</div>
            `)}`;
    }

    const sectionsHTML = r.sections.map(s => section('🚨', s.label, s.color, `
        <div><strong>Fármaco:</strong> ${s.drug}</div>
        <div style="margin-top:4px;"><strong>Objetivo:</strong> ${s.target}</div>
        <div style="margin-top:4px; color:var(--text-secondary);">${s.notes}</div>
    `)).join('');

    return `${headerHTML}
        <div style="background:#7f1d1d; color:#fca5a5; border:2px solid #dc2626; border-radius:var(--radius-lg); padding:14px; margin-bottom:12px; font-size:13px;">
            <strong>Regla general:</strong> salvo disección aórtica o eclampsia (reducción rápida en minutos), reducir la PAM ~25% en la primera hora — la corrección demasiado rápida puede causar hipoperfusión de órganos ya autorregulados a presiones más altas.
        </div>
        ${sectionsHTML}`;
}

function calculateHypertensiveCrisisProtocol(event) {
    event.preventDefault();
    const damages = Array.from(document.querySelectorAll('.htn-damage:checked')).map(cb => cb.value);
    const inputs = {
        sbp: parseFloat(document.getElementById('htnSbp').value),
        dbp: parseFloat(document.getElementById('htnDbp').value),
        damages,
        thromboCandidate: document.getElementById('htnThrombo') ? document.getElementById('htnThrombo').checked : false
    };
    const r = Calculators.calculateHypertensiveCrisis(inputs);
    const container = document.getElementById('htnCrisisResult');
    container.innerHTML = buildHypertensiveCrisisHTML(r) + `
        <button class="btn btn-secondary" onclick="document.getElementById('htnCrisisForm').reset(); document.getElementById('htnCrisisResult').style.display='none';" style="width:100%; margin-top:12px;">
            🔄 Nuevo Protocolo
        </button>`;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 41, calculatorName: 'Crisis Hipertensiva', inputs, result: r, interpretation: r.interpretation });
}

// === 42. ESTATUS EPILÉPTICO === //
function createStatusEpilepticusForm() {
    const units = Storage.getSettings().units;
    const wUnit = units.weight || 'kg';
    return `
        <form id="seForm" onsubmit="calculateStatusEpilepticusProtocol(event)">

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Peso (${wUnit})</label>
                    <input type="number" id="seWeight" required step="any" min="20" max="300" class="form-input">
                </div>

                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Etapa actual</label>
                    <select id="seStage" required class="form-input">
                        <option value="temprano">Incipiente (&lt; 5 min, primera dosis de benzodiacepina)</option>
                        <option value="establecido">Establecido (persiste tras 2 dosis de benzodiacepina, 5-20 min)</option>
                        <option value="refractario">Refractario (persiste tras 2ª línea IV, &gt; 20-30 min)</option>
                    </select>
                </div>

                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Acceso IV disponible</label>
                    <select id="seIvAccess" required class="form-input">
                        <option value="si">Sí</option>
                        <option value="no">No (usar vía IM/bucal/rectal)</option>
                    </select>
                </div>

                <div style="display:flex; flex-direction:column; gap:10px;">
                    <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                        <input type="checkbox" id="seHepatopatia" style="width:18px; height:18px;">
                        <span style="font-size:13px;">Hepatopatía severa (evitar Ácido Valproico)</span>
                    </label>
                    <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                        <input type="checkbox" id="seEmbarazo" style="width:18px; height:18px;">
                        <span style="font-size:13px;">Embarazo (evitar Ácido Valproico — teratógeno)</span>
                    </label>
                    <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                        <input type="checkbox" id="seHipoglucemia" style="width:18px; height:18px;">
                        <span style="font-size:13px;">Hipoglucemia sospechada / etilismo-desnutrición</span>
                    </label>
                </div>
            </div>

            <div style="background:#fef3c7; border-left:4px solid #f59e0b; padding:14px; border-radius:8px; margin-bottom:16px;">
                <p style="font-size:12px; color:#92400e; margin:0;">
                    <strong>⚠️ Herramienta de apoyo clínico</strong> — Verificar siempre con el equipo médico. Basado en AES Guideline 2016 · Neurocritical Care Society 2012 (ESETT).
                </p>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">
                🧮 Generar Protocolo
            </button>
        </form>
        <div id="seResult" style="display:none; margin-top:24px;"></div>
    `;
}

function buildStatusEpilepticusHTML(r) {
    const section = (icon, title, color, content, active) => `
        <div style="margin-bottom:12px; border-radius:var(--radius-lg); overflow:hidden; border:${active ? '2px solid ' + color : '1px solid ' + color + '33'};">
            <div style="background:${color}22; padding:12px 16px; display:flex; align-items:center; gap:8px; border-bottom:1px solid ${color}33;">
                <span style="font-size:18px;">${icon}</span>
                <span style="font-size:14px; font-weight:700; color:${color};">${title}</span>
                ${active ? `<span style="margin-left:auto; font-size:11px; font-weight:700; background:${color}; color:white; padding:2px 8px; border-radius:999px;">ETAPA ACTUAL</span>` : ''}
            </div>
            <div style="padding:14px 16px; background:var(--bg-card); font-size:13px; line-height:1.8;">${content}</div>
        </div>`;

    const headerHTML = `
        <div style="background:#dc2626; padding:20px; border-radius:var(--radius-lg); color:white; margin-bottom:12px;">
            <div style="font-size:22px; font-weight:800; margin-bottom:6px;">🚨 ${r.interpretation.label}</div>
            <div style="font-size:13px; opacity:0.9;">Peso: ${r.weight} kg</div>
        </div>`;

    const abcContent = `
        <div><strong>A-B-C:</strong> vía aérea, oxígeno suplementario, monitorización (SpO₂, ECG, PA)</div>
        <div style="margin-top:4px;"><strong>Glucemia capilar:</strong> ${r.hipoglucemia ? '<span style="color:#dc2626;font-weight:700;">Sospecha de hipoglucemia — dar Tiamina 100 mg IV ANTES de Dextrosa 50% 25g IV (evitar encefalopatía de Wernicke)</span>' : 'Descartar hipoglucemia como causa'}</div>
        <div style="margin-top:4px;">Vía IV, extracción de laboratorio (glucosa, electrolitos, niveles de antiepilépticos, tóxicos) y considerar neuroimagen/PL según sospecha etiológica.</div>`;

    const benzoContent = `
        <div><strong>Lorazepam:</strong> <span style="color:var(--brand-accent);font-weight:700;">0.1 mg/kg IV = ${r.benzo.lorazepamDose} mg</span> (máx. 4 mg), repetir en 5 min si persiste</div>
        <div style="margin-top:4px;"><strong>Alternativa:</strong> Diazepam 0.15-0.2 mg/kg IV = ${r.benzo.diazepamDose} mg (máx. 10 mg)</div>
        <div style="margin-top:4px;"><strong>Sin acceso IV:</strong> Midazolam IM = ${r.benzo.midazolamIM} mg (dosis única, RAMPART)</div>
        ${r.ivAccess === 'no' ? '<div style="margin-top:4px;color:#f59e0b;font-weight:600;">Sin acceso IV marcado — usar Midazolam IM como primera opción</div>' : ''}`;

    const segundaContent = `
        <div><strong>Levetiracetam:</strong> <span style="color:var(--brand-accent);font-weight:700;">60 mg/kg IV = ${r.segundaLinea.levetiracetamDose} mg</span> (máx. 4500 mg) en 15 min — perfil de seguridad más favorable</div>
        <div style="margin-top:4px;"><strong>Fosfenitoína/Fenitoína:</strong> 20 mg PE/kg IV = ${r.segundaLinea.fosfenitoinaDose} mg (máx. 1500 mg), a &lt; 150 mg/min</div>
        <div style="margin-top:4px;"><strong>Ácido Valproico:</strong> 40 mg/kg IV = ${r.segundaLinea.valproatoDose} mg (máx. 3000 mg)
            ${r.segundaLinea.avoidValproate ? ' <span style="color:#dc2626;font-weight:700;">— EVITAR (hepatopatía/embarazo marcados)</span>' : ''}
        </div>
        <div style="margin-top:4px;color:var(--text-secondary);font-size:12px;">Los tres fármacos mostraron eficacia similar en el ensayo ESETT — elegir según comorbilidad y disponibilidad.</div>`;

    const refractarioContent = `
        <div><strong>Midazolam en infusión:</strong> bolo 0.2 mg/kg IV, luego 0.05-2 mg/kg/h</div>
        <div style="margin-top:4px;"><strong>Propofol:</strong> bolo 1-2 mg/kg IV, luego 30-200 mcg/kg/min (vigilar síndrome de infusión de propofol)</div>
        <div style="margin-top:4px;"><strong>Alternativa:</strong> coma con Pentobarbital si refractario a lo anterior</div>
        <div style="margin-top:4px;color:#dc2626;font-weight:600;">Requiere intubación orotraqueal, UCI y EEG continuo (objetivo: supresión de brotes o control de crisis 24-48h antes de retirar)</div>
        <div style="margin-top:4px;color:var(--text-secondary);font-size:12px;">Superrefractario (&gt;24h): considerar Ketamina, anestésicos inhalados, dieta cetogénica o inmunoterapia si se sospecha etiología autoinmune.</div>`;

    return `${headerHTML}
        ${section('🅰️', '0. Soporte y Estabilización (ABC)', '#0ea5e9', abcContent, false)}
        ${section('💊', '1. Benzodiacepina (0-5 min)', '#f59e0b', benzoContent, r.currentStage === 0)}
        ${section('⚡', '2. Segunda Línea IV (5-20 min)', '#dc2626', segundaContent, r.currentStage === 1)}
        ${section('🛌', '3. Refractario — Anestesia (>20-30 min)', '#7c3aed', refractarioContent, r.currentStage === 2)}`;
}

function calculateStatusEpilepticusProtocol(event) {
    event.preventDefault();
    const inputs = {
        weight: parseFloat(document.getElementById('seWeight').value),
        stage: document.getElementById('seStage').value,
        ivAccess: document.getElementById('seIvAccess').value,
        hepatopatia: document.getElementById('seHepatopatia').checked,
        embarazo: document.getElementById('seEmbarazo').checked,
        hipoglucemia: document.getElementById('seHipoglucemia').checked
    };
    const r = Calculators.calculateStatusEpilepticus(inputs);
    const container = document.getElementById('seResult');
    container.innerHTML = buildStatusEpilepticusHTML(r) + `
        <button class="btn btn-secondary" onclick="document.getElementById('seForm').reset(); document.getElementById('seResult').style.display='none';" style="width:100%; margin-top:12px;">
            🔄 Nuevo Protocolo
        </button>`;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 42, calculatorName: 'Estatus Epiléptico', inputs, result: r, interpretation: r.interpretation });
}

// === 43. SEPSIS / SHOCK SÉPTICO — BUNDLE TERAPÉUTICO === //
function createSepsisBundleForm() {
    const units = Storage.getSettings().units;
    const wUnit = units.weight || 'kg';
    return `
        <form id="sepsisForm" onsubmit="calculateSepsisBundleProtocol(event)">

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Peso (${wUnit})</label>
                    <input type="number" id="sepsisWeight" required step="any" min="30" max="300" class="form-input">
                </div>

                <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:14px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Lactato (mmol/L)</label>
                        <input type="number" id="sepsisLactato" required step="0.1" min="0" max="30" class="form-input">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">PAM (mmHg)</label>
                        <input type="number" id="sepsisPam" required step="any" min="20" max="150" class="form-input">
                    </div>
                </div>

                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Foco infeccioso sospechado</label>
                    <select id="sepsisFoco" required class="form-input">
                        <option value="respiratorio">Respiratorio</option>
                        <option value="urinario">Urinario</option>
                        <option value="abdominal">Abdominal</option>
                        <option value="piel">Piel / Tejidos blandos</option>
                        <option value="desconocido">Desconocido</option>
                    </select>
                </div>

                <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                    <input type="checkbox" id="sepsisHipotensionPersistente" style="width:18px; height:18px;">
                    <span style="font-size:13px;">PAM &lt; 65 mmHg PERSISTENTE tras el bolo inicial de cristaloides</span>
                </label>
            </div>

            <div style="background:#fef3c7; border-left:4px solid #f59e0b; padding:14px; border-radius:8px; margin-bottom:16px;">
                <p style="font-size:12px; color:#92400e; margin:0;">
                    <strong>⚠️ Herramienta de apoyo clínico</strong> — Verificar siempre con el equipo médico. Basado en Surviving Sepsis Campaign 2021 (Hour-1 Bundle).
                </p>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">
                🧮 Generar Bundle
            </button>
        </form>
        <div id="sepsisResult" style="display:none; margin-top:24px;"></div>
    `;
}

function buildSepsisBundleHTML(r) {
    const section = (icon, title, color, content) => `
        <div style="margin-bottom:12px; border-radius:var(--radius-lg); overflow:hidden; border:1px solid ${color}33;">
            <div style="background:${color}22; padding:12px 16px; display:flex; align-items:center; gap:8px; border-bottom:1px solid ${color}33;">
                <span style="font-size:18px;">${icon}</span>
                <span style="font-size:14px; font-weight:700; color:${color};">${title}</span>
            </div>
            <div style="padding:14px 16px; background:var(--bg-card); font-size:13px; line-height:1.8;">${content}</div>
        </div>`;

    const focoLabels = { respiratorio: 'Respiratorio', urinario: 'Urinario', abdominal: 'Abdominal', piel: 'Piel/Tejidos blandos', desconocido: 'Desconocido' };

    const headerHTML = `
        <div style="background:${r.severity.colorHex}; padding:20px; border-radius:var(--radius-lg); color:white; margin-bottom:12px;">
            <div style="font-size:22px; font-weight:800; margin-bottom:6px;">${r.severity.badge} ${r.severity.label}</div>
            <div style="font-size:13px; opacity:0.9; display:flex; flex-wrap:wrap; gap:12px;">
                <span>Lactato ${r.lactato} mmol/L</span><span>PAM ${r.pam} mmHg</span><span>Foco: ${focoLabels[r.foco] || r.foco}</span>
            </div>
        </div>`;

    const diagContent = `
        <div>Lactato sérico — <strong>repetir a las 2-4h</strong> si el valor inicial es &gt; 2 mmol/L (guía de reanimación)</div>
        <div style="margin-top:4px;">Obtener 2 sets de hemocultivos (aerobio + anaerobio) ANTES de iniciar el antibiótico, sin retrasar su administración &gt; 45 min</div>`;

    const abxContent = `
        <div style="color:#dc2626; font-weight:700;">Administrar antibiótico empírico de amplio espectro dentro de la PRIMERA HORA</div>
        <div style="margin-top:4px;">Elegir esquema según foco sospechado (${focoLabels[r.foco] || r.foco}) — ver <strong>Calculadora 30, Guía de Antibioterapia Empírica</strong> para el régimen específico</div>
        <div style="margin-top:4px; color:var(--text-secondary);">Control del foco (drenaje de absceso, retiro de catéter, cirugía) tan pronto como sea posible tras la estabilización inicial.</div>`;

    const fluidContent = `
        <div><strong>Bolo inicial:</strong> <span style="color:var(--brand-accent);font-weight:700;">30 mL/kg = ${r.fluidBolusML} mL</span> de cristaloide balanceado, a pasar en las primeras 3 horas (más rápido si hipotensión franca)</div>
        <div style="margin-top:4px;">${r.needsBolus ? 'Indicado — PAM &lt; 65 o lactato ≥ 4 mmol/L' : 'Reevaluar necesidad según respuesta clínica — no bolo fijo si no hay datos de hipoperfusión'}</div>
        <div style="margin-top:4px; color:var(--text-secondary);">Reevaluar la respuesta a fluidos con variables dinámicas (elevación pasiva de piernas, variación de presión de pulso, ecografía de VCI) antes de continuar con más volumen.</div>`;

    const vasoContent = r.shockSeptico ? `
        <div style="color:#dc2626; font-weight:700;">Hipotensión persistente pese a fluidos — iniciar vasopresor</div>
        <div style="margin-top:4px;"><strong>1ª línea:</strong> Norepinefrina IV 0.01-3 mcg/kg/min, titular a <strong>PAM ≥ ${r.pamTarget} mmHg</strong></div>
        <div style="margin-top:4px;"><strong>2ª línea:</strong> Vasopresina 0.03 U/min (dosis fija) si Norepinefrina &gt; 0.25-0.5 mcg/kg/min</div>
        <div style="margin-top:4px;"><strong>3ª línea:</strong> Adrenalina si refractario a los dos anteriores</div>
        <div style="margin-top:4px;">Considerar Hidrocortisona 200 mg/día IV si shock refractario a vasopresores pese a fluidoterapia adecuada</div>
        <div style="margin-top:4px; color:var(--text-secondary);">Acceso venoso central y línea arterial recomendados. Considerar ingreso a UCI.</div>`
        : `<div style="color:var(--success); font-weight:600;">PAM ≥ ${r.pamTarget} mmHg tras fluidos — sin indicación de vasopresor por ahora</div>
           <div style="margin-top:4px; color:var(--text-secondary);">Reevaluar continuamente — iniciar Norepinefrina si la PAM cae por debajo de ${r.pamTarget} mmHg pese a fluidoterapia adecuada.</div>`;

    const checklistContent = `
        <div style="padding:4px 0;border-bottom:1px solid var(--border-color);">☐ Lactato medido (y repetido si &gt; 2 mmol/L)</div>
        <div style="padding:4px 0;border-bottom:1px solid var(--border-color);">☐ Hemocultivos x2 obtenidos antes del antibiótico</div>
        <div style="padding:4px 0;border-bottom:1px solid var(--border-color);">☐ Antibiótico de amplio espectro administrado (&lt; 1h)</div>
        <div style="padding:4px 0;border-bottom:1px solid var(--border-color);">☐ 30 mL/kg de cristaloide si hipotensión o lactato ≥ 4 mmol/L</div>
        <div style="padding:4px 0;">☐ Vasopresor iniciado si hipotensión persiste durante/después de fluidos (meta PAM ≥ 65 mmHg)</div>`;

    return `${headerHTML}
        ${section('🔬', '1. Diagnóstico Rápido', '#8b5cf6', diagContent)}
        ${section('💊', '2. Antibiótico Empírico', '#dc2626', abxContent)}
        ${section('💧', '3. Fluidoterapia', '#3b82f6', fluidContent)}
        ${section('💉', '4. Vasopresores', r.shockSeptico ? '#dc2626' : '#22c55e', vasoContent)}
        ${section('✅', '5. Checklist — Bundle de la Primera Hora', '#14b8a6', checklistContent)}`;
}

function calculateSepsisBundleProtocol(event) {
    event.preventDefault();
    const inputs = {
        weight: parseFloat(document.getElementById('sepsisWeight').value),
        lactato: parseFloat(document.getElementById('sepsisLactato').value),
        pam: parseFloat(document.getElementById('sepsisPam').value),
        foco: document.getElementById('sepsisFoco').value,
        hipotensionPersistente: document.getElementById('sepsisHipotensionPersistente').checked
    };
    const r = Calculators.calculateSepsisBundle(inputs);
    const container = document.getElementById('sepsisResult');
    container.innerHTML = buildSepsisBundleHTML(r) + `
        <button class="btn btn-secondary" onclick="document.getElementById('sepsisForm').reset(); document.getElementById('sepsisResult').style.display='none';" style="width:100%; margin-top:12px;">
            🔄 Nuevo Protocolo
        </button>`;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 43, calculatorName: 'Sepsis / Shock Séptico', inputs, result: r, interpretation: r.interpretation });
}

// === 44. EDEMA AGUDO DE PULMÓN / ICA DESCOMPENSADA === //
function createEAPForm() {
    return `
        <form id="eapForm" onsubmit="calculateEAPProtocol(event)">

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:14px; text-transform:uppercase; letter-spacing:0.05em;">Signos Vitales</div>
                <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">PAS (mmHg)</label>
                        <input type="number" id="eapSbp" required step="any" min="50" max="260" class="form-input">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">SpO₂ (%)</label>
                        <input type="number" id="eapSpo2" required step="any" min="50" max="100" class="form-input">
                    </div>
                </div>
            </div>

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:6px; text-transform:uppercase; letter-spacing:0.05em;">Signos de Hipoperfusión ("Frío")</div>
                <p style="font-size:12px; color:var(--text-tertiary); margin-bottom:10px;">Marcar todo lo presente.</p>
                ${[
                    ['eapExtremidadesFrias', 'Extremidades frías / livideces'],
                    ['eapOliguria', 'Oliguria / empeoramiento de función renal'],
                    ['eapAlteracionConciencia', 'Alteración del estado de conciencia'],
                    ['eapLactatoElevado', 'Lactato elevado']
                ].map(([id, label]) => `
                    <label style="display:flex; align-items:center; gap:10px; margin-bottom:10px; cursor:pointer;">
                        <input type="checkbox" id="${id}" style="width:18px; height:18px;">
                        <span style="font-size:13px;">${label}</span>
                    </label>`).join('')}
            </div>

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:6px; text-transform:uppercase; letter-spacing:0.05em;">Signos de Congestión ("Húmedo")</div>
                <p style="font-size:12px; color:var(--text-tertiary); margin-bottom:10px;">Marcar todo lo presente.</p>
                ${[
                    ['eapEstertores', 'Estertores / crepitantes pulmonares'],
                    ['eapIngurgitacion', 'Ingurgitación yugular'],
                    ['eapEdema', 'Edema periférico'],
                    ['eapOrtopnea', 'Ortopnea / disnea paroxística nocturna']
                ].map(([id, label]) => `
                    <label style="display:flex; align-items:center; gap:10px; margin-bottom:10px; cursor:pointer;">
                        <input type="checkbox" id="${id}" style="width:18px; height:18px;">
                        <span style="font-size:13px;">${label}</span>
                    </label>`).join('')}
            </div>

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Causa precipitante sospechada</label>
                <select id="eapCausa" required class="form-input">
                    <option value="volumen">Sobrecarga de volumen / incumplimiento dietético-farmacológico</option>
                    <option value="sca">Síndrome coronario agudo</option>
                    <option value="hipertensiva">Crisis hipertensiva</option>
                    <option value="arritmia">Arritmia (FA rápida, bloqueo, etc.)</option>
                    <option value="valvular">Valvulopatía aguda (rotura de cuerda, endocarditis)</option>
                    <option value="desconocida">No clara / a investigar</option>
                </select>
            </div>

            <div style="background:#fef3c7; border-left:4px solid #f59e0b; padding:14px; border-radius:8px; margin-bottom:16px;">
                <p style="font-size:12px; color:#92400e; margin:0;">
                    <strong>⚠️ Herramienta de apoyo clínico</strong> — Verificar siempre con el equipo médico. Basado en ESC Heart Failure Guidelines 2021/2023 · perfiles Forrester/Nohria-Stevenson.
                </p>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">
                🧮 Generar Protocolo
            </button>
        </form>
        <div id="eapResult" style="display:none; margin-top:24px;"></div>
    `;
}

function buildEAPProtocolHTML(r) {
    const section = (icon, title, color, content) => `
        <div style="margin-bottom:12px; border-radius:var(--radius-lg); overflow:hidden; border:1px solid ${color}33;">
            <div style="background:${color}22; padding:12px 16px; display:flex; align-items:center; gap:8px; border-bottom:1px solid ${color}33;">
                <span style="font-size:18px;">${icon}</span>
                <span style="font-size:14px; font-weight:700; color:${color};">${title}</span>
            </div>
            <div style="padding:14px 16px; background:var(--bg-card); font-size:13px; line-height:1.8;">${content}</div>
        </div>`;

    const causaLabels = { volumen: 'Sobrecarga de volumen', sca: 'Síndrome coronario agudo', hipertensiva: 'Crisis hipertensiva', arritmia: 'Arritmia', valvular: 'Valvulopatía aguda', desconocida: 'No clara' };

    const headerHTML = `
        <div style="background:${r.severity.colorHex}; padding:20px; border-radius:var(--radius-lg); color:white; margin-bottom:12px;">
            <div style="font-size:22px; font-weight:800; margin-bottom:6px;">${r.severity.badge} ${r.severity.label}</div>
            <div style="font-size:13px; opacity:0.9; display:flex; flex-wrap:wrap; gap:12px;">
                <span>PAS ${r.sbp} mmHg</span><span>SpO₂ ${r.spo2}%</span><span>Causa: ${causaLabels[r.causa] || r.causa}</span>
            </div>
            <div style="margin-top:8px; font-size:12px; opacity:0.85;">${r.profile.freq}</div>
        </div>`;

    const shockAlertHTML = r.shockCardiogenico ? `
        <div style="background:#7f1d1d; color:#fca5a5; border:2px solid #dc2626; border-radius:var(--radius-lg); padding:16px; margin-bottom:12px; font-weight:700; font-size:14px; display:flex; align-items:center; gap:10px;">
            <span style="font-size:24px;">🚨</span><span>Shock cardiogénico — hipoperfusión + PAS &lt; 90 mmHg. Priorizar soporte hemodinámico sobre diuréticos. Considerar UCI/hemodinamia urgente (equivalente a Killip IV).</span>
        </div>` : '';

    const nivHTML = r.needsNIV ? `
        <div style="background:#431407; color:#fdba74; border:2px solid #f97316; border-radius:var(--radius-lg); padding:16px; margin-bottom:12px; font-size:13px;">
            <strong>⚠️ SpO₂ &lt; 90%:</strong> iniciar ventilación no invasiva (CPAP/BiPAP) precozmente salvo contraindicación — reduce la necesidad de intubación en EAP.
        </div>` : '';

    let treatmentContent;
    if (r.profile.key === 'caliente-humedo') {
        treatmentContent = `
            <div><strong>Vasodilatador:</strong> Nitroglicerina IV, iniciar 10-20 mcg/min, titular c/5 min según respuesta y PA (mantener PAS &gt; 90-100 mmHg)</div>
            <div style="margin-top:4px;"><strong>Diurético:</strong> Furosemida IV — 20-40 mg si no toma diurético crónico; 1-2.5× la dosis oral diaria habitual (IV) si ya lo usa</div>
            <div style="margin-top:4px;">Reevaluar diuresis a las 2h — si respuesta inadecuada (&lt;100-150 mL/h o sin mejoría clínica), duplicar la dosis de Furosemida</div>
            <div style="margin-top:4px; color:#dc2626; font-weight:600;">Evitar betabloqueante IV en fase aguda descompensada (mantener el oral crónico si el paciente ya lo tomaba y está estable)</div>`;
    } else if (r.profile.key === 'frio-humedo') {
        treatmentContent = r.shockCardiogenico ? `
            <div><strong>Inotrópico:</strong> Dobutamina 2-20 mcg/kg/min o Milrinone, titulado a perfusión</div>
            <div style="margin-top:4px;"><strong>Vasopresor:</strong> Norepinefrina IV si hipotensión franca asociada, para mantener PAM ≥ 65 mmHg</div>
            <div style="margin-top:4px;">Diurético solo una vez mejorada la perfusión — no como primera medida en shock</div>
            <div style="margin-top:4px; color:#dc2626; font-weight:600;">Buscar y tratar la causa (reperfusión si SCA, control de arritmia). Considerar soporte mecánico (balón de contrapulsación, ECMO) si refractario — interconsulta urgente a cardiología intervencionista/cirugía cardíaca.</div>`
            : `
            <div>PA aceptable pese a hipoperfusión — puede tolerar vasodilatador a dosis bajas + diurético con cautela</div>
            <div style="margin-top:4px;">Considerar Inotrópico (Dobutamina/Milrinone) si no mejora la perfusión pese a lo anterior</div>
            <div style="margin-top:4px;">Monitorización estrecha — puede progresar a shock cardiogénico</div>`;
    } else if (r.profile.key === 'frio-seco') {
        treatmentContent = `
            <div>Perfil poco frecuente — hipoperfusión SIN congestión franca</div>
            <div style="margin-top:4px;">Optimizar precarga con pequeños bolos de fluido si tolera (evaluar respuesta a volumen)</div>
            <div style="margin-top:4px;">Inotrópico a dosis baja si persiste hipoperfusión tras optimizar precarga</div>
            <div style="margin-top:4px; color:#dc2626; font-weight:600;">Evitar diuréticos — pueden empeorar la hipoperfusión</div>`;
    } else {
        treatmentContent = `
            <div style="color:var(--success); font-weight:600;">Perfil compensado — no requiere manejo IV agudo</div>
            <div style="margin-top:4px;">Optimizar terapia crónica de insuficiencia cardíaca: IECA/ARA-II/ARNI, betabloqueante, antagonista mineralocorticoide, iSGLT2</div>
            <div style="margin-top:4px;">Reforzar restricción de sodio/líquidos y adherencia terapéutica antes del alta</div>`;
    }

    const reevalContent = `
        <div>Diuresis horaria, peso diario, disnea (escala subjetiva) y signos de congestión/perfusión seriados</div>
        <div style="margin-top:4px;">Lactato seriado si hipoperfusión — su descenso confirma respuesta al tratamiento</div>
        <div style="margin-top:4px;">Traslado a UCI/unidad de cuidados intermedios si shock cardiogénico, necesidad de VNI prolongada o soporte inotrópico/vasopresor</div>
        <div style="margin-top:4px; color:var(--text-secondary); font-size:12px;">Antes del alta: optimizar terapia crónica de IC, educar sobre signos de alarma y asegurar seguimiento precoz (7-14 días).</div>`;

    return `${headerHTML}${shockAlertHTML}${nivHTML}
        ${section('🫧', '1. Perfil Hemodinámico', r.profile.colorHex, `<div><strong>${r.profile.label}</strong> — ${r.isFrio ? 'con' : 'sin'} hipoperfusión, ${r.isHumedo ? 'con' : 'sin'} congestión</div>`)}
        ${section('💊', '2. Tratamiento Dirigido por Perfil', r.profile.colorHex, treatmentContent)}
        ${section('📋', '3. Reevaluación y Disposición', '#14b8a6', reevalContent)}`;
}

function calculateEAPProtocol(event) {
    event.preventDefault();
    const inputs = {
        sbp: parseFloat(document.getElementById('eapSbp').value),
        spo2: parseFloat(document.getElementById('eapSpo2').value),
        hypoperfusion: {
            extremidadesFrias: document.getElementById('eapExtremidadesFrias').checked,
            oliguria: document.getElementById('eapOliguria').checked,
            alteracionConciencia: document.getElementById('eapAlteracionConciencia').checked,
            lactatoElevado: document.getElementById('eapLactatoElevado').checked
        },
        congestion: {
            estertores: document.getElementById('eapEstertores').checked,
            ingurgitacion: document.getElementById('eapIngurgitacion').checked,
            edema: document.getElementById('eapEdema').checked,
            ortopnea: document.getElementById('eapOrtopnea').checked
        },
        causa: document.getElementById('eapCausa').value
    };
    const r = Calculators.calculateEAP(inputs);
    const container = document.getElementById('eapResult');
    container.innerHTML = buildEAPProtocolHTML(r) + `
        <button class="btn btn-secondary" onclick="document.getElementById('eapForm').reset(); document.getElementById('eapResult').style.display='none';" style="width:100%; margin-top:12px;">
            🔄 Nuevo Protocolo
        </button>`;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 44, calculatorName: 'EAP / ICA Descompensada', inputs, result: r, interpretation: r.interpretation });
}

// === 45. PROTOCOLO DE ARRITMIAS === //
function createArritmiaForm() {
    const units = Storage.getSettings().units;
    const wUnit = units.weight || 'kg';
    return `
        <form id="arritmiaForm" onsubmit="calculateArritmiaProtocol(event)">

            <div style="background:#7f1d1d; border:2px solid #dc2626; border-radius:12px; padding:14px; margin-bottom:16px;">
                <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                    <input type="checkbox" id="arrSinPulso" style="width:20px; height:20px;" onchange="toggleArritmiaArrest(this)">
                    <span style="font-size:14px; font-weight:700; color:#fca5a5;">🚨 Paciente SIN PULSO / en paro cardíaco</span>
                </label>
                <div id="arrParoRitmoWrap" style="display:none; margin-top:12px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:13px; color:#fca5a5;">Ritmo del paro</label>
                    <select id="arrRitmoParo" class="form-input">
                        <option value="desfibrilable">Desfibrilable — FV / TV sin pulso</option>
                        <option value="no_desfibrilable">No desfibrilable — Asistolia / AESP</option>
                    </select>
                </div>
            </div>

            <div id="arrNormalWrap">
                <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                    <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:6px; text-transform:uppercase; letter-spacing:0.05em;">Tipo de Arritmia</div>
                    <p style="font-size:11px; color:var(--text-tertiary); margin-bottom:10px;">Requiere interpretación previa del ECG — esta herramienta no interpreta el trazado.</p>
                    <select id="arrTipo" required class="form-input" onchange="toggleArritmiaFields()">
                        <option value="bradicardia">Bradicardia sintomática (incluye BAV)</option>
                        <option value="taqui_estrecha_regular">Taquicardia de QRS estrecho, REGULAR (SVT/PSVT)</option>
                        <option value="taqui_estrecha_irregular">Taquicardia de QRS estrecho/ancho, IRREGULAR (FA/Flutter con RVR)</option>
                        <option value="taqui_ancha_regular">Taquicardia de QRS ancho, REGULAR MONOMÓRFICA (TV estable)</option>
                        <option value="taqui_ancha_polimorfica">Taquicardia de QRS ancho, POLIMÓRFICA / Torsades</option>
                    </select>
                </div>

                <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                    <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:6px; text-transform:uppercase; letter-spacing:0.05em;">Estado Hemodinámico</div>
                    <p style="font-size:12px; color:var(--text-tertiary); margin-bottom:10px;">Marcar si hay CUALQUIERA de los siguientes — determina inestabilidad.</p>
                    ${[
                        ['arrHipotension', 'Hipotensión sintomática (PAS < 90 mmHg)'],
                        ['arrConciencia', 'Alteración aguda del estado de conciencia'],
                        ['arrShock', 'Signos de shock / hipoperfusión (frialdad, oliguria, lactato elevado)'],
                        ['arrDolorToracico', 'Dolor torácico isquémico agudo'],
                        ['arrEap', 'Edema agudo de pulmón / disnea severa aguda']
                    ].map(([id, label]) => `
                        <label style="display:flex; align-items:center; gap:10px; margin-bottom:10px; cursor:pointer;">
                            <input type="checkbox" id="${id}" style="width:18px; height:18px;">
                            <span style="font-size:13px;">${label}</span>
                        </label>`).join('')}
                </div>

                <div id="arrEstrechaRegularFields" style="display:none; background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                    <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                        <input type="checkbox" id="arrAdenosinaFallida" style="width:18px; height:18px;">
                        <span style="font-size:13px;">Ya se administró Adenosina sin respuesta / recurrió</span>
                    </label>
                </div>

                <div id="arrIrregularFields" style="display:none; background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                    <label style="display:flex; align-items:center; gap:10px; margin-bottom:10px; cursor:pointer;">
                        <input type="checkbox" id="arrEfReducida" style="width:18px; height:18px;">
                        <span style="font-size:13px;">Fracción de eyección reducida conocida (HFrEF)</span>
                    </label>
                    <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                        <input type="checkbox" id="arrPreexcitacion" style="width:18px; height:18px;">
                        <span style="font-size:13px;">Sospecha de preexcitación / WPW (QRS ancho e irregular, muy rápido &gt;200 lpm)</span>
                    </label>
                </div>

                <div id="arrAnchaRegularFields" style="display:none; background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Peso (${wUnit}) <span style="font-size:11px; font-weight:500; color:var(--text-tertiary);">para tope de Procainamida 17 mg/kg</span></label>
                    <input type="number" id="arrWeight" step="any" min="20" max="300" class="form-input">
                </div>

                <div id="arrPolimorficaFields" style="display:none; background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                    <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                        <input type="checkbox" id="arrQtLargo" style="width:18px; height:18px;">
                        <span style="font-size:13px;">QT prolongado conocido/basal (Torsades típica) — si no se marca, se asume mecanismo isquémico/Brugada/catecolaminérgico</span>
                    </label>
                </div>
            </div>

            <div style="background:#fef3c7; border-left:4px solid #f59e0b; padding:14px; border-radius:8px; margin-bottom:16px;">
                <p style="font-size:12px; color:#92400e; margin:0;">
                    <strong>⚠️ Herramienta de apoyo clínico</strong> — Verificar siempre con el equipo médico. Basado en AHA ACLS 2020 (Guidelines Update).
                </p>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">
                🧮 Generar Protocolo
            </button>
        </form>
        <div id="arritmiaResult" style="display:none; margin-top:24px;"></div>
    `;
}

function toggleArritmiaArrest(checkbox) {
    document.getElementById('arrParoRitmoWrap').style.display = checkbox.checked ? 'block' : 'none';
    document.getElementById('arrNormalWrap').style.display = checkbox.checked ? 'none' : 'block';
}

function toggleArritmiaFields() {
    const tipo = document.getElementById('arrTipo').value;
    document.getElementById('arrEstrechaRegularFields').style.display = tipo === 'taqui_estrecha_regular' ? 'block' : 'none';
    document.getElementById('arrIrregularFields').style.display = tipo === 'taqui_estrecha_irregular' ? 'block' : 'none';
    document.getElementById('arrAnchaRegularFields').style.display = tipo === 'taqui_ancha_regular' ? 'block' : 'none';
    document.getElementById('arrPolimorficaFields').style.display = tipo === 'taqui_ancha_polimorfica' ? 'block' : 'none';
}

function buildArritmiaProtocolHTML(r) {
    const section = (icon, title, color, content) => `
        <div style="margin-bottom:12px; border-radius:var(--radius-lg); overflow:hidden; border:1px solid ${color}33;">
            <div style="background:${color}22; padding:12px 16px; display:flex; align-items:center; gap:8px; border-bottom:1px solid ${color}33;">
                <span style="font-size:18px;">${icon}</span>
                <span style="font-size:14px; font-weight:700; color:${color};">${title}</span>
            </div>
            <div style="padding:14px 16px; background:var(--bg-card); font-size:13px; line-height:1.8;">${content}</div>
        </div>`;

    const headerHTML = `
        <div style="background:${r.severity.colorHex}; padding:20px; border-radius:var(--radius-lg); color:white; margin-bottom:12px;">
            <div style="font-size:20px; font-weight:800;">${r.severity.badge} ${r.severity.label}</div>
        </div>`;

    // ── PARO CARDÍACO ──────────────────────────────────────────────
    if (r.isArrest) {
        const rcpContent = `
            <div><strong>RCP de alta calidad:</strong> compresiones continuas (100-120/min, 5-6 cm), mínima interrupción, permitir expansión torácica completa</div>
            <div style="margin-top:4px;">Vía aérea avanzada y capnografía si disponible — objetivo EtCO₂ ≥ 10 mmHg como indicador de calidad de RCP</div>`;

        const shockableContent = `
            <div style="color:#dc2626; font-weight:700;">Desfibrilación INMEDIATA, NO sincronizada (200 J bifásico o dosis máxima del equipo)</div>
            <div style="margin-top:4px;">Reanudar RCP inmediatamente tras la descarga — NO verificar pulso/ritmo hasta completar 2 min de RCP</div>
            <div style="margin-top:4px;"><strong>Epinefrina:</strong> 1 mg IV/IO cada 3-5 min (tras la 2ª o 3ª descarga)</div>
            <div style="margin-top:4px;"><strong>Antiarrítmico:</strong> Amiodarona 300 mg IV/IO (bolo) → segunda dosis 150 mg si FV/TV recurrente; alternativa: Lidocaína 1-1.5 mg/kg IV/IO</div>`;

        const nonShockableContent = `
            <div style="color:var(--text-primary); font-weight:700;">NO desfibrilar</div>
            <div style="margin-top:4px;"><strong>Epinefrina:</strong> 1 mg IV/IO cada 3-5 min, lo antes posible</div>
            <div style="margin-top:4px;">El antiarrítmico (Amiodarona/Lidocaína) NO está indicado en Asistolia/AESP</div>
            <div style="margin-top:4px;">Reevaluar ritmo cada 2 min — si aparece un ritmo desfibrilable, cambiar de inmediato al protocolo correspondiente</div>`;

        const causasContent = `
            <div style="font-weight:700; margin-bottom:4px;">6 H:</div>
            <div>Hipovolemia · Hipoxia · Hidrogeniones (acidosis) · Hipo/Hiperkalemia · Hipotermia · Hipoglucemia</div>
            <div style="font-weight:700; margin:8px 0 4px;">5 T:</div>
            <div>Neumotórax a Tensión · Taponamiento cardíaco · Tóxicos · Trombosis pulmonar · Trombosis coronaria</div>`;

        return `${headerHTML}
            ${section('❤️‍🩹', '1. RCP', '#dc2626', rcpContent)}
            ${section(r.ritmoParo === 'desfibrilable' ? '⚡' : '🚫', '2. Ritmo — ' + (r.ritmoParo === 'desfibrilable' ? 'Desfibrilable' : 'No Desfibrilable'), r.ritmoParo === 'desfibrilable' ? '#dc2626' : '#6366f1', r.ritmoParo === 'desfibrilable' ? shockableContent : nonShockableContent)}
            ${section('🔍', '3. Causas Reversibles (6H/5T)', '#8b5cf6', causasContent)}`;
    }

    // ── INESTABLE (excepto polimórfica, que se trata siempre como FV) ──
    if (r.inestable && r.tipo !== 'bradicardia') {

        const prepContent = `
            <div>Oxígeno suplementario, monitor/desfibrilador con electrodos de parche, vía IV/IO permeable, capnografía si disponible</div>
            <div style="margin-top:4px;"><strong>Sedación breve si el tiempo y la estabilidad lo permiten:</strong> Etomidato 0.1-0.3 mg/kg IV, o Midazolam 0.05-0.1 mg/kg + Fentanilo 1-2 µg/kg IV, o Propofol 0.5-1 mg/kg IV</div>
            <div style="margin-top:4px; color:#dc2626; font-weight:600;">NO retrasar la cardioversión por sedación si el paciente está en inestabilidad extrema (shock franco, EAP fulminante) — priorizar la descarga</div>`;

        const cvContent = r.requiresDefibrillation ? `
            <div style="color:#dc2626; font-weight:700;">Tratar como Fibrilación Ventricular — Desfibrilación INMEDIATA, NO sincronizada (200 J bifásico o dosis máxima del equipo)</div>
            <div style="margin-top:4px;">La irregularidad de la TV polimórfica impide una sincronización fiable — no perder tiempo intentando sincronizar</div>
            <div style="margin-top:4px;">Si no revierte o degenera a TV sin pulso → pasar de inmediato al protocolo de paro cardíaco (RCP + descargas seriadas + Epinefrina + Amiodarona)</div>`
            : `
            <div><strong>Cardioversión eléctrica SINCRONIZADA</strong> — energía inicial: <span style="color:var(--brand-accent);font-weight:700;">${r.cardioversionJ}</span> (bifásico)</div>
            <div style="margin-top:4px;"><strong>Si el primer choque no revierte la arritmia:</strong> aumentar la energía de forma escalonada en el siguiente intento (habitualmente duplicando, p.ej. 100→200→300→360 J, o según las recomendaciones del fabricante, hasta la energía máxima del equipo) y repetir sincronizado</div>
            <div style="margin-top:4px; color:#dc2626; font-weight:600;">Si no hay captura, o el ritmo degenera a FV/TV sin pulso en cualquier momento → pasar de inmediato a desfibrilación NO sincronizada y al protocolo de paro cardíaco</div>
            <div style="margin-top:4px; color:var(--text-secondary); font-size:12px;">Reconfirmar el modo "sincronizado" antes de cada descarga — el desfibrilador lo desactiva automáticamente tras cada choque en muchos equipos</div>`;

        let recurContent;
        if (r.tipo === 'taqui_estrecha_regular') {
            recurContent = `
                <div>Si recurre tras la cardioversión o entre descargas: Adenosina 6 mg IV en bolo rápido (si no se ha probado) → 12 mg si no responde</div>
                <div style="margin-top:4px;">Para prevenir recurrencia: Betabloqueante IV (Metoprolol) o Calcioantagonista IV (Diltiazem) — evitar si preexcitación/WPW o disfunción ventricular severa</div>
                ${r.adenosinaFallida ? '<div style="margin-top:4px;color:#f59e0b;font-weight:600;">⚠️ Adenosina ya fallida — priorizar Betabloqueante/Calcioantagonista tras la cardioversión</div>' : ''}`;
        } else if (r.tipo === 'taqui_estrecha_irregular') {
            recurContent = r.preexcitacion ? `
                <div style="color:#dc2626; font-weight:700;">⚠️ Preexcitación (WPW) sospechada — EVITAR bloqueadores del nodo AV incluso peri-cardioversión</div>
                <div style="margin-top:4px;">NO usar Adenosina, Betabloqueante, Calcioantagonista ni Digoxina. Para prevenir recurrencia: Procainamida IV o Ibutilida IV</div>
                <div style="margin-top:4px;">Interconsulta a Electrofisiología — candidato a ablación de la vía accesoria</div>`
                : `
                <div>Para prevenir recurrencia tras la cardioversión — control de frecuencia: ${r.efReducida ? 'Amiodarona IV o Digoxina IV (FE reducida — evitar Calcioantagonistas no dihidropiridínicos)' : 'Betabloqueante IV (Metoprolol) o Calcioantagonista IV (Diltiazem)'}</div>
                <div style="margin-top:4px;">Anticoagulación: iniciar según CHA₂DS₂-VASc (Calculadora 9) independientemente de si se cardiovirtió — si &gt; 48h de inicio o incierto, considerar ecocardiograma transesofágico antes de cualquier cardioversión adicional para descartar trombo auricular</div>`;
        } else if (r.tipo === 'taqui_ancha_regular') {
            recurContent = `
                <div>Para prevenir recurrencia tras la cardioversión: Amiodarona IV 150 mg en 10 min (puede repetirse), luego infusión 1 mg/min × 6h y 0.5 mg/min × 18h</div>
                <div style="margin-top:4px;">Alternativa si función ventricular conservada y sin QT prolongado: Procainamida IV 20-50 mg/min${r.procainamidaMaxMg ? ` hasta un máximo de <span style="color:var(--brand-accent);font-weight:700;">${r.procainamidaMaxMg} mg</span> (17 mg/kg)` : ' (máx. 17 mg/kg)'}</div>
                <div style="margin-top:4px; color:var(--text-secondary); font-size:12px;">Buscar y corregir causa (isquemia, alteración electrolítica, proarritmia por fármacos) para evitar recurrencia inmediata</div>`;
        }

        const causaContent = `
            <div>Buscar y tratar la causa precipitante de forma simultánea: isquemia/IAM, alteración electrolítica (K⁺, Mg²⁺), hipoxia, embolia pulmonar, intoxicación/proarritmia farmacológica, disfunción tiroidea</div>
            <div style="margin-top:4px;">ECG de 12 derivaciones e interconsulta a Cardiología tan pronto como el paciente esté estabilizado</div>`;

        const postContent = `
            <div>Monitorización ECG continua y control seriado de PA tras la cardioversión</div>
            <div style="margin-top:4px;">Revisar la piel bajo los electrodos (quemaduras) y el estado neurológico post-sedación</div>
            <div style="margin-top:4px;">Troponinas seriadas si se sospecha isquemia concomitante o si la cardioversión fue prolongada/con múltiples descargas</div>
            <div style="margin-top:4px; color:var(--text-secondary); font-size:12px;">Considerar ingreso a UCI/unidad de monitorización si requirió múltiples descargas, soporte vasoactivo o antiarrítmico en infusión.</div>`;

        return `${headerHTML}
            ${section('🅰️', '1. Preparación', '#0ea5e9', prepContent)}
            ${section('⚡', '2. Cardioversión / Desfibrilación', '#dc2626', cvContent)}
            ${recurContent ? section('💊', '3. Prevención de Recurrencia / Si Recurre', '#f59e0b', recurContent) : ''}
            ${section('🔍', `${recurContent ? '4' : '3'}. Causa Precipitante`, '#8b5cf6', causaContent)}
            ${section('📋', `${recurContent ? '5' : '4'}. Monitorización Post-Procedimiento`, '#14b8a6', postContent)}`;
    }

    // ── BRADICARDIA ──────────────────────────────────────────────
    if (r.tipo === 'bradicardia') {
        if (r.inestable) {
            const content = `
                <div><strong>1. Atropina:</strong> 1 mg IV en bolo, repetir cada 3-5 min (máximo 3 mg)</div>
                <div style="margin-top:4px; color:#dc2626; font-weight:600;">Si BAV de alto grado (Mobitz II o 3er grado con QRS ancho) → NO esperar respuesta a la atropina, iniciar marcapasos transcutáneo de inmediato</div>
                <div style="margin-top:8px;"><strong>2. Marcapasos transcutáneo:</strong> si atropina inefectiva/contraindicada. Sedoanalgesia si el paciente está consciente (es doloroso). Verificar captura eléctrica Y mecánica (pulso palpable)</div>
                <div style="margin-top:8px;"><strong>3. Fármacos puente (si atropina/marcapasos no disponibles o inefectivos):</strong> Dopamina 5-20 µg/kg/min IV o Epinefrina 2-10 µg/min IV (ver Calculadora 29, Vasoactivos IV)</div>
                <div style="margin-top:8px;"><strong>4. Causas reversibles:</strong> hiperkalemia, intoxicación por betabloqueante/calcioantagonista (Gluconato de calcio, Glucagón, insulina-dextrosa en dosis altas), intoxicación digitálica (fragmentos Fab antidigoxina), IAM inferior, hipotiroidismo</div>
                <div style="margin-top:8px;">5. Interconsulta a Cardiología / marcapasos transvenoso si refractaria o BAV de alto grado persistente</div>`;
            return `${headerHTML}${section('💓', 'Bradicardia Inestable', '#dc2626', content)}`;
        }
        const content = `
            <div>Observación y monitorización continua — no requiere intervención inmediata salvo progresión a inestabilidad</div>
            <div style="margin-top:4px;">Identificar y tratar la causa subyacente (fármacos bradicardizantes, isquemia, alteraciones electrolíticas, hipotiroidismo)</div>
            <div style="margin-top:4px;">Suspender/ajustar fármacos bradicardizantes si aplica (betabloqueante, calcioantagonista no dihidropiridínico, digoxina, amiodarona)</div>`;
        return `${headerHTML}${section('💓', 'Bradicardia Estable', '#eab308', content)}`;
    }

    // ── TAQUICARDIA ESTRECHA REGULAR (SVT/PSVT) — estable ───────────
    if (r.tipo === 'taqui_estrecha_regular') {
        const content = `
            <div><strong>1. Maniobras vagales:</strong> Valsalva modificada (espirar contra resistencia + elevación pasiva de piernas) o masaje del seno carotídeo (solo si no hay soplo carotídeo/contraindicación)</div>
            <div style="margin-top:8px;"><strong>2. Adenosina:</strong> 6 mg IV en bolo RÁPIDO + flush de 20 mL SSN, elevar el brazo de inmediato. Si no responde en 1-2 min: 12 mg IV, puede repetirse una vez más (12 mg)</div>
            <div style="margin-top:4px; color:var(--text-secondary); font-size:12px;">Advertir al paciente de sensación transitoria de muerte inminente/rubor — es esperado y de segundos de duración</div>
            <div style="margin-top:8px;"><strong>3. Si falla Adenosina o recurre:</strong> Betabloqueante IV (Metoprolol 2.5-5 mg IV c/5 min) o Calcioantagonista IV (Diltiazem 0.25 mg/kg IV en 2 min, luego infusión 5-15 mg/h)</div>
            <div style="margin-top:4px; color:#dc2626; font-weight:600;">Evitar Calcioantagonistas si preexcitación/WPW conocido o disfunción ventricular severa</div>
            <div style="margin-top:8px;">4. Interconsulta a Cardiología/Electrofisiología si recurrente — candidato a estudio electrofisiológico y ablación</div>
            ${r.adenosinaFallida ? '<div style="margin-top:8px;color:#f59e0b;font-weight:600;">⚠️ Adenosina ya fallida/recurrió — proceder directamente al paso 3 (Betabloqueante/Calcioantagonista)</div>' : ''}`;
        return `${headerHTML}${section('💊', 'SVT/PSVT Estable', '#eab308', content)}`;
    }

    // ── TAQUICARDIA IRREGULAR (FA/Flutter con RVR) — estable ────────
    if (r.tipo === 'taqui_estrecha_irregular') {
        let content;
        if (r.preexcitacion) {
            content = `
                <div style="color:#dc2626; font-weight:700;">⚠️ Sospecha de preexcitación (WPW) — EVITAR bloqueadores del nodo AV</div>
                <div style="margin-top:4px;">NO usar: Adenosina, Betabloqueante, Calcioantagonista ni Digoxina — riesgo de conducción preferencial por la vía accesoria y degeneración a FV</div>
                <div style="margin-top:8px;"><strong>Usar:</strong> Procainamida IV o Ibutilida IV, o cardioversión eléctrica sincronizada (electiva o urgente según tolerancia)</div>
                <div style="margin-top:8px;">Interconsulta a Electrofisiología — candidato a ablación de la vía accesoria</div>`;
        } else {
            content = `
                <div style="font-weight:700; margin-bottom:4px;">Control de frecuencia:</div>
                <div>${r.efReducida
                    ? '<strong>FE reducida (HFrEF):</strong> Amiodarona IV (150 mg en 10 min, luego infusión) o Digoxina IV — evitar Calcioantagonistas no dihidropiridínicos; usar Betabloqueantes con cautela solo si compensado'
                    : '<strong>FE preservada:</strong> Betabloqueante IV (Metoprolol) o Calcioantagonista IV (Diltiazem)'}</div>
                <div style="margin-top:10px; font-weight:700; margin-bottom:4px;">Anticoagulación y control del ritmo:</div>
                <div>Si &lt; 48h de inicio → puede considerarse cardioversión electiva. Si &gt; 48h o incierto → anticoagular ≥ 3 semanas antes de cardioversión electiva, o ecocardiograma transesofágico para descartar trombo auricular</div>
                <div style="margin-top:4px;">Iniciar anticoagulación según CHA₂DS₂-VASc (Calculadora 9 de esta app) independientemente de la estrategia elegida</div>`;
        }
        return `${headerHTML}${section('💊', 'FA/Flutter con RVR — Estable', '#eab308', content)}`;
    }

    // ── TAQUICARDIA ANCHA REGULAR MONOMÓRFICA (TV estable) ──────────
    if (r.tipo === 'taqui_ancha_regular') {
        const content = `
            <div><strong>1. Procainamida IV:</strong> 20-50 mg/min (o 100 mg c/5 min) hasta control de la arritmia, hipotensión, ensanchamiento del QRS &gt; 50%, o dosis máxima de 17 mg/kg${r.procainamidaMaxMg ? ` = <span style="color:var(--brand-accent);font-weight:700;">${r.procainamidaMaxMg} mg</span> para este paciente` : ''} — mantenimiento 1-4 mg/min. Preferida si función ventricular conservada</div>
            <div style="margin-top:8px;"><strong>2. Amiodarona IV:</strong> 150 mg en 10 min (puede repetirse), luego infusión 1 mg/min × 6h y 0.5 mg/min × 18h. Preferida si disfunción ventricular/IC conocida</div>
            <div style="margin-top:4px; color:#dc2626; font-weight:600;">Evitar Procainamida si QT prolongado basal o insuficiencia cardíaca severa</div>
            <div style="margin-top:8px;">3. Si refractaria a fármacos → cardioversión eléctrica sincronizada electiva</div>
            <div style="margin-top:8px; color:var(--text-secondary); font-size:12px;">Ante incertidumbre diagnóstica entre TV y SVT con aberrancia, tratar como TV por defecto — especialmente con cardiopatía estructural conocida.</div>`;
        return `${headerHTML}${section('💊', 'TV Monomórfica Estable', '#eab308', content)}`;
    }

    // ── TAQUICARDIA ANCHA POLIMÓRFICA / TORSADES — estable ──────────
    if (r.tipo === 'taqui_ancha_polimorfica') {
        const content = r.qtLargo ? `
            <div style="font-weight:700; margin-bottom:4px;">QT prolongado — Torsades típica:</div>
            <div><strong>1. Sulfato de Magnesio:</strong> 2 g IV en 5-10 min (incluso con Mg sérico normal), puede repetirse</div>
            <div style="margin-top:4px;"><strong>2.</strong> Corregir K⁺ (mantener &gt; 4.5 mEq/L) y demás electrolitos</div>
            <div style="margin-top:4px;"><strong>3.</strong> Suspender todo fármaco que prolongue el QT</div>
            <div style="margin-top:4px;"><strong>4.</strong> Considerar marcapasos con sobreestimulación (overdrive pacing) o Isoproterenol IV (Calculadora 29, Vasoactivos IV) como puente — acorta el QT dependiente de bradicardia</div>`
            : `
            <div style="font-weight:700; margin-bottom:4px;">QT normal — isquemia / Brugada / TV catecolaminérgica:</div>
            <div><strong>1.</strong> Tratar la isquemia miocárdica activa (revascularización urgente si aplica)</div>
            <div style="margin-top:4px;"><strong>2.</strong> Betabloqueante IV — especialmente eficaz en TV catecolaminérgica</div>
            <div style="margin-top:4px;"><strong>3.</strong> Amiodarona IV como alternativa</div>
            <div style="margin-top:4px; color:#dc2626; font-weight:600;">Evitar Isoproterenol si se sospecha Síndrome de Brugada o TV catecolaminérgica — puede empeorarlas</div>`;
        return `${headerHTML}
            <div style="background:#431407; color:#fdba74; border:2px solid #f97316; border-radius:var(--radius-lg); padding:14px; margin-bottom:12px; font-size:13px;">
                <strong>⚠️ Si degenera a inestable o TV sin pulso/FV en cualquier momento:</strong> desfibrilación inmediata, NO sincronizada.
            </div>
            ${section('💊', 'TV Polimórfica / Torsades', '#eab308', content)}`;
    }

    return headerHTML;
}

function calculateArritmiaProtocol(event) {
    event.preventDefault();
    const sinPulso = document.getElementById('arrSinPulso').checked;

    let inputs;
    if (sinPulso) {
        inputs = { tipo: 'paro', ritmoParo: document.getElementById('arrRitmoParo').value };
    } else {
        const tipo = document.getElementById('arrTipo').value;
        const inestable = ['arrHipotension', 'arrConciencia', 'arrShock', 'arrDolorToracico', 'arrEap']
            .some(id => document.getElementById(id).checked);
        const weightRaw = tipo === 'taqui_ancha_regular' ? document.getElementById('arrWeight').value : '';
        inputs = {
            tipo, inestable,
            efReducida: tipo === 'taqui_estrecha_irregular' ? document.getElementById('arrEfReducida').checked : false,
            preexcitacion: tipo === 'taqui_estrecha_irregular' ? document.getElementById('arrPreexcitacion').checked : false,
            qtLargo: tipo === 'taqui_ancha_polimorfica' ? document.getElementById('arrQtLargo').checked : false,
            adenosinaFallida: tipo === 'taqui_estrecha_regular' ? document.getElementById('arrAdenosinaFallida').checked : false,
            weight: weightRaw === '' ? null : parseFloat(weightRaw)
        };
    }

    const r = Calculators.calculateArritmia(inputs);
    const container = document.getElementById('arritmiaResult');
    container.innerHTML = buildArritmiaProtocolHTML(r) + `
        <button class="btn btn-secondary" onclick="document.getElementById('arritmiaForm').reset(); document.getElementById('arritmiaResult').style.display='none'; toggleArritmiaArrest({checked:false}); toggleArritmiaFields();" style="width:100%; margin-top:12px;">
            🔄 Nuevo Protocolo
        </button>`;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 45, calculatorName: 'Protocolo de Arritmias', inputs, result: r, interpretation: r.interpretation });
}

// === 46. PARO CARDÍACO — RCP + BÚSQUEDA GUIADA DE CAUSA (6H/5T) === //
function createParoForm() {
    const causaExtraField = (causaId) => {
        if (causaId === 'hipoglucemia') {
            return `<div style="margin-top:8px;"><label style="display:block; margin-bottom:4px; font-size:12px; color:var(--text-tertiary);">Glucemia capilar (mg/dL) — opcional</label>
                <input type="number" id="paroGlucemia" step="any" min="0" max="800" class="form-input" placeholder="ej. 45"></div>`;
        }
        if (causaId === 'kalemia') {
            return `<div style="margin-top:8px;"><label style="display:block; margin-bottom:4px; font-size:12px; color:var(--text-tertiary);">Potasio sérico (mEq/L) — opcional</label>
                <input type="number" id="paroPotasio" step="0.1" min="0" max="12" class="form-input" placeholder="ej. 7.2"></div>`;
        }
        if (causaId === 'hipotermia') {
            return `<div style="margin-top:8px;"><label style="display:block; margin-bottom:4px; font-size:12px; color:var(--text-tertiary);">Temperatura corporal (°C) — opcional</label>
                <input type="number" id="paroTemperatura" step="0.1" min="15" max="42" class="form-input" placeholder="ej. 29.5"></div>`;
        }
        return '';
    };

    const causaBloques = Calculators.CAUSAS_PARO.map(c => `
        <div style="background:var(--bg-secondary); padding:14px 16px; border-radius:10px; margin-bottom:10px;">
            <div style="font-size:13px; font-weight:700; margin-bottom:8px;">${c.icon} ${c.label} <span style="font-size:11px; font-weight:500; color:var(--text-tertiary);">(${c.letra})</span></div>
            ${c.clues.map((clue, idx) => `
                <label style="display:flex; align-items:flex-start; gap:8px; margin-bottom:6px; cursor:pointer;">
                    <input type="checkbox" id="paroClue_${c.id}_${idx}" style="width:16px; height:16px; margin-top:2px; flex-shrink:0;">
                    <span style="font-size:12px; line-height:1.4;">${clue}</span>
                </label>`).join('')}
            ${causaExtraField(c.id)}
        </div>`).join('');

    return `
        <form id="paroForm" onsubmit="calculateParoProtocol(event)">

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Ritmo del paro</label>
                <select id="paroRitmo" required class="form-input">
                    <option value="desfibrilable">Desfibrilable — FV / TV sin pulso</option>
                    <option value="no_desfibrilable">No desfibrilable — Asistolia / AESP</option>
                </select>
            </div>

            <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:6px; text-transform:uppercase; letter-spacing:0.05em;">Búsqueda de la causa (6H / 5T)</div>
            <p style="font-size:11px; color:var(--text-tertiary); margin-bottom:12px;">Marca cualquier hallazgo compatible (antecedente, examen, POCUS, laboratorio o ECG previo). Si no marcas nada, la herramienta te muestra las 11 causas para descartarlas de forma sistemática.</p>

            ${causaBloques}

            <div style="background:#fef3c7; border-left:4px solid #f59e0b; padding:14px; border-radius:8px; margin-bottom:16px; margin-top:6px;">
                <p style="font-size:12px; color:#92400e; margin:0;">
                    <strong>⚠️ Herramienta de apoyo clínico</strong> — Verificar siempre con el equipo médico. Basado en AHA ACLS 2020 (Guidelines Update).
                </p>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">
                🧮 Generar Protocolo
            </button>
        </form>
        <div id="paroResult" style="display:none; margin-top:24px;"></div>
    `;
}

function buildParoProtocolHTML(r) {
    const section = (icon, title, color, content) => `
        <div style="margin-bottom:12px; border-radius:var(--radius-lg); overflow:hidden; border:1px solid ${color}33;">
            <div style="background:${color}22; padding:12px 16px; display:flex; align-items:center; gap:8px; border-bottom:1px solid ${color}33;">
                <span style="font-size:18px;">${icon}</span>
                <span style="font-size:14px; font-weight:700; color:${color};">${title}</span>
            </div>
            <div style="padding:14px 16px; background:var(--bg-card); font-size:13px; line-height:1.8;">${content}</div>
        </div>`;

    const headerHTML = `
        <div style="background:${r.severity.colorHex}; padding:20px; border-radius:var(--radius-lg); color:white; margin-bottom:12px;">
            <div style="font-size:20px; font-weight:800;">${r.severity.badge} ${r.severity.label}</div>
        </div>`;

    const rcpContent = `
        <div><strong>RCP de alta calidad:</strong> compresiones continuas (100-120/min, 5-6 cm), mínima interrupción, permitir expansión torácica completa</div>
        <div style="margin-top:4px;">Vía aérea avanzada y capnografía si disponible — objetivo EtCO₂ ≥ 10 mmHg como indicador de calidad de RCP</div>`;

    const shockableContent = `
        <div style="color:#dc2626; font-weight:700;">Desfibrilación INMEDIATA, NO sincronizada (200 J bifásico o dosis máxima del equipo)</div>
        <div style="margin-top:4px;">Reanudar RCP inmediatamente tras la descarga — NO verificar pulso/ritmo hasta completar 2 min de RCP</div>
        <div style="margin-top:4px;"><strong>Epinefrina:</strong> 1 mg IV/IO cada 3-5 min (tras la 2ª o 3ª descarga)</div>
        <div style="margin-top:4px;"><strong>Antiarrítmico:</strong> Amiodarona 300 mg IV/IO (bolo) → segunda dosis 150 mg si FV/TV recurrente; alternativa: Lidocaína 1-1.5 mg/kg IV/IO</div>`;

    const nonShockableContent = `
        <div style="color:var(--text-primary); font-weight:700;">NO desfibrilar</div>
        <div style="margin-top:4px;"><strong>Epinefrina:</strong> 1 mg IV/IO cada 3-5 min, lo antes posible</div>
        <div style="margin-top:4px;">El antiarrítmico (Amiodarona/Lidocaína) NO está indicado en Asistolia/AESP</div>
        <div style="margin-top:4px;">Reevaluar ritmo cada 2 min — si aparece un ritmo desfibrilable, cambiar de inmediato al protocolo correspondiente</div>`;

    let causasHtml;
    if (r.sinHallazgos) {
        const repasoContent = r.todasLasCausas.map(c => `
            <div style="margin-bottom:10px; padding-bottom:10px; border-bottom:1px solid var(--border-color);">
                <div style="font-weight:700; margin-bottom:2px;">${c.icon} ${c.label} <span style="font-size:11px; font-weight:500; color:var(--text-tertiary);">(${c.letra})</span></div>
                <div style="font-size:12px; color:var(--text-secondary);">${c.clues.join(' · ')}</div>
            </div>`).join('');
        causasHtml = section('🔍', '3. Repaso Sistemático — 6H / 5T', '#8b5cf6', `
            <div style="margin-bottom:10px; color:var(--text-secondary); font-size:12px;">Ningún hallazgo marcado todavía — repasa cada causa de forma sistemática mientras continúa la RCP:</div>
            ${repasoContent}`);
    } else {
        causasHtml = r.causasRankeadas.map((c, i) => {
            let actionContent;
            if (c.isKalemia) {
                actionContent = (c.hyperFlag ? `<div>${c.hyperAction}</div>` : '') +
                    (c.hypoFlag ? `<div style="margin-top:${c.hyperFlag ? '8px' : '0'};">${c.hypoAction}</div>` : '') +
                    (c.hyperFlag && c.hypoFlag ? '<div style="margin-top:8px; color:var(--text-secondary); font-size:12px;">Pista ambigua o ambas direcciones marcadas — diferenciar con laboratorio/ECG específico antes de tratar.</div>' : '');
            } else {
                actionContent = `<div>${c.action}</div>`;
            }
            return section(c.icon, `${3 + i}. ${c.label} — Sospechada (${c.matchedCount} hallazgo${c.matchedCount > 1 ? 's' : ''})`, '#dc2626', actionContent);
        }).join('');
    }

    return `${headerHTML}
        ${section('❤️‍🩹', '1. RCP', '#dc2626', rcpContent)}
        ${section(r.ritmo === 'desfibrilable' ? '⚡' : '🚫', '2. Ritmo — ' + (r.ritmo === 'desfibrilable' ? 'Desfibrilable' : 'No Desfibrilable'), r.ritmo === 'desfibrilable' ? '#dc2626' : '#6366f1', r.ritmo === 'desfibrilable' ? shockableContent : nonShockableContent)}
        ${causasHtml}`;
}

function calculateParoProtocol(event) {
    event.preventDefault();
    const ritmo = document.getElementById('paroRitmo').value;

    const clues = {};
    Calculators.CAUSAS_PARO.forEach(c => {
        clues[c.id] = c.clues.map((_, idx) => document.getElementById(`paroClue_${c.id}_${idx}`).checked);
    });

    const glucemiaRaw = document.getElementById('paroGlucemia').value;
    const potasioRaw = document.getElementById('paroPotasio').value;
    const temperaturaRaw = document.getElementById('paroTemperatura').value;

    const inputs = {
        ritmo, clues,
        glucemia: glucemiaRaw === '' ? null : parseFloat(glucemiaRaw),
        potasio: potasioRaw === '' ? null : parseFloat(potasioRaw),
        temperatura: temperaturaRaw === '' ? null : parseFloat(temperaturaRaw)
    };

    const r = Calculators.calculateParo(inputs);
    const container = document.getElementById('paroResult');
    container.innerHTML = buildParoProtocolHTML(r) + `
        <button class="btn btn-secondary" onclick="document.getElementById('paroForm').reset(); document.getElementById('paroResult').style.display='none';" style="width:100%; margin-top:12px;">
            🔄 Nuevo Protocolo
        </button>`;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 46, calculatorName: 'Paro Cardíaco', inputs, result: r, interpretation: r.interpretation });
}

// === 47. DENGUE — CLASIFICACIÓN OMS GRUPO A/B/C === //
function createDengueForm() {
    const units = Storage.getSettings().units;
    const wUnit = units.weight || 'kg';
    return `
        <form id="dengueForm" onsubmit="calculateDengueProtocol(event)">

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:6px; text-transform:uppercase; letter-spacing:0.05em;">Criterios de Gravedad (Grupo C)</div>
                <p style="font-size:11px; color:var(--text-tertiary); margin-bottom:10px;">Cualquiera marcado clasifica como Dengue Grave.</p>
                ${[
                    ['dengueGrav1', 'Extravasación grave de plasma con shock o dificultad respiratoria'],
                    ['dengueGrav2', 'Sangrado grave (a criterio clínico)'],
                    ['dengueGrav3', 'Compromiso grave de órgano (SNC, hígado con AST/ALT ≥1000, corazón u otro)']
                ].map(([id, label]) => `
                    <label style="display:flex; align-items:flex-start; gap:10px; margin-bottom:8px; cursor:pointer;">
                        <input type="checkbox" id="${id}" style="width:18px; height:18px; margin-top:2px;">
                        <span style="font-size:13px;">${label}</span>
                    </label>`).join('')}
            </div>

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:6px; text-transform:uppercase; letter-spacing:0.05em;">Signos de Alarma (Grupo B)</div>
                <p style="font-size:11px; color:var(--text-tertiary); margin-bottom:10px;">Aparecen típicamente en la caída de la fiebre (día 3-7).</p>
                ${[
                    ['dengueAlarma1', 'Dolor abdominal intenso y continuo'],
                    ['dengueAlarma2', 'Vómitos persistentes (≥3 en 1h o ≥4 en 6h)'],
                    ['dengueAlarma3', 'Acumulación de líquidos clínicamente detectable (ascitis, derrame pleural)'],
                    ['dengueAlarma4', 'Sangrado de mucosas'],
                    ['dengueAlarma5', 'Letargia o irritabilidad'],
                    ['dengueAlarma6', 'Hepatomegalia > 2 cm'],
                    ['dengueAlarma7', 'Hematocrito en ascenso progresivo con caída rápida de plaquetas (laboratorio)']
                ].map(([id, label]) => `
                    <label style="display:flex; align-items:flex-start; gap:10px; margin-bottom:8px; cursor:pointer;">
                        <input type="checkbox" id="${id}" style="width:18px; height:18px; margin-top:2px;">
                        <span style="font-size:13px;">${label}</span>
                    </label>`).join('')}
            </div>

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:6px; text-transform:uppercase; letter-spacing:0.05em;">Condiciones Asociadas</div>
                <p style="font-size:11px; color:var(--text-tertiary); margin-bottom:10px;">Aunque no haya signos de alarma, cualquiera marcada obliga a manejo hospitalario (Grupo B).</p>
                ${[
                    ['dengueComorb1', 'Embarazo'],
                    ['dengueComorb2', 'Menor de 1 año o mayor de 65 años'],
                    ['dengueComorb3', 'Obesidad, Diabetes Mellitus o Enfermedad Renal Crónica'],
                    ['dengueComorb4', 'Enfermedad hemolítica crónica u otra condición de riesgo social/de acceso a salud']
                ].map(([id, label]) => `
                    <label style="display:flex; align-items:flex-start; gap:10px; margin-bottom:8px; cursor:pointer;">
                        <input type="checkbox" id="${id}" style="width:18px; height:18px; margin-top:2px;">
                        <span style="font-size:13px;">${label}</span>
                    </label>`).join('')}
            </div>

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:14px; text-transform:uppercase; letter-spacing:0.05em;">Datos para Fluidoterapia (Grupo B/C)</div>
                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Peso (${wUnit})</label>
                    <input type="number" id="dengueWeight" step="any" min="10" max="300" class="form-input">
                </div>
                <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">PAS (mmHg)</label>
                        <input type="number" id="dengueSbp" step="any" min="40" max="250" class="form-input">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">PAD (mmHg)</label>
                        <input type="number" id="dengueDbp" step="any" min="20" max="150" class="form-input">
                    </div>
                </div>
            </div>

            <div style="background:#fef3c7; border-left:4px solid #f59e0b; padding:14px; border-radius:8px; margin-bottom:16px;">
                <p style="font-size:12px; color:#92400e; margin:0;">
                    <strong>⚠️ Herramienta de apoyo clínico</strong> — Verificar siempre con el equipo médico. Basado en OMS 2009 · PAHO Dengue Guidelines.
                </p>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">
                🧮 Generar Protocolo
            </button>
        </form>
        <div id="dengueResult" style="display:none; margin-top:24px;"></div>
    `;
}

function buildDengueProtocolHTML(r) {
    const section = (icon, title, color, content) => `
        <div style="margin-bottom:12px; border-radius:var(--radius-lg); overflow:hidden; border:1px solid ${color}33;">
            <div style="background:${color}22; padding:12px 16px; display:flex; align-items:center; gap:8px; border-bottom:1px solid ${color}33;">
                <span style="font-size:18px;">${icon}</span>
                <span style="font-size:14px; font-weight:700; color:${color};">${title}</span>
            </div>
            <div style="padding:14px 16px; background:var(--bg-card); font-size:13px; line-height:1.8;">${content}</div>
        </div>`;

    const headerHTML = `
        <div style="background:${r.severity.colorHex}; padding:20px; border-radius:var(--radius-lg); color:white; margin-bottom:12px;">
            <div style="font-size:20px; font-weight:800;">${r.severity.badge} ${r.severity.label}</div>
            ${r.forzadoPorComorbilidad ? '<div style="font-size:12px; opacity:0.9; margin-top:6px;">Clasificado como Grupo B por condición asociada, aunque no presenta signos de alarma.</div>' : ''}
        </div>`;

    let manejoHtml;
    if (r.grupo === 'A') {
        manejoHtml = section('💧', 'Manejo Ambulatorio', '#22c55e', `
            <div>Hidratación oral abundante (sales de rehidratación, jugos, líquidos con electrolitos)</div>
            <div style="margin-top:4px;"><strong>Paracetamol</strong> para fiebre/dolor — <span style="color:#dc2626; font-weight:600;">NO AINEs ni Ácido Acetilsalicílico</span> (riesgo hemorrágico)</div>
            <div style="margin-top:4px;">Control diario ambulatorio con hematocrito y plaquetas seriados</div>
            <div style="margin-top:4px;">Educar en signos de alarma para reconsulta inmediata</div>
            <div style="margin-top:8px; color:var(--text-secondary); font-size:12px;">Ver también <strong>Calculadora 30, Guía de Antibioterapia Empírica → "Dengue"</strong> para el detalle de soporte sintomático ya documentado ahí.</div>`);
    } else if (r.grupo === 'B') {
        const fluidHtml = r.fluidos ? `
            <div><strong>Fase 1 (1-2h):</strong> <span style="color:var(--brand-accent); font-weight:700;">${r.fluidos.fase1}</span></div>
            <div style="margin-top:4px;"><strong>Fase 2 (2-4h):</strong> ${r.fluidos.fase2}</div>
            <div style="margin-top:4px;"><strong>Fase 3 (mantenimiento):</strong> ${r.fluidos.fase3}, ajustar según clínica/hematocrito</div>`
            : `<div style="color:#f59e0b;">Ingresa el peso para calcular las tasas de infusión.</div>`;
        manejoHtml = section('🏥', 'Hospitalización + Fluidoterapia IV', '#dc2626', `
            <div>Cristaloides IV (SSN 0.9% o Ringer Lactato) en 3 fases decrecientes:</div>
            <div style="margin-top:6px;">${fluidHtml}</div>
            <div style="margin-top:8px;">Reevaluación clínica cada 1-4h — signos vitales, diuresis, hematocrito seriado cada 4-6h</div>
            <div style="margin-top:4px; color:var(--text-secondary); font-size:12px;">Reducir el ritmo de infusión progresivamente conforme mejora — evitar sobrecarga de líquidos.</div>`);
    } else {
        const boloHtml = r.fluidos ? `
            <div><strong>Shock compensado</strong> (PAS normal, presión de pulso &lt; 20 mmHg): bolo <span style="color:var(--brand-accent); font-weight:700;">${r.fluidos.boloCompensado}</span>, reevaluar</div>
            <div style="margin-top:4px;"><strong>Shock hipotenso</strong> (PAS &lt; 90 o caída &gt; 20% del basal): bolo rápido <span style="color:var(--brand-accent); font-weight:700;">${r.fluidos.boloHipotenso}</span>, repetir si no mejora</div>`
            : `<div style="color:#f59e0b;">Ingresa peso y PA para diferenciar el tipo de shock y calcular el bolo.</div>`;
        manejoHtml = section('🚨', 'UCI — Shock por Dengue', '#7f1d1d', `
            ${boloHtml}
            <div style="margin-top:8px;">Considerar hemoderivados si sangrado significativo o hematocrito en descenso pese a reanimación adecuada (sugiere sangrado oculto)</div>
            <div style="margin-top:4px;">Monitorización horaria: PA, FC, diuresis, hematocrito seriado</div>
            <div style="margin-top:8px; color:var(--text-secondary); font-size:12px;">Fase de reabsorción (día 7-10): vigilar sobrecarga de volumen — no fluidos de rutina en esta fase, considerar diuréticos si hay signos de sobrecarga.</div>`);
    }

    return `${headerHTML}${manejoHtml}`;
}

function calculateDengueProtocol(event) {
    event.preventDefault();
    const weightRaw = document.getElementById('dengueWeight').value;
    const sbpRaw = document.getElementById('dengueSbp').value;
    const dbpRaw = document.getElementById('dengueDbp').value;

    const inputs = {
        gravedad: {
            g1: document.getElementById('dengueGrav1').checked,
            g2: document.getElementById('dengueGrav2').checked,
            g3: document.getElementById('dengueGrav3').checked
        },
        alarma: {
            a1: document.getElementById('dengueAlarma1').checked,
            a2: document.getElementById('dengueAlarma2').checked,
            a3: document.getElementById('dengueAlarma3').checked,
            a4: document.getElementById('dengueAlarma4').checked,
            a5: document.getElementById('dengueAlarma5').checked,
            a6: document.getElementById('dengueAlarma6').checked,
            a7: document.getElementById('dengueAlarma7').checked
        },
        comorbilidad: {
            c1: document.getElementById('dengueComorb1').checked,
            c2: document.getElementById('dengueComorb2').checked,
            c3: document.getElementById('dengueComorb3').checked,
            c4: document.getElementById('dengueComorb4').checked
        },
        weight: weightRaw === '' ? null : parseFloat(weightRaw),
        sbp: sbpRaw === '' ? null : parseFloat(sbpRaw),
        dbp: dbpRaw === '' ? null : parseFloat(dbpRaw)
    };

    const r = Calculators.calculateDengue(inputs);
    const container = document.getElementById('dengueResult');
    container.innerHTML = buildDengueProtocolHTML(r) + `
        <button class="btn btn-secondary" onclick="document.getElementById('dengueForm').reset(); document.getElementById('dengueResult').style.display='none';" style="width:100%; margin-top:12px;">
            🔄 Nuevo Protocolo
        </button>`;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 47, calculatorName: 'Dengue', inputs, result: r, interpretation: r.interpretation });
}

// === 48. CÓDIGO ICTUS — TROMBOLISIS / TROMBECTOMÍA === //
function createCodigoIctusForm() {
    const units = Storage.getSettings().units;
    const wUnit = units.weight || 'kg';
    return `
        <form id="ictusForm" onsubmit="calculateCodigoIctusProtocol(event)">

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Horas desde el inicio de síntomas / última vez visto bien</label>
                    <input type="number" id="ictusHoras" step="any" min="0" max="72" class="form-input" placeholder="ej. 2.5" oninput="toggleIctusFields()">
                </div>
                <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                    <input type="checkbox" id="ictusVentanaIncierta" style="width:18px; height:18px;" onchange="toggleIctusFields()">
                    <span style="font-size:13px;">Hora de inicio incierta / al despertar sin última hora visto bien conocida</span>
                </label>
                <div class="form-group" style="margin-top:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">NIHSS <span style="font-size:11px; font-weight:500; color:var(--text-tertiary);">opcional — calcular en Calculadora 17, NIHSS</span></label>
                    <input type="number" id="ictusNihss" step="1" min="0" max="42" class="form-input">
                </div>
                <div class="form-group" style="margin-top:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Peso (${wUnit})</label>
                    <input type="number" id="ictusWeight" step="any" min="20" max="300" class="form-input">
                </div>
                <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-top:14px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">PAS (mmHg)</label>
                        <input type="number" id="ictusSbp" step="any" min="60" max="260" class="form-input">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">PAD (mmHg)</label>
                        <input type="number" id="ictusDbp" step="any" min="30" max="150" class="form-input">
                    </div>
                </div>
            </div>

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:6px; text-transform:uppercase; letter-spacing:0.05em;">Exclusión Absoluta para Trombolisis</div>
                <p style="font-size:11px; color:var(--text-tertiary); margin-bottom:10px;">Cualquiera marcada contraindica la Alteplasa.</p>
                ${[
                    ['ictusExAbs1', 'Hemorragia intracraneal en la TC'],
                    ['ictusExAbs2', 'Ictus isquémico o TCE severo en los últimos 3 meses'],
                    ['ictusExAbs3', 'Cirugía intracraneal o espinal reciente'],
                    ['ictusExAbs4', 'Antecedente de hemorragia intracraneal'],
                    ['ictusExAbs5', 'Neoplasia, malformación arteriovenosa o aneurisma intracraneal'],
                    ['ictusExAbs6', 'Sangrado activo o diátesis hemorrágica conocida'],
                    ['ictusExAbs7', 'Plaquetas &lt; 100.000/mm³'],
                    ['ictusExAbs8', 'INR &gt; 1.7 o anticoagulado (warfarina/DOAC) sin reversión'],
                    ['ictusExAbs9', 'PA no controlable &lt; 185/110 pese a tratamiento'],
                    ['ictusExAbs10', 'Glucemia &lt; 50 mg/dL'],
                    ['ictusExAbs11', 'Endocarditis infecciosa o disección aórtica']
                ].map(([id, label]) => `
                    <label style="display:flex; align-items:flex-start; gap:10px; margin-bottom:8px; cursor:pointer;">
                        <input type="checkbox" id="${id}" class="ictus-ex-abs" style="width:18px; height:18px; margin-top:2px;">
                        <span style="font-size:13px;">${label}</span>
                    </label>`).join('')}
            </div>

            <div id="ictusExRelWrap" style="display:none; background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:6px; text-transform:uppercase; letter-spacing:0.05em;">Exclusión Relativa (ventana extendida 3-4.5h)</div>
                ${[
                    ['ictusExRel1', 'Edad &gt; 80 años'],
                    ['ictusExRel2', 'Uso de anticoagulantes orales (independiente del INR)'],
                    ['ictusExRel3', 'NIHSS &gt; 25'],
                    ['ictusExRel4', 'Antecedente combinado de ictus previo + Diabetes Mellitus']
                ].map(([id, label]) => `
                    <label style="display:flex; align-items:flex-start; gap:10px; margin-bottom:8px; cursor:pointer;">
                        <input type="checkbox" id="${id}" class="ictus-ex-rel" style="width:18px; height:18px; margin-top:2px;">
                        <span style="font-size:13px;">${label}</span>
                    </label>`).join('')}
            </div>

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:6px; text-transform:uppercase; letter-spacing:0.05em;">Trombectomía Mecánica</div>
                ${[
                    ['ictusTromb1', 'Oclusión de gran vaso confirmada (angio-TC/angio-RM)'],
                    ['ictusTromb2', 'Ventana &lt; 24h desde el inicio/última vez visto bien'],
                    ['ictusTromb3', 'ASPECTS ≥ 6 o estudio de perfusión favorable'],
                    ['ictusTromb4', 'Rankin funcional previo ≤ 1']
                ].map(([id, label]) => `
                    <label style="display:flex; align-items:flex-start; gap:10px; margin-bottom:8px; cursor:pointer;">
                        <input type="checkbox" id="${id}" class="ictus-tromb" style="width:18px; height:18px; margin-top:2px;">
                        <span style="font-size:13px;">${label}</span>
                    </label>`).join('')}
            </div>

            <div style="background:#fef3c7; border-left:4px solid #f59e0b; padding:14px; border-radius:8px; margin-bottom:16px;">
                <p style="font-size:12px; color:#92400e; margin:0;">
                    <strong>⚠️ Herramienta de apoyo clínico</strong> — Verificar siempre con el equipo médico. Basado en AHA/ASA 2019 Guideline for Early Management of Acute Ischemic Stroke.
                </p>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">
                🧮 Generar Checklist
            </button>
        </form>
        <div id="ictusResult" style="display:none; margin-top:24px;"></div>
    `;
}

function toggleIctusFields() {
    const horas = parseFloat(document.getElementById('ictusHoras').value);
    const incierta = document.getElementById('ictusVentanaIncierta').checked;
    const enVentanaExtendida = !incierta && !isNaN(horas) && horas > 3 && horas <= 4.5;
    document.getElementById('ictusExRelWrap').style.display = enVentanaExtendida ? 'block' : 'none';
}

function buildCodigoIctusHTML(r) {
    const section = (icon, title, color, content) => `
        <div style="margin-bottom:12px; border-radius:var(--radius-lg); overflow:hidden; border:1px solid ${color}33;">
            <div style="background:${color}22; padding:12px 16px; display:flex; align-items:center; gap:8px; border-bottom:1px solid ${color}33;">
                <span style="font-size:18px;">${icon}</span>
                <span style="font-size:14px; font-weight:700; color:${color};">${title}</span>
            </div>
            <div style="padding:14px 16px; background:var(--bg-card); font-size:13px; line-height:1.8;">${content}</div>
        </div>`;

    const headerHTML = `
        <div style="background:${r.severity.colorHex}; padding:20px; border-radius:var(--radius-lg); color:white; margin-bottom:12px;">
            <div style="font-size:20px; font-weight:800;">${r.severity.badge} ${r.severity.label}</div>
            <div style="font-size:13px; opacity:0.9; margin-top:4px;">${r.ventanaIncierta ? 'Ventana incierta' : `${r.horasInicio}h desde el inicio/última vez visto bien`}</div>
        </div>`;

    let cuerpoHtml;
    if (r.candidatoTrombolisis) {
        const paHtml = r.requierePAPrevia ? `
            <div style="color:#dc2626; font-weight:700; margin-bottom:6px;">⚠️ PA &gt; 185/110 — tratar ANTES de administrar Alteplasa</div>
            <div>Labetalol IV o Nicardipino IV hasta lograr PA &lt; 185/110. Si no se logra → NO administrar trombolisis.</div>` : '';
        cuerpoHtml = section('💉', 'Trombolisis IV — Alteplasa', '#22c55e', `
            ${paHtml}
            ${r.doseAlteplasaTotal ? `
                <div><strong>Dosis total:</strong> 0.9 mg/kg = <span style="color:var(--brand-accent); font-weight:700;">${r.doseAlteplasaTotal} mg</span> (máx. 90 mg)</div>
                <div style="margin-top:4px;"><strong>Bolo (1 min):</strong> ${r.doseBolo} mg (10%)</div>
                <div style="margin-top:4px;"><strong>Infusión (60 min):</strong> ${r.doseInfusion} mg (90%)</div>`
                : '<div style="color:#f59e0b;">Ingresa el peso para calcular la dosis de Alteplasa.</div>'}
            <div style="margin-top:8px; color:var(--text-secondary); font-size:12px;">Referenciar NIHSS (Calculadora 17) y Glasgow (Calculadora 18) para documentar el déficit basal antes de iniciar.</div>
        `);
    } else {
        const razones = [...r.exclusionAbsolutaMarcada, ...(r.dentroVentanaExtendida ? r.exclusionRelativaMarcada : [])];
        cuerpoHtml = section('🚫', 'NO Candidato a Trombolisis', '#dc2626', `
            <div>${!r.dentroVentanaEstandar ? (r.ventanaIncierta ? 'Ventana de tiempo incierta.' : 'Fuera de ventana de 4.5h.') : `${r.numExclusionAbsoluta} criterio(s) de exclusión marcado(s).`}</div>
            <div style="margin-top:8px; font-weight:700;">Manejo alternativo:</div>
            <div style="margin-top:4px;">Hipertensión permisiva — tratar solo si PA &gt; 220/120 mmHg (salvo comorbilidad que requiera control más estricto)</div>
            <div style="margin-top:4px;">Doble antiagregación (AAS + Clopidogrel) si ictus menor/AIT de alto riesgo, iniciada en &lt; 24h por 21 días</div>
        `);
    }

    const trombectomiaHtml = section(r.cumpleTrombectomia ? '✅' : '➖', 'Trombectomía Mecánica', r.cumpleTrombectomia ? '#22c55e' : '#64748b',
        r.cumpleTrombectomia
            ? '<div>Cumple criterios de trombectomía mecánica — remitir a neurointervencionismo de inmediato. Puede combinarse con la trombolisis IV si también es candidato.</div>'
            : '<div>No cumple todos los criterios marcados para trombectomía en este momento — reevaluar si cambian los hallazgos de imagen.</div>');

    const postHtml = section('📋', 'Manejo Post-Trombolisis', '#8b5cf6', `
        <div>Sin antiagregantes ni anticoagulantes en las primeras 24h</div>
        <div style="margin-top:4px;">Mantener PA &lt; 180/105 mmHg durante 24h</div>
        <div style="margin-top:4px;">Vigilancia neurológica: cada 15min×2h → cada 30min×6h → cada 1h×16h</div>
        <div style="margin-top:4px; color:#dc2626; font-weight:600;">Señales de transformación hemorrágica (deterioro súbito, cefalea intensa, HTA aguda) → suspender infusión si en curso, TC urgente, considerar crioprecipitado/ácido tranexámico</div>
        <div style="margin-top:4px;">TC de control a las 24h antes de iniciar antiagregación</div>`);

    return `${headerHTML}${cuerpoHtml}${trombectomiaHtml}${postHtml}`;
}

function calculateCodigoIctusProtocol(event) {
    event.preventDefault();
    const horasRaw = document.getElementById('ictusHoras').value;
    const weightRaw = document.getElementById('ictusWeight').value;
    const sbpRaw = document.getElementById('ictusSbp').value;
    const dbpRaw = document.getElementById('ictusDbp').value;

    const exclusionAbsoluta = {};
    document.querySelectorAll('.ictus-ex-abs').forEach(cb => { exclusionAbsoluta[cb.id] = cb.checked; });
    const exclusionRelativa = {};
    document.querySelectorAll('.ictus-ex-rel').forEach(cb => { exclusionRelativa[cb.id] = cb.checked; });
    const trombectomia = {};
    document.querySelectorAll('.ictus-tromb').forEach(cb => { trombectomia[cb.id] = cb.checked; });

    const inputs = {
        horasInicio: horasRaw === '' ? null : parseFloat(horasRaw),
        ventanaIncierta: document.getElementById('ictusVentanaIncierta').checked,
        weight: weightRaw === '' ? null : parseFloat(weightRaw),
        sbp: sbpRaw === '' ? null : parseFloat(sbpRaw),
        dbp: dbpRaw === '' ? null : parseFloat(dbpRaw),
        exclusionAbsoluta, exclusionRelativa, trombectomia
    };

    const r = Calculators.calculateCodigoIctus(inputs);
    const container = document.getElementById('ictusResult');
    container.innerHTML = buildCodigoIctusHTML(r) + `
        <button class="btn btn-secondary" onclick="document.getElementById('ictusForm').reset(); document.getElementById('ictusResult').style.display='none'; toggleIctusFields();" style="width:100%; margin-top:12px;">
            🔄 Nuevo Protocolo
        </button>`;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 48, calculatorName: 'Código Ictus', inputs, result: r, interpretation: r.interpretation });
}

// === 49. GASOMETRÍA ARTERIAL — INTERPRETACIÓN SISTEMÁTICA ÁCIDO-BASE === //
function createGasometriaForm() {
    return `
        <form id="gasoForm" onsubmit="calculateGasometriaProtocol(event)">

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:14px; text-transform:uppercase; letter-spacing:0.05em;">Gasometría</div>
                <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">pH</label>
                        <input type="number" id="gasoPh" required step="0.01" min="6.5" max="7.8" class="form-input" placeholder="7.40">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">pCO₂ (mmHg)</label>
                        <input type="number" id="gasoPco2" required step="any" min="10" max="150" class="form-input" placeholder="40">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">HCO₃⁻ (mEq/L)</label>
                        <input type="number" id="gasoHco3" required step="any" min="2" max="60" class="form-input" placeholder="24">
                    </div>
                </div>
                <div class="form-group" style="margin-top:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Si hay componente respiratorio, ¿es agudo o crónico?</label>
                    <select id="gasoCronico" class="form-input">
                        <option value="no">Agudo (&lt; 24-48h, ej. asma/crisis aguda)</option>
                        <option value="si">Crónico (días-semanas, ej. EPOC retenedor de CO₂)</option>
                    </select>
                    <p style="font-size:11px; color:var(--text-tertiary); margin-top:4px;">Solo se usa si el análisis identifica un componente respiratorio primario o compensador.</p>
                </div>
            </div>

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:6px; text-transform:uppercase; letter-spacing:0.05em;">Electrolitos <span style="font-size:11px; font-weight:500; color:var(--text-tertiary); text-transform:none;">— opcional, para Anion Gap</span></div>
                <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-size:12px; color:var(--text-tertiary);">Na⁺ (mEq/L)</label>
                        <input type="number" id="gasoSodium" step="any" min="100" max="180" class="form-input">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-size:12px; color:var(--text-tertiary);">Cl⁻ (mEq/L)</label>
                        <input type="number" id="gasoChloride" step="any" min="60" max="140" class="form-input">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-size:12px; color:var(--text-tertiary);">Albúmina (g/dL)</label>
                        <input type="number" id="gasoAlbumin" step="any" min="1" max="6" class="form-input">
                    </div>
                </div>
            </div>

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:6px; text-transform:uppercase; letter-spacing:0.05em;">Oxigenación <span style="font-size:11px; font-weight:500; color:var(--text-tertiary); text-transform:none;">— opcional</span></div>
                <div class="form-row" style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px;">
                    <div>
                        <label style="display:block; margin-bottom:6px; font-size:12px; color:var(--text-tertiary);">PaO₂ (mmHg)</label>
                        <input type="number" id="gasoPao2" step="any" min="20" max="600" class="form-input">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-size:12px; color:var(--text-tertiary);">FiO₂ (%)</label>
                        <input type="number" id="gasoFio2" step="any" min="21" max="100" class="form-input" placeholder="21-100">
                    </div>
                    <div>
                        <label style="display:block; margin-bottom:6px; font-size:12px; color:var(--text-tertiary);">Edad (años)</label>
                        <input type="number" id="gasoEdad" step="1" min="0" max="120" class="form-input">
                    </div>
                </div>
            </div>

            <div style="background:#fef3c7; border-left:4px solid #f59e0b; padding:14px; border-radius:8px; margin-bottom:16px;">
                <p style="font-size:12px; color:#92400e; margin:0;">
                    <strong>⚠️ Herramienta de apoyo clínico</strong> — Verificar siempre con el equipo médico. Enfoque sistemático Boston/Winter — la interpretación numérica no reemplaza la correlación clínica.
                </p>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">
                🧮 Interpretar Gasometría
            </button>
        </form>
        <div id="gasoResult" style="display:none; margin-top:24px;"></div>
    `;
}

function buildGasometriaHTML(r) {
    const section = (icon, title, color, content) => `
        <div style="margin-bottom:12px; border-radius:var(--radius-lg); overflow:hidden; border:1px solid ${color}33;">
            <div style="background:${color}22; padding:12px 16px; display:flex; align-items:center; gap:8px; border-bottom:1px solid ${color}33;">
                <span style="font-size:18px;">${icon}</span>
                <span style="font-size:14px; font-weight:700; color:${color};">${title}</span>
            </div>
            <div style="padding:14px 16px; background:var(--bg-card); font-size:13px; line-height:1.8;">${content}</div>
        </div>`;

    const PRIMARIO_LABELS = {
        normal: 'Gasometría Normal',
        acidosis_metabolica: 'Acidosis Metabólica',
        alcalosis_metabolica: 'Alcalosis Metabólica',
        acidosis_respiratoria: 'Acidosis Respiratoria',
        alcalosis_respiratoria: 'Alcalosis Respiratoria',
        acidosis_mixta: 'Acidosis Mixta (Metabólica + Respiratoria)',
        alcalosis_mixta: 'Alcalosis Mixta (Metabólica + Respiratoria)',
        ambiguo_acidmet_o_alcresp: 'Patrón Ambiguo — Acidosis Metabólica vs. Alcalosis Respiratoria',
        ambiguo_acidresp_o_alcmet: 'Patrón Ambiguo — Acidosis Respiratoria vs. Alcalosis Metabólica'
    };

    const HALLAZGO_LABELS = {
        apropiada: 'Compensación apropiada — trastorno simple',
        acidosis_respiratoria_concomitante: 'pCO₂ más alta de lo esperado → acidosis respiratoria concomitante',
        alcalosis_respiratoria_concomitante: 'pCO₂ más baja de lo esperado → alcalosis respiratoria concomitante',
        acidosis_metabolica_concomitante: 'HCO₃⁻ más bajo de lo esperado → acidosis metabólica concomitante',
        alcalosis_metabolica_concomitante: 'HCO₃⁻ más alto de lo esperado → alcalosis metabólica concomitante'
    };

    const DELTA_LABELS = {
        hiperclorémica_predominante: 'Acidosis hiperclorémica predominante (AG poco relevante)',
        mixta_ag_hiperclorémica: 'Acidosis con AG elevado + acidosis hiperclorémica concomitante',
        agma_pura: 'Acidosis con AG elevado PURA (sin otro trastorno metabólico oculto)',
        ag_mas_alcalosis_metabolica: 'Acidosis con AG elevado + alcalosis metabólica concomitante (o proceso crónico previo)'
    };

    const headerHTML = `
        <div style="background:${r.severity.colorHex}; padding:20px; border-radius:var(--radius-lg); color:white; margin-bottom:12px;">
            <div style="font-size:20px; font-weight:800;">${r.severity.badge} ${PRIMARIO_LABELS[r.primario] || r.primario}</div>
            <div style="font-size:13px; opacity:0.9; margin-top:4px;">pH ${r.ph} · pCO₂ ${r.pco2} mmHg · HCO₃⁻ ${r.hco3} mEq/L</div>
        </div>`;

    const congruenciaHtml = !r.congruente ? `
        <div style="background:#431407; color:#fdba74; border:2px solid #f97316; border-radius:var(--radius-lg); padding:14px; margin-bottom:12px; font-size:13px;">
            <strong>⚠️ Valores posiblemente incongruentes</strong> — el pH medido no concuerda con el esperado a partir de pCO₂/HCO₃⁻ (ecuación de Henderson). Verificar la muestra o considerar error de laboratorio antes de confiar en la interpretación.
        </div>` : '';

    let trastornoContent = `<div>Valores dentro de rango normal (pH 7.35-7.45, pCO₂ 35-45, HCO₃⁻ 22-26).</div>`;
    if (r.esMixtoObvio) {
        trastornoContent = `<div style="color:#dc2626; font-weight:700;">Ambos componentes (pCO₂ y HCO₃⁻) están alterados en la MISMA dirección de pH — esto no puede explicarse por una compensación fisiológica única, por lo que es necesariamente un trastorno doble/mixto.</div>`;
    } else if (r.primario && r.primario.startsWith('ambiguo_')) {
        trastornoContent = `
            <div style="color:#f59e0b; font-weight:700;">Patrón compatible con más de una interpretación primaria:</div>
            <div style="margin-top:6px;"><strong>Hipótesis 1 (${r.compensacion.tipo === 'acidosis_respiratoria' || r.compensacion.tipo === 'acidosis_metabolica' ? 'primaria' : 'primaria'}):</strong> ${PRIMARIO_LABELS[r.compensacion.tipo] || r.compensacion.tipo} — ${r.compensacion.formula}, esperado ${r.compensacion.esperadoMin}-${r.compensacion.esperadoMax}, medido ${r.compensacion.medido} ${r.compensacion.fit ? '✓ ajusta' : '✗ no ajusta bien'}</div>
            <div style="margin-top:4px;"><strong>Hipótesis 2:</strong> ${PRIMARIO_LABELS[r.hipotesisAlternativa.tipo] || r.hipotesisAlternativa.tipo} — ${r.hipotesisAlternativa.formula}, esperado ${r.hipotesisAlternativa.esperadoMin}-${r.hipotesisAlternativa.esperadoMax}, medido ${r.hipotesisAlternativa.medido} ${r.hipotesisAlternativa.fit ? '✓ ajusta' : '✗ no ajusta bien'}</div>
            <div style="margin-top:8px; color:var(--text-secondary); font-size:12px;">Correlacionar con la clínica: antecedente respiratorio crónico (EPOC) sugiere origen respiratorio; vómitos/diuréticos/succión nasogástrica sugieren origen metabólico.</div>`;
    } else if (r.primario !== 'normal' && r.compensacion) {
        trastornoContent = `
            <div><strong>Trastorno primario:</strong> ${PRIMARIO_LABELS[r.primario]}</div>
            <div style="margin-top:6px;"><strong>Compensación esperada (${r.compensacion.formula}):</strong> ${r.compensacion.esperadoMin}-${r.compensacion.esperadoMax}, medido ${r.compensacion.medido}</div>
            <div style="margin-top:4px; color:${r.compensacion.hallazgo === 'apropiada' ? 'var(--success)' : '#dc2626'}; font-weight:700;">${HALLAZGO_LABELS[r.compensacion.hallazgo]}</div>
            ${r.hipotesisAlternativa ? `<div style="margin-top:6px; color:var(--text-secondary); font-size:12px;">Hipótesis alternativa descartada: ${PRIMARIO_LABELS[r.hipotesisAlternativa.tipo]} (esperado ${r.hipotesisAlternativa.esperadoMin}-${r.hipotesisAlternativa.esperadoMax}, no ajusta).</div>` : ''}`;
    }

    let agContent = '<div style="color:var(--text-secondary);">Ingresa Na⁺ y Cl⁻ para calcular el Anion Gap.</div>';
    if (r.agResult) {
        agContent = `
            <div><strong>Anion Gap:</strong> ${r.agResult.value} mEq/L${r.agResult.correctedValue !== null ? ` (corregido por albúmina: ${r.agResult.correctedValue} mEq/L)` : ''}</div>
            <div style="margin-top:4px; color:${r.agResult.agElevado ? '#dc2626' : 'var(--success)'}; font-weight:600;">${r.agResult.agElevado ? 'Anion Gap elevado' : 'Anion Gap normal'}</div>
            ${r.deltaRatio !== null ? `
                <div style="margin-top:8px;"><strong>Delta Ratio:</strong> ${r.deltaRatio}</div>
                <div style="margin-top:4px;">${DELTA_LABELS[r.deltaInterpretacion]}</div>` : ''}`;
    }

    let oxContent = '<div style="color:var(--text-secondary);">Ingresa PaO₂ y FiO₂ para evaluar oxigenación.</div>';
    if (r.oxigenacion) {
        oxContent = `
            <div><strong>Índice de Kirby (PaO₂/FiO₂):</strong> ${r.oxigenacion.kirby}</div>
            ${r.oxigenacion.sdra ? `<div style="margin-top:4px; color:#dc2626; font-weight:600;">Compatible con SDRA ${r.oxigenacion.sdra} (criterios de Berlín), en el contexto clínico apropiado</div>` : '<div style="margin-top:4px; color:var(--success);">Sin criterio de SDRA por índice de Kirby</div>'}
            ${r.oxigenacion.gradienteAa !== null ? `<div style="margin-top:8px;"><strong>Gradiente A-a:</strong> ${r.oxigenacion.gradienteAa} mmHg (esperado por edad: ≈ ${r.oxigenacion.gradienteEsperado} mmHg)</div>` : ''}`;
    }

    return `${headerHTML}${congruenciaHtml}
        ${section('🔬', '1. Trastorno Ácido-Base', '#f59e0b', trastornoContent)}
        ${section('📐', '2. Anion Gap', '#8b5cf6', agContent)}
        ${section('🫁', '3. Oxigenación', '#0ea5e9', oxContent)}`;
}

function calculateGasometriaProtocol(event) {
    event.preventDefault();
    const optNum = (id) => { const v = document.getElementById(id).value; return v === '' ? null : parseFloat(v); };

    const fio2Raw = optNum('gasoFio2');
    const inputs = {
        ph: parseFloat(document.getElementById('gasoPh').value),
        pco2: parseFloat(document.getElementById('gasoPco2').value),
        hco3: parseFloat(document.getElementById('gasoHco3').value),
        cronico: document.getElementById('gasoCronico').value === 'si',
        sodium: optNum('gasoSodium'),
        chloride: optNum('gasoChloride'),
        albumin: optNum('gasoAlbumin'),
        pao2: optNum('gasoPao2'),
        fio2: fio2Raw,
        edad: optNum('gasoEdad')
    };

    const r = Calculators.calculateGasometria(inputs);
    const container = document.getElementById('gasoResult');
    container.innerHTML = buildGasometriaHTML(r) + `
        <button class="btn btn-secondary" onclick="document.getElementById('gasoForm').reset(); document.getElementById('gasoResult').style.display='none';" style="width:100%; margin-top:12px;">
            🔄 Nueva Interpretación
        </button>`;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 49, calculatorName: 'Gasometría Arterial', inputs, result: r, interpretation: r.interpretation });
}

// === 50. QTc CORREGIDO === //
function createQTcForm() {
    return `
        <form id="qtcForm" onsubmit="calculateQTcForm(event)">
            <div class="form-group" style="margin-bottom:14px;">
                <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Intervalo QT medido (ms)</label>
                <input type="number" id="qtcQt" step="any" min="200" max="800" class="form-input" required>
            </div>
            <div class="form-group" style="margin-bottom:14px;">
                <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Frecuencia Cardíaca (lpm)</label>
                <input type="number" id="qtcHr" step="any" min="20" max="250" class="form-input" required>
            </div>
            <div class="form-group" style="margin-bottom:20px;">
                <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Sexo</label>
                <select id="qtcSex" class="form-input">
                    <option value="M">Masculino</option>
                    <option value="F">Femenino</option>
                </select>
            </div>
            <div style="background:#dbeafe; border-left:4px solid #3b82f6; padding:14px; border-radius:8px; margin-bottom:16px;">
                <p style="font-size:12px; color:#1e3a8a; margin:0;">Relevante junto a <strong>Protocolo de Arritmias (Calculadora 45)</strong> y fármacos QT-prolongantes de <strong>Vasoactivos IV (Calculadora 29)</strong> (ej. amiodarona).</p>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">🧮 Calcular QTc</button>
        </form>
        <div id="qtcResult" style="display:none; margin-top:24px;"></div>
    `;
}

function calculateQTcForm(event) {
    event.preventDefault();
    const inputs = {
        qt: parseFloat(document.getElementById('qtcQt').value),
        hr: parseFloat(document.getElementById('qtcHr').value),
        sex: document.getElementById('qtcSex').value
    };
    const result = Calculators.calculateQTc(inputs);
    const colorMap = { success: 'var(--success)', warning: 'var(--warning)', danger: 'var(--danger)' };
    const container = document.getElementById('qtcResult');
    container.innerHTML = `
        <div style="background:linear-gradient(135deg,var(--brand-accent-dark),var(--brand-accent)); padding:24px; border-radius:var(--radius-lg); color:var(--brand-primary-dark); margin-bottom:16px;">
            <div style="font-size:13px; font-weight:600; margin-bottom:8px; opacity:0.8;">QTc (BAZETT)</div>
            <div style="font-size:36px; font-weight:800; margin-bottom:4px;">${result.qtcBazett} <span style="font-size:20px; font-weight:500;">ms</span></div>
            <div style="font-size:14px; font-weight:600; margin-bottom:12px;">${result.interpretation.label}</div>
            <div style="background:rgba(30,56,114,0.15); padding:12px; border-radius:8px; font-size:13px; display:flex; justify-content:space-around;">
                <span><strong>Fridericia</strong> ${result.qtcFridericia}ms</span>
                <span><strong>Framingham</strong> ${result.qtcFramingham}ms</span>
            </div>
        </div>
        ${result.frecuenciaExtrema ? `<div style="background:#fef3c7; border-left:4px solid #f59e0b; padding:12px; border-radius:8px; margin-bottom:16px; font-size:12px; color:#92400e;">⚠️ FC fuera de 60-90 lpm — Bazett puede sobre/subcorregir; considerar Fridericia o Framingham como más fiables en este rango.</div>` : ''}
        <div style="background:var(--bg-secondary); padding:20px; border-radius:var(--radius-lg); border-left:4px solid ${colorMap[result.interpretation.color]}; margin-bottom:16px;">
            <h4 style="font-size:14px; font-weight:700; margin-bottom:8px;">Interpretación</h4>
            <p style="font-size:13px; color:var(--text-secondary); line-height:1.6;">${result.interpretation.description}</p>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('qtcForm').reset(); document.getElementById('qtcResult').style.display='none';" style="width:100%; margin-top:0;">🔄 Nuevo Cálculo</button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 50, calculatorName: 'QTc Corregido', inputs, result, interpretation: result.interpretation });
}

// === 51. ABCD2 SCORE === //
function createABCD2Form() {
    const check = (id, text) => `
        <label style="display:flex; align-items:flex-start; gap:10px; margin-bottom:12px; cursor:pointer;">
            <input type="checkbox" id="${id}" style="width:18px; height:18px; margin-top:2px; flex-shrink:0;">
            <span style="font-size:14px;">${text}</span>
        </label>`;
    return `
        <form id="abcd2Form" onsubmit="calculateABCD2Form(event)">
            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                ${check('abcd2Edad', 'Edad ≥ 60 años (1 pt)')}
                ${check('abcd2Pa', 'PA ≥ 140/90 mmHg en la evaluación inicial (1 pt)')}
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin:14px 0 8px; text-transform:uppercase; letter-spacing:0.05em;">Características Clínicas</div>
                <select id="abcd2Clinica" class="form-input">
                    <option value="otra">Otros síntomas (0 pts)</option>
                    <option value="habla">Alteración del habla sin debilidad (1 pt)</option>
                    <option value="debilidad">Debilidad unilateral (2 pts)</option>
                </select>
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin:14px 0 8px; text-transform:uppercase; letter-spacing:0.05em;">Duración</div>
                <select id="abcd2Duracion" class="form-input">
                    <option value="menor10">&lt; 10 minutos (0 pts)</option>
                    <option value="entre10y59">10-59 minutos (1 pt)</option>
                    <option value="mayor60">≥ 60 minutos (2 pts)</option>
                </select>
                <div style="margin-top:14px;">${check('abcd2Diabetes', 'Diabetes Mellitus (1 pt)')}</div>
            </div>
            <div style="background:#dbeafe; border-left:4px solid #3b82f6; padding:14px; border-radius:8px; margin-bottom:16px;">
                <p style="font-size:12px; color:#1e3a8a; margin:0;">Complementa <strong>NIHSS (Calculadora 17)</strong> y <strong>Código Ictus (Calculadora 48)</strong> en la evaluación tras un AIT.</p>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">🧮 Calcular ABCD2</button>
        </form>
        <div id="abcd2Result" style="display:none; margin-top:24px;"></div>
    `;
}

function calculateABCD2Form(event) {
    event.preventDefault();
    const inputs = {
        edad60: document.getElementById('abcd2Edad').checked,
        pa: document.getElementById('abcd2Pa').checked,
        clinica: document.getElementById('abcd2Clinica').value,
        duracion: document.getElementById('abcd2Duracion').value,
        diabetes: document.getElementById('abcd2Diabetes').checked
    };
    const result = Calculators.calculateABCD2(inputs);
    const colorMap = { success: 'var(--success)', warning: 'var(--warning)', danger: 'var(--danger)' };
    const container = document.getElementById('abcd2Result');
    container.innerHTML = `
        <div style="background:linear-gradient(135deg,var(--brand-accent-dark),var(--brand-accent)); padding:24px; border-radius:var(--radius-lg); color:var(--brand-primary-dark); margin-bottom:16px;">
            <div style="font-size:13px; font-weight:600; margin-bottom:8px; opacity:0.8;">ABCD2 SCORE</div>
            <div style="font-size:36px; font-weight:800; margin-bottom:4px;">${result.value} <span style="font-size:20px; font-weight:500;">/7</span></div>
            <div style="font-size:14px; font-weight:600;">${result.interpretation.label}</div>
        </div>
        <div style="background:var(--bg-secondary); padding:20px; border-radius:var(--radius-lg); border-left:4px solid ${colorMap[result.interpretation.color]}; margin-bottom:16px;">
            <h4 style="font-size:14px; font-weight:700; margin-bottom:8px;">Interpretación</h4>
            <p style="font-size:13px; color:var(--text-secondary); line-height:1.6;">${result.interpretation.description}</p>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('abcd2Form').reset(); document.getElementById('abcd2Result').style.display='none';" style="width:100%; margin-top:0;">🔄 Nuevo Cálculo</button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 51, calculatorName: 'ABCD2 Score', inputs, result, interpretation: result.interpretation });
}

// === 52. ESCALA DE RANKIN MODIFICADA (mRS) === //
function createRankinForm() {
    const opts = Calculators.RANKIN_LEVELS.map(l => `<option value="${l.level}">${l.level} — ${l.label}</option>`).join('');
    return `
        <form id="rankinForm" onsubmit="calculateRankinForm(event)">
            <div class="form-group" style="margin-bottom:20px;">
                <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Nivel de discapacidad funcional</label>
                <select id="rankinLevel" class="form-input">${opts}</select>
            </div>
            <div style="background:#dbeafe; border-left:4px solid #3b82f6; padding:14px; border-radius:8px; margin-bottom:16px;">
                <p style="font-size:12px; color:#1e3a8a; margin:0;">Uso dual: Rankin <strong>previo</strong> (basal, pre-ictus — Código Ictus exige ≤1 para trombectomía) o Rankin <strong>al alta</strong> (resultado funcional). Ver <strong>Código Ictus (Calculadora 48)</strong>.</p>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">🧮 Ver Descripción</button>
        </form>
        <div id="rankinResult" style="display:none; margin-top:24px;"></div>
    `;
}

function calculateRankinForm(event) {
    event.preventDefault();
    const inputs = { level: parseInt(document.getElementById('rankinLevel').value) };
    const result = Calculators.calculateRankin(inputs);
    const colorMap = { success: 'var(--success)', warning: 'var(--warning)', danger: 'var(--danger)' };
    const container = document.getElementById('rankinResult');
    container.innerHTML = `
        <div style="background:linear-gradient(135deg,var(--brand-accent-dark),var(--brand-accent)); padding:24px; border-radius:var(--radius-lg); color:var(--brand-primary-dark); margin-bottom:16px;">
            <div style="font-size:13px; font-weight:600; margin-bottom:8px; opacity:0.8;">ESCALA DE RANKIN MODIFICADA</div>
            <div style="font-size:36px; font-weight:800;">mRS ${result.value}</div>
        </div>
        <div style="background:var(--bg-secondary); padding:20px; border-radius:var(--radius-lg); border-left:4px solid ${colorMap[result.interpretation.color]}; margin-bottom:16px;">
            <p style="font-size:13px; color:var(--text-secondary); line-height:1.6;">${result.interpretation.description}</p>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('rankinForm').reset(); document.getElementById('rankinResult').style.display='none';" style="width:100%; margin-top:0;">🔄 Nueva Consulta</button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 52, calculatorName: 'Escala de Rankin Modificada', inputs, result, interpretation: result.interpretation });
}

// === 53. PROFILAXIS DE TVE — CAPRINI / PADUA === //
function createVTEForm() {
    const check = (id, text) => `
        <label style="display:flex; align-items:flex-start; gap:10px; margin-bottom:10px; cursor:pointer;">
            <input type="checkbox" id="${id}" style="width:18px; height:18px; margin-top:2px; flex-shrink:0;">
            <span style="font-size:13px;">${text}</span>
        </label>`;
    return `
        <form id="vteForm" onsubmit="calculateVTEForm(event)">
            <div style="background:var(--bg-secondary); padding:14px; border-radius:12px; margin-bottom:16px; display:flex; gap:16px; flex-wrap:wrap;">
                <label style="display:flex; align-items:center; gap:8px; cursor:pointer; font-size:13px; font-weight:600;">
                    <input type="radio" name="vteTipo" value="medico" checked onchange="toggleVTEType()"> Paciente médico (Padua)
                </label>
                <label style="display:flex; align-items:center; gap:8px; cursor:pointer; font-size:13px; font-weight:600;">
                    <input type="radio" name="vteTipo" value="quirurgico" onchange="toggleVTEType()"> Paciente quirúrgico (Caprini)
                </label>
            </div>

            <div id="vtePaduaWrap" style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                ${check('vtePCancer', 'Cáncer activo (3 pts)')}
                ${check('vtePTvp', 'TVE previa, excluyendo trombosis venosa superficial (3 pts)')}
                ${check('vtePMovilidad', 'Movilidad reducida — reposo en cama ≥3 días (3 pts)')}
                ${check('vtePTrombofilia', 'Trombofilia conocida (3 pts)')}
                ${check('vtePTrauma', 'Trauma o cirugía reciente (≤1 mes) (2 pts)')}
                ${check('vtePEdad70', 'Edad ≥ 70 años (1 pt)')}
                ${check('vtePIcResp', 'Insuficiencia cardíaca y/o respiratoria (1 pt)')}
                ${check('vtePIamAvc', 'IAM o ACV isquémico agudo (1 pt)')}
                ${check('vtePInfeccion', 'Infección aguda y/o enfermedad reumatológica (1 pt)')}
                ${check('vtePObesidad', 'Obesidad (IMC ≥ 30) (1 pt)')}
                ${check('vtePHormonal', 'Tratamiento hormonal en curso (1 pt)')}
            </div>

            <div id="vteCapriniWrap" style="display:none; background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:8px; text-transform:uppercase; letter-spacing:0.05em;">Edad</div>
                <select id="vteEdadTier" class="form-input" style="margin-bottom:14px;">
                    <option value="menor41">&lt; 41 años (0 pts)</option>
                    <option value="41-60">41-60 años (1 pt)</option>
                    <option value="61-74">61-74 años (2 pts)</option>
                    <option value="75+">≥ 75 años (3 pts)</option>
                </select>
                <p style="font-size:11px; color:var(--text-tertiary); margin-bottom:6px;">Versión focalizada — subconjunto representativo de los factores de mayor peso (no las ~40 variables completas del Caprini original).</p>
                <div style="font-size:12px; font-weight:700; color:var(--text-secondary); margin:10px 0 4px;">1 punto c/u</div>
                ${check('vteCCirugiaMenor', 'Cirugía menor planeada')}
                ${check('vteCImc25', 'IMC ≥ 25')}
                ${check('vteCVarices', 'Venas varicosas')}
                ${check('vteCEmbarazo', 'Embarazo o puerperio')}
                ${check('vteCAcoTrh', 'Anticonceptivos orales o THR')}
                ${check('vteCSepsis', 'Sepsis (&lt; 1 mes)')}
                ${check('vteCEpoc', 'Enfermedad pulmonar grave incl. neumonía (&lt; 1 mes)')}
                ${check('vteCIam', 'IAM reciente')}
                ${check('vteCIc', 'Insuficiencia cardíaca (&lt; 1 mes)')}
                ${check('vteCEncamado', 'Paciente médico encamado')}
                <div style="font-size:12px; font-weight:700; color:var(--text-secondary); margin:14px 0 4px;">2 puntos c/u</div>
                ${check('vteCArtroscopia', 'Cirugía artroscópica')}
                ${check('vteCMayorAbierta', 'Cirugía mayor abierta (&gt; 45 min)')}
                ${check('vteCLaparoscopica', 'Cirugía laparoscópica (&gt; 45 min)')}
                ${check('vteCMalignidad', 'Malignidad activa')}
                ${check('vteCEncamado72h', 'Confinado a cama (&gt; 72h)')}
                ${check('vteCYeso', 'Inmovilización con yeso')}
                ${check('vteCAcceso', 'Acceso venoso central')}
                <div style="font-size:12px; font-weight:700; color:var(--text-secondary); margin:14px 0 4px;">3 puntos c/u</div>
                ${check('vteCHistoriaTVE', 'Historia personal de TVE/TEP')}
                ${check('vteCHistoriaFam', 'Historia familiar de TVE/TEP')}
                ${check('vteCTrombofiliaC', 'Trombofilia congénita/adquirida conocida')}
                ${check('vteCHit', 'Trombocitopenia inducida por heparina (HIT)')}
                <div style="font-size:12px; font-weight:700; color:var(--text-secondary); margin:14px 0 4px;">5 puntos c/u</div>
                ${check('vteCIctus', 'Ictus (&lt; 1 mes)')}
                ${check('vteCArtroplastia', 'Artroplastia mayor electiva de miembro inferior')}
                ${check('vteCFractura', 'Fractura de cadera/pelvis/pierna (&lt; 1 mes)')}
                ${check('vteCTrauma', 'Trauma múltiple (&lt; 1 mes)')}
                ${check('vteCLesionMedular', 'Lesión medular aguda (&lt; 1 mes)')}
            </div>

            <div style="background:#dbeafe; border-left:4px solid #3b82f6; padding:14px; border-radius:8px; margin-bottom:16px;">
                <p style="font-size:12px; color:#1e3a8a; margin:0;">Distinto de <strong>Wells TEP (Calculadora 14)</strong>, que es diagnóstico de TEP ya establecido — esta herramienta decide si el paciente hospitalizado necesita profilaxis.</p>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">🧮 Calcular Riesgo de TVE</button>
        </form>
        <div id="vteResult" style="display:none; margin-top:24px;"></div>
    `;
}

function toggleVTEType() {
    const tipo = document.querySelector('input[name="vteTipo"]:checked').value;
    document.getElementById('vtePaduaWrap').style.display = tipo === 'medico' ? 'block' : 'none';
    document.getElementById('vteCapriniWrap').style.display = tipo === 'quirurgico' ? 'block' : 'none';
}

function calculateVTEForm(event) {
    event.preventDefault();
    const tipo = document.querySelector('input[name="vteTipo"]:checked').value;
    let inputs;
    if (tipo === 'medico') {
        inputs = {
            tipo, factores: {
                cancer: document.getElementById('vtePCancer').checked,
                tvpPrevia: document.getElementById('vtePTvp').checked,
                movilidadReducida: document.getElementById('vtePMovilidad').checked,
                trombofilia: document.getElementById('vtePTrombofilia').checked,
                traumaCirugiaReciente: document.getElementById('vtePTrauma').checked,
                edad70: document.getElementById('vtePEdad70').checked,
                icCardioRespiratoria: document.getElementById('vtePIcResp').checked,
                iamAvcAgudo: document.getElementById('vtePIamAvc').checked,
                infeccionReumatico: document.getElementById('vtePInfeccion').checked,
                obesidad: document.getElementById('vtePObesidad').checked,
                hormonal: document.getElementById('vtePHormonal').checked
            }
        };
    } else {
        inputs = {
            tipo, edadTier: document.getElementById('vteEdadTier').value,
            factores: {
                cirugiaMenor: document.getElementById('vteCCirugiaMenor').checked,
                imc25: document.getElementById('vteCImc25').checked,
                varices: document.getElementById('vteCVarices').checked,
                embarazoPuerperio: document.getElementById('vteCEmbarazo').checked,
                acoTrh: document.getElementById('vteCAcoTrh').checked,
                sepsisReciente: document.getElementById('vteCSepsis').checked,
                epocNeumoniaReciente: document.getElementById('vteCEpoc').checked,
                iamReciente: document.getElementById('vteCIam').checked,
                icReciente: document.getElementById('vteCIc').checked,
                encamadoMedico: document.getElementById('vteCEncamado').checked,
                artroscopia: document.getElementById('vteCArtroscopia').checked,
                cirugiaMayorAbierta: document.getElementById('vteCMayorAbierta').checked,
                cirugiaLaparoscopicaLarga: document.getElementById('vteCLaparoscopica').checked,
                malignidadActiva: document.getElementById('vteCMalignidad').checked,
                encamado72h: document.getElementById('vteCEncamado72h').checked,
                yesoInmovilizador: document.getElementById('vteCYeso').checked,
                accesoVenosoCentral: document.getElementById('vteCAcceso').checked,
                historiaTVE: document.getElementById('vteCHistoriaTVE').checked,
                historiaFamiliarTVE: document.getElementById('vteCHistoriaFam').checked,
                trombofiliaConocida: document.getElementById('vteCTrombofiliaC').checked,
                hit: document.getElementById('vteCHit').checked,
                ictusReciente: document.getElementById('vteCIctus').checked,
                artroplastiaMayorMI: document.getElementById('vteCArtroplastia').checked,
                fracturaCaderaPelvisPiernaReciente: document.getElementById('vteCFractura').checked,
                traumaMultipleReciente: document.getElementById('vteCTrauma').checked,
                lesionMedularAguda: document.getElementById('vteCLesionMedular').checked
            }
        };
    }

    const result = Calculators.calculateVTEProphylaxis(inputs);
    const colorMap = { success: 'var(--success)', warning: 'var(--warning)', danger: 'var(--danger)' };
    const container = document.getElementById('vteResult');
    container.innerHTML = `
        <div style="background:linear-gradient(135deg,var(--brand-accent-dark),var(--brand-accent)); padding:24px; border-radius:var(--radius-lg); color:var(--brand-primary-dark); margin-bottom:16px;">
            <div style="font-size:13px; font-weight:600; margin-bottom:8px; opacity:0.8;">${result.escala.toUpperCase()}</div>
            <div style="font-size:36px; font-weight:800; margin-bottom:4px;">${result.value} <span style="font-size:20px; font-weight:500;">pts</span></div>
            <div style="font-size:14px; font-weight:600;">${result.interpretation.label}</div>
        </div>
        <div style="background:var(--bg-secondary); padding:20px; border-radius:var(--radius-lg); border-left:4px solid ${colorMap[result.interpretation.color]}; margin-bottom:16px;">
            <p style="font-size:13px; color:var(--text-secondary); line-height:1.6;">${result.interpretation.description}</p>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('vteForm').reset(); document.getElementById('vteResult').style.display='none'; toggleVTEType();" style="width:100%; margin-top:0;">🔄 Nuevo Cálculo</button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 53, calculatorName: 'Profilaxis de TVE (Caprini/Padua)', inputs, result, interpretation: result.interpretation });
}

// === 54. SCORE 4Ts (HIT) === //
function create4TsForm() {
    const sel = (id, opts) => `<select id="${id}" class="form-input">${opts.map(o => `<option value="${o.v}">${o.v} pts — ${o.t}</option>`).join('')}</select>`;
    return `
        <form id="ts4Form" onsubmit="calculate4TsForm(event)">
            <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:8px; text-transform:uppercase; letter-spacing:0.05em;">Trombocitopenia</div>
            <div style="margin-bottom:16px;">${sel('ts4Plaquetas', [
                { v: 0, t: 'Caída &lt;30% o nadir &lt;10.000/mm³' },
                { v: 1, t: 'Caída 30-50% o nadir 10.000-19.000/mm³' },
                { v: 2, t: 'Caída &gt;50% Y nadir ≥20.000/mm³' }
            ])}</div>

            <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:8px; text-transform:uppercase; letter-spacing:0.05em;">Cronología</div>
            <div style="margin-bottom:16px;">${sel('ts4Tiempo', [
                { v: 0, t: 'Caída reciente (&lt;4 días) sin exposición previa a heparina' },
                { v: 1, t: 'Consistente pero incierto, o inicio &gt;día 10, o caída ≤1 día con exposición 30-100 días antes' },
                { v: 2, t: 'Inicio claro días 5-10, o ≤1 día si exposición a heparina en últimos 30 días' }
            ])}</div>

            <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:8px; text-transform:uppercase; letter-spacing:0.05em;">Trombosis u otras secuelas</div>
            <div style="margin-bottom:16px;">${sel('ts4Trombosis', [
                { v: 0, t: 'Ninguna' },
                { v: 1, t: 'Trombosis progresiva/recurrente, lesiones cutáneas eritematosas, sospecha no confirmada' },
                { v: 2, t: 'Trombosis nueva confirmada, necrosis cutánea, reacción sistémica aguda post-bolo IV' }
            ])}</div>

            <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:8px; text-transform:uppercase; letter-spacing:0.05em;">Otras causas de trombocitopenia</div>
            <div style="margin-bottom:20px;">${sel('ts4Otras', [
                { v: 0, t: 'Causa definida presente' },
                { v: 1, t: 'Causa posible' },
                { v: 2, t: 'Ninguna otra causa aparente' }
            ])}</div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">🧮 Calcular Score 4Ts</button>
        </form>
        <div id="ts4Result" style="display:none; margin-top:24px;"></div>
    `;
}

function calculate4TsForm(event) {
    event.preventDefault();
    const inputs = {
        plaquetas: parseInt(document.getElementById('ts4Plaquetas').value),
        tiempo: parseInt(document.getElementById('ts4Tiempo').value),
        trombosis: parseInt(document.getElementById('ts4Trombosis').value),
        otrasCausas: parseInt(document.getElementById('ts4Otras').value)
    };
    const result = Calculators.calculate4Ts(inputs);
    const colorMap = { success: 'var(--success)', warning: 'var(--warning)', danger: 'var(--danger)' };
    const container = document.getElementById('ts4Result');
    container.innerHTML = `
        <div style="background:linear-gradient(135deg,var(--brand-accent-dark),var(--brand-accent)); padding:24px; border-radius:var(--radius-lg); color:var(--brand-primary-dark); margin-bottom:16px;">
            <div style="font-size:13px; font-weight:600; margin-bottom:8px; opacity:0.8;">SCORE 4Ts</div>
            <div style="font-size:36px; font-weight:800; margin-bottom:4px;">${result.value} <span style="font-size:20px; font-weight:500;">/8</span></div>
            <div style="font-size:14px; font-weight:600;">${result.interpretation.label}</div>
        </div>
        <div style="background:var(--bg-secondary); padding:20px; border-radius:var(--radius-lg); border-left:4px solid ${colorMap[result.interpretation.color]}; margin-bottom:16px;">
            <p style="font-size:13px; color:var(--text-secondary); line-height:1.6;">${result.interpretation.description}</p>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('ts4Form').reset(); document.getElementById('ts4Result').style.display='none';" style="width:100%; margin-top:0;">🔄 Nuevo Cálculo</button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 54, calculatorName: 'Score 4Ts (HIT)', inputs, result, interpretation: result.interpretation });
}

// === 55. FÓRMULA DE PARKLAND (QUEMADOS) === //
function createParklandForm() {
    const units = Storage.getSettings().units;
    const wUnit = units.weight || 'kg';
    return `
        <form id="parklandForm" onsubmit="calculateParklandProtocol(event)">
            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Peso (${wUnit})</label>
                    <input type="number" id="parklandWeight" step="any" min="1" max="300" class="form-input" required>
                </div>
                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">% Superficie Corporal Total quemada (2º-3er grado)</label>
                    <input type="number" id="parklandTbsa" step="any" min="1" max="100" class="form-input" required>
                </div>
                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Horas transcurridas desde la quemadura</label>
                    <input type="number" id="parklandHoras" step="any" min="0" max="48" class="form-input" placeholder="No desde la llegada al hospital">
                </div>
                <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                    <input type="checkbox" id="parklandPediatrico" style="width:18px; height:18px;">
                    <span style="font-size:13px;">Paciente pediátrico (añadir líquidos de mantenimiento Holliday-Segar)</span>
                </label>
            </div>
            <div style="background:#fef3c7; border-left:4px solid #f59e0b; padding:14px; border-radius:8px; margin-bottom:16px;">
                <p style="font-size:12px; color:#92400e; margin:0;"><strong>⚠️ Herramienta de apoyo clínico</strong> — Verificar siempre con el equipo médico. El tiempo se cuenta desde el momento de la quemadura, no desde la llegada.</p>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">🧮 Calcular Fluidoterapia</button>
        </form>
        <div id="parklandResult" style="display:none; margin-top:24px;"></div>
    `;
}

function buildParklandHTML(r) {
    const section = (icon, title, color, content) => `
        <div style="margin-bottom:12px; border-radius:var(--radius-lg); overflow:hidden; border:1px solid ${color}33;">
            <div style="background:${color}22; padding:12px 16px; display:flex; align-items:center; gap:8px; border-bottom:1px solid ${color}33;">
                <span style="font-size:18px;">${icon}</span>
                <span style="font-size:14px; font-weight:700; color:${color};">${title}</span>
            </div>
            <div style="padding:14px 16px; background:var(--bg-card); font-size:13px; line-height:1.8;">${content}</div>
        </div>`;

    const headerHTML = `
        <div style="background:#3b82f6; padding:20px; border-radius:var(--radius-lg); color:white; margin-bottom:12px;">
            <div style="font-size:20px; font-weight:800;">💧 Fórmula de Parkland</div>
            <div style="font-size:13px; opacity:0.9; margin-top:4px;">Volumen total 24h: ${r.volumenTotal} mL</div>
        </div>`;

    const fasesHtml = section('⏱️', 'Fluidoterapia por Fases', '#3b82f6', `
        <div><strong>Primeras 8h (desde la quemadura):</strong> ${r.primeras8h} mL</div>
        <div style="margin-top:4px;"><strong>Siguientes 16h:</strong> ${r.siguientes16h} mL</div>
        ${r.tasaActual !== null ? `<div style="margin-top:8px; color:var(--brand-accent); font-weight:700;">${r.fase}: tasa actual ≈ ${r.tasaActual} mL/h</div>` : (r.fase ? `<div style="margin-top:8px; color:#f59e0b;">${r.fase}</div>` : '')}
        <div style="margin-top:8px; color:var(--text-secondary); font-size:12px;">Usar Ringer Lactato preferentemente. Ajustar según diuresis objetivo (0.5-1 mL/kg/h adultos).</div>`);

    const pediatricoHtml = r.mantenimientoPediatrico ? section('👶', 'Mantenimiento Pediátrico (Holliday-Segar)', '#8b5cf6', `
        <div>Añadir <strong>${r.mantenimientoPediatrico.mlDia} mL/día</strong> (≈${r.mantenimientoPediatrico.mlHora} mL/h) sobre el volumen de Parkland.</div>`) : '';

    return `${headerHTML}${fasesHtml}${pediatricoHtml}`;
}

function calculateParklandProtocol(event) {
    event.preventDefault();
    const units = Storage.getSettings().units;
    let weightKg = parseFloat(document.getElementById('parklandWeight').value);
    if (units.weight === 'lb') weightKg = weightKg / 2.20462;
    const horasRaw = document.getElementById('parklandHoras').value;

    const inputs = {
        weightKg,
        tbsa: parseFloat(document.getElementById('parklandTbsa').value),
        horasTranscurridas: horasRaw === '' ? null : parseFloat(horasRaw),
        pediatrico: document.getElementById('parklandPediatrico').checked
    };

    const r = Calculators.calculateParkland(inputs);
    const container = document.getElementById('parklandResult');
    container.innerHTML = buildParklandHTML(r) + `
        <button class="btn btn-secondary" onclick="document.getElementById('parklandForm').reset(); document.getElementById('parklandResult').style.display='none';" style="width:100%; margin-top:12px;">🔄 Nuevo Cálculo</button>`;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 55, calculatorName: 'Fórmula de Parkland', inputs, result: r, interpretation: r.interpretation });
}

// === 56. DELIRIO Y SEDACIÓN EN UCI — RASS + CAM-ICU === //
function createRassCamForm() {
    const opts = Calculators.RASS_LEVELS.map(l => `<option value="${l.level}" ${l.level === 0 ? 'selected' : ''}>${l.label}${l.description ? ' — ' + l.description : ''}</option>`).join('');
    return `
        <form id="rassCamForm" onsubmit="calculateRassCamProtocol(event)">
            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:8px; text-transform:uppercase; letter-spacing:0.05em;">Paso 1 — RASS</div>
                <select id="rassLevel" class="form-input" onchange="toggleCamIcuVisibility()">${opts}</select>
            </div>

            <div id="camIcuWrap" style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:6px; text-transform:uppercase; letter-spacing:0.05em;">Paso 2 — CAM-ICU</div>
                <label style="display:flex; align-items:flex-start; gap:10px; margin-bottom:10px; cursor:pointer;">
                    <input type="checkbox" id="camF1" style="width:18px; height:18px; margin-top:2px;">
                    <span style="font-size:13px;"><strong>Feature 1</strong> — Inicio agudo o curso fluctuante del estado mental</span>
                </label>
                <label style="display:flex; align-items:flex-start; gap:10px; margin-bottom:10px; cursor:pointer;">
                    <input type="checkbox" id="camF2" style="width:18px; height:18px; margin-top:2px;">
                    <span style="font-size:13px;"><strong>Feature 2</strong> — Inatención (test de atención alterado)</span>
                </label>
                <label style="display:flex; align-items:flex-start; gap:10px; margin-bottom:10px; cursor:pointer;">
                    <input type="checkbox" id="camF3" style="width:18px; height:18px; margin-top:2px;">
                    <span style="font-size:13px;"><strong>Feature 3</strong> — Nivel de conciencia alterado (RASS distinto de 0)</span>
                </label>
                <label style="display:flex; align-items:flex-start; gap:10px; margin-bottom:10px; cursor:pointer;">
                    <input type="checkbox" id="camF4" style="width:18px; height:18px; margin-top:2px;">
                    <span style="font-size:13px;"><strong>Feature 4</strong> — Pensamiento desorganizado</span>
                </label>
                <p style="font-size:11px; color:var(--text-tertiary); margin:0;">Positivo = Feature 1 Y Feature 2 Y (Feature 3 O Feature 4)</p>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">🧮 Evaluar</button>
        </form>
        <div id="rassCamResult" style="display:none; margin-top:24px;"></div>
    `;
}

function toggleCamIcuVisibility() {
    const rass = parseInt(document.getElementById('rassLevel').value);
    document.getElementById('camIcuWrap').style.display = rass >= -3 ? 'block' : 'none';
}

function calculateRassCamProtocol(event) {
    event.preventDefault();
    const rass = parseInt(document.getElementById('rassLevel').value);
    const evaluable = rass >= -3;
    const inputs = {
        rass,
        camIcu: evaluable ? {
            inicioAgudo: document.getElementById('camF1').checked,
            inatencion: document.getElementById('camF2').checked,
            nivelConciencia: document.getElementById('camF3').checked,
            pensamientoDesorganizado: document.getElementById('camF4').checked
        } : null
    };

    const r = Calculators.calculateDelirioSedacion(inputs);
    const colorMap = { success: '#22c55e', warning: '#f59e0b', danger: '#ef4444' };
    const container = document.getElementById('rassCamResult');
    container.innerHTML = `
        <div style="background:${colorMap[r.interpretation.color]}; padding:20px; border-radius:var(--radius-lg); color:white; margin-bottom:12px;">
            <div style="font-size:20px; font-weight:800;">${r.interpretation.label}</div>
            <div style="font-size:13px; opacity:0.9; margin-top:4px;">RASS ${r.rass} — ${r.rassLabel}</div>
        </div>
        <div style="background:var(--bg-secondary); padding:16px; border-radius:var(--radius-lg); font-size:13px; line-height:1.7; margin-bottom:12px;">${r.interpretation.description}</div>
        <button class="btn btn-secondary" onclick="document.getElementById('rassCamForm').reset(); document.getElementById('rassCamResult').style.display='none'; toggleCamIcuVisibility();" style="width:100%; margin-top:0;">🔄 Nueva Evaluación</button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 56, calculatorName: 'Delirio y Sedación en UCI (RASS/CAM-ICU)', inputs, result: r, interpretation: r.interpretation });
}

// === 57. ESCALAS DE ABSTINENCIA — CIWA-Ar / COWS === //
function createAbstinenciaForm() {
    const scale7 = (id, label) => `
        <div style="margin-bottom:12px;">
            <label style="display:block; font-size:13px; font-weight:600; margin-bottom:4px;">${label}</label>
            <select id="${id}" class="form-input">
                <option value="0">0 — Ausente</option>
                <option value="1">1 — Muy leve</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4 — Moderada</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7 — Extrema</option>
            </select>
        </div>`;
    const cowsSel = (id, label, opts) => `
        <div style="margin-bottom:12px;">
            <label style="display:block; font-size:13px; font-weight:600; margin-bottom:4px;">${label}</label>
            <select id="${id}" class="form-input">
                ${opts.map(o => `<option value="${o.v}">${o.v} — ${o.t}</option>`).join('')}
            </select>
        </div>`;

    return `
        <form id="abstForm" onsubmit="calculateAbstinenciaForm(event)">
            <div style="background:var(--bg-secondary); padding:14px; border-radius:12px; margin-bottom:16px; display:flex; gap:16px; flex-wrap:wrap;">
                <label style="display:flex; align-items:center; gap:8px; cursor:pointer; font-size:13px; font-weight:600;">
                    <input type="radio" name="abstTipo" value="alcohol" checked onchange="toggleAbstinenciaType()"> Alcohol (CIWA-Ar)
                </label>
                <label style="display:flex; align-items:center; gap:8px; cursor:pointer; font-size:13px; font-weight:600;">
                    <input type="radio" name="abstTipo" value="opioides" onchange="toggleAbstinenciaType()"> Opioides (COWS)
                </label>
            </div>

            <div id="ciwaWrap" style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                ${scale7('ciwaNausea', 'Náuseas / Vómitos')}
                ${scale7('ciwaTemblor', 'Temblor')}
                ${scale7('ciwaSudor', 'Sudoración paroxística')}
                ${scale7('ciwaAnsiedad', 'Ansiedad')}
                ${scale7('ciwaAgitacion', 'Agitación')}
                ${scale7('ciwaTactil', 'Alteraciones táctiles')}
                ${scale7('ciwaAuditivo', 'Alteraciones auditivas')}
                ${scale7('ciwaVisual', 'Alteraciones visuales')}
                ${scale7('ciwaCefalea', 'Cefalea / sensación de plenitud')}
                <div style="margin-bottom:4px;">
                    <label style="display:block; font-size:13px; font-weight:600; margin-bottom:4px;">Orientación / obnubilación</label>
                    <select id="ciwaOrientacion" class="form-input">
                        <option value="0">0 — Orientado, suma series correctamente</option>
                        <option value="1">1 — No suma series o duda de la fecha</option>
                        <option value="2">2 — Desorientado en fecha ≤2 días</option>
                        <option value="3">3 — Desorientado en fecha &gt;2 días</option>
                        <option value="4">4 — Desorientado en lugar y/o persona</option>
                    </select>
                </div>
            </div>

            <div id="cowsWrap" style="display:none; background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                ${cowsSel('cowsPulso', 'Pulso en reposo', [{v:0,t:'≤80 lpm'},{v:1,t:'81-100 lpm'},{v:2,t:'101-120 lpm'},{v:4,t:'&gt;120 lpm'}])}
                ${cowsSel('cowsSudor', 'Sudoración', [{v:0,t:'Ninguna'},{v:1,t:'Escalofríos/rubor subjetivo'},{v:2,t:'Rubor/humedad facial'},{v:3,t:'Gotas de sudor en frente'},{v:4,t:'Sudor profuso'}])}
                ${cowsSel('cowsInquietud', 'Inquietud', [{v:0,t:'Capaz de estar quieto'},{v:1,t:'Refiere dificultad'},{v:3,t:'Mueve piernas/brazos con inquietud'},{v:5,t:'Incapaz de estar quieto &gt;pocos min'}])}
                ${cowsSel('cowsPupilas', 'Tamaño pupilar', [{v:0,t:'Normal/pinpoint'},{v:1,t:'Posiblemente más grandes'},{v:2,t:'Moderadamente dilatadas'},{v:5,t:'Dilatadas, solo se ve el reborde'}])}
                ${cowsSel('cowsHuesos', 'Dolor óseo/articular', [{v:0,t:'Ninguno'},{v:1,t:'Leve difuso'},{v:2,t:'Paciente reporta severo'},{v:4,t:'Se frota articulaciones, no puede estar quieto'}])}
                ${cowsSel('cowsNariz', 'Rinorrea / lagrimeo', [{v:0,t:'Ausente'},{v:1,t:'Congestión/ojos húmedos'},{v:2,t:'Nariz que moquea/lagrimeo'},{v:4,t:'Constante'}])}
                ${cowsSel('cowsGi', 'Malestar gastrointestinal', [{v:0,t:'Ninguno'},{v:1,t:'Calambres'},{v:2,t:'Náusea / deposición suelta'},{v:3,t:'Vómito/diarrea'},{v:5,t:'Múltiples episodios'}])}
                ${cowsSel('cowsTemblor', 'Temblor', [{v:0,t:'Ausente'},{v:1,t:'Se palpa pero no se ve'},{v:2,t:'Leve, visible'},{v:4,t:'Grosero / espasmos musculares'}])}
                ${cowsSel('cowsBostezo', 'Bostezos', [{v:0,t:'Ninguno'},{v:1,t:'1-2 veces'},{v:2,t:'≥3 veces'},{v:4,t:'Varias veces por minuto'}])}
                ${cowsSel('cowsAnsiedad', 'Ansiedad/irritabilidad', [{v:0,t:'Ninguna'},{v:1,t:'Creciente'},{v:2,t:'Obviamente irritable/ansioso'},{v:4,t:'Dificulta la evaluación'}])}
                ${cowsSel('cowsPiel', 'Piel de gallina', [{v:0,t:'Piel lisa'},{v:3,t:'Piloerección palpable'},{v:5,t:'Piloerección prominente'}])}
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">🧮 Calcular Score</button>
        </form>
        <div id="abstResult" style="display:none; margin-top:24px;"></div>
    `;
}

function toggleAbstinenciaType() {
    const tipo = document.querySelector('input[name="abstTipo"]:checked').value;
    document.getElementById('ciwaWrap').style.display = tipo === 'alcohol' ? 'block' : 'none';
    document.getElementById('cowsWrap').style.display = tipo === 'opioides' ? 'block' : 'none';
}

function calculateAbstinenciaForm(event) {
    event.preventDefault();
    const tipo = document.querySelector('input[name="abstTipo"]:checked').value;
    let items;
    if (tipo === 'alcohol') {
        items = ['ciwaNausea', 'ciwaTemblor', 'ciwaSudor', 'ciwaAnsiedad', 'ciwaAgitacion', 'ciwaTactil', 'ciwaAuditivo', 'ciwaVisual', 'ciwaCefalea', 'ciwaOrientacion']
            .map(id => parseInt(document.getElementById(id).value));
    } else {
        items = ['cowsPulso', 'cowsSudor', 'cowsInquietud', 'cowsPupilas', 'cowsHuesos', 'cowsNariz', 'cowsGi', 'cowsTemblor', 'cowsBostezo', 'cowsAnsiedad', 'cowsPiel']
            .map(id => parseInt(document.getElementById(id).value));
    }
    const inputs = { tipo, items };
    const result = Calculators.calculateAbstinencia(inputs);
    const colorMap = { success: 'var(--success)', warning: 'var(--warning)', danger: 'var(--danger)' };
    const container = document.getElementById('abstResult');
    container.innerHTML = `
        <div style="background:linear-gradient(135deg,var(--brand-accent-dark),var(--brand-accent)); padding:24px; border-radius:var(--radius-lg); color:var(--brand-primary-dark); margin-bottom:16px;">
            <div style="font-size:13px; font-weight:600; margin-bottom:8px; opacity:0.8;">${result.escala}</div>
            <div style="font-size:36px; font-weight:800; margin-bottom:4px;">${result.value} <span style="font-size:20px; font-weight:500;">${result.unit}</span></div>
            <div style="font-size:14px; font-weight:600;">${result.interpretation.label}</div>
        </div>
        <div style="background:var(--bg-secondary); padding:20px; border-radius:var(--radius-lg); border-left:4px solid ${colorMap[result.interpretation.color]}; margin-bottom:16px;">
            <p style="font-size:13px; color:var(--text-secondary); line-height:1.6;">${result.interpretation.description}</p>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('abstForm').reset(); document.getElementById('abstResult').style.display='none'; toggleAbstinenciaType();" style="width:100%; margin-top:0;">🔄 Nuevo Cálculo</button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 57, calculatorName: 'Escalas de Abstinencia (CIWA-Ar/COWS)', inputs, result, interpretation: result.interpretation });
}

// === 58. HEMORRAGIA DIGESTIVA ALTA — GLASGOW-BLATCHFORD / ROCKALL === //
function createHDAForm() {
    const units = Storage.getSettings().units;
    const bunUnit = units.bun || 'mg/dL';
    return `
        <form id="hdaForm" onsubmit="calculateHDAProtocol(event)">
            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:10px; text-transform:uppercase; letter-spacing:0.05em;">Glasgow-Blatchford (al ingreso)</div>
                <div class="form-group" style="margin-bottom:12px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Urea/BUN (${bunUnit})</label>
                    <input type="number" id="hdaUrea" step="any" min="0" class="form-input" required>
                </div>
                <div class="form-group" style="margin-bottom:12px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Hemoglobina (g/dL)</label>
                    <input type="number" id="hdaHb" step="any" min="1" max="25" class="form-input" required>
                </div>
                <div class="form-group" style="margin-bottom:12px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Sexo</label>
                    <select id="hdaSexo" class="form-input">
                        <option value="M">Masculino</option>
                        <option value="F">Femenino</option>
                    </select>
                </div>
                <div class="form-group" style="margin-bottom:12px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">PAS (mmHg)</label>
                    <input type="number" id="hdaSbp" step="any" min="40" max="250" class="form-input" required>
                </div>
                <label style="display:flex; align-items:center; gap:10px; margin-bottom:8px; cursor:pointer;"><input type="checkbox" id="hdaPulso100" style="width:18px; height:18px;"><span style="font-size:13px;">Pulso ≥ 100 lpm</span></label>
                <label style="display:flex; align-items:center; gap:10px; margin-bottom:8px; cursor:pointer;"><input type="checkbox" id="hdaMelena" style="width:18px; height:18px;"><span style="font-size:13px;">Melena presente</span></label>
                <label style="display:flex; align-items:center; gap:10px; margin-bottom:8px; cursor:pointer;"><input type="checkbox" id="hdaSincope" style="width:18px; height:18px;"><span style="font-size:13px;">Síncope</span></label>
                <label style="display:flex; align-items:center; gap:10px; margin-bottom:8px; cursor:pointer;"><input type="checkbox" id="hdaHepatopatia" style="width:18px; height:18px;"><span style="font-size:13px;">Hepatopatía conocida</span></label>
                <label style="display:flex; align-items:center; gap:10px; cursor:pointer;"><input type="checkbox" id="hdaIcc" style="width:18px; height:18px;"><span style="font-size:13px;">Insuficiencia cardíaca</span></label>
            </div>

            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:10px; text-transform:uppercase; letter-spacing:0.05em;">Rockall (pre-endoscopia)</div>
                <div class="form-group" style="margin-bottom:12px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Edad</label>
                    <input type="number" id="hdaEdad" step="1" min="0" max="120" class="form-input" required>
                </div>
                <div class="form-group" style="margin-bottom:12px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Shock</label>
                    <select id="hdaShock" class="form-input">
                        <option value="ninguno">Sin shock (PAS≥100, FC&lt;100)</option>
                        <option value="taquicardia">Taquicardia (PAS≥100, FC≥100)</option>
                        <option value="hipotension">Hipotensión (PAS&lt;100)</option>
                    </select>
                </div>
                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Comorbilidad</label>
                    <select id="hdaComorbilidad" class="form-input">
                        <option value="ninguna">Ninguna mayor</option>
                        <option value="icIhdMayor">ICC / cardiopatía isquémica / comorbilidad mayor</option>
                        <option value="renalHepaticaMalignidad">Insuficiencia renal/hepática o malignidad diseminada</option>
                    </select>
                </div>
                <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                    <input type="checkbox" id="hdaEndoDisponible" style="width:18px; height:18px;" onchange="toggleHDAEndoscopia()">
                    <span style="font-size:13px;">Resultado de endoscopia disponible (completar Rockall)</span>
                </label>
                <div id="hdaEndoWrap" style="display:none; margin-top:12px;">
                    <div class="form-group" style="margin-bottom:12px;">
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Diagnóstico endoscópico</label>
                        <select id="hdaDiagnostico" class="form-input">
                            <option value="ninguno">Mallory-Weiss / sin lesión / sin estigmas</option>
                            <option value="otro">Otro diagnóstico</option>
                            <option value="malignidad">Malignidad del tracto GI superior</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Estigmas de sangrado reciente</label>
                        <select id="hdaEstigmas" class="form-input">
                            <option value="ninguno">Ninguno / mancha oscura</option>
                            <option value="sangradoActivoVasoVisible">Sangre visible, coágulo adherente, vaso visible/sangrado activo</option>
                        </select>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">🧮 Calcular Ambos Scores</button>
        </form>
        <div id="hdaResult" style="display:none; margin-top:24px;"></div>
    `;
}

function toggleHDAEndoscopia() {
    document.getElementById('hdaEndoWrap').style.display = document.getElementById('hdaEndoDisponible').checked ? 'block' : 'none';
}

function buildHDAHTML(r) {
    const section = (icon, title, color, content) => `
        <div style="margin-bottom:12px; border-radius:var(--radius-lg); overflow:hidden; border:1px solid ${color}33;">
            <div style="background:${color}22; padding:12px 16px; display:flex; align-items:center; gap:8px; border-bottom:1px solid ${color}33;">
                <span style="font-size:18px;">${icon}</span>
                <span style="font-size:14px; font-weight:700; color:${color};">${title}</span>
            </div>
            <div style="padding:14px 16px; background:var(--bg-card); font-size:13px; line-height:1.8;">${content}</div>
        </div>`;

    const gbsColor = r.gbsMuyBajoRiesgo ? '#22c55e' : (r.gbs <= 3 ? '#f59e0b' : '#ef4444');
    const headerHTML = `
        <div style="background:${gbsColor}; padding:20px; border-radius:var(--radius-lg); color:white; margin-bottom:12px;">
            <div style="font-size:20px; font-weight:800;">🩸 ${r.interpretation.label}</div>
        </div>`;

    const gbsHtml = section('📋', 'Glasgow-Blatchford', gbsColor, `<div>${r.interpretation.description}</div>`);

    const rockallColor = { bajo: '#22c55e', intermedio: '#f59e0b', alto: '#ef4444' }[r.rockallBanda];
    const rockallHtml = section('🔬', `Rockall ${r.rockallCompleto ? '(completo)' : '(pre-endoscopia)'}`, rockallColor, `
        <div><strong>Score:</strong> ${r.rockallTotal} pts — riesgo ${r.rockallBanda}</div>
        ${!r.rockallCompleto ? `<div style="margin-top:6px; color:var(--text-secondary); font-size:12px;">Score pre-endoscopia (máx. 7). Completar hallazgos endoscópicos para el score total (máx. 11).</div>` : ''}
        <div style="margin-top:6px;">Bandas: 0-2 bajo riesgo · 3-4 intermedio · ≥5 alto riesgo de mortalidad/resangrado.</div>`);

    return `${headerHTML}${gbsHtml}${rockallHtml}`;
}

function calculateHDAProtocol(event) {
    event.preventDefault();
    const units = Storage.getSettings().units;
    let ureaVal = parseFloat(document.getElementById('hdaUrea').value);
    const ureaMmol = (units.bun === 'mmol/L') ? ureaVal : ureaVal * 0.357;

    const endoDisponible = document.getElementById('hdaEndoDisponible').checked;

    const inputs = {
        blatchford: {
            ureaMmol,
            hb: parseFloat(document.getElementById('hdaHb').value),
            sexo: document.getElementById('hdaSexo').value,
            sbp: parseFloat(document.getElementById('hdaSbp').value),
            pulso100: document.getElementById('hdaPulso100').checked,
            melena: document.getElementById('hdaMelena').checked,
            sincope: document.getElementById('hdaSincope').checked,
            hepatopatia: document.getElementById('hdaHepatopatia').checked,
            icc: document.getElementById('hdaIcc').checked
        },
        rockall: {
            edad: parseFloat(document.getElementById('hdaEdad').value),
            shock: document.getElementById('hdaShock').value,
            comorbilidad: document.getElementById('hdaComorbilidad').value,
            diagnostico: endoDisponible ? document.getElementById('hdaDiagnostico').value : null,
            estigmas: endoDisponible ? document.getElementById('hdaEstigmas').value : null
        }
    };

    const r = Calculators.calculateHDA(inputs);
    const container = document.getElementById('hdaResult');
    container.innerHTML = buildHDAHTML(r) + `
        <button class="btn btn-secondary" onclick="document.getElementById('hdaForm').reset(); document.getElementById('hdaResult').style.display='none'; toggleHDAEndoscopia();" style="width:100%; margin-top:12px;">🔄 Nuevo Cálculo</button>`;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 58, calculatorName: 'Hemorragia Digestiva Alta (Blatchford/Rockall)', inputs, result: r, interpretation: r.interpretation });
}

// === 59. PANCREATITIS AGUDA — RANSON / BISAP === //
function createPancreatitisForm() {
    const check = (id, text) => `
        <label style="display:flex; align-items:flex-start; gap:10px; margin-bottom:10px; cursor:pointer;">
            <input type="checkbox" id="${id}" style="width:18px; height:18px; margin-top:2px;">
            <span style="font-size:13px;">${text}</span>
        </label>`;
    return `
        <form id="pancForm" onsubmit="calculatePancreatitisForm(event)">
            <div style="background:var(--bg-secondary); padding:14px; border-radius:12px; margin-bottom:16px; display:flex; gap:16px; flex-wrap:wrap;">
                <label style="display:flex; align-items:center; gap:8px; cursor:pointer; font-size:13px; font-weight:600;">
                    <input type="radio" name="pancEscala" value="ranson" checked onchange="togglePancreatitisScale()"> Ranson
                </label>
                <label style="display:flex; align-items:center; gap:8px; cursor:pointer; font-size:13px; font-weight:600;">
                    <input type="radio" name="pancEscala" value="bisap" onchange="togglePancreatitisScale()"> BISAP
                </label>
            </div>

            <div id="ransonWrap" style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:8px; text-transform:uppercase; letter-spacing:0.05em;">Al Ingreso</div>
                ${check('ransonEdad55', 'Edad &gt; 55 años')}
                ${check('ransonLeuco', 'Leucocitos &gt; 16.000/mm³')}
                ${check('ransonGlucosa', 'Glucemia &gt; 200 mg/dL')}
                ${check('ransonLdh', 'LDH &gt; 350 UI/L')}
                ${check('ransonAst', 'AST &gt; 250 UI/L')}
                <label style="display:flex; align-items:center; gap:10px; margin:14px 0 10px; cursor:pointer;">
                    <input type="checkbox" id="ranson48Disponible" style="width:18px; height:18px;" onchange="togglePancreatitis48h()">
                    <span style="font-size:13px; font-weight:600;">Datos de 48h disponibles</span>
                </label>
                <div id="ranson48Wrap" style="display:none;">
                    <div style="font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:8px; text-transform:uppercase; letter-spacing:0.05em;">A las 48h</div>
                    ${check('ransonHto', 'Caída de Hematocrito &gt; 10%')}
                    ${check('ransonBun', 'Aumento de BUN &gt; 5 mg/dL')}
                    ${check('ransonCa', 'Calcio &lt; 8 mg/dL')}
                    ${check('ransonPao2', 'PaO₂ &lt; 60 mmHg')}
                    ${check('ransonDeficit', 'Déficit de base &gt; 4 mEq/L')}
                    ${check('ransonSecuestro', 'Secuestro de líquidos &gt; 6L')}
                </div>
            </div>

            <div id="bisapWrap" style="display:none; background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                ${check('bisapBun', 'BUN &gt; 25 mg/dL')}
                ${check('bisapGcs', 'Estado mental alterado (Glasgow &lt; 15)')}
                ${check('bisapSirs', 'SIRS ≥ 2 criterios')}
                ${check('bisapEdad', 'Edad &gt; 60 años')}
                ${check('bisapDerrame', 'Derrame pleural')}
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">🧮 Calcular Score</button>
        </form>
        <div id="pancResult" style="display:none; margin-top:24px;"></div>
    `;
}

function togglePancreatitisScale() {
    const escala = document.querySelector('input[name="pancEscala"]:checked').value;
    document.getElementById('ransonWrap').style.display = escala === 'ranson' ? 'block' : 'none';
    document.getElementById('bisapWrap').style.display = escala === 'bisap' ? 'block' : 'none';
}

function togglePancreatitis48h() {
    document.getElementById('ranson48Wrap').style.display = document.getElementById('ranson48Disponible').checked ? 'block' : 'none';
}

function calculatePancreatitisForm(event) {
    event.preventDefault();
    const escala = document.querySelector('input[name="pancEscala"]:checked').value;
    let inputs;
    if (escala === 'bisap') {
        inputs = {
            escala, bisap: {
                bun25: document.getElementById('bisapBun').checked,
                gcsAlterado: document.getElementById('bisapGcs').checked,
                sirs2: document.getElementById('bisapSirs').checked,
                edad60: document.getElementById('bisapEdad').checked,
                derramePleural: document.getElementById('bisapDerrame').checked
            }
        };
    } else {
        const h48Disponible = document.getElementById('ranson48Disponible').checked;
        inputs = {
            escala, ranson: {
                ingreso: {
                    edad55: document.getElementById('ransonEdad55').checked,
                    leucocitos16000: document.getElementById('ransonLeuco').checked,
                    glucosa200: document.getElementById('ransonGlucosa').checked,
                    ldh350: document.getElementById('ransonLdh').checked,
                    ast250: document.getElementById('ransonAst').checked
                },
                h48: h48Disponible ? {
                    caidaHto10: document.getElementById('ransonHto').checked,
                    aumentoBun5: document.getElementById('ransonBun').checked,
                    calcio8: document.getElementById('ransonCa').checked,
                    pao260: document.getElementById('ransonPao2').checked,
                    deficitBase4: document.getElementById('ransonDeficit').checked,
                    secuestroLiquidos6L: document.getElementById('ransonSecuestro').checked
                } : null
            }
        };
    }

    const result = Calculators.calculatePancreatitis(inputs);
    const colorMap = { success: 'var(--success)', warning: 'var(--warning)', danger: 'var(--danger)' };
    const container = document.getElementById('pancResult');
    container.innerHTML = `
        <div style="background:linear-gradient(135deg,var(--brand-accent-dark),var(--brand-accent)); padding:24px; border-radius:var(--radius-lg); color:var(--brand-primary-dark); margin-bottom:16px;">
            <div style="font-size:13px; font-weight:600; margin-bottom:8px; opacity:0.8;">${result.escala}</div>
            <div style="font-size:36px; font-weight:800; margin-bottom:4px;">${result.value} <span style="font-size:20px; font-weight:500;">${result.unit}</span></div>
            <div style="font-size:14px; font-weight:600;">${result.interpretation.label}</div>
        </div>
        <div style="background:var(--bg-secondary); padding:20px; border-radius:var(--radius-lg); border-left:4px solid ${colorMap[result.interpretation.color]}; margin-bottom:16px;">
            <p style="font-size:13px; color:var(--text-secondary); line-height:1.6;">${result.interpretation.description}</p>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('pancForm').reset(); document.getElementById('pancResult').style.display='none'; togglePancreatitisScale(); togglePancreatitis48h();" style="width:100%; margin-top:0;">🔄 Nuevo Cálculo</button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 59, calculatorName: 'Pancreatitis Aguda (Ranson/BISAP)', inputs, result, interpretation: result.interpretation });
}

// === 60. INTOXICACIÓN POR PARACETAMOL — NOMOGRAMA + NAC === //
function createParacetamolForm() {
    const units = Storage.getSettings().units;
    const wUnit = units.weight || 'kg';
    return `
        <form id="paracetForm" onsubmit="calculateParacetamolForm(event)">
            <div style="background:var(--bg-secondary); padding:16px; border-radius:12px; margin-bottom:16px;">
                <label style="display:flex; align-items:center; gap:10px; margin-bottom:14px; cursor:pointer;">
                    <input type="checkbox" id="paracetAguda" checked style="width:18px; height:18px;">
                    <span style="font-size:13px;">Ingesta única aguda con tiempo conocido (desmarcar si es crónica/escalonada o tiempo desconocido)</span>
                </label>
                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Horas desde la ingesta</label>
                    <input type="number" id="paracetHoras" step="any" min="0" max="48" class="form-input">
                </div>
                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Nivel sérico de paracetamol (µg/mL)</label>
                    <input type="number" id="paracetNivel" step="any" min="0" class="form-input" required>
                </div>
                <div class="form-group">
                    <label style="display:block; margin-bottom:6px; font-weight:600; font-size:14px;">Peso (${wUnit})</label>
                    <input type="number" id="paracetWeight" step="any" min="1" max="300" class="form-input" required>
                </div>
            </div>
            <div style="background:#fef3c7; border-left:4px solid #f59e0b; padding:14px; border-radius:8px; margin-bottom:16px;">
                <p style="font-size:12px; color:#92400e; margin:0;"><strong>⚠️</strong> El nomograma de Rumack-Matthew solo es válido entre las 4-24h de una ingesta única aguda con tiempo conocido.</p>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%; padding:14px;">🧮 Evaluar</button>
        </form>
        <div id="paracetResult" style="display:none; margin-top:24px;"></div>
    `;
}

function buildParacetamolHTML(r) {
    const section = (icon, title, color, content) => `
        <div style="margin-bottom:12px; border-radius:var(--radius-lg); overflow:hidden; border:1px solid ${color}33;">
            <div style="background:${color}22; padding:12px 16px; display:flex; align-items:center; gap:8px; border-bottom:1px solid ${color}33;">
                <span style="font-size:18px;">${icon}</span>
                <span style="font-size:14px; font-weight:700; color:${color};">${title}</span>
            </div>
            <div style="padding:14px 16px; background:var(--bg-card); font-size:13px; line-height:1.8;">${content}</div>
        </div>`;

    const color = r.interpretation.color === 'danger' ? '#ef4444' : (r.interpretation.color === 'warning' ? '#f59e0b' : '#22c55e');
    const headerHTML = `
        <div style="background:${color}; padding:20px; border-radius:var(--radius-lg); color:white; margin-bottom:12px;">
            <div style="font-size:20px; font-weight:800;">💊 ${r.interpretation.label}</div>
        </div>`;

    const detailHtml = section('📋', 'Detalle', color, `<div>${r.interpretation.description}</div>`);

    const nacHtml = r.naDosis ? section('💉', 'Dosis de N-Acetilcisteína (IV, 3 bolsas)', '#3b82f6', `
        <div><strong>Carga:</strong> ${r.naDosis.carga}</div>
        <div style="margin-top:4px;"><strong>Mantenimiento 1:</strong> ${r.naDosis.mantenimiento1}</div>
        <div style="margin-top:4px;"><strong>Mantenimiento 2:</strong> ${r.naDosis.mantenimiento2}</div>`) : '';

    return `${headerHTML}${detailHtml}${nacHtml}`;
}

function calculateParacetamolForm(event) {
    event.preventDefault();
    const units = Storage.getSettings().units;
    let weightKg = parseFloat(document.getElementById('paracetWeight').value);
    if (units.weight === 'lb') weightKg = weightKg / 2.20462;
    const horasRaw = document.getElementById('paracetHoras').value;

    const inputs = {
        ingestaAguda: document.getElementById('paracetAguda').checked,
        horas: horasRaw === '' ? null : parseFloat(horasRaw),
        nivel: parseFloat(document.getElementById('paracetNivel').value),
        weightKg
    };

    const r = Calculators.calculateParacetamol(inputs);
    const container = document.getElementById('paracetResult');
    container.innerHTML = buildParacetamolHTML(r) + `
        <button class="btn btn-secondary" onclick="document.getElementById('paracetForm').reset(); document.getElementById('paracetResult').style.display='none';" style="width:100%; margin-top:12px;">🔄 Nuevo Cálculo</button>`;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 60, calculatorName: 'Intoxicación por Paracetamol', inputs, result: r, interpretation: r.interpretation });
}

// === FUNCIÓN GENÉRICA PARA MOSTRAR RESULTADOS === //
function displayGenericResult(result, inputs, calcId, calcName, formula, containerId) {
    const container = document.getElementById(containerId);
    container.innerHTML = `
        <div class="result-card" style="background: linear-gradient(135deg, var(--brand-accent-dark), var(--brand-accent)); padding: 24px; border-radius: var(--radius-lg); color: var(--brand-primary-dark); margin-bottom: 16px;">
            <div style="font-size: 13px; font-weight: 600; margin-bottom: 8px; opacity: 0.8;">RESULTADO</div>
            <div style="font-size: 36px; font-weight: 800; margin-bottom: 4px;">
                ${result.value} <span style="font-size: 20px; font-weight: 600;">${result.unit}</span>
            </div>
            <div style="font-size: 14px; font-weight: 600;">
                ${result.interpretation.stage || ''}${result.interpretation.stage ? ': ' : ''}${result.interpretation.label}
            </div>
            ${formula ? `<div style="font-size: 12px; margin-top: 8px; opacity: 0.8;">Fórmula: ${formula}</div>` : ''}
        </div>
        <div class="interpretation-card" style="background: var(--bg-secondary); padding: 20px; border-radius: var(--radius-lg); border-left: 4px solid var(--${result.interpretation.color});">
            <h4 style="font-size: 14px; font-weight: 700; margin-bottom: 8px;">Interpretación</h4>
            <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.6;">
                ${result.interpretation.description}
            </p>
        </div>
        <button class="btn btn-secondary" onclick="resetCalculator('${containerId}')" style="width: 100%; margin-top: 16px;">
            🔄 Nuevo Cálculo
        </button>
    `;
    container.style.display = 'block';
}

function resetCalculator(containerId) {
    const formId = containerId.replace('Result', 'Form');
    const form = document.getElementById(formId);
    if (form) {
        form.reset();
        document.getElementById(containerId).style.display = 'none';
    }
}

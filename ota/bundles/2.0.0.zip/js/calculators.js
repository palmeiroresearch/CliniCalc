// ============================================
// CLINICALC - FÓRMULAS DE CALCULADORAS
// Implementación matemática de las 15 calculadoras
// ============================================

const Calculators = {
    
    // === CONVERSIÓN DE UNIDADES === //
    convertUnit(value, fromUnit, toUnit, type) {
        if (fromUnit === toUnit) return value;
        
        const conversions = UNIT_CONVERSIONS[type];
        if (!conversions || !conversions[fromUnit] || !conversions[toUnit]) {
            return value;
        }
        
        // Convertir a unidad base, luego a unidad destino
        const toBase = value / conversions[fromUnit].factor;
        const toTarget = toBase * conversions[toUnit].factor;
        
        return toTarget;
    },

    // === 1. GFR - FILTRADO GLOMERULAR === //
    calculateGFR(inputs, formula = 'CKD-EPI 2021') {
        let { age, sex, creatinine, race, weight, height } = inputs;
        const currentUnit = Storage.getSetting('units.creatinine');
        
        // Convertir creatinina a mg/dL si está en µmol/L
        if (currentUnit === 'µmol/L') {
            creatinine = creatinine / 88.42;
        }
        
        let gfr = 0;
        
        switch(formula) {
            case 'CKD-EPI 2021':
                // Nueva fórmula sin raza (KDIGO 2024)
                const kappa = sex === 'F' ? 0.7 : 0.9;
                const alpha = sex === 'F' ? -0.241 : -0.302;
                const minRatio = Math.min(creatinine / kappa, 1);
                const maxRatio = Math.max(creatinine / kappa, 1);
                const sexFactor = sex === 'F' ? 1.012 : 1;
                
                gfr = 142 * Math.pow(minRatio, alpha) * Math.pow(maxRatio, -1.200) * 
                      Math.pow(0.9938, age) * sexFactor;
                break;
                
            case 'CKD-EPI 2009':
                // Fórmula antigua con raza
                const kappa09 = sex === 'F' ? 0.7 : 0.9;
                const alpha09 = sex === 'F' ? -0.329 : -0.411;
                const minRatio09 = Math.min(creatinine / kappa09, 1);
                const maxRatio09 = Math.max(creatinine / kappa09, 1);
                const sexFactor09 = sex === 'F' ? 1.018 : 1;
                const raceFactor = race === 'black' ? 1.159 : 1;
                
                gfr = 141 * Math.pow(minRatio09, alpha09) * Math.pow(maxRatio09, -1.209) * 
                      Math.pow(0.993, age) * sexFactor09 * raceFactor;
                break;
                
            case 'Cockroft-Gault':
                // Requiere peso
                const sexMultiplier = sex === 'F' ? 0.85 : 1;
                gfr = ((140 - age) * weight * sexMultiplier) / (72 * creatinine);
                break;
                
            case 'MDRD':
                // MDRD simplificada
                const sexFactorMDRD = sex === 'F' ? 0.742 : 1;
                const raceFactorMDRD = race === 'black' ? 1.212 : 1;
                gfr = 175 * Math.pow(creatinine, -1.154) * Math.pow(age, -0.203) * 
                      sexFactorMDRD * raceFactorMDRD;
                break;
        }
        
        return {
            value: Math.round(gfr * 10) / 10,
            unit: formula === 'Cockroft-Gault' ? 'mL/min' : 'mL/min/1.73m²',
            interpretation: this.interpretGFR(gfr)
        };
    },

    interpretGFR(gfr) {
        const range = INTERPRETATIONS.gfr.find(r => gfr >= r.min && gfr <= r.max);
        return range || INTERPRETATIONS.gfr[INTERPRETATIONS.gfr.length - 1];
    },

    // === 2. CLEARANCE CREATININA 24H === //
    calculateClearance24h(inputs) {
        const { creatinineUrine, creatinineSerum, urineVolume } = inputs;
        const currentUnit = Storage.getSetting('units.creatinine');
        
        // Convertir a mg/dL si es necesario
        let crUrine = creatinineUrine;
        let crSerum = creatinineSerum;
        
        if (currentUnit === 'µmol/L') {
            crUrine = crUrine / 88.42;
            crSerum = crSerum / 88.42;
        }
        
        // Fórmula: (Cr orina × Vol orina) / (Cr plasma × 1440)
        const clearance = (crUrine * urineVolume) / (crSerum * 1440);
        
        return {
            value: Math.round(clearance * 10) / 10,
            unit: 'mL/min',
            interpretation: clearance >= 80 ? 
                { label: 'Normal', color: 'success', description: 'Función renal normal' } :
                { label: 'Disminuido', color: 'warning', description: 'Función renal disminuida' }
        };
    },

    // === 3. ANION GAP === //
    calculateAnionGap(inputs) {
        const { sodium, chloride, bicarbonate, albumin } = inputs;

        const ag = sodium - (chloride + bicarbonate);
        const hasAlbumin = albumin !== null && !isNaN(albumin);
        const agCorrected = hasAlbumin ? ag + 2.5 * (4 - albumin) : null;

        return {
            value:          Math.round(ag * 10) / 10,
            correctedValue: hasAlbumin ? Math.round(agCorrected * 10) / 10 : null,
            unit: 'mEq/L',
            interpretation: this.interpretAnionGap(hasAlbumin ? agCorrected : ag)
        };
    },

    interpretAnionGap(ag) {
        const range = INTERPRETATIONS.anionGap.find(r => ag >= r.min && ag <= r.max);
        return range || INTERPRETATIONS.anionGap[1];
    },

    // === 4. CALCIO CORREGIDO === //
    calculateCorrectedCalcium(inputs) {
        const { calcium, albumin } = inputs;
        
        // Fórmula de Payne: Ca corregido = Ca medido + 0.8 × (4 - albúmina)
        const correctedCa = calcium + 0.8 * (4 - albumin);
        
        let interpretation;
        if (correctedCa < 8.5) {
            interpretation = { label: 'Hipocalcemia', color: 'danger', description: 'Calcio bajo' };
        } else if (correctedCa > 10.5) {
            interpretation = { label: 'Hipercalcemia', color: 'danger', description: 'Calcio elevado' };
        } else {
            interpretation = { label: 'Normal', color: 'success', description: '8.5-10.5 mg/dL' };
        }
        
        return {
            value: Math.round(correctedCa * 100) / 100,
            unit: 'mg/dL',
            interpretation
        };
    },

    // === 5. SODIO CORREGIDO === //
    calculateCorrectedSodium(inputs) {
        const { sodium, glucose } = inputs;
        const currentUnit = Storage.getSetting('units.glucose');
        
        // Convertir glucosa a mg/dL si está en mmol/L
        let glucoseMgDl = glucose;
        if (currentUnit === 'mmol/L') {
            glucoseMgDl = glucose / 0.0555;
        }
        
        // Fórmula de Katz (1973): Na corregido = Na medido + 0.016 × (Glucosa - 100)
        // Fórmula de Hillier (1999): Na corregido = Na medido + 0.024 × (Glucosa - 100)
        
        const correctedNaKatz = sodium + 0.016 * (glucoseMgDl - 100);
        const correctedNaHillier = sodium + 0.024 * (glucoseMgDl - 100);
        
        return {
            value: Math.round(correctedNaKatz * 10) / 10,
            hillier: Math.round(correctedNaHillier * 10) / 10,
            unit: 'mEq/L',
            interpretation: correctedNaKatz < 135 ? 
                { label: 'Hiponatremia verdadera', color: 'danger', description: 'Sodio bajo' } :
                { label: 'Normal', color: 'success', description: '135-145 mEq/L' }
        };
    },

    // === 6. IMC === //
    calculateBMI(inputs) {
        let { weight, height } = inputs;
        const weightUnit = Storage.getSetting('units.weight');
        const heightUnit = Storage.getSetting('units.height');
        
        // Convertir peso a kg
        if (weightUnit === 'lb') {
            weight = weight / 2.20462;
        }
        
        // Convertir altura a metros
        if (heightUnit === 'cm') {
            height = height / 100;
        } else if (heightUnit === 'in') {
            height = height * 0.0254;
        } else if (heightUnit === 'ft') {
            height = height * 0.3048;
        }
        
        const bmi = weight / (height * height);
        
        return {
            value: Math.round(bmi * 10) / 10,
            unit: 'kg/m²',
            interpretation: this.interpretBMI(bmi)
        };
    },

    interpretBMI(bmi) {
        const range = INTERPRETATIONS.imc.find(r => bmi >= r.min && bmi < r.max);
        return range || INTERPRETATIONS.imc[INTERPRETATIONS.imc.length - 1];
    },

    // === 7. BSA (SUPERFICIE CORPORAL) === //
    calculateBSA(inputs, formula = 'Mosteller') {
        let { weight, height } = inputs;
        const weightUnit = Storage.getSetting('units.weight');
        const heightUnit = Storage.getSetting('units.height');
        
        // Convertir a unidades base
        if (weightUnit === 'lb') weight = weight / 2.20462;
        if (heightUnit === 'm') height = height * 100;
        if (heightUnit === 'in') height = height * 2.54;
        if (heightUnit === 'ft') height = height * 30.48;
        
        let bsa = 0;
        
        if (formula === 'Mosteller') {
            // Más simple y común
            bsa = Math.sqrt((height * weight) / 3600);
        } else if (formula === 'DuBois') {
            // Fórmula clásica
            bsa = 0.007184 * Math.pow(height, 0.725) * Math.pow(weight, 0.425);
        }
        
        return {
            value: Math.round(bsa * 100) / 100,
            unit: 'm²',
            interpretation: { 
                label: 'Calculado', 
                color: 'success', 
                description: 'Superficie corporal para ajuste de dosis' 
            }
        };
    },

    // === 8. OSMOLARIDAD SÉRICA === //
    calculateOsmolarity(inputs) {
        let { sodium, glucose, bun, measuredOsm } = inputs;
        const glucoseUnit = Storage.getSetting('units.glucose');
        const bunUnit = Storage.getSetting('units.bun');
        
        // Convertir glucosa a mg/dL
        if (glucoseUnit === 'mmol/L') {
            glucose = glucose / 0.0555;
        }
        
        // Convertir BUN a mg/dL
        if (bunUnit === 'mmol/L') {
            bun = bun / 0.357;
        }
        
        // Fórmula: 2 × Na + Glucosa/18 + BUN/2.8
        const calculatedOsm = 2 * sodium + glucose / 18 + bun / 2.8;
        
        // Gap osmolar (si hay medida)
        const osmGap = measuredOsm ? measuredOsm - calculatedOsm : null;
        
        return {
            value: Math.round(calculatedOsm * 10) / 10,
            unit: 'mOsm/kg',
            osmGap: osmGap ? Math.round(osmGap * 10) / 10 : null,
            interpretation: calculatedOsm >= 280 && calculatedOsm <= 295 ?
                { label: 'Normal', color: 'success', description: '280-295 mOsm/kg' } :
                { label: 'Anormal', color: 'warning', description: 'Fuera del rango normal' }
        };
    },

    // === 9. CHADS₂-VASc === //
    calculateCHADSVASc(inputs) {
        let score = 0;
        
        // CHF (1 punto)
        if (inputs.chf) score += 1;
        
        // Hypertension (1 punto)
        if (inputs.hypertension) score += 1;
        
        // Age ≥75 (2 puntos)
        if (inputs.age >= 75) {
            score += 2;
        } else if (inputs.age >= 65) {
            // Age 65-74 (1 punto)
            score += 1;
        }
        
        // Diabetes (1 punto)
        if (inputs.diabetes) score += 1;
        
        // Stroke/TIA/TE (2 puntos)
        if (inputs.stroke) score += 2;
        
        // Vascular disease (1 punto)
        if (inputs.vascularDisease) score += 1;
        
        // Sex category (Female = 1 punto)
        if (inputs.sex === 'F') score += 1;
        
        return {
            value: score,
            unit: 'puntos',
            interpretation: this.interpretCHADSVASc(score)
        };
    },

    interpretCHADSVASc(score) {
        const range = INTERPRETATIONS.chadsvasc.find(r => score >= r.min && score <= r.max);
        return range || INTERPRETATIONS.chadsvasc[INTERPRETATIONS.chadsvasc.length - 1];
    },

    // === 10. HAS-BLED === //
    calculateHASBLED(inputs) {
        let score = 0;
        
        // Hypertension (1 punto)
        if (inputs.hypertension) score += 1;
        
        // Abnormal renal/liver (1 punto cada uno, máximo 2)
        if (inputs.abnormalRenal) score += 1;
        if (inputs.abnormalLiver) score += 1;
        
        // Stroke (1 punto)
        if (inputs.stroke) score += 1;
        
        // Bleeding (1 punto)
        if (inputs.bleeding) score += 1;
        
        // Labile INR (1 punto)
        if (inputs.labileINR) score += 1;
        
        // Elderly (≥65 años) (1 punto)
        if (inputs.age >= 65) score += 1;
        
        // Drugs/Alcohol (1 punto cada uno, máximo 2)
        if (inputs.drugs) score += 1;
        if (inputs.alcohol) score += 1;
        
        return {
            value: score,
            unit: 'puntos',
            interpretation: this.interpretHASBLED(score)
        };
    },

    interpretHASBLED(score) {
        const range = INTERPRETATIONS.hasbled.find(r => score >= r.min && score <= r.max);
        return range || INTERPRETATIONS.hasbled[INTERPRETATIONS.hasbled.length - 1];
    },

    // === 11. CHILD-PUGH === //
    calculateChildPugh(inputs) {
        let score = 0;
        
        // Bilirrubina
        if (inputs.bilirubin < 2) score += 1;
        else if (inputs.bilirubin <= 3) score += 2;
        else score += 3;
        
        // Albúmina
        if (inputs.albumin > 3.5) score += 1;
        else if (inputs.albumin >= 2.8) score += 2;
        else score += 3;
        
        // INR
        if (inputs.inr < 1.7) score += 1;
        else if (inputs.inr <= 2.3) score += 2;
        else score += 3;
        
        // Ascitis
        score += parseInt(inputs.ascites);
        
        // Encefalopatía
        score += parseInt(inputs.encephalopathy);
        
        return {
            value: score,
            unit: 'puntos',
            interpretation: this.interpretChildPugh(score)
        };
    },

    interpretChildPugh(score) {
        const range = INTERPRETATIONS.childPugh.find(r => score >= r.min && score <= r.max);
        return range || INTERPRETATIONS.childPugh[INTERPRETATIONS.childPugh.length - 1];
    },

    // === 12. CURB-65 / CRB-65 === //
    calculateCURB65(inputs) {
        const hasBUN = inputs.bun !== null && !isNaN(inputs.bun);
        let score = 0;

        if (inputs.confusion)                                     score += 1;
        if (hasBUN && inputs.bun > 19)                           score += 1;
        if (inputs.respiratoryRate >= 30)                        score += 1;
        if (inputs.systolicBP < 90 || inputs.diastolicBP <= 60) score += 1;
        if (inputs.age >= 65)                                    score += 1;

        return {
            value: score,
            maxScore: hasBUN ? 5 : 4,
            mode: hasBUN ? 'CURB-65' : 'CRB-65',
            unit: 'puntos',
            interpretation: hasBUN ? this.interpretCURB65(score) : this.interpretCRB65(score)
        };
    },

    interpretCURB65(score) {
        const range = INTERPRETATIONS.curb65.find(r => score >= r.min && score <= r.max);
        return range || INTERPRETATIONS.curb65[INTERPRETATIONS.curb65.length - 1];
    },

    interpretCRB65(score) {
        const range = INTERPRETATIONS.crb65.find(r => score >= r.min && score <= r.max);
        return range || INTERPRETATIONS.crb65[INTERPRETATIONS.crb65.length - 1];
    },

    // === 13. qSOFA === //
    calculateQSOFA(inputs) {
        let score = 0;
        
        // Respiratory rate ≥22 (1 punto)
        if (inputs.respiratoryRate >= 22) score += 1;
        
        // Altered mentation (1 punto)
        if (inputs.alteredMentation) score += 1;
        
        // Systolic BP ≤100 (1 punto)
        if (inputs.systolicBP <= 100) score += 1;
        
        return {
            value: score,
            unit: 'puntos',
            interpretation: this.interpretQSOFA(score)
        };
    },

    interpretQSOFA(score) {
        const range = INTERPRETATIONS.qsofa.find(r => score >= r.min && score <= r.max);
        return range || INTERPRETATIONS.qsofa[INTERPRETATIONS.qsofa.length - 1];
    },

    // === 14. WELLS SCORE (TEP) === //
    calculateWellsTEP(inputs) {
        let score = 0;
        
        // Síntomas clínicos de TVP (3 puntos)
        if (inputs.dvpSymptoms) score += 3;
        
        // TEP más probable que otro diagnóstico (3 puntos)
        if (inputs.tepMostLikely) score += 3;
        
        // FC >100 (1.5 puntos)
        if (inputs.heartRate > 100) score += 1.5;
        
        // Inmovilización o cirugía en 4 semanas (1.5 puntos)
        if (inputs.immobilization) score += 1.5;
        
        // TEP o TVP previa (1.5 puntos)
        if (inputs.previousTEP) score += 1.5;
        
        // Hemoptisis (1 punto)
        if (inputs.hemoptysis) score += 1;
        
        // Cáncer activo (1 punto)
        if (inputs.cancer) score += 1;
        
        return {
            value: Math.round(score * 10) / 10,
            unit: 'puntos',
            interpretation: this.interpretWellsTEP(score)
        };
    },

    interpretWellsTEP(score) {
        const range = INTERPRETATIONS.wellsTEP.find(r => score >= r.min && score <= r.max);
        return range || INTERPRETATIONS.wellsTEP[INTERPRETATIONS.wellsTEP.length - 1];
    },

    // === 15. MELD SCORE === //
    calculateMELD(inputs) {
        let { bilirubin, inr, creatinine, dialysis, sodium } = inputs;

        // Convertir creatinina a mg/dL si está en µmol/L
        const currentUnit = Storage.getSetting('units.creatinine');
        if (currentUnit === 'µmol/L') {
            creatinine = creatinine / 88.42;
        }

        // Si está en diálisis, creatinina = 4 (antes de cualquier cálculo)
        if (dialysis) creatinine = 4;

        // MELD original
        const meld = 9.57 * Math.log(Math.max(creatinine, 1)) +
                     3.78 * Math.log(Math.max(bilirubin, 1)) +
                     11.2 * Math.log(Math.max(inr, 1)) +
                     6.43;

        let finalMeld = meld;
        
        // Límites
        finalMeld = Math.max(6, Math.min(40, Math.round(finalMeld * 10) / 10));
        
        // MELD-Na (si se proporciona sodio)
        let meldNa = null;
        if (sodium) {
            const naAdjusted = Math.max(125, Math.min(137, sodium));
            meldNa = finalMeld + 1.32 * (137 - naAdjusted) - (0.033 * finalMeld * (137 - naAdjusted));
            meldNa = Math.max(6, Math.min(40, Math.round(meldNa * 10) / 10));
        }
        
        return {
            value: Math.round(finalMeld),
            meldNa: meldNa ? Math.round(meldNa) : null,
            unit: 'puntos',
            interpretation: this.interpretMELD(finalMeld)
        };
    },

    interpretMELD(score) {
        const range = INTERPRETATIONS.meld.find(r => score >= r.min && score <= r.max);
        return range || INTERPRETATIONS.meld[INTERPRETATIONS.meld.length - 1];
    },

    // === 16. SOFA SCORE === //
    calculateSOFA(inputs) {
        let { pao2fio2, ventilation, platelets, bilirubin, cardiovascular, gcs, creatinine, urineOutput } = inputs;

        // Convertir creatinina a mg/dL si está en µmol/L
        const currentUnit = Storage.getSetting('units.creatinine');
        if (currentUnit === 'µmol/L') {
            creatinine = creatinine / 88.42;
        }

        // 1. Respiración (PaO2/FiO2)
        let resp = 0;
        if (pao2fio2 >= 400) resp = 0;
        else if (pao2fio2 >= 300) resp = 1;
        else if (pao2fio2 >= 200) resp = 2;
        else if (pao2fio2 >= 100 && ventilation) resp = 3;
        else if (pao2fio2 < 100 && ventilation) resp = 4;
        else resp = 2; // Sin ventilación con PaO2/FiO2 <200 → máx score posible = 2

        // 2. Coagulación (Plaquetas ×10³/µL)
        let coag = 0;
        if (platelets >= 150) coag = 0;
        else if (platelets >= 100) coag = 1;
        else if (platelets >= 50) coag = 2;
        else if (platelets >= 20) coag = 3;
        else coag = 4;

        // 3. Hepático (Bilirrubina mg/dL)
        let liver = 0;
        if (bilirubin < 1.2) liver = 0;
        else if (bilirubin < 2.0) liver = 1;
        else if (bilirubin < 6.0) liver = 2;
        else if (bilirubin < 12.0) liver = 3;
        else liver = 4;

        // 4. Cardiovascular (0-4 seleccionado directamente)
        const cardio = parseInt(cardiovascular);

        // 5. Neurológico (GCS)
        let neuro = 0;
        if (gcs === 15) neuro = 0;
        else if (gcs >= 13) neuro = 1;
        else if (gcs >= 10) neuro = 2;
        else if (gcs >= 6) neuro = 3;
        else neuro = 4;

        // 6. Renal (Creatinina mg/dL + diuresis opcional)
        let renal = 0;
        if (creatinine < 1.2) renal = 0;
        else if (creatinine < 2.0) renal = 1;
        else if (creatinine < 3.5) renal = 2;
        else if (creatinine < 5.0) renal = 3;
        else renal = 4;

        // Ajustar renal por diuresis si es peor
        if (urineOutput !== null && urineOutput !== undefined) {
            let renalByUrine = 0;
            if (urineOutput < 200) renalByUrine = 4;
            else if (urineOutput < 500) renalByUrine = 3;
            renal = Math.max(renal, renalByUrine);
        }

        const total = resp + coag + liver + cardio + neuro + renal;

        return {
            value: total,
            unit: 'puntos',
            components: { resp, coag, liver, cardio, neuro, renal },
            interpretation: this.interpretSOFA(total)
        };
    },

    interpretSOFA(score) {
        const range = INTERPRETATIONS.sofa.find(r => score >= r.min && score <= r.max);
        return range || INTERPRETATIONS.sofa[INTERPRETATIONS.sofa.length - 1];
    },

    // === 17. NIHSS SCORE === //
    calculateNIHSS(inputs) {
        const {
            loc, locQuestions, locCommands,
            gaze, visual, facial,
            motorArmL, motorArmR, motorLegL, motorLegR,
            ataxia, sensory, language, dysarthria, extinction
        } = inputs;

        const total = loc + locQuestions + locCommands +
                      gaze + visual + facial +
                      motorArmL + motorArmR + motorLegL + motorLegR +
                      ataxia + sensory + language + dysarthria + extinction;

        return {
            value: total,
            unit: 'puntos',
            interpretation: this.interpretNIHSS(total)
        };
    },

    interpretNIHSS(score) {
        const range = INTERPRETATIONS.nihss.find(r => score >= r.min && score <= r.max);
        return range || INTERPRETATIONS.nihss[INTERPRETATIONS.nihss.length - 1];
    },

    // === 18. GLASGOW COMA SCALE === //
    calculateGlasgow(inputs) {
        const { eyes, verbal, motor } = inputs;
        const total = eyes + verbal + motor;

        return {
            value: total,
            unit: 'puntos',
            components: { eyes, verbal, motor },
            interpretation: this.interpretGlasgow(total)
        };
    },

    interpretGlasgow(score) {
        const range = INTERPRETATIONS.glasgow.find(r => score >= r.min && score <= r.max);
        return range || INTERPRETATIONS.glasgow[INTERPRETATIONS.glasgow.length - 1];
    },

    // === 19. TIMI RISK SCORE — UA/NSTEMI === //
    calculateTIMI_NSTEMI(inputs) {
        let score = 0;
        if (inputs.age65)        score += 1;
        if (inputs.riskFactors)  score += 1;
        if (inputs.knownCAD)     score += 1;
        if (inputs.aspirin)      score += 1;
        if (inputs.severeAngina) score += 1;
        if (inputs.elevMarkers)  score += 1;
        if (inputs.stDeviation)  score += 1;

        return {
            value: score,
            unit: 'puntos',
            interpretation: this.interpretTIMI_NSTEMI(score)
        };
    },

    interpretTIMI_NSTEMI(score) {
        const range = INTERPRETATIONS.timiNSTEMI.find(r => score >= r.min && score <= r.max);
        return range || INTERPRETATIONS.timiNSTEMI[INTERPRETATIONS.timiNSTEMI.length - 1];
    },

    // === 20. TIMI RISK SCORE — STEMI === //
    calculateTIMI_STEMI(inputs) {
        let { age, sbp, hr, weight } = inputs;
        let score = 0;

        // Edad (rangos de puntos)
        if (age >= 75)      score += 3;
        else if (age >= 65) score += 2;

        // Checkboxes clínicos
        if (inputs.riskHistory) score += 1; // DM / HTA / angina previa
        if (sbp < 100)          score += 3;
        if (hr > 100)           score += 2;
        if (inputs.killip2plus)  score += 2; // Killip ≥ II

        // Peso: convertir a kg si está en lb
        const weightUnit = Storage.getSetting('units.weight');
        if (weightUnit === 'lb') weight = weight / 2.20462;
        if (weight < 67) score += 1;

        if (inputs.anteriorST)  score += 1; // Elevación ST anterior o BCRI
        if (inputs.timeLate)    score += 1; // Tiempo a tratamiento >4h

        return {
            value: score,
            unit: 'puntos',
            interpretation: this.interpretTIMI_STEMI(score)
        };
    },

    interpretTIMI_STEMI(score) {
        const range = INTERPRETATIONS.timiSTEMI.find(r => score >= r.min && score <= r.max);
        return range || INTERPRETATIONS.timiSTEMI[INTERPRETATIONS.timiSTEMI.length - 1];
    },

    // === 21. GRACE SCORE === //
    calculateGRACE(inputs) {
        let { age, hr, sbp, creatinine, killip, cardiacArrest, stDeviation, elevMarkers } = inputs;

        // Convertir creatinina a mg/dL si está en µmol/L
        const crUnit = Storage.getSetting('units.creatinine');
        if (crUnit === 'µmol/L') creatinine = creatinine / 88.42;

        // Puntos por edad
        let agePoints = 0;
        if      (age < 40)  agePoints = 0;
        else if (age < 50)  agePoints = 18;
        else if (age < 60)  agePoints = 36;
        else if (age < 70)  agePoints = 55;
        else if (age < 80)  agePoints = 73;
        else                agePoints = 91;

        // Puntos por FC
        let hrPoints = 0;
        if      (hr < 70)   hrPoints = 0;
        else if (hr < 90)   hrPoints = 7;
        else if (hr < 110)  hrPoints = 13;
        else if (hr < 150)  hrPoints = 23;
        else if (hr < 200)  hrPoints = 36;
        else                hrPoints = 46;

        // Puntos por PAS
        let sbpPoints = 0;
        if      (sbp < 80)   sbpPoints = 63;
        else if (sbp < 100)  sbpPoints = 58;
        else if (sbp < 120)  sbpPoints = 47;
        else if (sbp < 140)  sbpPoints = 37;
        else if (sbp < 160)  sbpPoints = 26;
        else if (sbp < 200)  sbpPoints = 11;
        else                 sbpPoints = 0;

        // Puntos por creatinina (mg/dL)
        let crPoints = 0;
        if      (creatinine < 0.4)  crPoints = 2;
        else if (creatinine < 0.8)  crPoints = 5;
        else if (creatinine < 1.2)  crPoints = 8;
        else if (creatinine < 1.6)  crPoints = 11;
        else if (creatinine < 2.0)  crPoints = 14;
        else if (creatinine < 4.0)  crPoints = 23;
        else                        crPoints = 31;

        // Killip class
        const killipMap = { '1': 0, '2': 21, '3': 43, '4': 64 };
        const killipPoints = killipMap[String(killip)] || 0;

        // Binarios
        const arrestPoints  = cardiacArrest ? 43 : 0;
        const stPoints      = stDeviation   ? 30 : 0;
        const markerPoints  = elevMarkers   ? 15 : 0;

        const total = agePoints + hrPoints + sbpPoints + crPoints + killipPoints + arrestPoints + stPoints + markerPoints;

        return {
            value: total,
            unit: 'puntos',
            components: { agePoints, hrPoints, sbpPoints, crPoints, killipPoints, arrestPoints, stPoints, markerPoints },
            interpretation: this.interpretGRACE(total)
        };
    },

    interpretGRACE(score) {
        const range = INTERPRETATIONS.grace.find(r => score >= r.min && score <= r.max);
        return range || INTERPRETATIONS.grace[INTERPRETATIONS.grace.length - 1];
    },

    // === 22. ESCALA DE BRADEN === //
    calculateBraden(inputs) {
        const { sensory, moisture, activity, mobility, nutrition, friction } = inputs;
        const total = sensory + moisture + activity + mobility + nutrition + friction;

        return {
            value: total,
            unit: 'puntos',
            components: { sensory, moisture, activity, mobility, nutrition, friction },
            interpretation: this.interpretBraden(total)
        };
    },

    interpretBraden(score) {
        const range = INTERPRETATIONS.braden.find(r => score >= r.min && score <= r.max);
        return range || INTERPRETATIONS.braden[INTERPRETATIONS.braden.length - 1];
    },

    // === 23. MACOCHA SCORE === //
    calculateMAOCHA(inputs) {
        let score = 0;
        if (inputs.mallampati) score += 5;
        if (inputs.osa)        score += 2;
        if (inputs.cervical)   score += 1;
        if (inputs.opening)    score += 1;
        if (inputs.coma)       score += 1;
        if (inputs.hypoxemia)  score += 1;
        if (inputs.nonAnest)   score += 1;
        return { value: score, unit: 'puntos', interpretation: this.interpretMAOCHA(score) };
    },

    interpretMAOCHA(score) {
        const range = INTERPRETATIONS.macocha.find(r => score >= r.min && score <= r.max);
        return range || INTERPRETATIONS.macocha[INTERPRETATIONS.macocha.length - 1];
    },

    // === 24. PBW + VOLUMEN TIDAL (ARDSNet) === //
    calculatePBW(inputs) {
        let { sex, height } = inputs;
        const heightUnit = Storage.getSetting('units.height');
        if (heightUnit === 'm')  height = height * 100;
        if (heightUnit === 'in') height = height * 2.54;
        if (heightUnit === 'ft') height = height * 30.48;

        const pbw = sex === 'male'
            ? 50 + 0.91 * (height - 152.4)
            : 45.5 + 0.91 * (height - 152.4);
        const p = Math.round(pbw * 10) / 10;

        return {
            value: p,
            unit: 'kg',
            tv4: Math.round(p * 4),
            tv6: Math.round(p * 6),
            tv8: Math.round(p * 8),
            interpretation: INTERPRETATIONS.pbw[0]
        };
    },

    // === 25. FOUR SCORE === //
    calculateFOURScore(inputs) {
        const { eyes, motor, brainstem, respiration } = inputs;
        const total = eyes + motor + brainstem + respiration;
        return {
            value: total,
            unit: 'puntos',
            components: { eyes, motor, brainstem, respiration },
            interpretation: this.interpretFOURScore(total)
        };
    },

    interpretFOURScore(score) {
        const range = INTERPRETATIONS.fourScore.find(r => score >= r.min && score <= r.max);
        return range || INTERPRETATIONS.fourScore[INTERPRETATIONS.fourScore.length - 1];
    },

    // === 26. HEART SCORE === //
    calculateHEART(inputs) {
        const { history, ecg, age, riskFactors, troponin } = inputs;
        const score = history + ecg + age + riskFactors + troponin;
        return {
            value: score,
            unit: 'puntos',
            components: { history, ecg, age, riskFactors, troponin },
            interpretation: this.interpretHEART(score)
        };
    },

    interpretHEART(score) {
        const range = INTERPRETATIONS.heart.find(r => score >= r.min && score <= r.max);
        return range || INTERPRETATIONS.heart[INTERPRETATIONS.heart.length - 1];
    },

    // === 27. REGLA PERC === //
    calculatePERC(inputs) {
        let score = 0;
        if (inputs.age50)       score++;
        if (inputs.hr100)       score++;
        if (inputs.spo294)      score++;
        if (inputs.legSwelling) score++;
        if (inputs.hemoptysis)  score++;
        if (inputs.surgery)     score++;
        if (inputs.priorVTE)    score++;
        if (inputs.estrogen)    score++;
        return {
            value: score,
            unit: 'criterios positivos',
            interpretation: this.interpretPERC(score)
        };
    },

    interpretPERC(score) {
        const range = INTERPRETATIONS.perc.find(r => score >= r.min && score <= r.max);
        return range || INTERPRETATIONS.perc[INTERPRETATIONS.perc.length - 1];
    },

    // === 28. CAD / CADE — PROTOCOLO INTEGRAL === //
    calculateDKA(inputs) {
        let { weight, type, hemodynamic, glucose, glucoseUnit, ph, hco3, sodium, potassium, chloride } = inputs;

        // Convertir unidades
        const weightUnit = Storage.getSetting('units.weight');
        if (weightUnit === 'lb') weight = weight / 2.20462;
        if (glucoseUnit === 'mmol/L') glucose = glucose / 0.0555;

        const isCADE = type === 'cade';

        // Na corregido (ADA 2024: factor 2.4 uniforme)
        const naCorregido = Math.round((sodium + 2.4 * (glucose - 100) / 100) * 10) / 10;

        // Anión Gap (solo si Cl disponible)
        const agCalc = (chloride !== null && !isNaN(chloride))
            ? Math.round((sodium - (chloride + hco3)) * 10) / 10
            : null;

        // Osmolaridad sérica efectiva
        const osmEffective = Math.round((2 * sodium + glucose / 18) * 10) / 10;

        // Clasificación de severidad (pH tiene prioridad clínica)
        let severity;
        if (isCADE) {
            severity = { label: 'CAD Euglucémica (CADE)', colorHex: '#7c3aed', badge: '🟣' };
        } else if (ph < 7.00 || hco3 < 10) {
            severity = { label: 'CAD Severa', colorHex: '#dc2626', badge: '🔴' };
        } else if (ph < 7.25 || hco3 < 15) {
            severity = { label: 'CAD Moderada', colorHex: '#f59e0b', badge: '🟠' };
        } else {
            severity = { label: 'CAD Leve', colorHex: '#16a34a', badge: '🟡' };
        }

        // Alerta crítica K+
        const criticalAlert = potassium < 3.3
            ? { hasAlert: true, message: `K⁺ ${potassium} mEq/L — RETENER INSULINA. Reponer potasio primero. Riesgo de arritmia fatal.` }
            : { hasAlert: false };

        // Fluidos
        let bolusML, bolusTime;
        if (hemodynamic === 'severe') {
            bolusML = 1000; bolusTime = '30 min';
        } else if (hemodynamic === 'cardiogenic') {
            bolusML = 250; bolusTime = '30 min con monitoreo estrecho';
        } else if (hemodynamic === 'euvolemic') {
            bolusML = 300; bolusTime = '30 min';
        } else {
            bolusML = Math.round(weight * 17.5); bolusTime = '60 min';
        }

        const fluidType = naCorregido > 150 ? 'NaCl 0.45%' : 'Ringer Lactato o Plasmalyte';
        const naNote = naCorregido > 150
            ? `Na corregido ${naCorregido} mEq/L (elevado) → usar NaCl 0.45% para reponer agua libre`
            : `Na corregido ${naCorregido} mEq/L → cristaloide balanceado (RL/Plasmalyte)`;
        const dextroseStart = isCADE ? 'DESDE EL INICIO — Dextrosa 5-10% (CADE)' : 'Cuando Glucosa < 250 mg/dL — sistema de 2 bolsas';

        // Potasio
        let kAction, kRate, holdInsulin, kNote;
        if (potassium < 3.3) {
            kAction = 'RETENER INSULINA — Reponer K⁺ primero';
            kRate = '20-40 mEq/h IV'; holdInsulin = true;
            kNote = 'Monitoreo ECG continuo. Si velocidad > 10 mEq/h: línea central o 2 venas periféricas. Reiniciar insulina cuando K⁺ ≥ 3.3 mEq/L.';
        } else if (potassium <= 4.0) {
            kAction = 'Reponer + iniciar insulina'; kRate = '20 mEq/h IV'; holdInsulin = false;
            kNote = 'Monitoreo ECG continuo. Reponer Mg²⁺ si está bajo (favorece refractariedad al K⁺).';
        } else if (potassium <= 5.5) {
            kAction = 'Reponer (dosis reducida) + iniciar insulina'; kRate = '10 mEq/h IV'; holdInsulin = false;
            kNote = 'K⁺ descenderá con insulina. Anticipar hipokalemia a las 2-4 h de iniciada la infusión.';
        } else {
            kAction = 'No reponer — iniciar insulina'; kRate = '—'; holdInsulin = false;
            kNote = 'Hiperkalemia ficticia por redistribución en acidosis. Descenderá con insulina + corrección de pH.';
        }

        // Insulina (dosis concretas)
        const doseIV       = Math.round(weight * 0.1  * 10) / 10;
        const doseIVReduced= Math.round(weight * 0.05 * 10) / 10;
        const doseSCBolus  = Math.round(weight * 0.15 * 10) / 10;
        const isSevereOrShock = ph < 7.00 || hco3 < 10 || hemodynamic === 'cardiogenic' || hemodynamic === 'severe';
        const insulinRoute = isSevereOrShock ? 'IV' : 'IV o SC';

        // Bicarbonato
        const bicarboIndicated = ph < 6.9;

        // Estado vs criterios de resolución
        const agMet  = agCalc !== null ? agCalc <= 12 : null;
        const hco3Met = hco3 > 18;
        const phMet   = ph > 7.30;

        // Transición a SC
        const glarginMin = Math.round(weight * 0.5);
        const glarginMax = Math.round(weight * 0.8);

        return {
            severity, criticalAlert, isCADE,
            naCorregido, agCalc, osmEffective,
            fluids: { bolusML, bolusTime, fluidType, naNote, dextroseStart, hemodynamic },
            potassium: { kAction, kRate, holdInsulin, kNote, value: potassium },
            insulin: { doseIV, doseIVReduced, doseSCBolus, insulinRoute, holdInsulin, isSevereOrShock },
            bicarbonate: { indicated: bicarboIndicated, ph },
            resolution: { agCalc, hco3, ph, agMet, hco3Met, phMet },
            transition: { glarginMin, glarginMax },
            value: weight,
            unit: 'kg',
            interpretation: { label: severity.label, color: 'danger', description: 'Protocolo CAD/CADE generado.' }
        };
    },

    // === 31. ASMA AGUDA — CRISIS BRONQUIAL === //
    calculateAsma(inputs) {
        let { age, weight, spo2, hr, rr, speech, accessory, wheeze, consciousness, cyanosis, fem, paco2 } = inputs;

        const weightUnit = Storage.getSetting('units.weight');
        if (weightUnit === 'lb') weight = weight / 2.20462;
        weight = Math.round(weight * 10) / 10;

        // Criterios potencialmente fatal (GINA 2024 / BTS-SIGN 2023)
        const fatalCriteria = [];
        if (spo2 < 90)                              fatalCriteria.push('SpO₂ < 90%');
        if (fem !== null && fem < 33)               fatalCriteria.push('FEM < 33%');
        if (wheeze === 'silent')                    fatalCriteria.push('Silencio torácico');
        if (cyanosis === 'si')                      fatalCriteria.push('Cianosis');
        if (consciousness === 'confused')           fatalCriteria.push('Confusión / somnolencia');
        if (paco2 !== null && paco2 >= 45)          fatalCriteria.push(`PaCO₂ ${paco2} mmHg ≥ 45 (agotamiento ventilatorio)`);
        const isFatal = fatalCriteria.length > 0;

        // Criterios graves
        const severeCriteria = [];
        if (!isFatal) {
            if (spo2 >= 90 && spo2 <= 93)                       severeCriteria.push('SpO₂ 90-93%');
            if (fem !== null && fem >= 33 && fem <= 50)          severeCriteria.push('FEM 33-50%');
            if (speech === 'words' || speech === 'unable')       severeCriteria.push('Solo palabras / Incapaz de hablar');
            if (hr >= 120)                                       severeCriteria.push(`FC ${hr} lpm ≥ 120`);
            if (rr >= 25)                                        severeCriteria.push(`FR ${rr} rpm ≥ 25`);
            if (accessory === 'si')                              severeCriteria.push('Músculos accesorios activos');
        }
        const isSevere = severeCriteria.length > 0;

        // Criterios moderados
        const moderateCriteria = [];
        if (!isFatal && !isSevere) {
            if (spo2 >= 94 && spo2 <= 96)                        moderateCriteria.push('SpO₂ 94-96%');
            if (fem !== null && fem >= 51 && fem <= 75)          moderateCriteria.push('FEM 51-75%');
            if (speech === 'phrases')                             moderateCriteria.push('Solo frases cortas');
            if (hr >= 100 && hr < 120)                           moderateCriteria.push(`FC ${hr} lpm (100-119)`);
            if (rr >= 20 && rr < 25)                             moderateCriteria.push(`FR ${rr} rpm (20-24)`);
        }
        const isModerate = moderateCriteria.length > 0;
        const isMild = !isFatal && !isSevere && !isModerate;

        let severity;
        if (isFatal)         severity = { label: 'Potencialmente Fatal', colorHex: '#dc2626', badge: '🔴', level: 4 };
        else if (isSevere)   severity = { label: 'Crisis Grave',         colorHex: '#ea580c', badge: '🟠', level: 3 };
        else if (isModerate) severity = { label: 'Crisis Moderada',      colorHex: '#ca8a04', badge: '🟡', level: 2 };
        else                 severity = { label: 'Crisis Leve',          colorHex: '#16a34a', badge: '🟢', level: 1 };

        // Oxigenoterapia
        const o2 = {
            needed: spo2 < 94,
            target: '94-98%',
            device: (isFatal || isSevere)
                ? 'Mascarilla Venturi 35-40% o mascarilla con reservorio'
                : 'Gafas nasales 2-4 L/min'
        };

        // SABA — Salbutamol
        let saba;
        if (isFatal) {
            saba = {
                ivDose: '5 mcg/min → aumentar hasta 20 mcg/min si no respuesta',
                ivPrep: '50 mg en 50 mL SF (1 mg/mL) → iniciar 0.3 mL/h · máx 1.2 mL/h',
                nebDose: '5 mg nebulizado c/20 min (o continuo 10-15 mg/h en UCI)',
                note: 'Monitorizar K⁺ (riesgo hipopotasemia con salbutamol IV)'
            };
        } else if (isSevere) {
            saba = {
                nebDose: '5 mg c/20 min × 3 dosis; continuo 10 mg/h si no respuesta',
                mdiDose: '8 puffs (100 mcg/puff) c/20 min × 3 (MDI + cámara)'
            };
        } else {
            saba = {
                mdiDose: '4-8 puffs (100 mcg/puff) c/20 min × 3, luego c/1-4h según respuesta',
                nebDose: '2.5 mg nebulizado c/20 min × 3 dosis'
            };
        }

        // Ipratropio (grave y fatal)
        const ipratropium = (isSevere || isFatal) ? {
            indicated: true,
            nebDose: '0.5 mg c/20 min × 3 dosis (primeras horas)',
            mdiDose: '4-8 puffs (20 mcg/puff) c/20 min × 3'
        } : { indicated: false };

        // Corticosteroides
        let cortico;
        if (isFatal || isSevere) {
            const mpMin = Math.round(weight * 1);
            const mpMax = Math.min(Math.round(weight * 2), 125);
            cortico = {
                drug1: 'Hidrocortisona 200 mg IV c/6h',
                drug2: `Metilprednisolona ${mpMin}-${mpMax} mg IV c/6h (1-2 mg/kg · máx 125 mg)`,
                duration: 'Hasta tolerar VO → prednisolona 40-50 mg VO × 5-7 días',
                note: 'Iniciar en la primera hora'
            };
        } else {
            cortico = {
                drug1: 'Prednisolona 40-50 mg VO c/24h × 5-7 días',
                drug2: null,
                duration: '5-7 días (no precisa pauta descendente si duración < 3 semanas)',
                note: 'Iniciar lo antes posible'
            };
        }

        // Sulfato de magnesio
        const magnesio = (isSevere || isFatal) ? {
            indicated: true,
            dose: 'MgSO₄ 2 g IV en 20 min (diluido en 100 mL SF)',
            when: 'Sin respuesta a broncodilatadores + corticoides en 30-60 min',
            caution: 'Precaución en insuficiencia renal severa'
        } : { indicated: false };

        // Aminofilina (rescate, solo fatal)
        const aminofilina = isFatal ? {
            indicated: true,
            loading: `${Math.round(weight * 5)} mg IV en 20 min (${weight} kg × 5 mg/kg)`,
            loadingNote: 'Si toma teofilina: OMITIR la carga o reducir al 50%',
            maintenance: `${Math.round(weight * 0.5 * 10) / 10} mg/h IV continua (0.5 mg/kg/h)`,
            warning: 'Índice terapéutico estrecho · Niveles objetivo 10-20 mcg/mL · Vigilar arritmias'
        } : { indicated: false };

        // Destino
        const admision = {
            icu: isFatal,
            required: isFatal || isSevere,
            criteria: isFatal
                ? 'UCI / Área de Críticos — Crisis potencialmente fatal'
                : isSevere
                ? 'Hospitalización — Crisis grave'
                : 'Observación 1h · Alta si FEM > 75% y SpO₂ ≥ 94% en aire ambiente'
        };

        const alta = !admision.required ? {
            applicable: true,
            criteria: [
                'SpO₂ ≥ 94% en aire ambiente',
                'FEM ≥ 75% del mejor personal',
                'Habla en frases completas',
                'Técnica de inhalador verificada',
                'Plan de acción escrito entregado',
                'Control ambulatorio en 48-72h'
            ]
        } : { applicable: false };

        return {
            severity, o2, saba, ipratropium, cortico, magnesio, aminofilina, admision, alta,
            isFatal, isSevere, isModerate, isMild,
            fatalCriteria, severeCriteria, moderateCriteria,
            weightKg: weight,
            value: spo2, unit: '%',
            interpretation: {
                label: severity.label,
                color: 'danger',
                description: `Crisis aguda de asma: ${severity.label}. Protocolo GINA 2024 / BTS-SIGN 2023 generado.`
            }
        };
    },

    // === 32. CONTROL ASMA CRÓNICA — CLASIFICACIÓN Y ESCALÓN === //
    calculateAsmaControl(inputs) {
        const { enTratamiento, escalon, tiempoEscalon, sintomasDiurnos, sintomasNocturnos,
                limitacion, rescate, fev1fem, exacerbaciones, ocs, tabaco } = inputs;

        // ────────────────────────────────────────────────────────────
        // A) EVALUACIÓN DE CONTROL (si en tratamiento — GINA 2024)
        // ────────────────────────────────────────────────────────────
        let controlScore = 0;
        if (sintomasDiurnos === 'gt2' || sintomasDiurnos === 'daily') controlScore++;
        if (limitacion === 'alguna' || limitacion === 'bastante' || limitacion === 'total') controlScore++;
        if (sintomasNocturnos === 'gt2' || sintomasNocturnos === 'frequent') controlScore++;
        if (rescate === 'gt2') controlScore++;

        let control;
        if (controlScore === 0) {
            control = { label: 'Bien controlado', badge: '✅', colorHex: '#16a34a', level: 0 };
        } else if (controlScore <= 2) {
            control = { label: 'Parcialmente controlado', badge: '⚠️', colorHex: '#ca8a04', level: 1 };
        } else {
            control = { label: 'No controlado', badge: '🔴', colorHex: '#dc2626', level: 2 };
        }

        const femRiesgo = fev1fem === 'lt60' || fev1fem === '60-79';

        // ────────────────────────────────────────────────────────────
        // B) CLASIFICACIÓN DE SEVERIDAD (si no en tratamiento)
        // ────────────────────────────────────────────────────────────
        // Regla: el síntoma más grave determina la severidad
        let severidadLevel = 0; // 0=intermitente, 1=leve, 2=moderada, 3=grave

        // Síntomas diurnos
        if (sintomasDiurnos === 'daily') severidadLevel = Math.max(severidadLevel, 3);
        else if (sintomasDiurnos === 'gt2') severidadLevel = Math.max(severidadLevel, 2);
        else if (sintomasDiurnos === 'lte2') severidadLevel = Math.max(severidadLevel, 1);

        // Síntomas nocturnos
        if (sintomasNocturnos === 'frequent') severidadLevel = Math.max(severidadLevel, 3);
        else if (sintomasNocturnos === 'gt2') severidadLevel = Math.max(severidadLevel, 2);
        else if (sintomasNocturnos === 'lte2') severidadLevel = Math.max(severidadLevel, 1);

        // Limitación de actividad
        if (limitacion === 'total') severidadLevel = Math.max(severidadLevel, 3);
        else if (limitacion === 'bastante') severidadLevel = Math.max(severidadLevel, 2);
        else if (limitacion === 'alguna') severidadLevel = Math.max(severidadLevel, 1);

        // FEV1/FEM
        if (fev1fem === 'lt60') severidadLevel = Math.max(severidadLevel, 3);
        else if (fev1fem === '60-79') severidadLevel = Math.max(severidadLevel, 2);

        const SEVERIDADES = [
            { label: 'Intermitente',        colorHex: '#16a34a', badge: '🟢', escalon: 1 },
            { label: 'Persistente Leve',    colorHex: '#ca8a04', badge: '🟡', escalon: 2 },
            { label: 'Persistente Moderada',colorHex: '#ea580c', badge: '🟠', escalon: 3 },
            { label: 'Persistente Grave',   colorHex: '#dc2626', badge: '🔴', escalon: 4 }
        ];
        const severidad = SEVERIDADES[severidadLevel];

        // ────────────────────────────────────────────────────────────
        // C) ESCALÓN RECOMENDADO
        // ────────────────────────────────────────────────────────────
        let escalonRec;
        const escalonActual = enTratamiento === 'si' ? parseInt(escalon) : null;

        if (enTratamiento === 'no') {
            // Diagnóstico inicial: escalón según severidad
            escalonRec = severidadLevel === 3 ? 4 : severidad.escalon;
        } else {
            // En tratamiento: ajustar según control
            if (control.level === 2) {
                // No controlado → subir
                escalonRec = Math.min(escalonActual + 1, 5);
            } else if (control.level === 0 && tiempoEscalon === 'gte3' && escalonActual > 1) {
                // Bien controlado ≥ 3 meses → considerar bajar
                escalonRec = escalonActual - 1;
            } else {
                // Parcialmente controlado o bien controlado < 3 meses → mantener
                escalonRec = escalonActual;
            }
            // Factores de riesgo fuerzan al menos escalón actual
            if ((exacerbaciones === 'gte2' || ocs === 'si') && escalonRec < escalonActual) {
                escalonRec = escalonActual;
            }
        }

        // Indicador de cambio
        const cambio = escalonActual === null ? 'nuevo'
            : escalonRec > escalonActual ? 'subir'
            : escalonRec < escalonActual ? 'bajar'
            : 'mantener';

        // ────────────────────────────────────────────────────────────
        // D) CONTENIDO DE CADA ESCALÓN
        // ────────────────────────────────────────────────────────────
        const ESCALONES = {
            1: {
                label: 'Escalón 1',
                colorHex: '#16a34a',
                controlador: null,
                controladorAlt: null,
                rescatador: 'ICS-Formoterol dosis baja PRN (preferido GINA 2024)',
                rescatadorDetalle: 'Budesonida/Formoterol 160/4.5 mcg 1 inh según necesidad',
                rescatadorAlt: 'Alternativa: Salbutamol 100 mcg 2 inh PRN (si ICS-formoterol no disponible)',
                smart: false,
                nota: 'Sin controlador diario necesario. Máx 2 usos/sem de rescate — si más → subir escalón.'
            },
            2: {
                label: 'Escalón 2',
                colorHex: '#16a34a',
                controlador: 'ICS dosis baja diario (primera línea)',
                controladorDetalle: '• Budesonida 200-400 mcg/día (1-2 inh)\n• Fluticasona propionato 100-200 mcg/día\n• Beclometasona 100-200 mcg/día',
                controladorAlt: 'Alternativas: Montelukast 10 mg/noche (si ICS no tolerado) · ICS dosis baja antes de ejercicio',
                rescatador: 'SABA PRN o ICS-Formoterol PRN',
                rescatadorDetalle: 'Salbutamol 100 mcg 2 inh PRN  o  Budesonida/Formoterol 160/4.5 mcg 1 inh PRN',
                smart: false,
                nota: null
            },
            3: {
                label: 'Escalón 3',
                colorHex: '#ca8a04',
                controlador: 'ICS dosis baja + LABA (primera línea)',
                controladorDetalle: '• Budesonida/Formoterol 160/4.5 mcg 2 inh BID\n• Fluticasona/Salmeterol 100/50 mcg 1 inh BID\n• Beclometasona/Formoterol 100/6 mcg 2 inh BID',
                controladorAlt: 'Alternativas: ICS dosis media diario · ICS + Montelukast 10 mg/noche',
                rescatador: 'SABA PRN  o  SMART (BUD/FORM como mantenimiento y rescate)',
                rescatadorDetalle: 'SMART — Budesonida/Formoterol 160/4.5 mcg: mismo inhalador como controlador y rescate. Reduce exacerbaciones.',
                smart: true,
                nota: null
            },
            4: {
                label: 'Escalón 4',
                colorHex: '#ea580c',
                controlador: 'ICS dosis media-alta + LABA',
                controladorDetalle: '• Budesonida 400-800 mcg/día + Formoterol\n• Fluticasona propionato 250-500 mcg/día + Salmeterol\n• Fluticasona furoato/Vilanterol 92/22 mcg 1 inh/día',
                controladorAlt: 'Add-ons: Tiotropio 2.5 mcg/día (≥ 12a, con exacerbaciones) · Montelukast · Azitromicina 250 mg/día (asma no alérgica — requiere ECG previo)',
                rescatador: 'SABA PRN  o  SMART si usa BUD/FORM',
                rescatadorDetalle: 'Salbutamol 100 mcg 2 inh PRN  o  Budesonida/Formoterol PRN (SMART)',
                smart: true,
                nota: '⚠️ Derivar a especialista en Neumología / Alergología'
            },
            5: {
                label: 'Escalón 5',
                colorHex: '#dc2626',
                controlador: 'ICS dosis alta + LABA + Tiotropio',
                controladorDetalle: '• ICS alta dosis + LABA (continuar)\n• Tiotropio 2.5 mcg/día add-on\n• OCS (Prednisolona ≤ 7.5 mg/día) solo si sin otras opciones',
                controladorAlt: null,
                rescatador: 'SABA PRN  o  ICS-Formoterol PRN',
                rescatadorDetalle: 'Salbutamol 100 mcg 2 inh PRN  o  Budesonida/Formoterol 160/4.5 mcg 1 inh PRN',
                smart: false,
                biologicos: {
                    alergico: {
                        fenotipo: 'Asma alérgica (IgE elevada + sensibilización alérgeno perenne)',
                        farmacos: 'Omalizumab',
                        indicacion: 'IgE total 30-1500 UI/mL · Sensibilización a alérgeno perenne · ≥ 6 años'
                    },
                    eosinofilico: {
                        fenotipo: 'Asma eosinofílica (Eos ≥ 300/µL en sangre)',
                        farmacos: 'Mepolizumab · Benralizumab · Tezepelumab',
                        indicacion: 'Eos ≥ 300/µL (o ≥ 150 si corticodependiente) · Mepolizumab también en Eos < 300 si OCS-dependiente'
                    },
                    tipo2: {
                        fenotipo: 'Asma tipo 2 (Eos elevados y/o FeNO alto)',
                        farmacos: 'Dupilumab',
                        indicacion: 'Eos ≥ 150/µL o FeNO ≥ 25 ppb · También si rinitis alérgica o dermatitis atópica comórbida'
                    }
                },
                nota: '⚠️ Derivación OBLIGATORIA a Neumología / Alergología'
            }
        };

        const escalonData = ESCALONES[escalonRec];

        // Factores de riesgo adicionales
        const riesgos = [];
        if (exacerbaciones === 'gte2') riesgos.push('≥ 2 exacerbaciones en el último año (alto riesgo)');
        else if (exacerbaciones === '1') riesgos.push('1 exacerbación en el último año (riesgo moderado)');
        if (ocs === 'si') riesgos.push('Uso de OCS sistémicos en el último año');
        if (tabaco === 'si') riesgos.push('Tabaquismo activo — reduce respuesta a ICS');
        if (femRiesgo && enTratamiento === 'si') riesgos.push('FEV1/FEM reducido — riesgo de limitación fija del flujo');

        const derivar = escalonRec >= 4 || exacerbaciones === 'gte2' || (enTratamiento === 'si' && control.level === 2 && escalonActual >= 3);

        return {
            enTratamiento, control, severidad, severidadLevel,
            escalonActual, escalonRec, cambio,
            escalonData, riesgos, derivar, femRiesgo, controlScore,
            value: escalonRec, unit: `Escalón ${escalonRec}`,
            interpretation: {
                label: enTratamiento === 'no' ? severidad.label : control.label,
                color: 'info',
                description: `Asma crónica: ${enTratamiento === 'no' ? severidad.label : control.label}. Escalón recomendado: ${escalonRec}.`
            }
        };
    },

    // === 34. PAM — PRESIÓN ARTERIAL MEDIA === //
    calculatePAM(inputs) {
        const { pas, pad } = inputs;
        const pam = Math.round((pad + (pas - pad) / 3) * 10) / 10;

        let stage, label, color, description;
        if (pam < 60) {
            stage = '< 60 mmHg'; label = 'Hipoperfusión grave'; color = 'danger';
            description = 'PAM crítica — perfusión de órganos comprometida. Requiere intervención inmediata: vasopresores y/o reanimación con fluidos.';
        } else if (pam < 65) {
            stage = '60-64 mmHg'; label = 'Límite inferior'; color = 'warning';
            description = 'PAM en límite crítico. Por debajo del objetivo mínimo en sepsis (≥65 mmHg). Evaluar estado hemodinámico y necesidad de vasopresores.';
        } else if (pam <= 100) {
            stage = '65-100 mmHg'; label = 'Normal'; color = 'success';
            description = 'PAM dentro del rango normal. Adecuada para la mayoría de pacientes. Verificar objetivos específicos según contexto clínico.';
        } else if (pam <= 110) {
            stage = '101-110 mmHg'; label = 'Hipertensión leve'; color = 'warning';
            description = 'PAM elevada. Aumenta la poscarga cardíaca. Evaluar en contexto de HTA crónica, ansiedad o dolor.';
        } else {
            stage = '> 110 mmHg'; label = 'Hipertensión moderada-grave'; color = 'danger';
            description = 'PAM muy elevada. Riesgo de daño de órgano diana. Evaluar urgencia/emergencia hipertensiva y necesidad de tratamiento.';
        }

        return {
            value: pam, unit: 'mmHg',
            interpretation: { stage, label, color, description }
        };
    },

    // === 33. DIAGNÓSTICO LES — CRITERIOS ACR/EULAR 2019 === //
    calculateLES(inputs) {
        const { ana, fever, leukopenia, thrombocytopenia, hemolysis,
                delirium, psychosis, seizures,
                alopecia, oralUlcers, subacuteDiscoid, acuteCutaneous,
                effusion, pericarditis, joints,
                proteinuria, biopsy25, biopsy34,
                antiphospholipid, complement, specificAb } = inputs;

        function domMax(criteria) {
            const pts = criteria.filter(c => c.checked).map(c => c.pts);
            return pts.length ? Math.max(...pts) : 0;
        }

        function markDomain(criteria, domScore) {
            let countedYet = false;
            criteria.slice().sort((a, b) => b.pts - a.pts).forEach(cr => {
                if (!cr.checked) { cr.counts = null; return; }
                if (cr.pts === domScore && !countedYet) { cr.counts = true; countedYet = true; }
                else { cr.counts = false; }
            });
        }

        const domainDefs = [
            {
                key: 'constitutional', name: 'Constitucional', max: 2, icon: '🌡️',
                criteria: [{ label: 'Fiebre >38.3°C inexplicada', pts: 2, checked: !!fever }]
            },
            {
                key: 'hematological', name: 'Hematológico', max: 4, icon: '🩸',
                criteria: [
                    { label: 'Leucopenia <4.000/µL', pts: 3, checked: !!leukopenia },
                    { label: 'Trombocitopenia <100.000/µL', pts: 4, checked: !!thrombocytopenia },
                    { label: 'Hemólisis autoinmune — Coombs directo + anemia', pts: 4, checked: !!hemolysis }
                ]
            },
            {
                key: 'neuropsychiatric', name: 'Neuropsiquiátrico', max: 5, icon: '🧠',
                criteria: [
                    { label: 'Delirium', pts: 2, checked: !!delirium },
                    { label: 'Psicosis', pts: 3, checked: !!psychosis },
                    { label: 'Convulsiones', pts: 5, checked: !!seizures }
                ]
            },
            {
                key: 'mucocutaneous', name: 'Mucocutáneo', max: 6, icon: '🔴',
                criteria: [
                    { label: 'Alopecia no cicatricial (parcheada o difusa)', pts: 2, checked: !!alopecia },
                    { label: 'Úlceras orales (paladar o mucosa oral)', pts: 2, checked: !!oralUlcers },
                    { label: 'Lupus cutáneo subagudo o discoide', pts: 4, checked: !!subacuteDiscoid },
                    { label: 'Lupus cutáneo agudo / eritema malar / fotosensibilidad', pts: 6, checked: !!acuteCutaneous }
                ]
            },
            {
                key: 'serosal', name: 'Seroso', max: 6, icon: '💧',
                criteria: [
                    { label: 'Derrame pleural o pericárdico', pts: 5, checked: !!effusion },
                    { label: 'Pericarditis aguda', pts: 6, checked: !!pericarditis }
                ]
            },
            {
                key: 'musculoskeletal', name: 'Musculoesquelético', max: 6, icon: '🦴',
                criteria: [{ label: 'Sinovitis ≥2 articulaciones o rigidez matutina ≥30 min', pts: 6, checked: !!joints }]
            },
            {
                key: 'renal', name: 'Renal', max: 10, icon: '🫘',
                criteria: [
                    { label: 'Proteinuria >0.5 g/24h o cociente Pr/Cr >0.5', pts: 4, checked: !!proteinuria },
                    { label: 'Biopsia renal: Nefritis lúpica clase II o V', pts: 8, checked: !!biopsy25 },
                    { label: 'Biopsia renal: Nefritis lúpica clase III o IV', pts: 10, checked: !!biopsy34 }
                ]
            }
        ];

        domainDefs.forEach(d => {
            d.score = domMax(d.criteria);
            markDomain(d.criteria, d.score);
        });

        const sAphospho = antiphospholipid === 'positive' ? 2 : 0;
        const sComp     = complement === 'both_low' ? 4 : complement === 'one_low' ? 3 : 0;
        const sSpecAb   = specificAb === 'positive' ? 6 : 0;
        const sImmuno   = sAphospho + sComp + sSpecAb;

        const immunoDef = {
            key: 'immunological', name: 'Inmunológico', max: 12, icon: '🔬',
            score: sImmuno, isAdditive: true,
            criteria: [
                { label: 'Anticuerpos antifosfolípidos', pts: 2, score: sAphospho, state: antiphospholipid },
                {
                    label: complement === 'both_low' ? 'Complemento C3 Y C4 bajos' :
                           complement === 'one_low'  ? 'Complemento C3 O C4 bajo'  :
                           complement === 'normal'   ? 'Complemento normal' : 'Complemento',
                    pts: complement === 'both_low' ? 4 : 3, score: sComp,
                    state: complement === 'not_done' ? 'not_done' : sComp > 0 ? 'positive' : 'negative'
                },
                { label: 'Anti-dsDNA o Anti-Sm', pts: 6, score: sSpecAb, state: specificAb }
            ]
        };

        const allDomains = [...domainDefs, immunoDef];
        const totalScore = allDomains.reduce((sum, d) => sum + d.score, 0);

        const anaPositive = ana === 'positive';
        const anaNotDone  = ana === 'not_done';
        const anaNegative = ana === 'negative';

        let classification;
        if (anaNotDone)                           classification = 'incomplete';
        else if (anaNegative)                     classification = 'ana_negative';
        else if (anaPositive && totalScore >= 10) classification = 'met';
        else if (anaPositive && totalScore >= 7)  classification = 'possible';
        else                                      classification = 'not_met';

        const pendingTests = [];
        if (anaNotDone)                           pendingTests.push({ test: 'ANA (HEp-2 ≥1:80)',                                                                pts: 'Criterio de entrada obligatorio' });
        if (antiphospholipid === 'not_done')      pendingTests.push({ test: 'Anticuerpos antifosfolípidos (anti-CL IgG, anti-β2GPI IgG, anticoagulante lúpico)', pts: '+2 pts si positivo' });
        if (complement === 'not_done')            pendingTests.push({ test: 'Complemento C3 y C4',                                                              pts: '+3-4 pts si bajos' });
        if (specificAb === 'not_done')            pendingTests.push({ test: 'Anti-dsDNA y Anti-Sm',                                                             pts: '+6 pts si positivo' });
        if (!proteinuria && !biopsy25 && !biopsy34) pendingTests.push({ test: 'Proteinuria 24h o cociente Pr/Cr',                                               pts: '+4 pts si >0.5 g/24h' });

        let maxAdditional = 0;
        if (antiphospholipid === 'not_done')      maxAdditional += 2;
        if (complement === 'not_done')            maxAdditional += 4;
        if (specificAb === 'not_done')            maxAdditional += 6;
        if (!proteinuria && !biopsy25 && !biopsy34) maxAdditional += 4;

        const classMap = {
            'met':          'Cumple criterios ACR/EULAR 2019 para LES',
            'possible':     'Score elevado — completar evaluación antes de clasificar',
            'not_met':      'No cumple criterios ACR/EULAR 2019',
            'incomplete':   'Score parcial — ANA pendiente',
            'ana_negative': 'LES muy improbable (ANA negativo, sensibilidad 97-99%)'
        };

        return {
            totalScore, classification, classLabel: classMap[classification],
            anaPositive, anaNotDone, anaNegative,
            pendingTests, maxAdditional,
            domains: allDomains,
            value: totalScore, unit: 'pts',
            interpretation: {
                label: classMap[classification],
                color: classification === 'met' ? 'danger' : 'info',
                description: `Score ACR/EULAR 2019: ${totalScore} pts. ${classMap[classification]}.`
            }
        };
    },

    // === 39. EPOC — CLASIFICACIÓN Y TRATAMIENTO (GOLD 2025) === //
    calculateEPOC(inputs) {
        const { fev1fvc, fev1, cat, mmrc, exacMod, hospitalization, eos } = inputs;

        // FEV1/FVC post-BD
        const fev1fvcNum = parseFloat(fev1fvc);
        const fev1fvcOk   = !isNaN(fev1fvcNum) && fev1fvcNum < 0.70;
        const fev1fvcHigh = !isNaN(fev1fvcNum) && fev1fvcNum >= 0.70;
        const fev1fvcND   = !fev1fvc || fev1fvc === '';

        // GOLD spirometric grade (only if FEV1/FVC < 0.70)
        const fev1Num = parseFloat(fev1);
        let goldGrade = null, goldLabel = null, goldColor = null;
        if (fev1fvcOk && !isNaN(fev1Num) && fev1Num > 0) {
            if (fev1Num >= 80)      { goldGrade = 1; goldLabel = 'GOLD 1 — Leve';      goldColor = '#22c55e'; }
            else if (fev1Num >= 50) { goldGrade = 2; goldLabel = 'GOLD 2 — Moderada';  goldColor = '#f59e0b'; }
            else if (fev1Num >= 30) { goldGrade = 3; goldLabel = 'GOLD 3 — Grave';     goldColor = '#f97316'; }
            else                   { goldGrade = 4; goldLabel = 'GOLD 4 — Muy grave';  goldColor = '#ef4444'; }
        }

        // CAT Score (8 ítems, 0–5 cada uno)
        const catArr = Array.isArray(cat) ? cat.map(v => parseInt(v) || 0) : [];
        const catScore = catArr.length === 8 ? catArr.reduce((a, b) => a + b, 0) : null;
        let catLevel = null, catColor = null;
        if (catScore !== null) {
            if (catScore <= 10)      { catLevel = 'Leve (≤10)';      catColor = '#22c55e'; }
            else if (catScore <= 20) { catLevel = 'Moderado (11–20)'; catColor = '#f59e0b'; }
            else if (catScore <= 30) { catLevel = 'Grave (21–30)';    catColor = '#f97316'; }
            else                    { catLevel = 'Muy grave (>30)';  catColor = '#ef4444'; }
        }

        // mMRC
        const mmrcNum = mmrc !== '' && mmrc !== null && mmrc !== undefined ? parseInt(mmrc) : null;
        const mmrcLabels = [
            'Solo con ejercicio intenso',
            'Al caminar rápido o en pendiente leve',
            'Camina más despacio o para al ritmo propio',
            'Para tras ~100 m o pocos minutos en llano',
            'Demasiada disnea para salir de casa o vestirse'
        ];

        // Symptom burden
        const highSymptoms = (catScore !== null && catScore >= 10) || (mmrcNum !== null && mmrcNum >= 2);

        // Exacerbations
        const exacModNum = parseInt(exacMod) || 0;
        const hospitBool = hospitalization === true || hospitalization === 'true';
        const frequentExac = exacModNum >= 2 || hospitBool;

        // ABE group
        let abeGroup = null, abeColor = null, abeLabel = null;
        if (catScore === null && mmrcNum === null) {
            abeGroup = null;
        } else if (frequentExac) {
            abeGroup = 'E'; abeColor = '#ef4444'; abeLabel = 'Grupo E — Exacerbador frecuente';
        } else if (highSymptoms) {
            abeGroup = 'B'; abeColor = '#f59e0b'; abeLabel = 'Grupo B — Más síntomas';
        } else {
            abeGroup = 'A'; abeColor = '#22c55e'; abeLabel = 'Grupo A — Pocos síntomas';
        }

        // Eosinophils
        const eosNum = eos !== '' && eos !== undefined && eos !== null ? parseFloat(eos) : null;

        // ICS guidance
        let icsNote = null;
        if (eosNum !== null) {
            if (eosNum >= 300)      icsNote = { level: 'keep',   text: 'eos ≥ 300: NO retirar ICS — alto riesgo de exacerbación (WISDOM trial)' };
            else if (eosNum >= 100) icsNote = { level: 'gray',   text: 'eos 100–299: zona gris — individualizar según exacerbaciones y efectos adversos' };
            else                   icsNote = { level: 'remove', text: 'eos < 100: se puede retirar el ICS con seguridad — beneficio mínimo, riesgo de neumonía' };
        }

        // Treatment
        let treatmentTitle = '', treatmentLines = [], treatmentColor = '#64748b';
        if (abeGroup === 'A') {
            treatmentTitle = 'Broncodilatador de acción larga en monoterapia';
            treatmentLines = [
                '🥇 LAMA o LABA (monoterapia)',
                '· LAMA: Tiotropio (Spiriva®), Glicopirronio (Seebri®), Umeclidinio (Incruse®)',
                '· LABA: Indacaterol (Onbrez®), Salmeterol, Formoterol, Olodaterol',
                'Si síntomas muy ocasionales → SABA/SAMA a demanda (salbutamol, ipratropio)'
            ];
            treatmentColor = '#22c55e';
        } else if (abeGroup === 'B') {
            treatmentTitle = 'LAMA preferido → escalar a LABA+LAMA si síntomas persisten';
            treatmentLines = [
                '🥇 LAMA (preferido sobre LABA en Grupo B)',
                '· Tiotropio (Spiriva®), Glicopirronio (Seebri®), Umeclidinio (Incruse®)',
                '🔼 Si síntomas persisten → LABA + LAMA:',
                '· Indacaterol/Glicopirronio (Ultibro®)',
                '· Vilanterol/Umeclidinio (Anoro® Ellipta)',
                '· Olodaterol/Tiotropio (Spiolto® Respimat)'
            ];
            treatmentColor = '#f59e0b';
        } else if (abeGroup === 'E') {
            if (eosNum === null) {
                treatmentTitle = 'LABA + LAMA — solicitar eosinófilos para refinar';
                treatmentLines = [
                    '🥇 LABA + LAMA (doble broncodilatación):',
                    '· Indacaterol/Glicopirronio (Ultibro®)',
                    '· Vilanterol/Umeclidinio (Anoro® Ellipta)',
                    '· Formoterol/Aclidinio (Duaklir® Genuair)',
                    'ℹ️ Solicitar eosinófilos para decidir si añadir ICS'
                ];
                treatmentColor = '#f97316';
            } else if (eosNum >= 300) {
                treatmentTitle = 'Triple terapia (LABA+LAMA+ICS) — eos ≥ 300 cél/µL';
                treatmentLines = [
                    '🥇 Triple terapia indicada:',
                    '· Fluticasona/Umeclidinio/Vilanterol (Trelegy® Ellipta)',
                    '· Budesonida/Glicopirronio/Formoterol (Breztri® Aerosphere)',
                    '· Beclometasona/Formoterol/Glicopirronio (Trimbow®)',
                    '📊 IMPACT trial (NEJM 2018): −25% exacerbaciones vs LABA+LAMA'
                ];
                treatmentColor = '#ef4444';
            } else if (eosNum >= 100) {
                treatmentTitle = 'LABA + LAMA → escalar a triple si exacerbaciones persisten';
                treatmentLines = [
                    '🥇 Base: LABA + LAMA',
                    '· Indacaterol/Glicopirronio (Ultibro®), Vilanterol/Umeclidinio (Anoro®)',
                    '🔼 Si exacerbaciones persisten pese a LABA+LAMA → triple terapia:',
                    '· Trelegy® Ellipta, Breztri® Aerosphere, Trimbow®',
                    '⚠️ eos 100–299: zona gris — individualizar decisión de ICS'
                ];
                treatmentColor = '#f97316';
            } else {
                treatmentTitle = 'LABA + LAMA — ICS NO recomendado (eos < 100)';
                treatmentLines = [
                    '🥇 LABA + LAMA (doble broncodilatación):',
                    '· Indacaterol/Glicopirronio (Ultibro®)',
                    '· Vilanterol/Umeclidinio (Anoro® Ellipta)',
                    '· Formoterol/Aclidinio (Duaklir® Genuair)',
                    '⛔ ICS NO indicado — eos < 100: beneficio mínimo, riesgo elevado de neumonía'
                ];
                treatmentColor = '#f97316';
            }
        }

        const descLabel = abeGroup ? `${abeLabel}${goldGrade ? ' · GOLD ' + goldGrade : ''}` : 'Completar datos';
        return {
            fev1fvcOk, fev1fvcHigh, fev1fvcND, fev1fvcNum,
            goldGrade, goldLabel, goldColor,
            catScore, catLevel, catColor, catArr,
            mmrcNum, mmrcLabel: mmrcNum !== null ? mmrcLabels[mmrcNum] : null,
            highSymptoms, exacModNum, hospitBool, frequentExac,
            abeGroup, abeColor, abeLabel,
            eosNum, icsNote,
            treatmentTitle, treatmentLines, treatmentColor,
            value: abeGroup || '—', unit: '(ABE)',
            description: descLabel,
            interpretation: {
                label: abeLabel || 'Datos incompletos',
                color: abeGroup === 'E' ? 'danger' : abeGroup === 'B' ? 'warning' : 'success',
                description: `Grupo ABE: ${abeGroup || '—'}. GOLD: ${goldGrade || '—'}. CAT: ${catScore ?? '—'}. mMRC: ${mmrcNum ?? '—'}. ${abeLabel || ''}.`
            }
        };
    },

    // === 38. FIB-4 / APRI — FIBROSIS HEPÁTICA === //
    calculateFibrosis(inputs) {
        const { age, ast, alt, platelets, plateletsUnit, lsnAst,
                spiderNevi, eritemaPalmar, ictericia, leuconiquia, dupuytren,
                ginecomastia, perdidaVello, sarcopenia,
                hepatomegalia, esplenomegalia, ascitis, caputMedusae, edema,
                asterixis, encefalopatia } = inputs;

        const ageNum  = parseFloat(age)  || 0;
        const astNum  = parseFloat(ast)  || 0;
        const altNum  = parseFloat(alt)  || 0;
        let   platNum = parseFloat(platelets) || 0;
        if (plateletsUnit === 'mm3') platNum = platNum / 1000;
        const lsnNum  = parseFloat(lsnAst) || 40;

        // FIB-4 = (Edad × AST) / (Plaquetas × √ALT)
        let fib4 = null;
        if (ageNum > 0 && astNum > 0 && altNum > 0 && platNum > 0) {
            fib4 = Math.round((ageNum * astNum) / (platNum * Math.sqrt(altNum)) * 100) / 100;
        }

        // APRI = (AST / LSN_AST × 100) / Plaquetas
        let apri = null;
        if (astNum > 0 && platNum > 0) {
            apri = Math.round(((astNum / lsnNum) * 100) / platNum * 100) / 100;
        }

        // FIB-4 cutoffs (ajustados si >65 años — AASLD 2023)
        const isOld = ageNum > 65;
        let fib4Zone = null, fib4Label = null, fib4Color = null;
        if (fib4 !== null) {
            if (isOld) {
                if (fib4 < 2.0)       { fib4Zone = 'low';  fib4Label = 'Bajo riesgo';     fib4Color = '#22c55e'; }
                else if (fib4 <= 3.25){ fib4Zone = 'gray'; fib4Label = 'Indeterminado';   fib4Color = '#f59e0b'; }
                else                  { fib4Zone = 'high'; fib4Label = 'Alto riesgo';     fib4Color = '#ef4444'; }
            } else {
                if (fib4 < 1.30)      { fib4Zone = 'low';  fib4Label = 'Fibrosis avanzada poco probable'; fib4Color = '#22c55e'; }
                else if (fib4 <= 2.67){ fib4Zone = 'gray'; fib4Label = 'Zona indeterminada';              fib4Color = '#f59e0b'; }
                else                  { fib4Zone = 'high'; fib4Label = 'Fibrosis avanzada probable';      fib4Color = '#ef4444'; }
            }
        }

        // APRI interpretation
        let apriZone = null, apriLabel = null, apriColor = null;
        if (apri !== null) {
            if (apri < 0.5)      { apriZone = 'low';      apriLabel = 'Fibrosis poco probable';    apriColor = '#22c55e'; }
            else if (apri < 1.0) { apriZone = 'gray';     apriLabel = 'Indeterminado';             apriColor = '#f59e0b'; }
            else if (apri < 2.0) { apriZone = 'moderate'; apriLabel = 'Fibrosis significativa';   apriColor = '#f97316'; }
            else                 { apriZone = 'high';     apriLabel = 'Cirrosis probable';         apriColor = '#ef4444'; }
        }

        // Estigmas clínicos
        const stigmataMap = { spiderNevi, eritemaPalmar, ictericia, leuconiquia, dupuytren,
                              ginecomastia, perdidaVello, sarcopenia,
                              hepatomegalia, esplenomegalia, ascitis, caputMedusae, edema,
                              asterixis, encefalopatia };
        const stigmataCount = Object.values(stigmataMap).filter(Boolean).length;

        // Interpretación combinada
        let combinedLabel, combinedColor, combinedRec, combinedColorName;
        if (!fib4Zone) {
            combinedLabel = 'Completar laboratorio para interpretación';
            combinedColor = '#64748b'; combinedColorName = 'info';
            combinedRec = 'Ingresa AST/TGO, ALT/TGP, plaquetas y edad para calcular FIB-4 y APRI.';
        } else if (fib4Zone === 'low' && stigmataCount < 2) {
            combinedLabel = 'Hepatopatía crónica avanzada poco probable';
            combinedColor = '#22c55e'; combinedColorName = 'success';
            combinedRec = 'Seguimiento según etiología. Repetir FIB-4 en 1–2 años si persisten factores de riesgo.';
        } else if (fib4Zone === 'low' && stigmataCount >= 2) {
            combinedLabel = 'Discordancia clínico-laboratorial';
            combinedColor = '#f59e0b'; combinedColorName = 'warning';
            combinedRec = 'Hallazgos clínicos no concordantes con laboratorio. Repetir labs en 3-6 meses, considerar elastografía o diagnóstico alternativo.';
        } else if (fib4Zone === 'gray' && stigmataCount === 0) {
            combinedLabel = 'Zona indeterminada — solicitar elastografía';
            combinedColor = '#f59e0b'; combinedColorName = 'warning';
            combinedRec = 'Solicitar elastografía hepática (FibroScan o SWE). Si no disponible, repetir FIB-4 en 6–12 meses.';
        } else if (fib4Zone === 'gray' && stigmataCount >= 1) {
            combinedLabel = 'Zona indeterminada con hallazgos clínicos';
            combinedColor = '#f97316'; combinedColorName = 'warning';
            combinedRec = 'Elastografía hepática prioritaria y valoración por hepatólogo. La clínica aumenta la sospecha.';
        } else if (fib4Zone === 'high' && stigmataCount < 2) {
            combinedLabel = 'Fibrosis avanzada — derivar a hepatólogo';
            combinedColor = '#f97316'; combinedColorName = 'warning';
            combinedRec = 'Elastografía hepática + derivación a hepatólogo. Evaluar complicaciones de hipertensión portal.';
        } else {
            combinedLabel = 'Probable cirrosis establecida';
            combinedColor = '#ef4444'; combinedColorName = 'danger';
            combinedRec = 'Derivar urgente a hepatólogo. Evaluar: endoscopia (várices), ecografía (hepatocarcinoma), Child-Pugh y MELD.';
        }

        return {
            fib4, apri, fib4Zone, fib4Label, fib4Color, apriZone, apriLabel, apriColor,
            stigmataCount, stigmataMap, combinedLabel, combinedColor, combinedRec, isOld,
            value: fib4 ?? '—', unit: '(FIB-4)',
            description: combinedLabel,
            interpretation: { label: combinedLabel, color: combinedColorName, description: `FIB-4: ${fib4 ?? '—'}. APRI: ${apri ?? '—'}. Estigmas: ${stigmataCount}. ${combinedLabel}.` }
        };
    },

    // === 37. PSI/PORT — ÍNDICE DE SEVERIDAD DE NEUMONÍA === //
    calculatePSI(inputs) {
        const { age, sex, nursingHome,
                neoplasia, liver, chf, cerebrovascular, renal,
                ams, rr30, sbp90, tempAbnormal, hr125,
                phAcidosis, bunHigh, sodiumLow, glucoseHigh, hctLow, hypoxia, effusion } = inputs;

        const ageNum = parseInt(age) || 0;

        // Paso 1 — Clase I: ≤50 años, sin comorbilidades, sin alteraciones de signos vitales
        const hasComorbidity = neoplasia || liver || chf || cerebrovascular || renal;
        const hasVitalAbnormality = ams || rr30 || sbp90 || tempAbnormal || hr125;
        const isClassI = ageNum <= 50 && !nursingHome && !hasComorbidity && !hasVitalAbnormality;

        // Paso 2 — Score (aplica si no es Clase I)
        let score = 0;
        const agePts = sex === 'F' ? Math.max(ageNum - 10, 0) : ageNum;
        score += agePts;
        if (nursingHome)     score += 10;
        if (neoplasia)       score += 30;
        if (liver)           score += 20;
        if (chf)             score += 10;
        if (cerebrovascular) score += 10;
        if (renal)           score += 10;
        if (ams)             score += 20;
        if (rr30)            score += 20;
        if (sbp90)           score += 20;
        if (tempAbnormal)    score += 15;
        if (hr125)           score += 10;
        if (phAcidosis)      score += 30;
        if (bunHigh)         score += 20;
        if (sodiumLow)       score += 20;
        if (glucoseHigh)     score += 10;
        if (hctLow)          score += 10;
        if (hypoxia)         score += 10;
        if (effusion)        score += 10;

        let riskClass, mortality, color, colorName, disposicion;
        if (isClassI) {
            riskClass = 'I';   mortality = '<0.1%'; color = '#22c55e'; colorName = 'success';
            disposicion = 'Tratamiento ambulatorio';
        } else if (score <= 70) {
            riskClass = 'II';  mortality = '0.6%';  color = '#22c55e'; colorName = 'success';
            disposicion = 'Tratamiento ambulatorio';
        } else if (score <= 90) {
            riskClass = 'III'; mortality = '2.8%';  color = '#f59e0b'; colorName = 'warning';
            disposicion = 'Observación breve o ingreso hospitalario corto';
        } else if (score <= 130) {
            riskClass = 'IV';  mortality = '8.2%';  color = '#f97316'; colorName = 'warning';
            disposicion = 'Hospitalización en sala';
        } else {
            riskClass = 'V';   mortality = '29.2%'; color = '#ef4444'; colorName = 'danger';
            disposicion = 'Hospitalización — considerar UCI';
        }

        const scoreDisplay = isClassI ? 'N/A' : String(score);
        return {
            score, isClassI, riskClass, mortality, color, colorName, disposicion, agePts,
            value: isClassI ? 'I' : score, unit: isClassI ? '(Clase I)' : 'pts',
            description: `PSI Clase ${riskClass}`,
            interpretation: {
                label: `Clase ${riskClass} — ${disposicion}`,
                color: colorName,
                description: `PSI Clase ${riskClass}. Score: ${scoreDisplay} pts. Mortalidad a 30 días: ${mortality}. ${disposicion}.`
            }
        };
    },

    // === 36. KILLIP-KIMBALL === //
    calculateKillip({ estertores, s3, jvd, pasBaja, hipoperfusion }) {
        let clase = null, warning = null;
        if (pasBaja && hipoperfusion) {
            clase = 4;
        } else if (pasBaja && !hipoperfusion) {
            clase = null;
            warning = 'PAS <90 mmHg sin hipoperfusión periférica completa — verificar: ¿hipovolemia?, ¿bradiarritmia?. Si se confirma hipoperfusión → Clase IV.';
        } else if (estertores === 'mayor_mitad') {
            clase = 3;
        } else if (s3 || estertores === 'menor_mitad' || jvd) {
            clase = 2;
        } else {
            clase = 1;
        }
        const data = {
            1: { label: 'Clase I',   desc: 'Sin signos de insuficiencia cardíaca', mortalidadHist: '~6%',  mortalidadAct: '1–2%',   color: '#22c55e', colorName: 'success' },
            2: { label: 'Clase II',  desc: 'Insuficiencia cardíaca leve',          mortalidadHist: '~17%', mortalidadAct: '4–6%',   color: '#f59e0b', colorName: 'warning' },
            3: { label: 'Clase III', desc: 'Edema agudo de pulmón',                mortalidadHist: '~38%', mortalidadAct: '8–12%',  color: '#f97316', colorName: 'warning' },
            4: { label: 'Clase IV',  desc: 'Shock cardiogénico',                   mortalidadHist: '~81%', mortalidadAct: '40–60%', color: '#ef4444', colorName: 'danger'  },
        };
        if (!clase) {
            return {
                clase: null, warning,
                value: null, unit: '',
                description: 'Indeterminado',
                interpretation: { label: 'Indeterminado', color: 'warning', description: warning || 'No se puede determinar la clase con los datos ingresados.' }
            };
        }
        const d = data[clase];
        return {
            clase, label: d.label, desc: d.desc,
            mortalidadHist: d.mortalidadHist, mortalidadAct: d.mortalidadAct,
            color: d.color, colorName: d.colorName, warning,
            value: clase, unit: `(${d.desc})`,
            description: d.desc,
            interpretation: {
                label: d.label, color: d.colorName,
                description: `${d.label}: ${d.desc}. Mortalidad intrahospitalaria histórica: ${d.mortalidadHist}. Contemporánea: ${d.mortalidadAct}.`
            }
        };
    },

    // === 40. ESTADO HIPEROSMOLAR HIPERGLUCÉMICO (EHH/HHS) === //
    calculateHHS(inputs) {
        let { weight, hemodynamic, glucose, glucoseUnit, sodium, potassium, chloride, mentalStatus } = inputs;

        const weightUnit = Storage.getSetting('units.weight');
        if (weightUnit === 'lb') weight = weight / 2.20462;
        if (glucoseUnit === 'mmol/L') glucose = glucose / 0.0555;

        // Na corregido (mismo factor 2.4 usado en CAD/CADE — ADA 2024)
        const naCorregido = Math.round((sodium + 2.4 * (glucose - 100) / 100) * 10) / 10;

        // Osmolaridad sérica efectiva — variable diagnóstica clave en EHH (>320 mOsm/kg)
        const osmEffective = Math.round((2 * sodium + glucose / 18) * 10) / 10;

        const agCalc = (chloride !== null && !isNaN(chloride))
            ? Math.round((sodium - chloride) * 10) / 10
            : null;

        // Clasificación de severidad por osmolaridad + estado mental
        let severity;
        if (osmEffective < 320) {
            severity = { label: 'Osm <320 — Reevaluar diagnóstico', colorHex: '#64748b', badge: '⚪' };
        } else if (osmEffective >= 350 || mentalStatus === 'coma') {
            severity = { label: 'EHH Severo', colorHex: '#dc2626', badge: '🔴' };
        } else if (osmEffective >= 330 || mentalStatus === 'estupor') {
            severity = { label: 'EHH Moderado', colorHex: '#f59e0b', badge: '🟠' };
        } else {
            severity = { label: 'EHH Leve', colorHex: '#eab308', badge: '🟡' };
        }

        const criticalAlert = potassium < 3.3
            ? { hasAlert: true, message: `K⁺ ${potassium} mEq/L — RETENER INSULINA. Reponer potasio primero. Riesgo de arritmia fatal.` }
            : { hasAlert: false };

        // Fluidos — déficit típico 8-10 L, reposición MÁS LENTA y cautelosa que en CAD
        let bolusML, bolusTime;
        if (hemodynamic === 'severe') {
            bolusML = Math.round(weight * 15); bolusTime = '1 hora, reevaluar respuesta hemodinámica';
        } else if (hemodynamic === 'cardiogenic') {
            bolusML = 250; bolusTime = '30-60 min con monitoreo hemodinámico estrecho (considerar línea arterial)';
        } else if (hemodynamic === 'euvolemic') {
            bolusML = Math.round(weight * 7); bolusTime = '1 hora';
        } else {
            bolusML = Math.round(weight * 10); bolusTime = '1 hora';
        }

        const fluidType = naCorregido > 150 ? 'NaCl 0.45%' : 'NaCl 0.9% o cristaloide balanceado';
        const naNote = naCorregido > 150
            ? `Na corregido ${naCorregido} mEq/L (elevado) → usar NaCl 0.45% tras la primera hora`
            : `Na corregido ${naCorregido} mEq/L → continuar NaCl 0.9%/balanceado`;

        // Potasio (mismos umbrales que CAD)
        let kAction, kRate, holdInsulin, kNote;
        if (potassium < 3.3) {
            kAction = 'RETENER INSULINA — Reponer K⁺ primero';
            kRate = '20-40 mEq/h IV'; holdInsulin = true;
            kNote = 'Monitoreo ECG continuo. Reiniciar/iniciar insulina cuando K⁺ ≥ 3.3 mEq/L.';
        } else if (potassium <= 4.0) {
            kAction = 'Reponer + iniciar insulina'; kRate = '20 mEq/h IV'; holdInsulin = false;
            kNote = 'Monitoreo ECG continuo. Reponer Mg²⁺ si está bajo.';
        } else if (potassium <= 5.5) {
            kAction = 'Reponer (dosis reducida) + iniciar insulina'; kRate = '10 mEq/h IV'; holdInsulin = false;
            kNote = 'K⁺ descenderá con insulina y expansión de volumen.';
        } else {
            kAction = 'No reponer — iniciar insulina'; kRate = '—'; holdInsulin = false;
            kNote = 'Hiperkalemia por redistribución/depleción de volumen — descenderá con el tratamiento.';
        }

        // Insulina — dosis MENOR que CAD y de inicio DIFERIDO (tras ≥1h de fluidos)
        const doseIV = Math.round(weight * 0.05 * 100) / 100;
        const glarginMin = Math.round(weight * 0.5);
        const glarginMax = Math.round(weight * 0.8);

        return {
            severity, criticalAlert,
            naCorregido, agCalc, osmEffective,
            fluids: { bolusML, bolusTime, fluidType, naNote, hemodynamic },
            potassium: { kAction, kRate, holdInsulin, kNote, value: potassium },
            insulin: { doseIV, holdInsulin },
            resolution: { osmEffective },
            transition: { glarginMin, glarginMax },
            value: weight,
            unit: 'kg',
            interpretation: { label: severity.label, color: 'danger', description: 'Protocolo de Estado Hiperosmolar Hiperglucémico generado.' }
        };
    },

    // === 41. CRISIS HIPERTENSIVA === //
    calculateHypertensiveCrisis(inputs) {
        const { sbp, dbp, damages, thromboCandidate } = inputs;

        const DAMAGE_PROTOCOLS = {
            acv_isquemico: {
                label: 'ACV Isquémico Agudo',
                color: '#6366f1',
                drug: thromboCandidate
                    ? 'Labetalol IV o Nicardipino IV'
                    : 'Solo tratar si PA > 220/120 mmHg — Labetalol o Nicardipino IV',
                target: thromboCandidate
                    ? 'Bajar a < 185/110 mmHg ANTES de trombólisis; mantener < 180/105 mmHg las primeras 24h post-trombólisis'
                    : 'Reducir PA solo ~15% en las primeras 24h si no es candidato a trombólisis (hipertensión permisiva)',
                notes: 'No usar Nifedipino sublingual — caídas bruscas de PA extienden el área de penumbra isquémica.'
            },
            acv_hemorragico: {
                label: 'ACV Hemorrágico',
                color: '#4f46e5',
                drug: 'Nicardipino IV o Labetalol IV',
                target: 'Si PAS 150-220 mmHg: bajar a PAS objetivo ~140 mmHg (evitar < 130 mmHg)',
                notes: 'Reducción rápida pero controlada — objetivo alcanzado en la primera hora, con monitorización neurológica estrecha.'
            },
            disec_aortica: {
                label: 'Disección Aórtica',
                color: '#ef4444',
                drug: 'Esmolol o Labetalol IV PRIMERO (control de FC) + Nitroprusiato o Nicardipino después',
                target: 'FC < 60 lpm y PAS 100-120 mmHg en 20 minutos',
                notes: 'NUNCA iniciar vasodilatador puro sin betabloqueo previo — la taquicardia refleja aumenta el estrés de cizallamiento aórtico (dP/dt). Cirugía/endovascular urgente si tipo A.'
            },
            eap: {
                label: 'Edema Agudo de Pulmón / Falla Cardíaca Aguda',
                color: '#0ea5e9',
                drug: 'Nitroglicerina IV ± diurético de asa (Furosemida)',
                target: 'Mejoría sintomática y de la precarga — reducir PA gradualmente según tolerancia',
                notes: 'Soporte ventilatorio (VNI) según hipoxemia. Evitar betabloqueantes IV en fase aguda descompensada.'
            },
            sca: {
                label: 'Síndrome Coronario Agudo',
                color: '#dc2626',
                drug: 'Nitroglicerina IV + Betabloqueante (si no contraindicado)',
                target: 'Aliviar isquemia — reducir PAM ~25% evitando hipotensión (perfusión coronaria)',
                notes: 'Evaluar coronariografía/reperfusión según protocolo de SCA — no retrasar por el manejo tensional.'
            },
            encefalopatia: {
                label: 'Encefalopatía Hipertensiva',
                color: '#8b5cf6',
                drug: 'Nicardipino IV o Labetalol IV',
                target: 'Reducir la PAM 20-25% en la primera hora',
                notes: 'Diagnóstico de exclusión (descartar ACV/HSA). Mejoría del estado mental confirma el diagnóstico retrospectivamente.'
            },
            preeclampsia_eclampsia: {
                label: 'Preeclampsia Severa / Eclampsia',
                color: '#db2777',
                drug: 'Labetalol IV o Hidralazina IV + Sulfato de Magnesio (profilaxis/tto de convulsiones)',
                target: 'PAS < 160 y PAD < 110 mmHg',
                notes: 'Sulfato de Magnesio es obligatorio si eclampsia o preeclampsia con criterios de severidad — no solo antihipertensivo. Finalización del embarazo según edad gestacional y estabilidad materno-fetal.'
            },
            ira: {
                label: 'Daño Renal Agudo / Microangiopatía',
                color: '#f97316',
                drug: 'Nicardipino IV o Labetalol IV',
                target: 'Reducir PAM 20-25% en la primera hora, evitando hipoperfusión renal',
                notes: 'Evitar diuréticos si hay depleción de volumen concomitante. Descartar HTA maligna con esquistocitos/hemólisis.'
            },
            retinopatia: {
                label: 'Retinopatía Hipertensiva Grado III-IV',
                color: '#0d9488',
                drug: 'Labetalol o Nicardipino IV (o manejo oral si estable)',
                target: 'Reducir PAM 20-25% en 24-48h',
                notes: 'Papiledema/hemorragias retinianas — fondo de ojo urgente y control ambulatorio estrecho tras el alta.'
            }
        };

        const validDamages = (damages || []).filter(d => DAMAGE_PROTOCOLS[d]);
        const isEmergency = validDamages.length > 0;
        const sections = validDamages.map(d => DAMAGE_PROTOCOLS[d]);

        const severity = isEmergency
            ? { label: 'Emergencia Hipertensiva', colorHex: '#dc2626', badge: '🔴' }
            : { label: 'Urgencia Hipertensiva', colorHex: '#f59e0b', badge: '🟡' };

        return {
            sbp, dbp, isEmergency, severity, sections,
            value: sbp, unit: 'mmHg',
            interpretation: {
                label: severity.label, color: isEmergency ? 'danger' : 'warning',
                description: isEmergency
                    ? 'PA severamente elevada CON daño agudo de órgano diana — manejo IV hospitalario inmediato.'
                    : 'PA severamente elevada SIN daño agudo de órgano diana — manejo oral ambulatorio, reducción gradual en 24-48h.'
            }
        };
    },

    // === 42. ESTATUS EPILÉPTICO === //
    calculateStatusEpilepticus(inputs) {
        let { weight, stage, ivAccess, hepatopatia, embarazo, hipoglucemia } = inputs;

        const weightUnit = Storage.getSetting('units.weight');
        if (weightUnit === 'lb') weight = weight / 2.20462;

        const lorazepamDose = Math.min(Math.round(weight * 0.1 * 10) / 10, 4);
        const diazepamDose = Math.min(Math.round(weight * 0.2 * 10) / 10, 10);
        const midazolamIM = weight >= 40 ? 10 : 5;
        const levetiracetamDose = Math.min(Math.round(weight * 60), 4500);
        const fosfenitoinaDose = Math.min(Math.round(weight * 20), 1500);
        const valproatoDose = Math.min(Math.round(weight * 40), 3000);

        const avoidValproate = hepatopatia || embarazo;

        const stageOrder = { temprano: 0, establecido: 1, refractario: 2 };
        const currentStage = stageOrder[stage] ?? 0;

        return {
            weight, stage, currentStage, ivAccess,
            hipoglucemia, avoidValproate,
            benzo: { lorazepamDose, diazepamDose, midazolamIM, ivAccess },
            segundaLinea: { levetiracetamDose, fosfenitoinaDose, valproatoDose, avoidValproate },
            value: weight,
            unit: 'kg',
            interpretation: {
                label: stage === 'refractario' ? 'Estatus Refractario' : stage === 'establecido' ? 'Estatus Establecido' : 'Estatus Incipiente',
                color: 'danger',
                description: 'Protocolo escalonado de estatus epiléptico generado.'
            }
        };
    },

    // === 43. SEPSIS / SHOCK SÉPTICO — BUNDLE TERAPÉUTICO === //
    calculateSepsisBundle(inputs) {
        let { weight, lactato, pam, hipotensionPersistente, foco } = inputs;

        const weightUnit = Storage.getSetting('units.weight');
        if (weightUnit === 'lb') weight = weight / 2.20462;

        const fluidBolusML = Math.round(weight * 30);
        const needsBolus = (pam < 65) || (lactato >= 4);
        const pamTarget = 65;

        const shockSeptico = pam < 65 && hipotensionPersistente;

        const severity = shockSeptico
            ? { label: 'Shock Séptico (hipotensión refractaria a fluidos)', colorHex: '#dc2626', badge: '🔴' }
            : (lactato >= 2)
                ? { label: 'Sepsis con hipoperfusión (lactato elevado)', colorHex: '#f59e0b', badge: '🟠' }
                : { label: 'Sepsis', colorHex: '#eab308', badge: '🟡' };

        return {
            weight, lactato, pam, foco, needsBolus, shockSeptico,
            fluidBolusML, pamTarget, severity,
            value: lactato, unit: 'mmol/L',
            interpretation: {
                label: severity.label, color: 'danger',
                description: 'Bundle de la primera hora (Surviving Sepsis Campaign) generado.'
            }
        };
    },

    // === 44. EDEMA AGUDO DE PULMÓN / ICA DESCOMPENSADA === //
    calculateEAP(inputs) {
        const { sbp, spo2, hypoperfusion, congestion, causa } = inputs;

        const hypoCount = Object.values(hypoperfusion).filter(Boolean).length;
        const congCount = Object.values(congestion).filter(Boolean).length;

        const isFrio = hypoCount >= 1 || sbp < 90;
        const isHumedo = congCount >= 1;
        const shockCardiogenico = sbp < 90 && hypoCount >= 1;

        let profile;
        if (!isFrio && isHumedo) {
            profile = { key: 'caliente-humedo', label: 'Caliente y Húmedo', colorHex: '#f59e0b', badge: '🟠', freq: 'El más frecuente (~70%)' };
        } else if (isFrio && isHumedo) {
            profile = { key: 'frio-humedo', label: 'Frío y Húmedo', colorHex: '#dc2626', badge: '🔴', freq: 'Bajo gasto + congestión' };
        } else if (isFrio && !isHumedo) {
            profile = { key: 'frio-seco', label: 'Frío y Seco', colorHex: '#7c3aed', badge: '🟣', freq: 'Poco frecuente — hipoperfusión sin congestión franca' };
        } else {
            profile = { key: 'caliente-seco', label: 'Caliente y Seco', colorHex: '#22c55e', badge: '🟢', freq: 'Compensado' };
        }

        const needsNIV = spo2 < 90;

        const severity = shockCardiogenico
            ? { label: 'Shock Cardiogénico', colorHex: '#7f1d1d', badge: '🚨' }
            : { label: `Perfil: ${profile.label}`, colorHex: profile.colorHex, badge: profile.badge };

        return {
            sbp, spo2, causa, profile, isFrio, isHumedo, needsNIV, shockCardiogenico, severity,
            value: sbp, unit: 'mmHg',
            interpretation: {
                label: severity.label, color: 'danger',
                description: `Perfil hemodinámico ${profile.label} (Forrester/Nohria-Stevenson). Protocolo de EAP/ICA descompensada generado.`
            }
        };
    },

    // === 45. PROTOCOLO DE ARRITMIAS === //
    calculateArritmia(inputs) {
        let { tipo, ritmoParo, inestable, efReducida, preexcitacion, qtLargo, adenosinaFallida, weight } = inputs;

        if (tipo === 'paro') {
            const label = ritmoParo === 'desfibrilable' ? 'Paro Cardíaco — Ritmo Desfibrilable (FV/TVSP)' : 'Paro Cardíaco — Ritmo No Desfibrilable (Asistolia/AESP)';
            return {
                tipo, ritmoParo, inestable: true, isArrest: true,
                severity: { label, colorHex: '#7f1d1d', badge: '🚨' },
                value: 0, unit: '',
                interpretation: { label, color: 'danger', description: 'Protocolo de paro cardíaco (ACLS) generado.' }
            };
        }

        const weightUnit = Storage.getSetting('units.weight');
        if (weight && weightUnit === 'lb') weight = weight / 2.20462;
        const procainamidaMaxMg = weight ? Math.round(weight * 17) : null;

        const CARDIOVERSION_J = {
            bradicardia: null,
            taqui_estrecha_regular: '50-100 J',
            taqui_estrecha_irregular: '120-200 J',
            taqui_ancha_regular: '100 J',
            taqui_ancha_polimorfica: null // tratar como FV — desfibrilación no sincronizada
        };

        const TIPO_LABELS = {
            bradicardia: 'Bradicardia Sintomática',
            taqui_estrecha_regular: 'Taquicardia de Complejo Estrecho Regular (SVT/PSVT)',
            taqui_estrecha_irregular: 'Taquicardia de Complejo Estrecho/Ancho Irregular (FA/Flutter con RVR)',
            taqui_ancha_regular: 'Taquicardia de Complejo Ancho Regular Monomórfica (TV estable)',
            taqui_ancha_polimorfica: 'Taquicardia de Complejo Ancho Polimórfica / Torsades'
        };

        const severity = inestable
            ? { label: `${TIPO_LABELS[tipo]} — INESTABLE`, colorHex: '#dc2626', badge: '🔴' }
            : { label: `${TIPO_LABELS[tipo]} — Estable`, colorHex: '#eab308', badge: '🟡' };

        // La TV polimórfica/Torsades es intrínsecamente irregular — no se puede sincronizar de forma fiable
        const requiresDefibrillation = tipo === 'taqui_ancha_polimorfica' && inestable;

        return {
            tipo, inestable, isArrest: false,
            efReducida: !!efReducida, preexcitacion: !!preexcitacion, qtLargo: !!qtLargo, adenosinaFallida: !!adenosinaFallida,
            weight, procainamidaMaxMg,
            cardioversionJ: CARDIOVERSION_J[tipo] || null,
            requiresDefibrillation,
            severity,
            value: 0, unit: '',
            interpretation: {
                label: severity.label, color: 'danger',
                description: `Protocolo de manejo de ${TIPO_LABELS[tipo]} generado (AHA ACLS 2020).`
            }
        };
    },

    // === 46. PARO CARDÍACO — RCP + BÚSQUEDA GUIADA DE CAUSA (6H/5T) === //
    CAUSAS_PARO: [
        {
            id: 'hipovolemia', label: 'Hipovolemia', icon: '🩸', letra: 'H',
            clues: [
                'Antecedente de hemorragia activa o trauma reciente',
                'POCUS con VCI colapsada, o taquicardia/hipotensión marcada previa al paro'
            ],
            action: 'Bolo de cristaloides 1-2 L IV/IO rápido (o hemoderivados si hemorragia activa). Controlar el sangrado en paralelo (compresión, torniquete, cirugía/angioembolización urgente si es quirúrgico).'
        },
        {
            id: 'hipoxia', label: 'Hipoxia', icon: '🫁', letra: 'H',
            clues: [
                'Vía aérea difícil/obstruida o hipoxemia severa antes del paro',
                'Ahogamiento, asfixia o aspiración presenciada'
            ],
            action: 'Optimizar la vía aérea (intubación si no está asegurada) y ventilar con O₂ al 100%. Verificar posición del tubo endotraqueal y capnografía — el desplazamiento/obstrucción del tubo es causa frecuente de hipoxia iatrogénica durante la RCP.'
        },
        {
            id: 'acidosis', label: 'Hidrogeniones (Acidosis)', icon: '🧪', letra: 'H',
            clues: [
                'Cetoacidosis diabética o acidosis metabólica severa conocida',
                'Enfermedad renal crónica terminal sin diálisis reciente, o sepsis/shock prolongado previo'
            ],
            action: 'Asegurar ventilación adecuada (elimina CO₂). Bicarbonato de sodio 1 mEq/kg IV SOLO si acidosis metabólica severa confirmada o muy sospechada (uso NO rutinario en todo paro). Diálisis emergente en paralelo si ERC terminal.'
        },
        {
            id: 'kalemia', label: 'Hipo/Hiperkalemia', icon: '⚡', letra: 'H',
            clues: [
                'ERC en diálisis con sesión perdida, uso de IECA/ARA-II/espironolactona, o rabdomiólisis (sugiere Hiperkalemia)',
                'Vómitos/diarrea severa o uso de diuréticos (sugiere Hipokalemia)',
                'ECG previo con T picudas/QRS ancho (Hiperkalemia) u onda U prominente/QT largo (Hipokalemia)'
            ],
            isKalemia: true,
            hyperAction: '<strong>Hiperkalemia:</strong> Gluconato de calcio 1 g IV en bolo (o Cloruro de calcio 1 g IV) — estabiliza la membrana. Luego Insulina 10 U + Dextrosa 50% 25 g IV — desplaza K⁺ al intracelular. Bicarbonato de sodio 1 mEq/kg IV. Salbutamol nebulizado/IV. Considerar diálisis emergente si refractaria.',
            hypoAction: '<strong>Hipokalemia:</strong> Reposición de K⁺ IV en bolos monitorizados (típicamente 10-20 mEq bajo supervisión estrecha durante el paro) — corregir Mg²⁺ concomitante si está bajo.'
        },
        {
            id: 'hipotermia', label: 'Hipotermia', icon: '🥶', letra: 'H',
            clues: [
                'Exposición al frío o inmersión en agua fría',
                'Hallazgos de hipotermia al examen (piel fría, rigidez) sin causa térmica ambiental clara'
            ],
            action: 'Recalentamiento activo: interno si &lt;30°C (lavado peritoneal/torácico caliente, ECMO si disponible) o externo si 30-34°C. RCP prolongada — no declarar fallecimiento hasta recalentar ("nadie está muerto hasta que está caliente y muerto"). Limitar a 1 dosis de Epinefrina y espaciar las descargas hasta alcanzar &gt;30°C.'
        },
        {
            id: 'hipoglucemia', label: 'Hipoglucemia', icon: '🍬', letra: 'H',
            clues: ['Diabético en tratamiento con insulina o sulfonilurea'],
            action: 'Dextrosa 50% 25-50 mL (12.5-25 g) IV en bolo directo. Repetir glucemia a los 5-10 min.'
        },
        {
            id: 'neumotorax', label: 'Neumotórax a Tensión', icon: '💨', letra: 'T',
            clues: [
                'Trauma torácico o ventilación mecánica reciente',
                'Ausencia unilateral de murmullo vesicular + ingurgitación yugular o dificultad progresiva para ventilar'
            ],
            action: 'Descompresión con aguja (2º espacio intercostal línea medioclavicular, o 4-5º espacio línea axilar anterior) o toracostomía con dedo/tubo de tórax — inmediata, NO esperar radiografía.'
        },
        {
            id: 'taponamiento', label: 'Taponamiento Cardíaco', icon: '🫀', letra: 'T',
            clues: [
                'Trauma torácico penetrante, o neoplasia/pericarditis/insuficiencia renal conocida',
                'POCUS con derrame pericárdico, o AESP con buena contractilidad/FC preservada'
            ],
            action: 'Pericardiocentesis emergente (guiada por ecografía si disponible). Considerar toracotomía de reanimación si trauma penetrante con paro presenciado reciente.'
        },
        {
            id: 'toxicos', label: 'Tóxicos', icon: '💊', letra: 'T',
            clues: [
                'Antecedente de sobredosis/ingesta o frascos de medicamentos/drogas en la escena',
                'Pupilas mióticas (opioides) o QRS ancho en ECG previo (tricíclicos/bloqueadores de sodio)'
            ],
            action: 'Antídoto según sospecha: Naloxona 0.4-2 mg IV/IM/IN si opioides. Bicarbonato de sodio 1-2 mEq/kg IV en bolo si QRS ancho por tricíclicos/bloqueadores de sodio. Gluconato de calcio + Glucagón 3-5 mg IV + Insulina-dextrosa en dosis altas si betabloqueante/calcioantagonista. Emulsión lipídica IV 20% (bolo 1.5 mL/kg, luego infusión) si toxicidad por anestésicos locales u otros lipofílicos refractaria.'
        },
        {
            id: 'trombosis_pulmonar', label: 'Trombosis Pulmonar (TEP masivo)', icon: '🫁', letra: 'T',
            clues: [
                'Factores de riesgo de TVP/TEP (cirugía/inmovilización reciente, cáncer activo, embarazo)',
                'Disnea súbita o colapso presenciado, o POCUS con dilatación aguda de VD'
            ],
            action: 'Considerar Trombolisis durante el paro (Alteplasa 50 mg IV en bolo) si alta sospecha de TEP masivo como causa. Continuar RCP al menos 60-90 min tras la trombolisis antes de suspender esfuerzos.'
        },
        {
            id: 'trombosis_coronaria', label: 'Trombosis Coronaria (SCA)', icon: '❤️', letra: 'T',
            clues: [
                'Dolor torácico previo al paro o factores de riesgo cardiovascular mayores',
                'Elevación del ST en ECG previo al paro, si se registró'
            ],
            action: 'Tras lograr RCE: ECG de 12 derivaciones inmediato y cateterismo cardíaco urgente/angioplastia primaria si hay elevación del ST o alta sospecha de SCA como causa.'
        }
    ],

    calculateParo(inputs) {
        const { ritmo, clues, glucemia, potasio, temperatura } = inputs;

        const causas = this.CAUSAS_PARO.map(c => {
            const checked = (clues?.[c.id] || []).filter(Boolean).length;
            let overrideHit = false, hyperFlag = false, hypoFlag = false;

            if (c.id === 'hipoglucemia' && typeof glucemia === 'number' && !isNaN(glucemia) && glucemia < 60) overrideHit = true;
            if (c.id === 'hipotermia' && typeof temperatura === 'number' && !isNaN(temperatura) && temperatura < 32) overrideHit = true;
            if (c.id === 'kalemia' && typeof potasio === 'number' && !isNaN(potasio)) {
                if (potasio > 6.5) { overrideHit = true; hyperFlag = true; }
                else if (potasio < 2.5) { overrideHit = true; hypoFlag = true; }
            }

            const matchedCount = checked + (overrideHit ? 1 : 0);

            // Para la causa combinada de kalemia, determinar qué acción(es) mostrar
            if (c.isKalemia && matchedCount > 0) {
                const cluesArr = clues?.[c.id] || [];
                if (cluesArr[0]) hyperFlag = true;
                if (cluesArr[1]) hypoFlag = true;
                if (!hyperFlag && !hypoFlag) { hyperFlag = true; hypoFlag = true; } // solo pista ECG ambigua u override sin dirección clara
            }

            return { ...c, matchedCount, hyperFlag, hypoFlag };
        });

        const causasRankeadas = causas
            .filter(c => c.matchedCount > 0)
            .sort((a, b) => b.matchedCount - a.matchedCount || (a.letra === b.letra ? 0 : a.letra === 'H' ? -1 : 1));

        const sinHallazgos = causasRankeadas.length === 0;

        const severity = ritmo === 'desfibrilable'
            ? { label: 'Paro Cardíaco — Ritmo Desfibrilable (FV/TVSP)', colorHex: '#7f1d1d', badge: '🚨' }
            : { label: 'Paro Cardíaco — Ritmo No Desfibrilable (Asistolia/AESP)', colorHex: '#7f1d1d', badge: '🚨' };

        return {
            ritmo, causasRankeadas, sinHallazgos, todasLasCausas: causas, severity,
            value: 0, unit: '',
            interpretation: {
                label: severity.label, color: 'danger',
                description: 'Protocolo de paro cardíaco con búsqueda guiada de causa (6H/5T) generado.'
            }
        };
    },

    // === 47. DENGUE — CLASIFICACIÓN OMS GRUPO A/B/C === //
    calculateDengue(inputs) {
        let { alarma, gravedad, comorbilidad, weight, sbp, dbp } = inputs;

        const weightUnit = Storage.getSetting('units.weight');
        if (weight && weightUnit === 'lb') weight = weight / 2.20462;

        const tieneGravedad = Object.values(gravedad || {}).some(Boolean);
        const tieneAlarma = Object.values(alarma || {}).some(Boolean);
        const tieneComorbilidad = Object.values(comorbilidad || {}).some(Boolean);

        let grupo;
        if (tieneGravedad) grupo = 'C';
        else if (tieneAlarma || tieneComorbilidad) grupo = 'B';
        else grupo = 'A';

        const forzadoPorComorbilidad = grupo === 'B' && !tieneAlarma && tieneComorbilidad;

        const pulsePressure = (typeof sbp === 'number' && typeof dbp === 'number') ? sbp - dbp : null;
        const shockHipotenso = typeof sbp === 'number' && sbp < 90;
        const shockCompensado = !shockHipotenso && pulsePressure !== null && pulsePressure < 20;

        // Fluidos (solo Grupo B/C, requieren peso)
        let fluidos = null;
        if (weight && (grupo === 'B' || grupo === 'C')) {
            if (grupo === 'B') {
                fluidos = {
                    fase1: Math.round(weight * 5) + '-' + Math.round(weight * 7) + ' mL/h (1-2h)',
                    fase2: Math.round(weight * 3) + '-' + Math.round(weight * 5) + ' mL/h (2-4h)',
                    fase3: Math.round(weight * 2) + '-' + Math.round(weight * 3) + ' mL/h (mantenimiento)'
                };
            } else {
                fluidos = {
                    boloCompensado: Math.round(weight * 5) + '-' + Math.round(weight * 10) + ' mL en 1h',
                    boloHipotenso: Math.round(weight * 20) + ' mL en 15-30min'
                };
            }
        }

        const severity = {
            C: { label: 'Dengue Grave — Grupo C', colorHex: '#7f1d1d', badge: '🚨' },
            B: { label: 'Dengue con Signos de Alarma — Grupo B', colorHex: '#dc2626', badge: '🔴' },
            A: { label: 'Dengue sin Signos de Alarma — Grupo A', colorHex: '#22c55e', badge: '🟢' }
        }[grupo];

        return {
            grupo, forzadoPorComorbilidad, shockHipotenso, shockCompensado, pulsePressure,
            weight, fluidos, severity,
            value: 0, unit: '',
            interpretation: {
                label: severity.label, color: grupo === 'A' ? 'success' : 'danger',
                description: `Clasificación de Dengue: Grupo ${grupo} (OMS 2009). Protocolo de manejo generado.`
            }
        };
    },

    // === 48. CÓDIGO ICTUS — TROMBOLISIS / TROMBECTOMÍA === //
    calculateCodigoIctus(inputs) {
        let { horasInicio, ventanaIncierta, weight, sbp, dbp, exclusionAbsoluta, exclusionRelativa, trombectomia } = inputs;

        const weightUnit = Storage.getSetting('units.weight');
        if (weight && weightUnit === 'lb') weight = weight / 2.20462;

        const tieneExclusionAbsoluta = Object.values(exclusionAbsoluta || {}).filter(Boolean);
        const numExclusionAbsoluta = tieneExclusionAbsoluta.length;
        const tieneExclusionRelativa = Object.values(exclusionRelativa || {}).filter(Boolean);

        const dentroVentanaEstandar = !ventanaIncierta && typeof horasInicio === 'number' && horasInicio <= 4.5;
        const dentroVentanaExtendida = !ventanaIncierta && typeof horasInicio === 'number' && horasInicio > 3 && horasInicio <= 4.5;

        const requierePAPrevia = (typeof sbp === 'number' && sbp > 185) || (typeof dbp === 'number' && dbp > 110);

        const candidatoTrombolisis = dentroVentanaEstandar
            && numExclusionAbsoluta === 0
            && (!dentroVentanaExtendida || tieneExclusionRelativa.length === 0);

        let doseAlteplasaTotal = null, doseBolo = null, doseInfusion = null;
        if (candidatoTrombolisis && weight) {
            const raw = weight * 0.9;
            doseAlteplasaTotal = Math.min(Math.round(raw * 10) / 10, 90);
            doseBolo = Math.round(doseAlteplasaTotal * 0.1 * 10) / 10;
            doseInfusion = Math.round(doseAlteplasaTotal * 0.9 * 10) / 10;
        }

        const cumpleTrombectomia = trombectomia && Object.values(trombectomia).every(Boolean)
            && !ventanaIncierta && typeof horasInicio === 'number' && horasInicio <= 24;

        const severity = candidatoTrombolisis
            ? { label: 'Candidato a Trombolisis IV', colorHex: '#22c55e', badge: '✅' }
            : { label: 'NO Candidato a Trombolisis', colorHex: '#dc2626', badge: '🔴' };

        return {
            horasInicio, ventanaIncierta, dentroVentanaEstandar, dentroVentanaExtendida,
            candidatoTrombolisis, requierePAPrevia,
            exclusionAbsolutaMarcada: tieneExclusionAbsoluta, numExclusionAbsoluta,
            exclusionRelativaMarcada: tieneExclusionRelativa,
            weight, doseAlteplasaTotal, doseBolo, doseInfusion,
            cumpleTrombectomia, severity,
            value: 0, unit: '',
            interpretation: {
                label: severity.label, color: candidatoTrombolisis ? 'success' : 'danger',
                description: 'Checklist de Código Ictus (trombolisis/trombectomía) generado (AHA/ASA 2019).'
            }
        };
    },

    // === 49. GASOMETRÍA ARTERIAL — INTERPRETACIÓN SISTEMÁTICA ÁCIDO-BASE === //
    calculateGasometria(inputs) {
        const { ph, pco2, hco3, sodium, chloride, albumin, cronico, pao2, fio2, edad } = inputs;

        // 1. Verificación de congruencia: H+ desde pH vs H+ desde ecuación de Henderson
        const hFromPh = Math.pow(10, 9 - ph);
        const hFromRatio = 24 * pco2 / hco3;
        const congruente = Math.abs(hFromPh - hFromRatio) / hFromRatio <= 0.15;

        // 2. Trastorno primario — clasificación unificada por el PATRÓN hco3/pco2, no por el signo del pH
        //    (una compensación fisiológica NUNCA mueve hco3 y pco2 en la misma dirección "acidificante"
        //     ni en la misma dirección "alcalinizante" simultáneamente — esas combinaciones son SIEMPRE
        //     un trastorno mixto doble. Las combinaciones donde ambos se mueven en direcciones opuestas
        //     de pH son las fisiológicamente esperables de una compensación, pero cuando AMBOS valores
        //     están fuera de rango en la MISMA dirección de pH (ambos "suben" o ambos "bajan") el origen
        //     es ambiguo entre primario respiratorio compensado y primario metabólico compensado —
        //     se resuelve probando las DOS hipótesis con sus fórmulas de compensación esperada.)
        const hco3Bajo = hco3 < 22, hco3Alto = hco3 > 26, hco3Normal = !hco3Bajo && !hco3Alto;
        const pco2Alto = pco2 > 45, pco2Bajo = pco2 < 35, pco2Normal = !pco2Alto && !pco2Bajo;

        const testAcidosisMetabolica = () => {
            const min = 1.5 * hco3 + 8 - 2, max = 1.5 * hco3 + 8 + 2;
            return { tipo: 'acidosis_metabolica', variable: 'pCO2', esperadoMin: Math.round(min * 10) / 10, esperadoMax: Math.round(max * 10) / 10, medido: pco2, fit: pco2 >= min && pco2 <= max, formula: 'Winter: pCO2 = 1.5×HCO3 + 8 (±2)' };
        };
        const testAlcalosisMetabolica = () => {
            const esp = 40 + 0.7 * (hco3 - 24), min = esp - 2, max = esp + 2;
            return { tipo: 'alcalosis_metabolica', variable: 'pCO2', esperadoMin: Math.round(min * 10) / 10, esperadoMax: Math.round(max * 10) / 10, medido: pco2, fit: pco2 >= min && pco2 <= max, formula: 'pCO2 = 40 + 0.7×(HCO3-24) (±2)' };
        };
        const testAcidosisRespiratoria = (cron) => {
            const factor = cron ? 4 : 1, esp = 24 + factor * ((pco2 - 40) / 10), min = esp - 3, max = esp + 3;
            return { tipo: 'acidosis_respiratoria', variable: 'HCO3', esperadoMin: Math.round(min * 10) / 10, esperadoMax: Math.round(max * 10) / 10, medido: hco3, fit: hco3 >= min && hco3 <= max, formula: `HCO3 = 24 + ${factor}×(ΔpCO2/10) [${cron ? 'crónica' : 'aguda'}]` };
        };
        const testAlcalosisRespiratoria = (cron) => {
            const factor = cron ? 4 : 2, esp = 24 - factor * ((40 - pco2) / 10), min = esp - 3, max = esp + 3;
            return { tipo: 'alcalosis_respiratoria', variable: 'HCO3', esperadoMin: Math.round(min * 10) / 10, esperadoMax: Math.round(max * 10) / 10, medido: hco3, fit: hco3 >= min && hco3 <= max, formula: `HCO3 = 24 - ${factor}×(ΔpCO2/10) [${cron ? 'crónica' : 'aguda'}]` };
        };

        let primario, compensacion = null, esMixtoObvio = false, hipotesisAlternativa = null;

        if (hco3Normal && pco2Normal) {
            primario = 'normal';
        } else if (hco3Bajo && pco2Alto) {
            // ambos acidificantes a la vez — imposible como compensación única, es una acidosis doble
            primario = 'acidosis_mixta'; esMixtoObvio = true;
        } else if (hco3Alto && pco2Bajo) {
            // ambos alcalinizantes a la vez — alcalosis doble
            primario = 'alcalosis_mixta'; esMixtoObvio = true;
        } else if (hco3Bajo) {
            // hco3 bajo + pco2 normal o bajo
            if (pco2Bajo) {
                const hipMet = testAcidosisMetabolica();          // primario metabólico, pCO2 compensador (bajo)
                const hipResp = testAlcalosisRespiratoria(cronico); // primario respiratorio, HCO3 compensador (bajo)
                if (hipMet.fit && !hipResp.fit) { primario = 'acidosis_metabolica'; compensacion = hipMet; }
                else if (hipResp.fit && !hipMet.fit) { primario = 'alcalosis_respiratoria'; compensacion = hipResp; }
                else if (hipMet.fit && hipResp.fit) { primario = 'ambiguo_acidmet_o_alcresp'; compensacion = hipMet; hipotesisAlternativa = hipResp; }
                else { primario = 'acidosis_metabolica'; compensacion = hipMet; hipotesisAlternativa = hipResp; }
            } else {
                primario = 'acidosis_metabolica';
                compensacion = testAcidosisMetabolica();
            }
        } else if (hco3Alto) {
            // hco3 alto + pco2 normal o alto
            if (pco2Alto) {
                const hipResp = testAcidosisRespiratoria(cronico); // primario respiratorio, HCO3 compensador (alto)
                const hipMet = testAlcalosisMetabolica();          // primario metabólico, pCO2 compensador (alto)
                if (hipResp.fit && !hipMet.fit) { primario = 'acidosis_respiratoria'; compensacion = hipResp; }
                else if (hipMet.fit && !hipResp.fit) { primario = 'alcalosis_metabolica'; compensacion = hipMet; }
                else if (hipResp.fit && hipMet.fit) { primario = 'ambiguo_acidresp_o_alcmet'; compensacion = hipResp; hipotesisAlternativa = hipMet; }
                else { primario = 'acidosis_respiratoria'; compensacion = hipResp; hipotesisAlternativa = hipMet; }
            } else {
                primario = 'alcalosis_metabolica';
                compensacion = testAlcalosisMetabolica();
            }
        } else if (pco2Alto) {
            // solo pCO2 alto, hco3 normal (proceso agudo, compensación renal aún no establecida)
            primario = 'acidosis_respiratoria';
            compensacion = testAcidosisRespiratoria(cronico);
        } else {
            // solo pCO2 bajo, hco3 normal
            primario = 'alcalosis_respiratoria';
            compensacion = testAlcalosisRespiratoria(cronico);
        }

        // "hallazgo" homogéneo para mostrar en el resultado: si la compensación no ajusta, señalar
        // el componente concomitante específico según hacia qué lado se desvía el valor medido
        if (compensacion && !esMixtoObvio) {
            if (compensacion.fit) {
                compensacion.hallazgo = 'apropiada';
            } else if (compensacion.variable === 'pCO2') {
                compensacion.hallazgo = compensacion.medido < compensacion.esperadoMin ? 'alcalosis_respiratoria_concomitante' : 'acidosis_respiratoria_concomitante';
            } else {
                compensacion.hallazgo = compensacion.medido < compensacion.esperadoMin ? 'acidosis_metabolica_concomitante' : 'alcalosis_metabolica_concomitante';
            }
        }

        // 4. Anion Gap — reutiliza Calculators.calculateAnionGap (no reimplementar).
        //    Elegible siempre que HCO3 esté bajo (independiente de cuál haya quedado como "primario"),
        //    porque el AG depende fisiológicamente de HCO3 bajo por ácido no medido, no de la etiqueta.
        let agResult = null, deltaRatio = null, deltaInterpretacion = null;
        const hasElectrolytes = typeof sodium === 'number' && typeof chloride === 'number';
        if (hasElectrolytes) {
            agResult = this.calculateAnionGap({ sodium, chloride, bicarbonate: hco3, albumin: (typeof albumin === 'number' ? albumin : null) });
            const agValue = agResult.correctedValue !== null ? agResult.correctedValue : agResult.value;
            const agElevado = agValue > 12;
            if (agElevado && hco3Bajo && hco3 !== 24) {
                deltaRatio = Math.round(((agValue - 12) / (24 - hco3)) * 100) / 100;
                if (deltaRatio < 0.4) deltaInterpretacion = 'hiperclorémica_predominante';
                else if (deltaRatio <= 0.8) deltaInterpretacion = 'mixta_ag_hiperclorémica';
                else if (deltaRatio <= 2) deltaInterpretacion = 'agma_pura';
                else deltaInterpretacion = 'ag_mas_alcalosis_metabolica';
            }
            agResult.agElevado = agElevado;
            agResult.agValue = Math.round(agValue * 10) / 10;
        }

        // 5. Oxigenación
        let oxigenacion = null;
        if (typeof pao2 === 'number' && typeof fio2 === 'number' && fio2 > 0) {
            const fio2Frac = fio2 > 1 ? fio2 / 100 : fio2;
            const kirby = Math.round(pao2 / fio2Frac);
            let sdra = null;
            if (kirby <= 100) sdra = 'severo';
            else if (kirby <= 200) sdra = 'moderado';
            else if (kirby <= 300) sdra = 'leve';
            let gradienteAa = null, gradienteEsperado = null;
            if (typeof edad === 'number') {
                const pao2Alveolar = fio2Frac * (760 - 47) - (pco2 / 0.8);
                gradienteAa = Math.round((pao2Alveolar - pao2) * 10) / 10;
                gradienteEsperado = Math.round((edad / 4 + 4) * 10) / 10;
            }
            oxigenacion = { kirby, sdra, gradienteAa, gradienteEsperado };
        }

        const severity = primario === 'normal'
            ? { label: 'Gasometría Normal', colorHex: '#22c55e', badge: '🟢' }
            : { label: 'Trastorno Ácido-Base Detectado', colorHex: '#f59e0b', badge: '🧪' };

        return {
            ph, pco2, hco3, congruente, primario, esMixtoObvio, compensacion, hipotesisAlternativa,
            agResult, deltaRatio, deltaInterpretacion, oxigenacion, severity,
            value: ph, unit: '',
            interpretation: {
                label: severity.label, color: primario === 'normal' ? 'success' : 'warning',
                description: 'Interpretación sistemática de gasometría arterial generada (enfoque Boston/Winter).'
            }
        };
    },

    // === 50. QTc CORREGIDO === //
    calculateQTc(inputs) {
        const { qt, hr, sex } = inputs;
        const rrSec = 60 / hr;
        const round1 = v => Math.round(v * 10) / 10;
        const qtcBazett = round1(qt / Math.sqrt(rrSec));
        const qtcFridericia = round1(qt / Math.cbrt(rrSec));
        const qtcFramingham = round1(qt + 154 * (1 - rrSec));

        const isFemale = sex === 'F';
        const normalMax = isFemale ? 460 : 450;
        const altoRiesgoMin = 500;

        let label, color, description;
        if (qtcBazett >= altoRiesgoMin) {
            label = 'QTc muy prolongado — alto riesgo de Torsades de Pointes';
            color = 'danger';
            description = 'QTc (Bazett) ≥500ms — riesgo alto de arritmia ventricular polimórfica. Revisar y suspender fármacos QT-prolongantes, corregir K⁺/Mg²⁺/Ca²⁺, monitorización continua.';
        } else if (qtcBazett > normalMax) {
            label = 'QTc prolongado';
            color = 'warning';
            description = `QTc por encima del límite normal (>${normalMax}ms, sexo ${isFemale ? 'femenino' : 'masculino'}). Revisar fármacos QT-prolongantes y electrolitos.`;
        } else {
            label = 'QTc normal';
            color = 'success';
            description = `QTc dentro de rango normal (<${normalMax}ms).`;
        }

        return {
            qtcBazett, qtcFridericia, qtcFramingham,
            rrSec: round1(rrSec),
            frecuenciaExtrema: hr > 90 || hr < 60,
            value: qtcBazett, unit: 'ms',
            interpretation: { label, color, description }
        };
    },

    // === 51. ABCD2 SCORE === //
    calculateABCD2(inputs) {
        const { edad60, pa, clinica, duracion, diabetes } = inputs;
        let score = 0;
        if (edad60) score += 1;
        if (pa) score += 1;
        if (clinica === 'debilidad') score += 2;
        else if (clinica === 'habla') score += 1;
        if (duracion === 'mayor60') score += 2;
        else if (duracion === 'entre10y59') score += 1;
        if (diabetes) score += 1;

        let label, color, description;
        if (score <= 3) {
            label = 'Riesgo bajo';
            color = 'success';
            description = 'Riesgo de ictus a 2 días ≈1%. Estudio ambulatorio preferente aceptable según contexto clínico.';
        } else if (score <= 5) {
            label = 'Riesgo moderado';
            color = 'warning';
            description = 'Riesgo de ictus a 2 días ≈4%. Se recomienda estudio urgente (neuroimagen, doppler de troncos supraaórticos) y valorar ingreso.';
        } else {
            label = 'Riesgo alto';
            color = 'danger';
            description = 'Riesgo de ictus a 2 días ≈8%. Ingreso y estudio urgente recomendado — ver también NIHSS (Calculadora 17) y Código Ictus (Calculadora 48) si el déficit progresa.';
        }

        return { value: score, unit: 'pts', interpretation: { label, color, description } };
    },

    // === 52. ESCALA DE RANKIN MODIFICADA (mRS) === //
    RANKIN_LEVELS: [
        { level: 0, label: 'Sin síntomas' },
        { level: 1, label: 'Sin discapacidad significativa — capaz de realizar sus actividades y obligaciones habituales pese a los síntomas' },
        { level: 2, label: 'Discapacidad leve — incapaz de realizar todas sus actividades previas, pero capaz de velar por sus propios asuntos sin ayuda' },
        { level: 3, label: 'Discapacidad moderada — requiere alguna ayuda, pero capaz de caminar sin asistencia' },
        { level: 4, label: 'Discapacidad moderadamente severa — incapaz de caminar sin asistencia e incapaz de atender sus necesidades corporales sin ayuda' },
        { level: 5, label: 'Discapacidad severa — confinado a cama, incontinencia, requiere cuidado y atención constante de enfermería' },
        { level: 6, label: 'Muerte' }
    ],

    calculateRankin(inputs) {
        const level = inputs.level;
        const entry = this.RANKIN_LEVELS.find(l => l.level === level);
        const color = level <= 1 ? 'success' : level <= 3 ? 'warning' : 'danger';
        return {
            value: level, unit: '',
            interpretation: { label: `mRS ${level}`, color, description: entry.label }
        };
    },

    // === 53. PROFILAXIS DE TVE — CAPRINI / PADUA === //
    calculateVTEProphylaxis(inputs) {
        if (inputs.tipo === 'medico') {
            const f = inputs.factores;
            let score = 0;
            if (f.cancer) score += 3;
            if (f.tvpPrevia) score += 3;
            if (f.movilidadReducida) score += 3;
            if (f.trombofilia) score += 3;
            if (f.traumaCirugiaReciente) score += 2;
            if (f.edad70) score += 1;
            if (f.icCardioRespiratoria) score += 1;
            if (f.iamAvcAgudo) score += 1;
            if (f.infeccionReumatico) score += 1;
            if (f.obesidad) score += 1;
            if (f.hormonal) score += 1;

            const altoRiesgo = score >= 4;
            return {
                escala: 'Padua', value: score, unit: 'pts', altoRiesgo,
                interpretation: {
                    label: altoRiesgo ? 'Alto riesgo de TVE' : 'Bajo riesgo de TVE',
                    color: altoRiesgo ? 'danger' : 'success',
                    description: altoRiesgo
                        ? 'Score de Padua ≥4 — profilaxis farmacológica indicada (HBPM/HNF) salvo contraindicación; si contraindicada, profilaxis mecánica.'
                        : 'Score de Padua <4 — profilaxis farmacológica no indicada de rutina; deambulación precoz.'
                }
            };
        }

        // Quirúrgico — Caprini (versión focalizada: subconjunto representativo de cada nivel de peso, no las ~40 variables completas)
        const f = inputs.factores;
        let score = 0;
        if (inputs.edadTier === '41-60') score += 1;
        else if (inputs.edadTier === '61-74') score += 2;
        else if (inputs.edadTier === '75+') score += 3;

        ['cirugiaMenor', 'imc25', 'varices', 'embarazoPuerperio', 'acoTrh', 'sepsisReciente', 'epocNeumoniaReciente', 'iamReciente', 'icReciente', 'encamadoMedico']
            .forEach(k => { if (f[k]) score += 1; });
        ['artroscopia', 'cirugiaMayorAbierta', 'cirugiaLaparoscopicaLarga', 'malignidadActiva', 'encamado72h', 'yesoInmovilizador', 'accesoVenosoCentral']
            .forEach(k => { if (f[k]) score += 2; });
        ['historiaTVE', 'historiaFamiliarTVE', 'trombofiliaConocida', 'hit']
            .forEach(k => { if (f[k]) score += 3; });
        ['ictusReciente', 'artroplastiaMayorMI', 'fracturaCaderaPelvisPiernaReciente', 'traumaMultipleReciente', 'lesionMedularAguda']
            .forEach(k => { if (f[k]) score += 5; });

        let label, color, description;
        if (score === 0) { label = 'Riesgo muy bajo'; color = 'success'; description = 'Deambulación precoz, sin profilaxis farmacológica.'; }
        else if (score <= 2) { label = 'Riesgo bajo'; color = 'success'; description = 'Profilaxis mecánica (medias de compresión / compresión neumática intermitente).'; }
        else if (score <= 4) { label = 'Riesgo moderado'; color = 'warning'; description = 'Profilaxis farmacológica (HBPM/HNF) y/o mecánica según riesgo de sangrado.'; }
        else { label = 'Riesgo alto'; color = 'danger'; description = 'Profilaxis farmacológica + mecánica combinada — riesgo significativo de TVE/TEP.'; }

        return { escala: 'Caprini (focalizado)', value: score, unit: 'pts', interpretation: { label, color, description } };
    },

    // === 54. SCORE 4Ts (HIT) === //
    calculate4Ts(inputs) {
        const { plaquetas, tiempo, trombosis, otrasCausas } = inputs;
        const score = plaquetas + tiempo + trombosis + otrasCausas;
        let label, color, description;
        if (score <= 3) { label = 'Baja probabilidad de HIT'; color = 'success'; description = 'Probabilidad de HIT <5%. HIT poco probable — no suspender heparina solo por este score, pero seguir vigilando plaquetas.'; }
        else if (score <= 5) { label = 'Probabilidad intermedia de HIT'; color = 'warning'; description = 'Probabilidad de HIT ~14%. Suspender heparina, iniciar anticoagulante alternativo no heparínico, solicitar test de laboratorio (ELISA anti-PF4/heparina o funcional).'; }
        else { label = 'Alta probabilidad de HIT'; color = 'danger'; description = 'Probabilidad de HIT ~64%. Suspender TODA heparina (incluidos catéteres heparinizados y HBPM), iniciar anticoagulante alternativo no heparínico de inmediato, no esperar confirmación de laboratorio.'; }
        return { value: score, unit: 'pts', interpretation: { label, color, description } };
    },

    // === 55. FÓRMULA DE PARKLAND (QUEMADOS) === //
    _holidaySegar(weightKg) {
        let mlDia;
        if (weightKg <= 10) mlDia = weightKg * 100;
        else if (weightKg <= 20) mlDia = 1000 + (weightKg - 10) * 50;
        else mlDia = 1500 + (weightKg - 20) * 20;
        return { mlDia: Math.round(mlDia), mlHora: Math.round(mlDia / 24) };
    },

    calculateParkland(inputs) {
        const { weightKg, tbsa, horasTranscurridas, pediatrico } = inputs;
        const volumenTotal = 4 * weightKg * tbsa; // mL en 24h
        const primeras8h = volumenTotal / 2;
        const siguientes16h = volumenTotal / 2;

        let tasaActual = null, fase = null;
        if (typeof horasTranscurridas === 'number') {
            if (horasTranscurridas < 8) {
                const horasRestantesFase1 = 8 - horasTranscurridas;
                tasaActual = Math.round(primeras8h / horasRestantesFase1);
                fase = 'Fase 1 (primeras 8h desde la quemadura)';
            } else if (horasTranscurridas < 24) {
                const horasRestantesFase2 = 24 - horasTranscurridas;
                tasaActual = Math.round(siguientes16h / horasRestantesFase2);
                fase = 'Fase 2 (8-24h desde la quemadura)';
            } else {
                fase = 'Fuera de la ventana de 24h — reevaluar necesidades de mantenimiento';
            }
        }

        const mantenimientoPediatrico = pediatrico ? this._holidaySegar(weightKg) : null;

        return {
            volumenTotal: Math.round(volumenTotal),
            primeras8h: Math.round(primeras8h),
            siguientes16h: Math.round(siguientes16h),
            tasaActual, fase, mantenimientoPediatrico,
            value: Math.round(volumenTotal), unit: 'mL/24h',
            interpretation: {
                label: 'Fórmula de Parkland',
                color: 'info',
                description: `Volumen total 24h: ${Math.round(volumenTotal)} mL. Mitad en las primeras 8h desde la quemadura (no desde la llegada), resto en las 16h siguientes.`
            }
        };
    },

    // === 56. DELIRIO Y SEDACIÓN EN UCI — RASS + CAM-ICU === //
    RASS_LEVELS: [
        { level: 4, label: '+4 Combativo', description: 'Violento, peligro inmediato para el personal' },
        { level: 3, label: '+3 Muy agitado', description: 'Se arranca tubos/catéteres, agresivo' },
        { level: 2, label: '+2 Agitado', description: 'Movimientos frecuentes sin propósito, lucha con el ventilador' },
        { level: 1, label: '+1 Inquieto', description: 'Ansioso, movimientos no agresivos' },
        { level: 0, label: '0 Alerta y calmado', description: '' },
        { level: -1, label: '-1 Somnoliento', description: 'No completamente alerta, despierta (>10s) a la voz con contacto visual' },
        { level: -2, label: '-2 Sedación leve', description: 'Despierta brevemente (<10s) a la voz con contacto visual' },
        { level: -3, label: '-3 Sedación moderada', description: 'Movimiento o apertura ocular a la voz (sin contacto visual)' },
        { level: -4, label: '-4 Sedación profunda', description: 'Sin respuesta a la voz, movimiento o apertura ocular al estímulo físico' },
        { level: -5, label: '-5 No despertable', description: 'Sin respuesta a la voz ni al estímulo físico' }
    ],

    calculateDelirioSedacion(inputs) {
        const { rass, camIcu } = inputs;
        const rassEntry = this.RASS_LEVELS.find(l => l.level === rass);
        const evaluable = rass >= -3;

        let camResult = null;
        if (evaluable && camIcu) {
            const feature1 = camIcu.inicioAgudo;
            const feature2 = camIcu.inatencion;
            const feature3 = camIcu.nivelConciencia;
            const feature4 = camIcu.pensamientoDesorganizado;
            const positivo = feature1 && feature2 && (feature3 || feature4);
            camResult = { positivo, feature1, feature2, feature3, feature4 };
        }

        return {
            rass, rassLabel: rassEntry.label, rassDescription: rassEntry.description,
            evaluable, camResult,
            value: rass, unit: '',
            interpretation: evaluable
                ? (camResult
                    ? {
                        label: camResult.positivo ? 'CAM-ICU positivo — Delirio presente' : 'CAM-ICU negativo — sin delirio',
                        color: camResult.positivo ? 'danger' : 'success',
                        description: camResult.positivo
                            ? 'Iniciar manejo no farmacológico del delirio (reorientación, luz natural, movilización precoz, retirar sujeción/sonda si es posible); evitar benzodiacepinas.'
                            : 'Sin evidencia de delirio en esta evaluación — reevaluar periódicamente.'
                    }
                    : { label: 'RASS evaluable — completar CAM-ICU', color: 'warning', description: 'El nivel de sedación permite evaluar delirio; completar las 4 características del CAM-ICU.' })
                : { label: 'CAM-ICU no evaluable', color: 'warning', description: 'RASS ≤ -4 (sedación profunda o no despertable) — el delirio no puede evaluarse de forma fiable. Reevaluar tras aligerar la sedación.' }
        };
    },

    // === 57. ESCALAS DE ABSTINENCIA — CIWA-Ar / COWS === //
    calculateAbstinencia(inputs) {
        const { tipo, items } = inputs;
        const score = items.reduce((a, b) => a + b, 0);

        if (tipo === 'alcohol') {
            let label, color, description;
            if (score < 8) { label = 'Abstinencia mínima'; color = 'success'; description = 'CIWA-Ar <8 — generalmente no requiere tratamiento farmacológico; reevaluar periódicamente.'; }
            else if (score <= 15) { label = 'Abstinencia leve-moderada'; color = 'warning'; description = 'CIWA-Ar 8-15 — considerar benzodiacepina guiada por síntomas (protocolo CIWA), reevaluar cada 1-2h.'; }
            else if (score <= 20) { label = 'Abstinencia moderada-severa'; color = 'danger'; description = 'CIWA-Ar 15-20 — benzodiacepinas a dosis más altas, vigilancia estrecha, riesgo de progresión.'; }
            else { label = 'Abstinencia severa — riesgo de delirium tremens'; color = 'danger'; description = 'CIWA-Ar >20 — alto riesgo de delirium tremens/convulsiones. Benzodiacepinas IV a dosis altas, considerar UCI.'; }
            return { escala: 'CIWA-Ar', value: score, unit: '/67', interpretation: { label, color, description } };
        }

        let label, color, description;
        if (score < 5) { label = 'Sin abstinencia / mínima'; color = 'success'; description = 'COWS <5 — sin abstinencia significativa.'; }
        else if (score <= 12) { label = 'Abstinencia leve'; color = 'success'; description = 'COWS 5-12 — abstinencia leve, manejo sintomático.'; }
        else if (score <= 24) { label = 'Abstinencia moderada'; color = 'warning'; description = 'COWS 13-24 — abstinencia moderada; un score ≥12-13 suele ser suficiente para iniciar buprenorfina si esa es la estrategia elegida.'; }
        else if (score <= 36) { label = 'Abstinencia moderadamente severa'; color = 'danger'; description = 'COWS 25-36 — considerar manejo hospitalario.'; }
        else { label = 'Abstinencia severa'; color = 'danger'; description = 'COWS >36 — abstinencia severa, manejo hospitalario/monitorización estrecha.'; }
        return { escala: 'COWS', value: score, unit: '/48', interpretation: { label, color, description } };
    },

    // === 58. HEMORRAGIA DIGESTIVA ALTA — GLASGOW-BLATCHFORD / ROCKALL === //
    calculateHDA(inputs) {
        const { blatchford, rockall } = inputs;

        let gbs = 0;
        const ureaMmol = blatchford.ureaMmol;
        if (ureaMmol >= 25) gbs += 6;
        else if (ureaMmol >= 10) gbs += 4;
        else if (ureaMmol >= 8) gbs += 3;
        else if (ureaMmol >= 6.5) gbs += 2;

        const hb = blatchford.hb;
        const esHombre = blatchford.sexo === 'M';
        if (esHombre) {
            if (hb < 10) gbs += 6;
            else if (hb < 12) gbs += 3;
            else if (hb < 13) gbs += 1;
        } else {
            if (hb < 10) gbs += 6;
            else if (hb < 12) gbs += 1;
        }

        const sbp = blatchford.sbp;
        if (sbp < 90) gbs += 3;
        else if (sbp < 100) gbs += 2;
        else if (sbp < 110) gbs += 1;

        if (blatchford.pulso100) gbs += 1;
        if (blatchford.melena) gbs += 1;
        if (blatchford.sincope) gbs += 2;
        if (blatchford.hepatopatia) gbs += 2;
        if (blatchford.icc) gbs += 2;

        const gbsMuyBajoRiesgo = gbs === 0;

        let rocklPre = 0;
        if (rockall.edad >= 80) rocklPre += 2;
        else if (rockall.edad >= 60) rocklPre += 1;

        if (rockall.shock === 'hipotension') rocklPre += 2;
        else if (rockall.shock === 'taquicardia') rocklPre += 1;

        if (rockall.comorbilidad === 'renalHepaticaMalignidad') rocklPre += 3;
        else if (rockall.comorbilidad === 'icIhdMayor') rocklPre += 2;

        let rockallTotal = rocklPre;
        let rockallCompleto = false;
        if (rockall.diagnostico != null && rockall.estigmas != null) {
            rockallCompleto = true;
            if (rockall.diagnostico === 'malignidad') rockallTotal += 2;
            else if (rockall.diagnostico === 'otro') rockallTotal += 1;
            if (rockall.estigmas === 'sangradoActivoVasoVisible') rockallTotal += 2;
        }

        let rockallBanda;
        if (rockallTotal <= 2) rockallBanda = 'bajo';
        else if (rockallTotal <= 4) rockallBanda = 'intermedio';
        else rockallBanda = 'alto';

        return {
            gbs, gbsMuyBajoRiesgo,
            rocklPre, rockallTotal, rockallCompleto, rockallBanda,
            value: gbs, unit: 'pts',
            interpretation: {
                label: gbsMuyBajoRiesgo ? 'Glasgow-Blatchford 0 — riesgo muy bajo' : `Glasgow-Blatchford ${gbs}`,
                color: gbsMuyBajoRiesgo ? 'success' : (gbs <= 3 ? 'warning' : 'danger'),
                description: gbsMuyBajoRiesgo
                    ? 'Riesgo muy bajo de necesitar intervención — manejo ambulatorio seguro sin necesidad de ingreso ni endoscopia urgente.'
                    : 'Score >0 — ingreso hospitalario recomendado y endoscopia según disponibilidad/gravedad.'
            }
        };
    },

    // === 59. PANCREATITIS AGUDA — RANSON / BISAP === //
    calculatePancreatitis(inputs) {
        const { escala } = inputs;

        if (escala === 'bisap') {
            const b = inputs.bisap;
            let score = 0;
            if (b.bun25) score += 1;
            if (b.gcsAlterado) score += 1;
            if (b.sirs2) score += 1;
            if (b.edad60) score += 1;
            if (b.derramePleural) score += 1;

            const altoRiesgo = score >= 3;
            return {
                escala: 'BISAP', value: score, unit: '/5', altoRiesgo,
                interpretation: {
                    label: altoRiesgo ? 'BISAP ≥3 — alto riesgo' : 'BISAP <3 — bajo riesgo',
                    color: altoRiesgo ? 'danger' : 'success',
                    description: altoRiesgo
                        ? 'Score BISAP ≥3 asociado a mayor mortalidad y riesgo de falla orgánica — considerar UCI y TC contrastada a las 72h si hay deterioro.'
                        : 'Score BISAP bajo — riesgo de gravedad menor, continuar vigilancia clínica.'
                }
            };
        }

        const ing = inputs.ranson.ingreso;
        let ptsIngreso = 0;
        if (ing.edad55) ptsIngreso++;
        if (ing.leucocitos16000) ptsIngreso++;
        if (ing.glucosa200) ptsIngreso++;
        if (ing.ldh350) ptsIngreso++;
        if (ing.ast250) ptsIngreso++;

        let pts48h = null, total = ptsIngreso;
        if (inputs.ranson.h48) {
            const h48 = inputs.ranson.h48;
            pts48h = 0;
            if (h48.caidaHto10) pts48h++;
            if (h48.aumentoBun5) pts48h++;
            if (h48.calcio8) pts48h++;
            if (h48.pao260) pts48h++;
            if (h48.deficitBase4) pts48h++;
            if (h48.secuestroLiquidos6L) pts48h++;
            total = ptsIngreso + pts48h;
        }

        let mortalidad;
        if (total <= 2) mortalidad = '<5%';
        else if (total <= 4) mortalidad = '15-20%';
        else if (total <= 6) mortalidad = '~40%';
        else mortalidad = '~100%';

        return {
            escala: 'Ranson', ptsIngreso, pts48h, value: total, unit: 'pts', mortalidad,
            interpretation: {
                label: `Ranson ${total} pts`,
                color: total <= 2 ? 'success' : (total <= 4 ? 'warning' : 'danger'),
                description: pts48h === null
                    ? `Subtotal al ingreso: ${ptsIngreso} pts. Completar los criterios a las 48h para el score total. Mortalidad estimada con el total: ${mortalidad}.`
                    : `Score total (ingreso + 48h): ${total} pts. Mortalidad estimada: ${mortalidad}.`
            }
        };
    },

    // === 60. INTOXICACIÓN POR PARACETAMOL — NOMOGRAMA + NAC === //
    _nacDosis(weightKg) {
        return {
            carga: `${Math.round(weightKg * 150)} mg en 200 mL, IV en 1h`,
            mantenimiento1: `${Math.round(weightKg * 50)} mg en 500 mL, IV en 4h`,
            mantenimiento2: `${Math.round(weightKg * 100)} mg en 1000 mL, IV en 16h`
        };
    },

    calculateParacetamol(inputs) {
        const { horas, nivel, weightKg, ingestaAguda } = inputs;

        if (!ingestaAguda || horas == null || horas > 24 || horas < 4) {
            return {
                nomogramaAplicable: false,
                value: nivel, unit: 'µg/mL',
                naDosis: this._nacDosis(weightKg),
                interpretation: {
                    label: 'Nomograma no aplicable',
                    color: 'warning',
                    description: 'El nomograma de Rumack-Matthew solo es válido para ingesta única aguda con tiempo conocido entre 4 y 24h. Para ingesta crónica/escalonada o tiempo desconocido: tratar empíricamente si nivel >20-30 µg/mL, clínica compatible o transaminasas alteradas — no aplicar la línea del nomograma.'
                }
            };
        }

        const umbral = 150 * Math.pow(2, -(horas - 4) / 4);
        const porEncimaLinea = nivel >= umbral;

        return {
            nomogramaAplicable: true,
            umbral: Math.round(umbral * 10) / 10,
            porEncimaLinea,
            naDosis: porEncimaLinea ? this._nacDosis(weightKg) : null,
            value: nivel, unit: 'µg/mL',
            interpretation: {
                label: porEncimaLinea ? 'Por encima de la línea de tratamiento — NAC indicada' : 'Por debajo de la línea de tratamiento',
                color: porEncimaLinea ? 'danger' : 'success',
                description: porEncimaLinea
                    ? `Nivel ${nivel} µg/mL a las ${horas}h está por encima del umbral (${Math.round(umbral * 10) / 10} µg/mL) — iniciar N-acetilcisteína.`
                    : `Nivel ${nivel} µg/mL a las ${horas}h está por debajo del umbral (${Math.round(umbral * 10) / 10} µg/mL) — hepatotoxicidad poco probable, no requiere NAC por este criterio.`
            }
        };
    },

    // === 62. RIESGO CARDIOVASCULAR — ASCVD 2013 (Pooled Cohort Equations, Goff et al. 2013) === //
    // Coeficientes verificados contra el caso de referencia clásico (hombre blanco 55a, CT 213, HDL 50,
    // PAS 120 no tratada, no fumador, no diabético → 5.36%, coincide con el ~5.3% citado en la literatura).
    calculateASCVD(inputs) {
        const { sex, raza, age, totalChol, hdl, sbp, tratada, diabetes, fumador } = inputs;
        const isMale = sex === 'M';
        const isBlack = raza === 'afroamericano';

        const lnAge = Math.log(age);
        const lnTotalChol = Math.log(totalChol);
        const lnHdl = Math.log(hdl);
        const trlnsbp = tratada ? Math.log(sbp) : 0;
        const ntlnsbp = tratada ? 0 : Math.log(sbp);
        const ageTotalChol = lnAge * lnTotalChol;
        const ageHdl = lnAge * lnHdl;
        const agetSbp = lnAge * trlnsbp;
        const agentSbp = lnAge * ntlnsbp;
        const ageSmoke = fumador ? lnAge : 0;

        let s0, mean, predict;
        if (isBlack && !isMale) {
            s0 = 0.95334; mean = 86.6081;
            predict = 17.1141 * lnAge + 0.9396 * lnTotalChol - 18.9196 * lnHdl + 4.4748 * ageHdl
                + 29.2907 * trlnsbp - 6.4321 * agetSbp + 27.8197 * ntlnsbp - 6.0873 * agentSbp
                + (fumador ? 0.6908 : 0) + (diabetes ? 0.8738 : 0);
        } else if (!isBlack && !isMale) {
            s0 = 0.96652; mean = -29.1817;
            predict = -29.799 * lnAge + 4.884 * Math.pow(lnAge, 2) + 13.54 * lnTotalChol - 3.114 * ageTotalChol
                - 13.578 * lnHdl + 3.149 * ageHdl + 2.019 * trlnsbp + 1.957 * ntlnsbp
                + (fumador ? 7.574 : 0) - 1.665 * ageSmoke + (diabetes ? 0.661 : 0);
        } else if (isBlack && isMale) {
            s0 = 0.89536; mean = 19.5425;
            predict = 2.469 * lnAge + 0.302 * lnTotalChol - 0.307 * lnHdl + 1.916 * trlnsbp + 1.809 * ntlnsbp
                + (fumador ? 0.549 : 0) + (diabetes ? 0.645 : 0);
        } else {
            s0 = 0.91436; mean = 61.1816;
            predict = 12.344 * lnAge + 11.853 * lnTotalChol - 2.664 * ageTotalChol - 7.99 * lnHdl + 1.769 * ageHdl
                + 1.797 * trlnsbp + 1.764 * ntlnsbp + (fumador ? 7.837 : 0) - 1.795 * ageSmoke + (diabetes ? 0.658 : 0);
        }

        const riskPct = (1 - Math.pow(s0, Math.exp(predict - mean))) * 100;
        const risk = Math.round(riskPct * 10) / 10;

        let label, color, description;
        if (risk < 5) { label = 'Riesgo bajo'; color = 'success'; description = 'Riesgo <5% a 10 años — énfasis en cambios de estilo de vida.'; }
        else if (risk < 7.5) { label = 'Riesgo límite'; color = 'warning'; description = 'Riesgo 5-7.4% a 10 años — considerar factores agravantes (historia familiar, PCR-us, calcio coronario) y decisión compartida sobre estatina.'; }
        else if (risk < 20) { label = 'Riesgo intermedio'; color = 'warning'; description = 'Riesgo 7.5-19.9% a 10 años — estatina de intensidad moderada generalmente razonable.'; }
        else { label = 'Riesgo alto'; color = 'danger'; description = 'Riesgo ≥20% a 10 años — estatina de alta intensidad recomendada.'; }

        return {
            value: risk, unit: '%', raceAproximada: raza === 'otro',
            interpretation: { label, color, description }
        };
    },

    // === 63. WELLS DVT (TROMBOSIS VENOSA PROFUNDA) === //
    calculateWellsDVT(inputs) {
        let score = 0;
        ['cancer', 'paralisisInmovilizacion', 'encamado', 'dolorLocalizado', 'piernaEdematizada', 'edemaPantorrilla', 'edemaFovea', 'venasColaterales', 'tvpPrevia']
            .forEach(k => { if (inputs[k]) score += 1; });
        if (inputs.diagnosticoAlternativo) score -= 2;

        let label, color, description;
        if (score <= 0) { label = 'Baja probabilidad'; color = 'success'; description = 'Probabilidad de TVP ~5% — considerar dímero D para descartar sin necesidad de imagen.'; }
        else if (score <= 2) { label = 'Probabilidad moderada'; color = 'warning'; description = 'Probabilidad de TVP ~17% — dímero D y/o ecografía Doppler.'; }
        else { label = 'Alta probabilidad'; color = 'danger'; description = 'Probabilidad de TVP ~53% — ecografía Doppler directa recomendada.'; }

        return { value: score, unit: 'pts', interpretation: { label, color, description } };
    },

    // === 64. ÍNDICE DE RIESGO CARDÍACO REVISADO (RCRI / LEE) === //
    calculateRCRI(inputs) {
        let score = 0;
        ['cirugiaAltoRiesgo', 'cardiopatiaIsquemica', 'icc', 'enfermedadCerebrovascular', 'diabetesInsulina', 'creatininaMayor2']
            .forEach(k => { if (inputs[k]) score += 1; });

        let clase, riesgo;
        if (score === 0) { clase = 'I'; riesgo = '~0.4%'; }
        else if (score === 1) { clase = 'II'; riesgo = '~1.0%'; }
        else if (score === 2) { clase = 'III'; riesgo = '~2.4%'; }
        else { clase = 'IV'; riesgo = '~5.4%'; }

        const color = score === 0 ? 'success' : (score <= 2 ? 'warning' : 'danger');
        return {
            value: score, unit: 'pts', clase, riesgo,
            interpretation: { label: `Clase ${clase}`, color, description: `Riesgo estimado de evento cardíaco mayor perioperatorio: ${riesgo}.` }
        };
    },

    // === 65. HUNT & HESS / WFNS (HEMORRAGIA SUBARACNOIDEA) === //
    HUNT_HESS_LEVELS: [
        { level: 1, label: 'Grado I', description: 'Asintomático o cefalea leve, rigidez de nuca leve' },
        { level: 2, label: 'Grado II', description: 'Cefalea moderada-severa, rigidez de nuca, sin déficit neurológico salvo parálisis de par craneal' },
        { level: 3, label: 'Grado III', description: 'Somnolencia, confusión, o déficit focal leve' },
        { level: 4, label: 'Grado IV', description: 'Estupor, hemiparesia moderada-severa' },
        { level: 5, label: 'Grado V', description: 'Coma, postura de descerebración' }
    ],
    WFNS_LEVELS: [
        { level: 1, label: 'Grado I', description: 'GCS 15, sin déficit motor' },
        { level: 2, label: 'Grado II', description: 'GCS 13-14, sin déficit motor' },
        { level: 3, label: 'Grado III', description: 'GCS 13-14, con déficit motor' },
        { level: 4, label: 'Grado IV', description: 'GCS 7-12, con o sin déficit motor' },
        { level: 5, label: 'Grado V', description: 'GCS 3-6, con o sin déficit motor' }
    ],
    calculateHuntHessWFNS(inputs) {
        const hh = this.HUNT_HESS_LEVELS.find(l => l.level === inputs.huntHess);
        const wfns = this.WFNS_LEVELS.find(l => l.level === inputs.wfns);
        const worst = Math.max(inputs.huntHess, inputs.wfns);
        const color = worst <= 2 ? 'success' : (worst === 3 ? 'warning' : 'danger');
        return {
            huntHess: inputs.huntHess, hhLabel: hh.description,
            wfns: inputs.wfns, wfnsLabel: wfns.description,
            value: worst, unit: '',
            interpretation: {
                label: `Hunt & Hess ${hh.label} · WFNS ${wfns.label}`,
                color,
                description: 'Ambas escalas correlacionan con el pronóstico — a mayor grado, mayor mortalidad/peor recuperación funcional esperada.'
            }
        };
    },

    // === 66. ICH SCORE (HEMORRAGIA INTRACEREBRAL) === //
    calculateICHScore(inputs) {
        const { gcs, volumenMayor30, hiv, infratentorial, edadMayor80 } = inputs;
        let score = 0;
        if (gcs <= 4) score += 2;
        else if (gcs <= 12) score += 1;
        if (volumenMayor30) score += 1;
        if (hiv) score += 1;
        if (infratentorial) score += 1;
        if (edadMayor80) score += 1;

        const mortalidad = { 0: '0%', 1: '13%', 2: '26%', 3: '72%', 4: '97%', 5: '100%', 6: '100%' }[score];
        const color = score <= 1 ? 'success' : (score <= 2 ? 'warning' : 'danger');
        return {
            value: score, unit: '/6', mortalidad,
            interpretation: { label: `ICH Score ${score}`, color, description: `Mortalidad estimada a 30 días: ${mortalidad} (Hemphill et al. 2001).` }
        };
    },

    // === 67. TRAUMA CRANEOCERVICAL — CANADIAN CT HEAD RULE + CANADIAN C-SPINE RULE === //
    calculateTraumaCraneocervical(inputs) {
        const cth = inputs.ctHead;
        const altoCth = cth.gcsMenor15 || cth.fracturaAbierta || cth.signoFracturaBase || cth.vomitos2 || cth.edad65;
        const medioCth = cth.amnesia30 || cth.mecanismoPeligroso;
        let ctHeadResultado;
        if (altoCth) ctHeadResultado = { necesitaTC: true, motivo: 'alto' };
        else if (medioCth) ctHeadResultado = { necesitaTC: true, motivo: 'medio' };
        else ctHeadResultado = { necesitaTC: false, motivo: null };

        const cs = inputs.cSpine;
        let cSpineResultado;
        const altoCs = cs.edad65 || cs.mecanismoPeligroso || cs.parestesias;
        if (altoCs) {
            cSpineResultado = { necesitaImagen: true, paso: 'alto_riesgo' };
        } else {
            const bajoCumplido = cs.choqueTrasero && cs.sentadoEnServicio && cs.deambulando && cs.dolorDiferido && cs.sinDolorLineaMedia;
            if (!bajoCumplido) {
                cSpineResultado = { necesitaImagen: true, paso: 'sin_bajo_riesgo' };
            } else if (cs.puedeRotar === false) {
                cSpineResultado = { necesitaImagen: true, paso: 'no_rota' };
            } else if (cs.puedeRotar === true) {
                cSpineResultado = { necesitaImagen: false, paso: 'rota_ok' };
            } else {
                cSpineResultado = { necesitaImagen: null, paso: 'evaluar_rotacion' };
            }
        }

        return {
            ctHead: ctHeadResultado, cSpine: cSpineResultado, value: null, unit: '',
            interpretation: {
                label: 'Reglas de Decisión de Trauma Craneocervical',
                color: 'info',
                description: 'Ver desglose de TC craneal (Canadian CT Head Rule) y columna cervical (Canadian C-Spine Rule) por separado.'
            }
        };
    },

    // === 68. ASPECTS SCORE (CAMBIOS ISQUÉMICOS TEMPRANOS EN TC) === //
    calculateAspects(inputs) {
        const regiones = ['caudado', 'lentiforme', 'capsulaInterna', 'cintillaInsular', 'm1', 'm2', 'm3', 'm4', 'm5', 'm6'];
        const afectadas = regiones.filter(r => inputs[r]).length;
        const score = 10 - afectadas;

        let label, color, description;
        if (score === 10) { label = 'ASPECTS 10 — Normal'; color = 'success'; description = 'Sin cambios isquémicos tempranos evidentes en el territorio de la ACM.'; }
        else if (score >= 6) { label = `ASPECTS ${score}`; color = 'warning'; description = 'Dentro del umbral habitual de elegibilidad para trombectomía mecánica — ver Código Ictus (Calculadora 48).'; }
        else { label = `ASPECTS ${score}`; color = 'danger'; description = 'Cambios isquémicos extensos — mayor riesgo de transformación hemorrágica con trombolisis/trombectomía; valorar con el equipo de ictus.'; }

        return { value: score, unit: '/10', interpretation: { label, color, description } };
    },

    // === 69. LESIÓN RENAL AGUDA — FeNa + ESTADIAJE KDIGO === //
    calculateFeNa(inputs) {
        const { naOrina, naPlasma, crOrina, crPlasma } = inputs;
        const fena = (naOrina * crPlasma) / (naPlasma * crOrina) * 100;
        const value = Math.round(fena * 100) / 100;

        let label, color, description;
        if (value < 1) { label = 'FeNa <1% — sugiere causa prerenal'; color = 'warning'; description = 'Sugiere causa prerenal (hipoperfusión) — la capacidad de reabsorción tubular de sodio está preservada.'; }
        else if (value > 2) { label = 'FeNa >2% — sugiere necrosis tubular aguda'; color = 'danger'; description = 'Sugiere daño tubular intrínseco (necrosis tubular aguda) — la capacidad de reabsorción de sodio está alterada.'; }
        else { label = 'FeNa 1-2% — zona indeterminada'; color = 'warning'; description = 'Zona indeterminada — puede verse en prerenal parcialmente tratada o NTA temprana; interpretar según el contexto clínico.'; }

        return { value, unit: '%', interpretation: { label, color, description } };
    },

    calculateAKIStaging(inputs) {
        const { crRatio, crAumentoAbs48h, crAbsoluta, diuresisMlKgH, diuresisHoras, trr, anuria12h } = inputs;

        let estadioCr = 0;
        if (typeof crAbsoluta === 'number' && crAbsoluta >= 4.0 && typeof crAumentoAbs48h === 'number' && crAumentoAbs48h >= 0.5) estadioCr = 3;
        else if (typeof crRatio === 'number' && crRatio >= 3.0) estadioCr = 3;
        else if (typeof crRatio === 'number' && crRatio >= 2.0) estadioCr = 2;
        else if ((typeof crRatio === 'number' && crRatio >= 1.5) || (typeof crAumentoAbs48h === 'number' && crAumentoAbs48h >= 0.3)) estadioCr = 1;

        let estadioDiuresis = 0;
        if (anuria12h || (typeof diuresisMlKgH === 'number' && diuresisMlKgH < 0.3 && diuresisHoras >= 24)) estadioDiuresis = 3;
        else if (typeof diuresisMlKgH === 'number' && diuresisMlKgH < 0.5 && diuresisHoras >= 12) estadioDiuresis = 2;
        else if (typeof diuresisMlKgH === 'number' && diuresisMlKgH < 0.5 && diuresisHoras >= 6) estadioDiuresis = 1;

        let estadio = Math.max(estadioCr, estadioDiuresis);
        if (trr) estadio = 3;

        const color = estadio === 0 ? 'success' : (estadio === 1 ? 'warning' : 'danger');
        const label = estadio === 0 ? 'Sin criterios de AKI' : `Estadio KDIGO ${estadio}`;
        return {
            value: estadio, unit: '', estadioCr, estadioDiuresis,
            interpretation: {
                label, color,
                description: estadio === 0
                    ? 'No cumple criterios de lesión renal aguda por creatinina ni por diuresis.'
                    : `Clasificado por el criterio más severo entre creatinina (Estadio ${estadioCr}) y diuresis (Estadio ${estadioDiuresis}).`
            }
        };
    },

    // === 70. ÍNDICE DE COMORBILIDAD DE CHARLSON === //
    calculateCharlson(inputs) {
        let score = 0;
        ['iam', 'icc', 'epa', 'cerebrovascular', 'demencia', 'epoc', 'tejidoConectivo', 'ulceraPeptica', 'hepatopatiaLeve', 'diabetesSinComplicaciones']
            .forEach(k => { if (inputs[k]) score += 1; });
        ['hemiplejia', 'erc', 'diabetesConComplicaciones', 'tumor', 'leucemia', 'linfoma']
            .forEach(k => { if (inputs[k]) score += 2; });
        if (inputs.hepatopatiaModeradaSevera) score += 3;
        ['tumorMetastasico', 'sida'].forEach(k => { if (inputs[k]) score += 6; });

        let ageAdj = 0;
        const edad = inputs.edad;
        if (edad >= 90) ageAdj = 5;
        else if (edad >= 80) ageAdj = 4;
        else if (edad >= 70) ageAdj = 3;
        else if (edad >= 60) ageAdj = 2;
        else if (edad >= 50) ageAdj = 1;

        const total = score + ageAdj;
        let supervivencia, color;
        if (total === 0) { supervivencia = '~98%'; color = 'success'; }
        else if (total <= 2) { supervivencia = '~90%'; color = 'success'; }
        else if (total <= 4) { supervivencia = '~53%'; color = 'warning'; }
        else { supervivencia = '~21%'; color = 'danger'; }

        return {
            value: total, unit: 'pts', comorbilidad: score, ajusteEdad: ageAdj, supervivencia,
            interpretation: { label: `Charlson ${total} pts`, color, description: `Supervivencia estimada a 10 años: ${supervivencia} (incluye ajuste por edad).` }
        };
    }
};

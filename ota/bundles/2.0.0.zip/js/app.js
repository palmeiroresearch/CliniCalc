// ============================================
// CLINICALC - APLICACIÓN PRINCIPAL
// Inicialización, navegación y event handlers
// ============================================

// === VARIABLES GLOBALES === //
let currentTab = 'calculators';
let currentCalculator = null;

// === INICIALIZACIÓN === //
document.addEventListener('DOMContentLoaded', () => {
    // Ocultar splash screen
    setTimeout(() => {
        document.getElementById('splashScreen').style.display = 'none';
        document.getElementById('app').style.display = 'flex';
    }, 2000);
    
    // Inicializar módulos
    Storage.init();
    UI.init();

    // Poblar sección Información (valores dinámicos)
    document.getElementById('appVersion').textContent = APP_VERSION;
    document.getElementById('calcCount').textContent = CALCULATORS_CONFIG.length;

    // Aplicar tema
    applyTheme();
    
    // Setup event listeners
    setupEventListeners();
    
    // Registrar Service Worker
    registerServiceWorker();
});

// === NAVEGACIÓN === //
function switchTab(tabName) {
    // Ocultar todos los tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Mostrar tab seleccionado
    document.getElementById(tabName + 'Tab').classList.add('active');
    
    // Actualizar navegación
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    
    currentTab = tabName;
    
    // Refrescar contenido si es necesario
    if (tabName === 'history') {
        UI.renderHistory();
    }
}

// === FILTRO ACTIVO DE LA BIBLIOTECA === //
// Lee la categoría del chip activo para no perder el filtro al re-renderizar
// tras marcar favorito o pantalla principal desde la Biblioteca.
function getActiveLibraryFilter() {
    const activeChip = document.querySelector('.filter-chip.active');
    return activeChip ? activeChip.dataset.category : 'all';
}

// === FAVORITOS === //
function toggleFavorite(calcId) {
    const isFav = Storage.toggleFavorite(calcId);

    // Actualizar UI
    UI.renderMainScreenCalculators();
    UI.renderLibraryCalculators(getActiveLibraryFilter());

    UI.showToast(
        isFav ? 'Añadido a favoritos' : 'Eliminado de favoritos',
        'success'
    );
}

// === GESTIÓN PANTALLA PRINCIPAL === //
function toggleCalcInMainScreen(calcId) {
    const mainScreen = Storage.getMainScreen();
    const isActive = mainScreen.includes(calcId);

    if (isActive) {
        const result = Storage.removeFromMainScreen(calcId);
        if (!result.success) {
            UI.showToast(result.error, 'error');
            return;
        }
        UI.showToast('Calculadora eliminada de pantalla principal', 'success');
    } else {
        const result = Storage.addToMainScreen(calcId);
        if (!result.success) {
            UI.showToast(result.error, 'warning');
            return;
        }
        UI.showToast('Calculadora añadida a pantalla principal', 'success');
    }

    UI.renderMainScreenCalculators();
    UI.renderLibraryCalculators(getActiveLibraryFilter());
    UI.renderManageCalculatorsList();
    UI.updateActiveCalcCount();
}

// === ABRIR CALCULADORA === //
function openCalculator(calcId) {
    const calc = CALCULATORS_CONFIG.find(c => c.id === calcId);
    if (!calc) return;
    
    currentCalculator = calc;
    
    // Crear modal de calculadora
    createCalculatorModal(calc);
}

function createCalculatorModal(calc) {
    // Crear overlay
    const overlay = document.createElement('div');
    overlay.id = 'calculatorModal';
    overlay.className = 'modal-overlay';
    overlay.style.cssText = `
        position: fixed;
        top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
        backdrop-filter: blur(4px);
        animation: fadeIn 0.2s ease;
        overflow-y: auto;
        padding: 20px;
    `;
    
    // Crear modal
    const modal = document.createElement('div');
    modal.className = 'calculator-modal';
    modal.style.cssText = `
        background: var(--bg-card);
        border-radius: var(--radius-xl);
        padding: 24px;
        max-width: 500px;
        width: 100%;
        max-height: 90vh;
        overflow-y: auto;
        box-shadow: var(--shadow-xl);
        animation: scaleIn 0.3s ease;
    `;
    
    modal.innerHTML = `
        <div class="modal-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <div>
                <h2 style="font-size: 20px; font-weight: 700; margin-bottom: 4px;">${calc.icon} ${calc.fullName}</h2>
                <p style="font-size: 13px; color: var(--text-secondary);">${calc.description}</p>
            </div>
            <button class="btn-icon" onclick="event.stopPropagation(); closeCalculatorModal()" style="flex-shrink: 0;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="pointer-events:none;">
                    <line x1="18" y1="6" x2="6" y2="18"/>
                    <line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
            </button>
        </div>
        <div id="calculatorContent"></div>
    `;
    
    overlay.appendChild(modal);
    document.body.appendChild(overlay);
    
    // Cargar formulario específico
    loadCalculatorForm(calc);
    
    // Cerrar al hacer click fuera
    overlay.onclick = (e) => {
        if (e.target === overlay) {
            closeCalculatorModal();
        }
    };
}

function closeCalculatorModal() {
    const modal = document.getElementById('calculatorModal');
    if (!modal) return;
    modal.style.animation = 'fadeOut 0.2s ease forwards';
    setTimeout(() => modal.remove(), 210);
}

// === CARGAR FORMULARIO DE CALCULADORA === //
function loadCalculatorForm(calc) {
    const container = document.getElementById('calculatorContent');
    
    // Cargar formulario según ID de calculadora
    switch(calc.id) {
        case 1: container.innerHTML = createGFRForm(); break;
        case 2: container.innerHTML = createClearance24hForm(); break;
        case 3: container.innerHTML = createAnionGapForm(); break;
        case 4: container.innerHTML = createCorrectedCalciumForm(); break;
        case 5: container.innerHTML = createCorrectedSodiumForm(); break;
        case 6: container.innerHTML = createBMIForm(); break;
        case 7: container.innerHTML = createBSAForm(); break;
        case 8: container.innerHTML = createOsmolarityForm(); break;
        case 9: container.innerHTML = createCHADSVAScForm(); break;
        case 10: container.innerHTML = createHASBLEDForm(); break;
        case 11: container.innerHTML = createChildPughForm(); break;
        case 12: container.innerHTML = createCURB65Form(); break;
        case 13: container.innerHTML = createQSOFAForm(); break;
        case 14: container.innerHTML = createWellsTEPForm(); break;
        case 15: container.innerHTML = createMELDForm(); break;
        case 16: container.innerHTML = createSOFAForm(); break;
        case 17: container.innerHTML = createNIHSSForm(); break;
        case 18: container.innerHTML = createGlasgowForm(); break;
        case 19: container.innerHTML = createTIMI_NSTEMIForm(); break;
        case 20: container.innerHTML = createTIMI_STEMIForm(); break;
        case 21: container.innerHTML = createGRACEForm(); break;
        case 22: container.innerHTML = createBradenForm(); break;
        case 23: container.innerHTML = createMACOCHAForm(); break;
        case 24: container.innerHTML = createPBWForm(); break;
        case 25: container.innerHTML = createFOURScoreForm(); break;
        case 26: container.innerHTML = createHEARTForm(); break;
        case 27: container.innerHTML = createPERCForm(); break;
        case 28: container.innerHTML = createDKAForm(); break;
        case 29: container.innerHTML = createIVCalculatorForm(); break;
        case 30: container.innerHTML = createAntibioticsForm(); _abShowInitial(); break;
        case 31: container.innerHTML = createAsmaForm(); break;
        case 32: container.innerHTML = createAsmaControlForm(); break;
        case 33: container.innerHTML = createLESForm(); break;
        case 34: container.innerHTML = createPAMForm(); break;
        case 35: container.innerHTML = createCalculadoraForm(); break;
        case 36: container.innerHTML = createKillipForm(); break;
        case 37: container.innerHTML = createPSIForm(); break;
        case 38: container.innerHTML = createFibrosisForm(); break;
        case 39: container.innerHTML = createEPOCForm(); break;
        case 40: container.innerHTML = createHHSForm(); break;
        case 41: container.innerHTML = createHypertensiveCrisisForm(); break;
        case 42: container.innerHTML = createStatusEpilepticusForm(); break;
        case 43: container.innerHTML = createSepsisBundleForm(); break;
        case 44: container.innerHTML = createEAPForm(); break;
        case 45: container.innerHTML = createArritmiaForm(); break;
        case 46: container.innerHTML = createParoForm(); break;
        case 47: container.innerHTML = createDengueForm(); break;
        case 48: container.innerHTML = createCodigoIctusForm(); break;
        case 49: container.innerHTML = createGasometriaForm(); break;
        case 50: container.innerHTML = createQTcForm(); break;
        case 51: container.innerHTML = createABCD2Form(); break;
        case 52: container.innerHTML = createRankinForm(); break;
        case 53: container.innerHTML = createVTEForm(); break;
        case 54: container.innerHTML = create4TsForm(); break;
        case 55: container.innerHTML = createParklandForm(); break;
        case 56: container.innerHTML = createRassCamForm(); break;
        case 57: container.innerHTML = createAbstinenciaForm(); break;
        case 58: container.innerHTML = createHDAForm(); break;
        case 59: container.innerHTML = createPancreatitisForm(); break;
        case 60: container.innerHTML = createParacetamolForm(); break;
        case 61: container.innerHTML = createLabReferenceForm(); _labShowInitial(); break;
        case 62: container.innerHTML = createASCVDForm(); break;
        case 63: container.innerHTML = createWellsDVTForm(); break;
        case 64: container.innerHTML = createRCRIForm(); break;
        case 65: container.innerHTML = createHuntHessWFNSForm(); break;
        case 66: container.innerHTML = createICHScoreForm(); break;
        case 67: container.innerHTML = createTraumaCraneocervicalForm(); break;
        case 68: container.innerHTML = createAspectsForm(); break;
        case 69: container.innerHTML = createAKIForm(); break;
        case 70: container.innerHTML = createCharlsonForm(); break;
        default:
            container.innerHTML = `
                <div class="coming-soon" style="text-align: center; padding: 40px 20px;">
                    <div style="font-size: 48px; margin-bottom: 16px;">🚧</div>
                    <h3 style="margin-bottom: 8px;">Error</h3>
                    <p style="color: var(--text-secondary);">Calculadora no encontrada</p>
                </div>
            `;
    }
}

function createGFRForm() {
    const units = Storage.getSettings().units;
    
    // Ajustar validación según unidad
    const crMax = units.creatinine === 'mg/dL' ? 20 : 2000;
    
    return `
        <form id="gfrForm" onsubmit="calculateGFR(event)">
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">Fórmula</label>
                <select id="gfrFormula" class="form-input" onchange="toggleGFRFields()">
                    <option value="CKD-EPI 2021">CKD-EPI 2021 (Recomendada - sin raza)</option>
                    <option value="CKD-EPI 2009">CKD-EPI 2009 (con factor racial)</option>
                    <option value="Cockroft-Gault">Cockroft-Gault (requiere peso)</option>
                    <option value="MDRD">MDRD (con factor racial)</option>
                </select>
            </div>
            
            <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px;">
                <div class="form-group">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">Edad (años)</label>
                    <input type="number" id="gfrAge" required min="18" max="120" class="form-input">
                </div>
                <div class="form-group">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">Sexo</label>
                    <select id="gfrSex" required class="form-input">
                        <option value="M">Masculino</option>
                        <option value="F">Femenino</option>
                    </select>
                </div>
            </div>
            
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Creatinina sérica (${units.creatinine})
                </label>
                <input type="number" id="gfrCreatinine" required step="any" min="0.1" max="${crMax}" class="form-input">
            </div>
            
            <div id="gfrWeightField" class="form-group" style="margin-bottom: 16px; display: none;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Peso (${units.weight}) <span style="color: var(--danger);">*</span>
                </label>
                <input type="number" id="gfrWeight" step="any" min="30" max="300" class="form-input">
            </div>
            
            <div id="gfrRaceField" class="form-group" style="margin-bottom: 16px; display: none;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">Raza</label>
                <select id="gfrRace" class="form-input">
                    <option value="other">Otra</option>
                    <option value="black">Afroamericana</option>
                </select>
            </div>
            
            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular GFR
            </button>
        </form>
        <div id="gfrResult" style="display: none; margin-top: 24px;"></div>
    `;
}

// Función para mostrar/ocultar campos según fórmula seleccionada
function toggleGFRFields() {
    const formula = document.getElementById('gfrFormula').value;
    const weightField = document.getElementById('gfrWeightField');
    const weightInput = document.getElementById('gfrWeight');
    const raceField = document.getElementById('gfrRaceField');
    const raceInput = document.getElementById('gfrRace');
    
    // Reset
    weightField.style.display = 'none';
    weightInput.required = false;
    raceField.style.display = 'none';
    
    // Cockroft-Gault necesita peso
    if (formula === 'Cockroft-Gault') {
        weightField.style.display = 'block';
        weightInput.required = true;
    }
    
    // CKD-EPI 2009 y MDRD necesitan raza
    if (formula === 'CKD-EPI 2009' || formula === 'MDRD') {
        raceField.style.display = 'block';
    }
}

function calculateGFR(event) {
    event.preventDefault();
    
    const formula = document.getElementById('gfrFormula').value;
    const age = parseInt(document.getElementById('gfrAge').value);
    const sex = document.getElementById('gfrSex').value;
    const creatinine = parseFloat(document.getElementById('gfrCreatinine').value);
    
    // Peso solo para Cockroft-Gault
    const weightInput = document.getElementById('gfrWeight');
    const weight = weightInput && weightInput.value ? parseFloat(weightInput.value) : null;
    
    // Raza solo para CKD-EPI 2009 y MDRD
    const raceInput = document.getElementById('gfrRace');
    const race = raceInput ? raceInput.value : 'other';
    
    const inputs = { age, sex, creatinine, weight, race };
    const result = Calculators.calculateGFR(inputs, formula);
    
    // Mostrar resultado
    displayResult(result, inputs, 1, 'GFR', formula);
    
    // Guardar en historial
    Storage.addToHistory({
        calculatorId: 1,
        calculatorName: 'GFR',
        formula: formula,
        inputs: inputs,
        result: result,
        interpretation: result.interpretation
    });
}

function displayResult(result, inputs, calcId, calcName, formula) {
    const container = document.getElementById('gfrResult');
    
    container.innerHTML = `
        <div class="result-card" style="background: linear-gradient(135deg, var(--brand-accent-dark), var(--brand-accent)); padding: 24px; border-radius: var(--radius-lg); color: var(--brand-primary-dark); margin-bottom: 16px;">
            <div style="font-size: 13px; font-weight: 600; margin-bottom: 8px; opacity: 0.8;">RESULTADO</div>
            <div style="font-size: 36px; font-weight: 800; margin-bottom: 4px;">
                ${result.value} <span style="font-size: 20px; font-weight: 600;">${result.unit}</span>
            </div>
            <div style="font-size: 14px; font-weight: 600;">
                ${result.interpretation.stage ? result.interpretation.stage + ': ' : ''}${result.interpretation.label}
            </div>
        </div>
        
        <div class="interpretation-card" style="background: var(--bg-secondary); padding: 20px; border-radius: var(--radius-lg); border-left: 4px solid var(--${result.interpretation.color});">
            <h4 style="font-size: 14px; font-weight: 700; margin-bottom: 8px;">Interpretación</h4>
            <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.6;">
                ${result.interpretation.description}
            </p>
        </div>
        
        <div style="display: flex; gap: 12px; margin-top: 16px;">
            <button class="btn btn-secondary" onclick="shareGFRResult()" style="flex: 1;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M4 12v8a2 2 0 002 2h12a2 2 0 002-2v-8"/>
                    <polyline points="16 6 12 2 8 6"/>
                    <line x1="12" y1="2" x2="12" y2="15"/>
                </svg>
                Compartir
            </button>
            <button class="btn btn-secondary" onclick="document.getElementById('gfrForm').reset(); document.getElementById('gfrResult').style.display='none';" style="flex: 1;">
                🔄 Nuevo Cálculo
            </button>
        </div>
    `;
    
    container.style.display = 'block';
    
    // Animar aparición
    container.style.animation = 'slideDown 0.4s ease';
}

function shareGFRResult() {
    // Implementar compartir
    UI.showToast('Resultado copiado al portapapeles', 'success');
}

// === HISTORIAL === //
function recalculate(itemId) {
    const item = Storage.getHistory().find(h => h.id === itemId);
    if (!item) return;

    openCalculator(item.calculatorId);

    // Pre-rellenar campos con los valores guardados (best-effort)
    requestAnimationFrame(() => {
        if (!item.inputs) return;

        // Si hay fórmula (ej. GFR), intentar seleccionarla
        if (item.formula) {
            const formulaEl = document.querySelector('select[id$="Formula"], select[id*="formula"]');
            if (formulaEl) {
                formulaEl.value = item.formula;
                formulaEl.dispatchEvent(new Event('change', { bubbles: true }));
            }
        }

        Object.entries(item.inputs).forEach(([key, value]) => {
            if (value === null || value === undefined) return;
            // 1. Coincidencia exacta de ID
            let el = document.getElementById(key);
            // 2. Coincidencia parcial (ID contiene el key, ej. "sofaGCS" contiene "gcs" no, pero "bradenSensory" contiene "sensory")
            if (!el) el = document.querySelector(`[id$="${key}"], [id*="${key}"]`);
            if (!el) return;

            if (el.type === 'checkbox') {
                el.checked = Boolean(value);
            } else {
                el.value = value;
            }
            el.dispatchEvent(new Event('change', { bubbles: true }));
            el.dispatchEvent(new Event('input', { bubbles: true }));
        });

        // Actualizar totales en vivo (Glasgow, Braden)
        if (typeof updateGlasgowTotal === 'function') updateGlasgowTotal();
        if (typeof updateBradenTotal === 'function') updateBradenTotal();
    });
}

function shareResult(itemId) {
    const item = Storage.getHistory().find(h => h.id === itemId);
    if (!item) return;

    const patientLine = item.patientName
        ? `👤 *${item.patientName}*${item.bedNumber ? ` · Cama ${item.bedNumber}` : ''}\n`
        : '';
    const formulaLine = item.formula ? ` (${item.formula})` : '';
    const date = new Date(item.timestamp).toLocaleString('es-ES', {
        day: '2-digit', month: '2-digit', year: 'numeric',
        hour: '2-digit', minute: '2-digit'
    });

    const text = `🏥 *CliniCalc — ${item.calculatorName}${formulaLine}*
${patientLine}
📊 Resultado: *${item.result.value} ${item.result.unit}*
🔍 ${item.interpretation.label}
${item.interpretation.description}

📅 ${date}
_Calculado con CliniCalc_`;

    if (navigator.share) {
        navigator.share({ title: `CliniCalc — ${item.calculatorName}`, text })
            .catch(() => openWhatsApp(text));
    } else {
        openWhatsApp(text);
    }
}

function openWhatsApp(text) {
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
}

function editPatientInfo(itemId) {
    const display = document.getElementById(`patient-display-${itemId}`);
    const edit    = document.getElementById(`patient-edit-${itemId}`);
    if (!display || !edit) return;
    display.style.display = 'none';
    edit.style.display    = 'flex';
    document.getElementById(`pname-${itemId}`).focus();
}

function cancelPatientEdit(itemId) {
    const display = document.getElementById(`patient-display-${itemId}`);
    const edit    = document.getElementById(`patient-edit-${itemId}`);
    if (!display || !edit) return;
    display.style.display = '';
    edit.style.display    = 'none';
}

function savePatientInfo(itemId) {
    const name = document.getElementById(`pname-${itemId}`).value.trim();
    const bed  = document.getElementById(`pbed-${itemId}`).value.trim();
    Storage.updateHistoryItem(itemId, {
        patientName: name || null,
        bedNumber:   bed  || null
    });
    UI.renderHistory();
    UI.showToast('Datos del paciente guardados', 'success');
}

function deleteHistoryItem(itemId) {
    UI.showConfirmDialog(
        '¿Eliminar cálculo?',
        'Esta acción no se puede deshacer',
        () => {
            Storage.deleteHistoryItem(itemId);
            UI.renderHistory();
            UI.showToast('Cálculo eliminado', 'success');
        }
    );
}

function clearAllHistory() {
    UI.showConfirmDialog(
        '¿Limpiar todo el historial?',
        'Se eliminarán todos los cálculos guardados',
        () => {
            Storage.clearHistory();
            UI.renderHistory();
            UI.showToast('Historial limpiado', 'success');
        }
    );
}

// === AJUSTES === //
function applyTheme() {
    const darkMode = Storage.getSetting('darkMode');
    if (darkMode) {
        document.body.classList.add('dark-mode');
        document.getElementById('darkModeToggle').checked = true;
    } else {
        document.body.classList.remove('dark-mode');
        document.getElementById('darkModeToggle').checked = false;
    }
}

function restoreDefaultConfig() {
    UI.showConfirmDialog(
        '¿Restaurar configuración?',
        'Se restaurará la configuración predeterminada. No se perderá el historial.',
        () => {
            Storage.restoreDefaults();
            location.reload();
        }
    );
}

// === EVENT LISTENERS === //
function setupEventListeners() {
    // Navegación
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', () => {
            switchTab(item.dataset.tab);
        });
    });
    
    // Búsqueda
    const searchBtn = document.getElementById('searchBtn');
    const searchContainer = document.getElementById('searchContainer');
    const searchInput = document.getElementById('searchInput');
    const clearSearch = document.getElementById('clearSearch');
    
    searchBtn.addEventListener('click', () => {
        searchContainer.style.display = 'block';
        searchInput.focus();
    });
    
    searchInput.addEventListener('input', (e) => {
        const query = e.target.value;
        clearSearch.style.display = query ? 'block' : 'none';
        UI.handleSearch(query);
    });
    
    clearSearch.addEventListener('click', () => {
        searchInput.value = '';
        clearSearch.style.display = 'none';
        UI.hideSearchResults();
    });
    
    // Filtros de categoría
    document.querySelectorAll('.filter-chip').forEach(chip => {
        chip.addEventListener('click', () => {
            document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
            chip.classList.add('active');
            UI.renderLibraryCalculators(chip.dataset.category);
        });
    });
    
    // Modo oscuro
    document.getElementById('darkModeToggle').addEventListener('change', (e) => {
        Storage.updateSetting('darkMode', e.target.checked);
        applyTheme();
    });
    
    // Unidades
    const unitSelects = ['unitCreatinine', 'unitWeight', 'unitHeight', 'unitGlucose', 'unitBun'];
    unitSelects.forEach(id => {
        const select = document.getElementById(id);
        if (select) {
            const unitType = id.replace('unit', '').toLowerCase();
            select.value = Storage.getSetting(`units.${unitType}`);
            select.addEventListener('change', (e) => {
                Storage.updateSetting(`units.${unitType}`, e.target.value);
                UI.showToast('Unidad actualizada', 'success');
            });
        }
    });
    
    // Botones de gestión
    document.getElementById('manageCalcsBtn')?.addEventListener('click', () => {
        switchTab('settings');
        // Scroll hacia la sección de gestión
        setTimeout(() => {
            const manageSection = document.querySelector('.settings-section:nth-child(3)');
            if (manageSection) {
                manageSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        }, 100);
    });
    document.getElementById('reorderCalcsBtn')?.addEventListener('click', showReorderModal);
    document.getElementById('restoreDefaultBtn')?.addEventListener('click', restoreDefaultConfig);
    document.getElementById('clearHistoryBtn')?.addEventListener('click', clearAllHistory);
    document.getElementById('clearAllHistoryBtn')?.addEventListener('click', clearAllHistory);
    
    // Storage events
    window.addEventListener('storage:mainScreenChanged', () => {
        UI.renderMainScreenCalculators();
        UI.updateActiveCalcCount();
    });
    
    window.addEventListener('storage:favoritesChanged', () => {
        UI.renderMainScreenCalculators();
        UI.renderLibraryCalculators();
    });
    
    window.addEventListener('storage:historyChanged', () => {
        UI.renderHistory();
    });
}

function hideSearch() {
    document.getElementById('searchContainer').style.display = 'none';
    document.getElementById('searchInput').value = '';
    UI.hideSearchResults();
}

// === SERVICE WORKER === //
let swRegistration = null;

function registerServiceWorker() {
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('./sw.js')
            .then(reg => {
                swRegistration = reg;
                console.log('✅ Service Worker registrado');
                document.getElementById('offlineStatus').textContent = '✅ Activo';
                
                // Detectar actualizaciones
                reg.addEventListener('updatefound', () => {
                    const newWorker = reg.installing;
                    console.log('🔄 Nueva versión detectada');
                    
                    newWorker.addEventListener('statechange', () => {
                        if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                            // Hay una nueva versión disponible
                            showUpdateBanner(reg);
                        }
                    });
                });
                
                // Verificar si ya hay una actualización esperando
                if (reg.waiting) {
                    showUpdateBanner(reg);
                }
            })
            .catch(err => {
                console.error('❌ Error SW:', err);
                document.getElementById('offlineStatus').textContent = '❌ Error';
            });
        
        // Escuchar mensajes del SW (para confirmar actualización)
        navigator.serviceWorker.addEventListener('controllerchange', () => {
            console.log('🔄 Controlador actualizado, recargando...');
            window.location.reload();
        });
    }
}

async function checkForUpdates() {
    const btn = document.getElementById('checkUpdateBtn');
    btn.disabled = true;
    const originalText = btn.innerHTML;
    btn.innerHTML = '<span style="display:inline-flex;align-items:center;gap:6px;"><span class="update-spinner" style="width:14px;height:14px;border-width:2px;"></span> Verificando...</span>';

    try {
        // Dentro de la app nativa (APK), el mecanismo real es el OTA propio
        // (@capgo/capacitor-updater self-hosted) — el Service Worker no
        // aplica igual ahí, así que usamos window.OtaUpdater en vez de
        // swRegistration.update() cuando corremos nativo.
        if (window.OtaUpdater && window.Capacitor && Capacitor.isNativePlatform()) {
            const result = await window.OtaUpdater.checkNow();

            if (result.error === 'manifest') {
                UI.showToast('No se pudo verificar (sin conexión o el manifiesto no respondió)', 'error');
            } else if (result.error) {
                UI.showToast('Error al verificar actualizaciones', 'error');
            } else if (result.staged) {
                UI.showToast(`Nueva versión ${result.latestVersion} descargada — se aplicará al cerrar y reabrir la app`, 'success');
            } else if (result.upToDate) {
                UI.showToast(`Ya tienes la versión más reciente (${result.runningVersion}) ✓`, 'success');
            }
            return;
        }

        // Contexto web/PWA: comportamiento original, basado en Service Worker.
        if (!swRegistration) {
            UI.showToast('Service Worker no disponible', 'error');
            return;
        }

        let updateDetected = false;
        swRegistration.addEventListener('updatefound', () => { updateDetected = true; }, { once: true });

        await swRegistration.update();
        await new Promise(r => setTimeout(r, 1200));
        if (!updateDetected && !swRegistration.waiting) {
            UI.showToast('Ya tienes la versión más reciente ✓', 'success');
        }
    } catch {
        UI.showToast('Error al verificar actualizaciones', 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalText;
    }
}

function showFullResult(itemId) {
    const item = Storage.getHistory().find(h => h.id === itemId);
    if (!item) return;

    let bodyHTML;
    if (item.calculatorId === 28) {
        const r = Calculators.calculateDKA(item.inputs);
        bodyHTML = buildDKAProtocolHTML(r, item.inputs);
    } else if (item.calculatorId === 31) {
        const r = Calculators.calculateAsma(item.inputs);
        bodyHTML = buildAsmaProtocolHTML(r, item.inputs);
    } else if (item.calculatorId === 32) {
        const r = Calculators.calculateAsmaControl(item.inputs);
        bodyHTML = buildAsmaControlProtocolHTML(r, item.inputs);
    } else if (item.calculatorId === 33) {
        const r = Calculators.calculateLES(item.inputs);
        bodyHTML = buildLESResultHTML(r, item.inputs);
    } else if (item.calculatorId === 36) {
        const r = Calculators.calculateKillip(item.inputs);
        bodyHTML = buildKillipResultHTML(r);
    } else if (item.calculatorId === 37) {
        const r = Calculators.calculatePSI(item.inputs);
        bodyHTML = buildPSIResultHTML(r);
    } else if (item.calculatorId === 38) {
        const r = Calculators.calculateFibrosis(item.inputs);
        bodyHTML = buildFibrosisResultHTML(r);
    } else if (item.calculatorId === 39) {
        const r = Calculators.calculateEPOC(item.inputs);
        bodyHTML = buildEPOCResultHTML(r);
    } else {
        const colorMap = { success: 'var(--success)', warning: 'var(--warning)', danger: 'var(--danger)' };
        const c = colorMap[item.interpretation?.color] || 'var(--brand-accent)';
        bodyHTML = `
            <div style="background:linear-gradient(135deg,var(--brand-accent-dark),var(--brand-accent));
                        padding:24px; border-radius:var(--radius-lg); color:var(--brand-primary-dark); margin-bottom:16px;">
                <div style="font-size:13px; font-weight:600; margin-bottom:8px; opacity:0.8;">${item.calculatorName}</div>
                <div style="font-size:36px; font-weight:800; margin-bottom:4px;">
                    ${item.result?.value ?? '—'} <span style="font-size:20px;">${item.result?.unit ?? ''}</span>
                </div>
                <div style="font-size:14px; font-weight:600;">${item.interpretation?.label ?? ''}</div>
            </div>
            <div style="background:var(--bg-secondary); padding:20px; border-radius:var(--radius-lg);
                        border-left:4px solid ${c}; margin-bottom:8px;">
                <h4 style="font-size:14px; font-weight:700; margin-bottom:8px;">Interpretación completa</h4>
                <p style="font-size:13px; color:var(--text-secondary); line-height:1.6;">
                    ${item.interpretation?.description ?? 'Sin descripción disponible'}
                </p>
            </div>`;
    }

    const overlay = document.createElement('div');
    overlay.id = 'fullResultOverlay';
    overlay.style.cssText = `position:fixed;inset:0;background:rgba(0,0,0,0.6);display:flex;
        align-items:flex-start;justify-content:center;z-index:10000;
        backdrop-filter:blur(4px);animation:fadeIn 0.2s ease;overflow-y:auto;padding:20px;`;

    const ts = new Date(item.timestamp).toLocaleString('es-ES', {
        day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit'
    });
    const patientLine = item.patientName ? ` · ${item.patientName}${item.bedNumber ? ' · Cama ' + item.bedNumber : ''}` : '';

    overlay.innerHTML = `
        <div style="background:var(--bg-card); border-radius:var(--radius-xl); padding:24px;
                    max-width:560px; width:100%; margin:auto; box-shadow:var(--shadow-xl);
                    animation:scaleIn 0.3s ease;">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:16px;">
                <div>
                    <h2 style="font-size:18px; font-weight:700; margin-bottom:2px;">${item.calculatorName}</h2>
                    <p style="font-size:12px; color:var(--text-secondary);">${ts}${patientLine}</p>
                </div>
                <button onclick="event.stopPropagation(); document.getElementById('fullResultOverlay').remove();"
                        style="background:var(--bg-secondary);border:none;width:36px;height:36px;border-radius:8px;
                               cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="pointer-events:none;">
                        <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                    </svg>
                </button>
            </div>
            <div>${bodyHTML}</div>
        </div>`;

    overlay.onclick = e => { if (e.target === overlay) overlay.remove(); };
    document.body.appendChild(overlay);
}

function showUpdateBanner(registration) {
    if (document.getElementById('updateBanner')) return;

    const banner = document.createElement('div');
    banner.id = 'updateBanner';
    banner.className = 'update-banner';

    banner.innerHTML = `
        <div class="update-banner__icon">🔄</div>
        <div class="update-banner__body">
            <div class="update-banner__title">Nueva versión disponible</div>
            <div class="update-banner__sub">Toca "Ahora" para aplicar la actualización</div>
        </div>
        <div class="update-banner__actions">
            <button id="updateNowBtn" class="update-btn update-btn--primary">Ahora</button>
            <button id="dismissUpdateBtn" class="update-btn update-btn--secondary">Luego</button>
        </div>
    `;

    document.body.appendChild(banner);

    document.getElementById('updateNowBtn').addEventListener('click', () => {
        if (registration.waiting) {
            registration.waiting.postMessage({ type: 'SKIP_WAITING' });
        }
        banner.innerHTML = `
            <div class="update-banner__icon">
                <div class="update-spinner"></div>
            </div>
            <div class="update-banner__body">
                <div class="update-banner__title">Aplicando actualización…</div>
                <div class="update-banner__sub">La app se recargará en un momento</div>
            </div>
        `;
    });

    document.getElementById('dismissUpdateBtn').addEventListener('click', () => {
        banner.classList.add('update-banner--dismissing');
        setTimeout(() => banner.remove(), 350);
    });
}

// ============================================
// FORMULARIOS DE CALCULADORAS
// ============================================

// === 2. CLEARANCE CREATININA 24H === //
function createClearance24hForm() {
    const units = Storage.getSettings().units;
    return `
        <form id="clearance24hForm" onsubmit="calculateClearance24h(event)">
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Creatinina en orina (${units.creatinine})
                </label>
                <input type="number" id="creatinineUrine" required step="any" class="form-input">
            </div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Creatinina sérica (${units.creatinine})
                </label>
                <input type="number" id="creatinineSerum" required step="any" class="form-input">
            </div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Volumen de orina en 24h (mL)
                </label>
                <input type="number" id="urineVolume" required step="any" class="form-input">
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular Clearance
            </button>
        </form>
        <div id="clearance24hResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateClearance24h(event) {
    event.preventDefault();
    const inputs = {
        creatinineUrine: parseFloat(document.getElementById('creatinineUrine').value),
        creatinineSerum: parseFloat(document.getElementById('creatinineSerum').value),
        urineVolume: parseFloat(document.getElementById('urineVolume').value)
    };
    const result = Calculators.calculateClearance24h(inputs);
    displayGenericResult(result, inputs, 2, 'Clearance Cr 24h', null, 'clearance24hResult');
    Storage.addToHistory({ calculatorId: 2, calculatorName: 'Clearance Cr 24h', inputs, result, interpretation: result.interpretation });
}

// === 4. CALCIO CORREGIDO === //
function createCorrectedCalciumForm() {
    return `
        <form id="correctedCalciumForm" onsubmit="calculateCorrectedCalcium(event)">
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Calcio sérico (mg/dL)
                </label>
                <input type="number" id="calcium" required step="any" min="6" max="15" class="form-input">
            </div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Albúmina sérica (g/dL)
                </label>
                <input type="number" id="albuminCa" required step="any" min="1.5" max="6" class="form-input">
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular Calcio Corregido
            </button>
        </form>
        <div id="correctedCalciumResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateCorrectedCalcium(event) {
    event.preventDefault();
    const inputs = {
        calcium: parseFloat(document.getElementById('calcium').value),
        albumin: parseFloat(document.getElementById('albuminCa').value)
    };
    const result = Calculators.calculateCorrectedCalcium(inputs);
    displayGenericResult(result, inputs, 4, 'Calcio Corregido', null, 'correctedCalciumResult');
    Storage.addToHistory({ calculatorId: 4, calculatorName: 'Calcio Corregido', inputs, result, interpretation: result.interpretation });
}

// === 5. SODIO CORREGIDO === //
function createCorrectedSodiumForm() {
    const units = Storage.getSettings().units;
    return `
        <form id="correctedSodiumForm" onsubmit="calculateCorrectedSodium(event)">
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Sodio sérico (mEq/L)
                </label>
                <input type="number" id="sodiumNa" required step="any" min="120" max="160" class="form-input">
            </div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Glucosa (${units.glucose})
                </label>
                <input type="number" id="glucose" required step="any" class="form-input">
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular Sodio Corregido
            </button>
        </form>
        <div id="correctedSodiumResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateCorrectedSodium(event) {
    event.preventDefault();
    const inputs = {
        sodium: parseFloat(document.getElementById('sodiumNa').value),
        glucose: parseFloat(document.getElementById('glucose').value)
    };
    const result = Calculators.calculateCorrectedSodium(inputs);
    
    const container = document.getElementById('correctedSodiumResult');
    container.innerHTML = `
        <div class="result-card" style="background: linear-gradient(135deg, var(--brand-accent-dark), var(--brand-accent)); padding: 24px; border-radius: var(--radius-lg); color: var(--brand-primary-dark); margin-bottom: 16px;">
            <div style="font-size: 13px; font-weight: 600; margin-bottom: 8px; opacity: 0.8;">SODIO CORREGIDO</div>
            <div style="font-size: 36px; font-weight: 800; margin-bottom: 4px;">
                ${result.value} <span style="font-size: 20px; font-weight: 600;">${result.unit}</span>
            </div>
            <div style="font-size: 14px; font-weight: 600; margin-bottom: 12px;">
                ${result.interpretation.label}
            </div>
            <div style="background: rgba(30, 56, 114, 0.15); padding: 12px; border-radius: 8px; font-size: 13px;">
                <strong>Fórmula de Katz:</strong> ${result.value} ${result.unit}<br>
                <strong>Fórmula de Hillier:</strong> ${result.hillier} ${result.unit}
            </div>
        </div>
        <div class="interpretation-card" style="background: var(--bg-secondary); padding: 20px; border-radius: var(--radius-lg); border-left: 4px solid var(--${result.interpretation.color});">
            <h4 style="font-size: 14px; font-weight: 700; margin-bottom: 8px;">Interpretación</h4>
            <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.6;">
                ${result.interpretation.description}
            </p>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('correctedSodiumForm').reset(); document.getElementById('correctedSodiumResult').style.display='none';" style="width: 100%; margin-top: 16px;">
            🔄 Nuevo Cálculo
        </button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 5, calculatorName: 'Sodio Corregido', inputs, result, interpretation: result.interpretation });
}

// === 6. IMC === //
function createBMIForm() {
    const units = Storage.getSettings().units;
    return `
        <form id="bmiForm" onsubmit="calculateBMI(event)">
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Peso (${units.weight})
                </label>
                <input type="number" id="weight" required step="any" min="30" max="300" class="form-input">
            </div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Altura (${units.height})
                </label>
                <input type="number" id="height" required step="any" class="form-input">
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular IMC
            </button>
        </form>
        <div id="bmiResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateBMI(event) {
    event.preventDefault();
    const inputs = {
        weight: parseFloat(document.getElementById('weight').value),
        height: parseFloat(document.getElementById('height').value)
    };
    const result = Calculators.calculateBMI(inputs);
    displayGenericResult(result, inputs, 6, 'IMC', null, 'bmiResult');
    Storage.addToHistory({ calculatorId: 6, calculatorName: 'IMC', inputs, result, interpretation: result.interpretation });
}

// === 7. BSA === //
function createBSAForm() {
    const units = Storage.getSettings().units;
    return `
        <form id="bsaForm" onsubmit="calculateBSA(event)">
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">Fórmula</label>
                <select id="bsaFormula" class="form-input">
                    <option value="Mosteller">Mosteller (Recomendada)</option>
                    <option value="DuBois">DuBois</option>
                </select>
            </div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Peso (${units.weight})
                </label>
                <input type="number" id="weightBSA" required step="any" min="30" max="300" class="form-input">
            </div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Altura (${units.height})
                </label>
                <input type="number" id="heightBSA" required step="any" class="form-input">
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular BSA
            </button>
        </form>
        <div id="bsaResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateBSA(event) {
    event.preventDefault();
    const formula = document.getElementById('bsaFormula').value;
    const inputs = {
        weight: parseFloat(document.getElementById('weightBSA').value),
        height: parseFloat(document.getElementById('heightBSA').value)
    };
    const result = Calculators.calculateBSA(inputs, formula);
    displayGenericResult(result, inputs, 7, 'BSA', formula, 'bsaResult');
    Storage.addToHistory({ calculatorId: 7, calculatorName: 'BSA', formula, inputs, result, interpretation: result.interpretation });
}

// === 8. OSMOLARIDAD === //
function createOsmolarityForm() {
    const units = Storage.getSettings().units;
    return `
        <form id="osmolarityForm" onsubmit="calculateOsmolarity(event)">
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Sodio (mEq/L)
                </label>
                <input type="number" id="sodiumOsm" required step="any" class="form-input">
            </div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Glucosa (${units.glucose})
                </label>
                <input type="number" id="glucoseOsm" required step="any" class="form-input">
            </div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    BUN (${units.bun})
                </label>
                <input type="number" id="bunOsm" required step="any" class="form-input">
            </div>
            <div class="form-group" style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">
                    Osmolaridad medida (opcional) - mOsm/kg
                </label>
                <input type="number" id="measuredOsm" step="any" class="form-input" placeholder="Dejar vacío si no se midió">
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular Osmolaridad
            </button>
        </form>
        <div id="osmolarityResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateOsmolarity(event) {
    event.preventDefault();
    const measuredInput = document.getElementById('measuredOsm').value;
    const inputs = {
        sodium: parseFloat(document.getElementById('sodiumOsm').value),
        glucose: parseFloat(document.getElementById('glucoseOsm').value),
        bun: parseFloat(document.getElementById('bunOsm').value),
        measuredOsm: measuredInput ? parseFloat(measuredInput) : null
    };
    const result = Calculators.calculateOsmolarity(inputs);
    
    const container = document.getElementById('osmolarityResult');
    container.innerHTML = `
        <div class="result-card" style="background: linear-gradient(135deg, var(--brand-accent-dark), var(--brand-accent)); padding: 24px; border-radius: var(--radius-lg); color: var(--brand-primary-dark); margin-bottom: 16px;">
            <div style="font-size: 13px; font-weight: 600; margin-bottom: 8px; opacity: 0.8;">OSMOLARIDAD CALCULADA</div>
            <div style="font-size: 36px; font-weight: 800; margin-bottom: 4px;">
                ${result.value} <span style="font-size: 20px; font-weight: 600;">${result.unit}</span>
            </div>
            <div style="font-size: 14px; font-weight: 600; margin-bottom: 12px;">
                ${result.interpretation.label}
            </div>
            ${result.osmGap !== null ? `
                <div style="background: rgba(30, 56, 114, 0.15); padding: 12px; border-radius: 8px; font-size: 13px;">
                    <strong>Gap Osmolar:</strong> ${result.osmGap} mOsm/kg
                    ${Math.abs(result.osmGap) > 10 ? '<br><span style="color: #dc2626;">⚠️ Gap >10: considerar tóxicos (metanol, etilenglicol)</span>' : ''}
                </div>
            ` : ''}
        </div>
        <div class="interpretation-card" style="background: var(--bg-secondary); padding: 20px; border-radius: var(--radius-lg); border-left: 4px solid var(--${result.interpretation.color});">
            <h4 style="font-size: 14px; font-weight: 700; margin-bottom: 8px;">Interpretación</h4>
            <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.6;">
                ${result.interpretation.description}
            </p>
        </div>
        <button class="btn btn-secondary" onclick="document.getElementById('osmolarityForm').reset(); document.getElementById('osmolarityResult').style.display='none';" style="width: 100%; margin-top: 16px;">
            🔄 Nuevo Cálculo
        </button>
    `;
    container.style.display = 'block';
    Storage.addToHistory({ calculatorId: 8, calculatorName: 'Osmolaridad', inputs, result, interpretation: result.interpretation });
}

// === 9. CHADS2-VASc === //
function createCHADSVAScForm() {
    return `
        <form id="chadsVascForm" onsubmit="calculateCHADSVASc(event)">
            <div style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">Edad (años)</label>
                <input type="number" id="ageCHADS" required min="18" max="120" class="form-input">
            </div>
            <div style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">Sexo</label>
                <select id="sexCHADS" required class="form-input">
                    <option value="M">Masculino</option>
                    <option value="F">Femenino</option>
                </select>
            </div>
            <div style="background: var(--bg-secondary); padding: 16px; border-radius: 12px; margin-bottom: 16px;">
                <p style="font-size: 13px; font-weight: 600; margin-bottom: 12px;">Seleccione factores de riesgo:</p>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="chf" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Insuficiencia Cardíaca (CHF)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="hypertension" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Hipertensión</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="diabetes" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Diabetes</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="stroke" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">ACV/AIT/Embolia previos</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                    <input type="checkbox" id="vascularDisease" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Enfermedad Vascular</span>
                </label>
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular CHADS₂-VASc
            </button>
        </form>
        <div id="chadsVascResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateCHADSVASc(event) {
    event.preventDefault();
    const inputs = {
        age: parseInt(document.getElementById('ageCHADS').value),
        sex: document.getElementById('sexCHADS').value,
        chf: document.getElementById('chf').checked,
        hypertension: document.getElementById('hypertension').checked,
        diabetes: document.getElementById('diabetes').checked,
        stroke: document.getElementById('stroke').checked,
        vascularDisease: document.getElementById('vascularDisease').checked
    };
    const result = Calculators.calculateCHADSVASc(inputs);
    displayGenericResult(result, inputs, 9, 'CHADS₂-VASc', null, 'chadsVascResult');
    Storage.addToHistory({ calculatorId: 9, calculatorName: 'CHADS₂-VASc', inputs, result, interpretation: result.interpretation });
}

// === 10. HAS-BLED === //
function createHASBLEDForm() {
    return `
        <form id="hasBledForm" onsubmit="calculateHASBLED(event)">
            <div style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px;">Edad (años)</label>
                <input type="number" id="ageHAS" required min="18" max="120" class="form-input">
            </div>
            <div style="background: var(--bg-secondary); padding: 16px; border-radius: 12px; margin-bottom: 16px;">
                <p style="font-size: 13px; font-weight: 600; margin-bottom: 12px;">Seleccione factores de riesgo:</p>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="hypertensionHAS" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Hipertensión no controlada (>160 mmHg)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="abnormalRenal" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Función renal anormal (diálisis, Cr >2.3)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="abnormalLiver" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Función hepática anormal</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="strokeHAS" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">ACV previo</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="bleeding" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Historia de sangrado</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="labileINR" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">INR lábil (si usa warfarina)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; cursor: pointer;">
                    <input type="checkbox" id="drugs" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Medicación predisponente (AINEs, antiplaquetarios)</span>
                </label>
                <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                    <input type="checkbox" id="alcohol" style="width: 18px; height: 18px;">
                    <span style="font-size: 14px;">Abuso de alcohol (≥8 bebidas/semana)</span>
                </label>
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px;">
                🧮 Calcular HAS-BLED
            </button>
        </form>
        <div id="hasBledResult" style="display: none; margin-top: 24px;"></div>
    `;
}

function calculateHASBLED(event) {
    event.preventDefault();
    const inputs = {
        age: parseInt(document.getElementById('ageHAS').value),
        hypertension: document.getElementById('hypertensionHAS').checked,
        abnormalRenal: document.getElementById('abnormalRenal').checked,
        abnormalLiver: document.getElementById('abnormalLiver').checked,
        stroke: document.getElementById('strokeHAS').checked,
        bleeding: document.getElementById('bleeding').checked,
        labileINR: document.getElementById('labileINR').checked,
        drugs: document.getElementById('drugs').checked,
        alcohol: document.getElementById('alcohol').checked
    };
    const result = Calculators.calculateHASBLED(inputs);
    displayGenericResult(result, inputs, 10, 'HAS-BLED', null, 'hasBledResult');
    Storage.addToHistory({ calculatorId: 10, calculatorName: 'HAS-BLED', inputs, result, interpretation: result.interpretation });
}

// === FUNCIÓN GENÉRICA PARA MOSTRAR RESULTADOS === //
function displayGenericResult(result, inputs, calcId, calcName, formula, containerId) {
    const container = document.getElementById(containerId);
    container.innerHTML = `
        <div class="result-card" style="background: linear-gradient(135deg, var(--brand-accent-dark), var(--brand-accent)); padding: 24px; border-radius: var(--radius-lg); color: var(--brand-primary-dark); margin-bottom: 16px;">
            <div style="font-size: 13px; font-weight: 600; margin-bottom: 8px; opacity: 0.8;">RESULTADO</div>
            <div style="font-size: 36px; font-weight: 800; margin-bottom: 4px;">
                ${result.value} <span style="font-size: 20px; font-weight: 600;">${result.unit}</span>
            </div>
            <div style="font-size: 14px; font-weight: 600;">
                ${result.interpretation.label}
            </div>
            ${formula ? `<div style="font-size: 12px; margin-top: 8px; opacity: 0.8;">Fórmula: ${formula}</div>` : ''}
        </div>
        <div class="interpretation-card" style="background: var(--bg-secondary); padding: 20px; border-radius: var(--radius-lg); border-left: 4px solid var(--${result.interpretation.color});">
            <h4 style="font-size: 14px; font-weight: 700; margin-bottom: 8px;">Interpretación</h4>
            <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.6;">
                ${result.interpretation.description}
            </p>
        </div>
        <button class="btn btn-secondary" onclick="resetCalculator('${containerId}')" style="width: 100%; margin-top: 16px;">
            🔄 Nuevo Cálculo
        </button>
    `;
    container.style.display = 'block';
}

function resetCalculator(containerId) {
    const formId = containerId.replace('Result', 'Form');
    document.getElementById(formId).reset();
    document.getElementById(containerId).style.display = 'none';
}

// === REORDER MODAL === //
function showReorderModal() {
    const mainScreen = Storage.getMainScreen();

    const overlay = document.createElement('div');
    overlay.className = 'reorder-modal-overlay';
    overlay.innerHTML = `
        <div class="reorder-modal">
            <div class="reorder-modal-header">
                <h3>Reordenar calculadoras</h3>
                <button class="btn btn-primary" id="reorderDoneBtn" style="padding:8px 20px;font-size:14px;">Listo</button>
            </div>
            <p class="reorder-hint">Arrastra ⠿ para cambiar el orden</p>
            <div id="reorderList">
                ${mainScreen.map(calcId => {
                    const calc = CALCULATORS_CONFIG.find(c => c.id === calcId);
                    if (!calc) return '';
                    return `<div class="reorder-list-item" data-calc-id="${calcId}">
                        <span class="reorder-handle">⠿</span>
                        <span class="reorder-icon">${calc.icon}</span>
                        <span class="reorder-name">${calc.name}</span>
                    </div>`;
                }).join('')}
            </div>
        </div>
    `;

    document.body.appendChild(overlay);

    document.getElementById('reorderDoneBtn').addEventListener('click', () => {
        const newOrder = [...document.getElementById('reorderList')
            .querySelectorAll('.reorder-list-item[data-calc-id]')]
            .map(el => parseInt(el.dataset.calcId))
            .filter(id => !isNaN(id));
        Storage.reorderMainScreen(newOrder);
        overlay.remove();
    });

    overlay.addEventListener('click', e => {
        if (e.target === overlay) overlay.remove();
    });

    initReorderDrag(document.getElementById('reorderList'));
}

function initReorderDrag(list) {
    const SCROLL_ZONE = 64;
    const SCROLL_MAX_SPEED = 14;
    const scrollEl = list.closest('.reorder-modal');

    let dragging = false;
    let dragItem = null;
    let ghost = null;
    let placeholder = null;
    let lastCx = 0, lastCy = 0;
    let scrollRAF = null;

    const updatePlaceholder = (cx, cy) => {
        ghost.style.visibility = 'hidden';
        const target = document.elementFromPoint(cx, cy)?.closest('.reorder-list-item');
        ghost.style.visibility = '';
        if (target && target !== dragItem && list.contains(target)) {
            const tr = target.getBoundingClientRect();
            if (cy < tr.top + tr.height / 2) {
                list.insertBefore(placeholder, target);
            } else {
                target.after(placeholder);
            }
        }
    };

    const autoScroll = () => {
        if (!dragging || !scrollEl) return;
        const sr = scrollEl.getBoundingClientRect();
        const distTop    = lastCy - sr.top;
        const distBottom = sr.bottom - lastCy;
        let speed = 0;

        if (distTop < SCROLL_ZONE && distTop > 0) {
            speed = -SCROLL_MAX_SPEED * (1 - distTop / SCROLL_ZONE);
        } else if (distBottom < SCROLL_ZONE && distBottom > 0) {
            speed = SCROLL_MAX_SPEED * (1 - distBottom / SCROLL_ZONE);
        }

        if (speed !== 0) {
            scrollEl.scrollTop += speed;
            updatePlaceholder(lastCx, lastCy);
            scrollRAF = requestAnimationFrame(autoScroll);
        } else {
            scrollRAF = null;
        }
    };

    list.querySelectorAll('.reorder-handle').forEach(handle => {
        handle.addEventListener('pointerdown', e => {
            e.preventDefault();
            const item = handle.closest('.reorder-list-item');
            if (!item) return;

            dragging = true;
            dragItem = item;
            const rect = item.getBoundingClientRect();
            const offY = e.clientY - rect.top;
            lastCx = e.clientX; lastCy = e.clientY;

            ghost = item.cloneNode(true);
            ghost.className = 'reorder-list-item reorder-item-ghost';
            ghost.style.width  = rect.width  + 'px';
            ghost.style.height = rect.height + 'px';
            ghost.style.left   = rect.left   + 'px';
            ghost.style.top    = rect.top    + 'px';
            document.body.appendChild(ghost);

            placeholder = document.createElement('div');
            placeholder.className = 'reorder-item-placeholder';
            placeholder.style.height = rect.height + 'px';
            list.insertBefore(placeholder, item);
            item.style.visibility = 'hidden';

            if (navigator.vibrate) navigator.vibrate(20);

            const onMove = e => {
                if (!dragging) return;
                e.preventDefault();
                lastCx = e.clientX; lastCy = e.clientY;
                ghost.style.top = (lastCy - offY) + 'px';
                updatePlaceholder(lastCx, lastCy);
                if (!scrollRAF) scrollRAF = requestAnimationFrame(autoScroll);
            };

            const onUp = () => {
                if (!dragging) return;
                dragging = false;
                if (scrollRAF) { cancelAnimationFrame(scrollRAF); scrollRAF = null; }
                if (placeholder?.parentNode === list) {
                    list.insertBefore(dragItem, placeholder);
                }
                dragItem.style.visibility = '';
                placeholder?.remove();
                ghost?.remove();
                dragItem = null; ghost = null; placeholder = null;
                document.removeEventListener('pointermove', onMove);
                document.removeEventListener('pointerup', onUp);
                document.removeEventListener('pointercancel', onUp);
            };

            document.addEventListener('pointermove', onMove, { passive: false });
            document.addEventListener('pointerup', onUp);
            document.addEventListener('pointercancel', onUp);
        });
    });
}
